//! rumkin.com's Morse, Text Manipulator and Substitution.
//!
//! # Morse: the site's own table, including its oddities
//!
//! The table is transcribed from `morse.php`'s `MorseIndexes`/`MorseCodes` arrays
//! rather than from a standard reference, because the site's differs:
//!
//! * `!` appears **twice**, with two different codes (`-.-.--` and `.-.-.`). Lookup
//!   is first-match, so encoding `!` always yields the first; the second is reachable
//!   only when decoding.
//! * Several prosigns (`[Wait]`, `[Understood]`, …) share codes with punctuation, so
//!   decoding is genuinely ambiguous and resolves to whichever entry comes first.
//! * Word separation is ` / ` and letter separation a single space; newlines survive.
//!
//! # Manipulator: eight operations, applied in the order given
//!
//! `reverse`, `group`, `remove_spaces`, `remove_crlf`, `upper`, `lower`,
//! `first_letter`, `natural`. `group` strips whitespace first, then emits groups of
//! `group_size` separated by spaces with a newline every `group_count` groups —
//! which is why grouping is not reversible.
//!
//! `natural` capitalises after `.?!` only; `first_letter` capitalises after any
//! whitespace. Both lowercase the whole text first, so neither preserves existing
//! capitals.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: transforms at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

use super::rumkin_shift::make_keyed_alphabet;

const MORSE: &str = "rumkin_morse";
const MANIP: &str = "rumkin_manipulate";
const SUBST: &str = "rumkin_substitution";

/// `morse.php`'s table, in its own order. First match wins on lookup.
const MORSE_TABLE: &[(&str, &str)] = &[
    ("A", ".-"), ("B", "-..."), ("C", "-.-."), ("D", "-.."), ("E", "."),
    ("F", "..-."), ("G", "--."), ("H", "...."), ("I", ".."), ("J", ".---"),
    ("K", "-.-"), ("L", ".-.."), ("M", "--"), ("N", "-."), ("O", "---"),
    ("P", ".--."), ("Q", "--.-"), ("R", ".-."), ("S", "..."), ("T", "-"),
    ("U", "..-"), ("V", "...-"), ("W", ".--"), ("X", "-..-"), ("Y", "-.--"),
    ("Z", "--.."), ("0", "-----"), ("1", ".----"), ("2", "..---"), ("3", "...--"),
    ("4", "....-"), ("5", "....."), ("6", "-...."), ("7", "--..."), ("8", "---.."),
    ("9", "----."), (".", ".-.-.-"), (",", "--..--"), ("?", "..--.."), ("-", "-....-"),
    ("=", "-...-"), (":", "---..."), (";", "-.-.-."), ("(", "-.--."), (")", "-.--.-"),
    ("/", "-..-."), ("\"", ".-..-."), ("$", "...-..-"), ("'", ".----."),
    ("\n", ".-.-.."), ("_", "..--.-"), ("@", ".--.-."),
    ("!", "-.-.--"), ("+", ".-.-."), ("~", ".-..."), ("#", "...-.-"), ("&", ". ..."),
];

fn dir(node: &'static str, params: &Params) -> Result<bool> {
    match params.opt_str("direction").unwrap_or("decrypt") {
        "encrypt" => Ok(true),
        "decrypt" => Ok(false),
        o => Err(Error::bad_param(node, "direction", format!("got {o:?}"))),
    }
}

const MORSE_SCHEMA: &[ParamSpec] = &[ParamSpec::opt(
    "direction",
    ParamType::Str,
    "\"decrypt\" (default: morse -> text) or \"encrypt\"",
)];

/// The site's Morse tool.
pub struct RumkinMorse;

impl Node for RumkinMorse {
    fn name(&self) -> &'static str { MORSE }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_text(morse.php)" }
    fn params_schema(&self) -> &'static [ParamSpec] { MORSE_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let s = String::from_utf8_lossy(&input.data).to_string();
        let mut out = String::new();
        if dir(MORSE, params)? {
            let mut add_space = false;
            for ch in s.chars() {
                let up = ch.to_ascii_uppercase().to_string();
                match MORSE_TABLE.iter().find(|(k, _)| *k == up) {
                    Some((_, code)) => {
                        if add_space { out.push(' '); }
                        out.push_str(code);
                        add_space = true;
                    }
                    None => {
                        if ch == '\n' || ch == '\r' {
                            out.push(ch);
                        } else if add_space {
                            out.push_str(" / ");
                        }
                        add_space = false;
                    }
                }
            }
        } else {
            for word in s.split('/') {
                for tok in word.split_whitespace() {
                    if let Some((k, _)) = MORSE_TABLE.iter().find(|(_, c)| *c == tok) {
                        out.push_str(k);
                    }
                }
                out.push(' ');
            }
            let t = out.trim_end().to_string();
            out = t;
        }
        if out.is_empty() {
            return Err(Error::node_failed(MORSE, "nothing recognised in the input"));
        }
        Ok(Repr::new(out.into_bytes(), Display::Bytes))
    }
}

const MANIP_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req(
        "ops",
        ParamType::Str,
        "comma-separated operations applied left to right: reverse, group, \
         remove_spaces, remove_crlf, upper, lower, first_letter, natural",
    ),
    ParamSpec::opt("group_size", ParamType::Int, "letters per group (default 5)"),
    ParamSpec::opt("group_count", ParamType::Int, "groups per line (default 10)"),
];

/// The site's Text Manipulator.
pub struct RumkinManipulate;

impl Node for RumkinManipulate {
    fn name(&self) -> &'static str { MANIP }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_text(manipulate.php)" }
    fn params_schema(&self) -> &'static [ParamSpec] { MANIP_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let size = params.opt_i64("group_size", 5);
        let count = params.opt_i64("group_count", 10);
        if size < 1 || count < 1 {
            return Err(Error::bad_param(MANIP, "group_size", "sizes must be >= 1"));
        }
        let mut t = String::from_utf8_lossy(&input.data).to_string();
        for op in params.req_str(MANIP, "ops")?.split(',').map(|x| x.trim()) {
            t = match op {
                "" => continue,
                // the site drops \r while reversing
                "reverse" => t.chars().rev().filter(|&c| c != '\r').collect(),
                "remove_spaces" => t.chars().filter(|&c| c != ' ' && c != '\t').collect(),
                "remove_crlf" => t.chars().filter(|&c| c != '\r' && c != '\n').collect(),
                "upper" => t.to_uppercase(),
                "lower" => t.to_lowercase(),
                "first_letter" => {
                    let mut out = String::new();
                    let mut ws = true;
                    for c in t.to_lowercase().chars() {
                        if c == ' ' || c == '\r' || c == '\n' {
                            ws = true;
                            out.push(c);
                        } else {
                            out.push(if ws { c.to_ascii_uppercase() } else { c });
                            ws = false;
                        }
                    }
                    out
                }
                "natural" => {
                    let mut out = String::new();
                    let mut punct = true;
                    for c in t.to_lowercase().chars() {
                        if ".?!".contains(c) {
                            punct = true;
                            out.push(c);
                        } else if punct && c.is_ascii_lowercase() {
                            out.push(c.to_ascii_uppercase());
                            punct = false;
                        } else {
                            out.push(c);
                        }
                    }
                    out
                }
                "group" => {
                    let stripped: String = t
                        .chars()
                        .filter(|c| !matches!(c, ' ' | '\r' | '\n' | '\t'))
                        .collect();
                    let mut out = String::new();
                    let mut groups = 0i64;
                    let chars: Vec<char> = stripped.chars().collect();
                    let mut i = 0usize;
                    while i < chars.len() {
                        if !out.is_empty() { out.push(' '); }
                        if groups >= count {
                            out.push('\n');
                            groups = 0;
                        }
                        groups += 1;
                        let end = (i + size as usize).min(chars.len());
                        out.extend(&chars[i..end]);
                        i = end;
                    }
                    out
                }
                other => {
                    return Err(Error::bad_param(
                        MANIP, "ops",
                        format!("unknown operation {other:?}"),
                    ))
                }
            };
        }
        Ok(Repr::new(t.into_bytes(), Display::Bytes))
    }
}

const SUBST_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "keyword building the cipher alphabet"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// The site's Substitution tool: a keyed-alphabet monoalphabetic substitution.
///
/// Uses the same `MakeKeyedAlphabet` as the rest of the site, so a key here means
/// exactly what it means in Keyed Caesar or Keyed Vigenère.
pub struct RumkinSubstitution;

impl Node for RumkinSubstitution {
    fn name(&self) -> &'static str { SUBST }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_text(substitution.php)" }
    fn params_schema(&self) -> &'static [ParamSpec] { SUBST_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        const AZ: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        let key = make_keyed_alphabet(Some(params.req_str(SUBST, "key")?), AZ);
        let enc = dir(SUBST, params)?;
        let out: Vec<u8> = input
            .data
            .iter()
            .map(|&c| {
                let up = c.to_ascii_uppercase();
                if !up.is_ascii_uppercase() {
                    return c;
                }
                let r = if enc {
                    key[(up - b'A') as usize]
                } else {
                    b'A' + key.iter().position(|&x| x == up).unwrap_or(0) as u8
                };
                if c.is_ascii_lowercase() { r.to_ascii_lowercase() } else { r }
            })
            .collect();
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(RUMKIN_MORSE => || Box::new(RumkinMorse));
register_node!(RUMKIN_MANIPULATE => || Box::new(RumkinManipulate));
register_node!(RUMKIN_SUBSTITUTION => || Box::new(RumkinSubstitution));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn n(name: &str) -> &'static dyn Node { registry().get(name).unwrap() }

    #[test]
    fn all_are_xf() {
        for x in [MORSE, MANIP, SUBST] { assert_eq!(n(x).family(), Family::Xf); }
    }

    #[test]
    fn morse_round_trips_with_word_separators() {
        let e = n(MORSE)
            .apply(&Repr::bytes(b"SOS HELP".to_vec()), &params! {"direction" => "encrypt"})
            .unwrap();
        assert_eq!(e.data, b"... --- ... / .... . .-.. .--.");
        let d = n(MORSE).apply(&e, &Params::new()).unwrap();
        assert_eq!(d.data, b"SOS HELP");
    }

    /// The site's table lists `!` twice with different codes; encoding must use the
    /// first, which is the documented first-match behaviour.
    #[test]
    fn morse_duplicate_bang_uses_the_first_entry() {
        let e = n(MORSE)
            .apply(&Repr::bytes(b"!".to_vec()), &params! {"direction" => "encrypt"})
            .unwrap();
        assert_eq!(e.data, b"-.-.--");
    }

    #[test]
    fn manipulate_applies_ops_in_order() {
        let out = n(MANIP)
            .apply(&Repr::bytes(b"hello world".to_vec()), &params! {"ops" => "upper,remove_spaces"})
            .unwrap();
        assert_eq!(out.data, b"HELLOWORLD");
        // order matters
        let rev = n(MANIP)
            .apply(&Repr::bytes(b"ab cd".to_vec()), &params! {"ops" => "remove_spaces,reverse"})
            .unwrap();
        assert_eq!(rev.data, b"dcba");
    }

    #[test]
    fn manipulate_group_strips_whitespace_and_breaks_lines() {
        let out = n(MANIP)
            .apply(
                &Repr::bytes(b"ABCDEFGHIJKLMNOPQRSTUVWXYZ".to_vec()),
                &params! {"ops" => "group", "group_size" => 5i64, "group_count" => 3i64},
            )
            .unwrap();
        let s = String::from_utf8(out.data).unwrap();
        assert!(s.starts_with("ABCDE FGHIJ KLMNO"), "{s}");
        assert!(s.contains('\n'), "a newline every group_count groups: {s}");
    }

    /// `natural` capitalises only after .?! ; `first_letter` after any whitespace.
    #[test]
    fn natural_and_first_letter_differ() {
        let nat = n(MANIP)
            .apply(&Repr::bytes(b"one two. three four".to_vec()), &params! {"ops" => "natural"})
            .unwrap();
        assert_eq!(nat.data, b"One two. Three four");
        let fl = n(MANIP)
            .apply(&Repr::bytes(b"one two. three four".to_vec()), &params! {"ops" => "first_letter"})
            .unwrap();
        assert_eq!(fl.data, b"One Two. Three Four");
    }

    #[test]
    fn unknown_op_is_rejected() {
        assert!(n(MANIP)
            .apply(&Repr::bytes(b"abc".to_vec()), &params! {"ops" => "sideways"})
            .is_err());
    }

    #[test]
    fn substitution_round_trips_and_keeps_case() {
        let p = params! {"key" => "ZOMBIES"};
        let e = n(SUBST)
            .apply(&Repr::bytes(b"Attack at dawn!".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(n(SUBST).apply(&e, &p).unwrap().data, b"Attack at dawn!");
        assert_ne!(e.data, b"Attack at dawn!");
    }
}
