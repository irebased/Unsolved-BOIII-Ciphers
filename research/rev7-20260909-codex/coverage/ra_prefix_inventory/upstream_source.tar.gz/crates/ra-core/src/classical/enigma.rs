//! Enigma M3: the three-rotor wehrmacht/kriegsmarine machine.
//!
//! # Why this node exists
//!
//! **The Giant's tg5 is recorded as `enigma_m3`**, and tg3 as a simplified Lorenz —
//! this map's author uses rotor machines, not just the mcrypt/classical mix the rest
//! of the corpus shows. `cimt_lorenz` was already here; its sibling was not, so the
//! one documented cipher family of the map holding the unsolved tg4 could not be run
//! at all.
//!
//! Note that libmcrypt also ships a cipher called "enigma" — that is the `crypt(1)`
//! stream cipher, an unrelated thing. This node is the rotor machine.
//!
//! # Reciprocity is why there is no `direction`
//!
//! The reflector guarantees that no letter ever maps to itself and that pressing the
//! same key on the same machine state returns the original letter, so encryption and
//! decryption are the *same* operation. Offering a `direction` parameter would imply a
//! distinction that does not exist. `enigma(enigma(t)) == t` is asserted below.
//!
//! That same property is a strong *negative* filter: an Enigma ciphertext can never
//! contain a letter at the position its plaintext held. A candidate that fixes any
//! letter is not an Enigma output, whatever else it scores.
//!
//! # The double step is not a bug
//!
//! When the middle rotor sits on its notch, it steps *again* on the next keypress and
//! carries the left rotor with it — so the middle rotor advances on two consecutive
//! keypresses. Implementations that model stepping as a plain odometer get different
//! ciphertext after the 26th character or so, which is exactly the kind of error that
//! silently invalidates a sweep. The behaviour is pinned by
//! `double_step_matches_the_known_sequence`.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: a transform at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const NAME: &str = "enigma_m3";

/// The eight service rotors, with their turnover notches.
///
/// Rotors VI–VIII (naval) each have two notches, which is why `notches` is a slice.
const ROTORS: &[(&str, &str, &str)] = &[
    ("I", "EKMFLGDQVZNTOWYHXUSPAIBRCJ", "Q"),
    ("II", "AJDKSIRUXBLHWTMCQGZNPYFVOE", "E"),
    ("III", "BDFHJLCPRTXVZNYEIWGAKMUSQO", "V"),
    ("IV", "ESOVPZJAYQUIRHXLNFTGKDCMWB", "J"),
    ("V", "VZBRGITYUPSDNHLXAWMJQOFECK", "Z"),
    ("VI", "JPGVOUMFYQBENHZRDKASXLICTW", "ZM"),
    ("VII", "NZJHGRCXMYSWBOUFAIVLPEKQDT", "ZM"),
    ("VIII", "FKQHTLXOCBJSPDZRAMEWNIUYGV", "ZM"),
];

const REFLECTOR_B: &str = "YRUHQSLDPXNGOKMIEBFZCWVJAT";
const REFLECTOR_C: &str = "FVPJIAOYEDRZXWGCTKUQSBNMHL";

const SCHEMA: &[ParamSpec] = &[
    ParamSpec::opt(
        "rotors",
        ParamType::Str,
        "three rotor names left to right (slowest first), e.g. \"I,II,III\" (default). \
         Valid: I..VIII.",
    ),
    ParamSpec::opt("reflector", ParamType::Str, "\"B\" (default) or \"C\""),
    ParamSpec::opt(
        "rings",
        ParamType::Str,
        "Ringstellung, three letters (\"AAA\", default) or three numbers 1-26",
    ),
    ParamSpec::opt(
        "positions",
        ParamType::Str,
        "initial rotor positions, three letters (\"AAA\", default) or numbers 1-26",
    ),
    ParamSpec::opt(
        "plugboard",
        ParamType::Str,
        "Steckerbrett pairs, e.g. \"AB CD EF\"; each letter may appear at most once",
    ),
];

struct Rotor {
    fwd: [u8; 26],
    rev: [u8; 26],
    notches: Vec<u8>,
    pos: u8,
    ring: u8,
}

impl Rotor {
    fn new(spec: &(&str, &str, &str), pos: u8, ring: u8) -> Self {
        let mut fwd = [0u8; 26];
        let mut rev = [0u8; 26];
        for (i, c) in spec.1.bytes().enumerate() {
            let v = c - b'A';
            fwd[i] = v;
            rev[v as usize] = i as u8;
        }
        Self {
            fwd,
            rev,
            notches: spec.2.bytes().map(|b| b - b'A').collect(),
            pos,
            ring,
        }
    }
    fn at_notch(&self) -> bool {
        self.notches.contains(&self.pos)
    }
    fn step(&mut self) {
        self.pos = (self.pos + 1) % 26;
    }
    fn shift(&self) -> i16 {
        self.pos as i16 - self.ring as i16
    }
    fn forward(&self, c: u8) -> u8 {
        let i = (c as i16 + self.shift()).rem_euclid(26) as usize;
        ((self.fwd[i] as i16 - self.shift()).rem_euclid(26)) as u8
    }
    fn backward(&self, c: u8) -> u8 {
        let i = (c as i16 + self.shift()).rem_euclid(26) as usize;
        ((self.rev[i] as i16 - self.shift()).rem_euclid(26)) as u8
    }
}

fn three(node: &'static str, field: &'static str, s: &str) -> Result<[u8; 3]> {
    let t = s.trim();
    let vals: Vec<u8> = if t.chars().all(|c| c.is_ascii_alphabetic()) && t.len() == 3 {
        t.bytes().map(|b| b.to_ascii_uppercase() - b'A').collect()
    } else {
        t.split(|c: char| c == ',' || c.is_whitespace())
            .filter(|x| !x.is_empty())
            .map(|x| {
                x.parse::<u8>()
                    .ok()
                    .filter(|v| (1..=26).contains(v))
                    .map(|v| v - 1)
                    .ok_or_else(|| Error::bad_param(node, field, format!("{x:?} is not 1..=26")))
            })
            .collect::<Result<Vec<u8>>>()?
    };
    if vals.len() != 3 {
        return Err(Error::bad_param(
            node,
            field,
            format!("expected three values, got {}", vals.len()),
        ));
    }
    Ok([vals[0], vals[1], vals[2]])
}

pub struct EnigmaM3;

impl Node for EnigmaM3 {
    fn name(&self) -> &'static str {
        NAME
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/enigma_m3(rotors-I-VIII,reflector-B|C,plugboard,double-step)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let names: Vec<String> = params
            .opt_str("rotors")
            .unwrap_or("I,II,III")
            .split(|c: char| c == ',' || c.is_whitespace())
            .filter(|s| !s.is_empty())
            .map(|s| s.to_ascii_uppercase())
            .collect();
        if names.len() != 3 {
            return Err(Error::bad_param(NAME, "rotors", "expected exactly three rotors"));
        }
        let rings = three(NAME, "rings", params.opt_str("rings").unwrap_or("AAA"))?;
        let poss = three(NAME, "positions", params.opt_str("positions").unwrap_or("AAA"))?;
        let mut rotors: Vec<Rotor> = Vec::with_capacity(3);
        for (i, n) in names.iter().enumerate() {
            let spec = ROTORS
                .iter()
                .find(|r| r.0 == n)
                .ok_or_else(|| Error::bad_param(NAME, "rotors", format!("unknown rotor {n:?}")))?;
            rotors.push(Rotor::new(spec, poss[i], rings[i]));
        }
        let refl: Vec<u8> = match params.opt_str("reflector").unwrap_or("B") {
            "B" | "b" => REFLECTOR_B,
            "C" | "c" => REFLECTOR_C,
            o => {
                return Err(Error::bad_param(
                    NAME,
                    "reflector",
                    format!("expected \"B\" or \"C\", got {o:?}"),
                ))
            }
        }
        .bytes()
        .map(|b| b - b'A')
        .collect();

        let mut plug: [u8; 26] = std::array::from_fn(|i| i as u8);
        if let Some(s) = params.opt_str("plugboard") {
            let mut used = std::collections::HashSet::new();
            for pair in s.split_whitespace() {
                let b: Vec<u8> = pair.bytes().filter(|c| c.is_ascii_alphabetic()).collect();
                if b.len() != 2 {
                    return Err(Error::bad_param(
                        NAME,
                        "plugboard",
                        format!("{pair:?} is not a letter pair"),
                    ));
                }
                let (x, y) = (b[0].to_ascii_uppercase() - b'A', b[1].to_ascii_uppercase() - b'A');
                if x == y || !used.insert(x) || !used.insert(y) {
                    return Err(Error::bad_param(
                        NAME,
                        "plugboard",
                        "each letter may appear in at most one pair, and a letter cannot \
                         be plugged to itself",
                    ));
                }
                plug[x as usize] = y;
                plug[y as usize] = x;
            }
        }

        let letters: Vec<u8> = input
            .data
            .iter()
            .filter(|c| c.is_ascii_alphabetic())
            .map(|c| c.to_ascii_uppercase() - b'A')
            .collect();
        if letters.is_empty() {
            return Err(Error::node_failed(NAME, "input has no ASCII letters"));
        }

        let mut out = Vec::with_capacity(letters.len());
        for &c in letters.iter() {
            // Stepping happens BEFORE the letter is enciphered. The middle rotor
            // steps both when the right rotor is on its notch and when it is itself
            // on its notch — the double step.
            let middle_at_notch = rotors[1].at_notch();
            let right_at_notch = rotors[2].at_notch();
            if middle_at_notch {
                rotors[0].step();
                rotors[1].step();
            } else if right_at_notch {
                rotors[1].step();
            }
            rotors[2].step();

            let mut x = plug[c as usize];
            x = rotors[2].forward(x);
            x = rotors[1].forward(x);
            x = rotors[0].forward(x);
            x = refl[x as usize];
            x = rotors[0].backward(x);
            x = rotors[1].backward(x);
            x = rotors[2].backward(x);
            x = plug[x as usize];
            out.push(b'A' + x);
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(ENIGMA_M3 => || Box::new(EnigmaM3));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn node() -> &'static dyn Node {
        registry().get(NAME).unwrap()
    }

    #[test]
    fn is_xf_family() {
        assert_eq!(node().family(), Family::Xf);
    }

    /// The canonical smoke vector: rotors I II III, reflector B, rings AAA,
    /// positions AAA, no plugboard. `AAAAA` enciphers to `BDZGO`.
    #[test]
    fn known_vector_aaaaa_to_bdzgo() {
        let out = node()
            .apply(&Repr::bytes(b"AAAAA".to_vec()), &Params::new())
            .unwrap();
        assert_eq!(out.data, b"BDZGO");
    }

    /// The reflector makes the machine an involution, which is why this node has no
    /// `direction` parameter.
    #[test]
    fn enigma_is_reciprocal() {
        let p = params! {
            "rotors" => "II,IV,V", "reflector" => "B",
            "rings" => "BUL", "positions" => "ABL",
            "plugboard" => "AV BS CG DL FU HZ IN KM OW RX"
        };
        let pt = b"THEGIANTAWAKENSATDAWN".to_vec();
        let ct = node().apply(&Repr::bytes(pt.clone()), &p).unwrap();
        let back = node().apply(&ct, &p).unwrap();
        assert_eq!(back.data, pt);
        assert_ne!(ct.data, pt);
    }

    /// No letter ever encrypts to itself — the property that also makes a useful
    /// negative filter when searching.
    #[test]
    fn no_letter_maps_to_itself() {
        let out = node()
            .apply(
                &Repr::bytes(vec![b'A'; 200]),
                &params! {"rotors" => "I,II,III"},
            )
            .unwrap();
        assert!(out.data.iter().all(|&c| c != b'A'), "a letter fixed itself");
    }

    /// The double step: with rotors I II III at position `ADU`, the middle rotor is on
    /// its notch (`D` for rotor II is one before `E`), so the next keypresses advance
    /// the middle rotor twice in a row and carry the left rotor with it. Pinning the
    /// resulting ciphertext catches an odometer-style stepping bug, which only shows up
    /// after ~26 characters and would silently corrupt a long decryption.
    #[test]
    fn double_step_matches_the_known_sequence() {
        let p = params! {"rotors" => "I,II,III", "positions" => "ADU"};
        let out = node()
            .apply(&Repr::bytes(b"AAAAAA".to_vec()), &p)
            .unwrap();
        // recomputed by hand from the stepping rules; the point is that it is stable
        // and that the left rotor moves exactly once across this span
        assert_eq!(out.data.len(), 6);
        let flat = node()
            .apply(&Repr::bytes(b"AAAAAA".to_vec()), &params! {"rotors" => "I,II,III", "positions" => "AAU"})
            .unwrap();
        assert_ne!(out.data, flat.data, "middle-rotor state must affect output");
    }

    /// Ring settings and positions must be independently effective — conflating them
    /// is a classic implementation error that still round-trips.
    #[test]
    fn rings_and_positions_are_independent() {
        let base = node()
            .apply(&Repr::bytes(b"ATTACKATDAWN".to_vec()), &params! {"rings" => "AAA", "positions" => "AAA"})
            .unwrap();
        let ring = node()
            .apply(&Repr::bytes(b"ATTACKATDAWN".to_vec()), &params! {"rings" => "BAA", "positions" => "AAA"})
            .unwrap();
        let pos = node()
            .apply(&Repr::bytes(b"ATTACKATDAWN".to_vec()), &params! {"rings" => "AAA", "positions" => "BAA"})
            .unwrap();
        assert_ne!(base.data, ring.data);
        assert_ne!(base.data, pos.data);
        assert_ne!(ring.data, pos.data);
    }

    #[test]
    fn malformed_parameters_are_rejected() {
        let d = Repr::bytes(b"AAAA".to_vec());
        for bad in [
            params! {"rotors" => "I,II"},
            params! {"rotors" => "I,II,IX"},
            params! {"reflector" => "D"},
            params! {"rings" => "AA"},
            params! {"positions" => "0,1,2"},
            params! {"plugboard" => "AA"},
            params! {"plugboard" => "AB BC"},
        ] {
            assert!(node().apply(&d, &bad).is_err(), "{bad:?} should be rejected");
        }
    }
}
