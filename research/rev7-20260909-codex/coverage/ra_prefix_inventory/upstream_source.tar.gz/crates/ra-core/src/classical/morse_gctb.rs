//! Morse code, matching geocachingtoolbox.com's `morse` tool exactly.
//!
//! # Ground truth
//!
//! `docs/toolsites/geocachingtoolbox.json`, tool `"Morse"` (`page_id: "morse"`).
//! The character/morse tables and both directions (`translateMorse`, methods
//! `m2t`/`t2m`) were run verbatim under Node (a DOM shim stands in for
//! `document.getElementById`) to produce every vector in the test module below
//! and to pin down two behaviours the source alone doesn't make obvious:
//!
//! - **Letter spacing is a code-run boundary, not a literal separator.** `m2t`
//!   splits on *any* run of non-`.`/`-` bytes: a run of length 1 (a normal
//!   single space between two letters) is swallowed silently; a run of length 2
//!   or more (a genuine word gap, or a doubled separator anywhere else,
//!   including a leading/trailing one) emits exactly one space in the decoded
//!   text. This is reproduced by literally transliterating the site's
//!   char-by-char scan ([`decode`]) rather than trying to summarise it as a
//!   regex, because the boundary conditions (leading vs. trailing runs) are not
//!   symmetric — see `separator_run_length_rules` below.
//! - **`"END"` and `"SOS"` are reachable outputs, not just inputs.** The site's
//!   table has two multi-letter entries, morse `.-.-.` -> `"END"` and
//!   `...---...` -> `"SOS"`, which land in the decoded text as those literal
//!   three-letter strings when their exact code appears as a token. (The
//!   encode direction can never *produce* them, since `t2m` walks the input one
//!   character at a time and neither multi-char key is reachable that way — see
//!   `end_and_sos_are_decode_only` — but decode must still honour them.)
//!
//! This crate is decrypt-direction: [`MorseGctb`] implements `m2t` only. `t2m`
//! is reproduced test-only (as [`encode`]) purely to generate round-trip
//! ground truth; nothing outside the test module needs it.
//!
//! # Artifacts
//!
//! The tool writes into `morseDiv` via `.innerHTML` (`output_method:
//! "innerHTML"`, `copy_artifact_risk: "HIGH"` in the tool-site record), so a
//! select-all copy risks a trailing CRLF; the HTML result also forces the
//! decoded text lowercase (`case_handling: ["FORCED_LOWERCASE"]`) — reproduced
//! here as `Trailing::CrLf` / `CaseFold::Lower` defaults for [`OutputFmt`],
//! matching [`crate::classical::toolfmt`]'s per-tool-default contract.

use crate::classical::toolfmt::{read_output_fmt, CaseFold, OutputFmt, Trailing};
use crate::error::Result;
use crate::node::{Family, Node, ParamSpec};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const NAME: &str = "morse_gctb";

const SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!();

/// (character-table-string, morse-code) pairs, transcribed verbatim from the
/// site's `char`/`morse` arrays (see the module doc for how they were
/// verified). Multi-byte entries `"END"`/`"SOS"` are legal decode outputs;
/// `" "` -> `" "` is present in the source table but dead in both directions
/// (see `deliberately_omitted_dead_space_entry` in tests) and is not carried
/// here.
const TABLE: &[(&str, &str)] = &[
    ("a", ".-"),
    ("b", "-..."),
    ("c", "-.-."),
    ("d", "-.."),
    ("e", "."),
    ("f", "..-."),
    ("g", "--."),
    ("h", "...."),
    ("i", ".."),
    ("j", ".---"),
    ("k", "-.-"),
    ("l", ".-.."),
    ("m", "--"),
    ("n", "-."),
    ("o", "---"),
    ("p", ".--."),
    ("q", "--.-"),
    ("r", ".-."),
    ("s", "..."),
    ("t", "-"),
    ("u", "..-"),
    ("v", "...-"),
    ("w", ".--"),
    ("x", "-..-"),
    ("y", "-.--"),
    ("z", "--.."),
    ("0", "-----"),
    ("1", ".----"),
    ("2", "..---"),
    ("3", "...--"),
    ("4", "....-"),
    ("5", "....."),
    ("6", "-...."),
    ("7", "--..."),
    ("8", "---.."),
    ("9", "----."),
    (".", ".-.-.-"),
    (",", "--..--"),
    ("?", "..--.."),
    ("-", "-....-"),
    ("/", "-..-."),
    (":", "---..."),
    ("'", ".----."),
    (")", "-.--.-"),
    (";", "-.-.-"),
    ("(", "-.--."),
    ("=", "-...-"),
    ("@", ".--.-."),
    ("END", ".-.-."),
    ("SOS", "...---..."),
];

fn morse_to_char(code: &[u8]) -> Option<&'static str> {
    TABLE
        .iter()
        .find(|(_, m)| m.as_bytes() == code)
        .map(|(c, _)| *c)
}

/// `m2t`: decode Morse to text, transliterating the site's `translateMorse`
/// scan byte-for-byte. Any byte that is not `.` or `-` is a separator; a run
/// of exactly one separator between two code tokens is swallowed, a run of two
/// or more (anywhere, including at either end of the input) emits one space.
/// An unrecognised code token becomes `#`, exactly as the site does.
pub fn decode(input: &[u8]) -> Vec<u8> {
    let mut tokens: Vec<Vec<u8>> = vec![Vec::new()];
    for &b in input {
        if b == b'.' || b == b'-' {
            tokens.last_mut().unwrap().push(b);
        } else {
            tokens.push(Vec::new());
        }
    }

    let n = tokens.len();
    let mut out = Vec::new();
    for (i, tok) in tokens.iter().enumerate() {
        if tok.is_empty() {
            if i != n - 1 && !tokens[i + 1].is_empty() {
                out.push(b' ');
            }
        } else if let Some(ch) = morse_to_char(tok) {
            out.extend_from_slice(ch.as_bytes());
        } else {
            out.push(b'#');
        }
    }
    out
}

/// `t2m`: encode text to Morse, matching the site's `translateMorse` exactly.
/// Test-only (see module doc): the engine only ever needs `decode`.
#[cfg(test)]
fn encode(input: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    for &b in input {
        let lower = (b as char).to_ascii_lowercase();
        if lower == ' ' {
            out.push(b' ');
        } else if let Some((_, code)) = TABLE
            .iter()
            .find(|(c, _)| c.len() == 1 && c.as_bytes()[0] == lower as u8)
        {
            out.extend_from_slice(code.as_bytes());
            out.push(b' ');
        } else {
            out.push(b'#');
            out.push(b' ');
        }
    }
    out
}

pub struct MorseGctb;

impl Node for MorseGctb {
    fn name(&self) -> &'static str {
        NAME
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/morse_gctb(geocachingtoolbox.com morse tool, m2t direction)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let norm = crate::classical::toolfmt::read_input_norm(
            NAME,
            params,
            crate::classical::toolfmt::InputNorm::default(),
        )?;
        let data = norm.apply(&input.data);

        let decoded = decode(&data);

        let fmt = read_output_fmt(
            NAME,
            params,
            OutputFmt {
                case: CaseFold::Preserve, // decode already only emits lowercase/#/digits
                grouping: None,
                trailing: Trailing::CrLf, // .innerHTML select-all copy risk (HIGH)
            },
        )?;
        Ok(Repr::new(fmt.apply(&decoded), Display::Bytes))
    }
}

register_node!(MORSE_GCTB => || Box::new(MorseGctb));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn node() -> &'static dyn Node {
        registry().get(NAME).unwrap()
    }

    /// Ground truth: computed by running the site's own `translateMorse`
    /// (method `t2m`) under Node via a DOM shim (see module doc), stripping
    /// the site's `&nbsp;` HTML separator artifact down to a plain space,
    /// which is what it renders as when the result div's `<br>`/`&nbsp;`
    /// markup is stripped for a plain-text comparison.
    #[test]
    fn t2m_ground_truth_from_site_js() {
        // node run_morse.js: {"method":"t2m","text":"sos","out":"...&nbsp;---&nbsp;...&nbsp;</textarea>"}
        assert_eq!(encode(b"sos"), b"... --- ... ");
        // {"method":"t2m","text":"a b","out":".-&nbsp;&nbsp;-...&nbsp;"}
        assert_eq!(encode(b"a b"), b".-  -... ");
        // {"method":"t2m","text":"the quick brown fox jumps over the lazy dog 0123456789", ...}
        assert_eq!(
            encode(b"the quick brown fox jumps over the lazy dog 0123456789"),
            b"- .... .  --.- ..- .. -.-. -.-  -... .-. --- .-- -.  ..-. --- -..-  \
              .--- ..- -- .--. ...  --- ...- . .-.  - .... .  .-.. .- --.. -.--  \
              -.. --- --.  ----- .---- ..--- ...-- ....- ..... -.... --... ---.. ----. "
        );
    }

    /// Ground truth for `m2t`: `node run_morse.js`.
    #[test]
    fn m2t_ground_truth_from_site_js() {
        assert_eq!(decode(b"... --- ..."), b"sos");
        assert_eq!(
            decode(b".... . .-.. .-.. ---  .-- --- .-. .-.. -.."),
            b"hello world"
        );
        assert_eq!(decode(b".-  -...  -.-."), b"a b c");
    }

    #[test]
    fn separator_run_length_rules() {
        // node: single space between codes -> letters join, no separator
        assert_eq!(decode(b".- -..."), b"ab");
        // two or more spaces -> exactly one emitted space, regardless of count
        for seps in 2..=5 {
            let input = format!(".-{}-...", " ".repeat(seps));
            assert_eq!(decode(input.as_bytes()), b"a b", "seps={seps}");
        }
        // leading run of any length -> one leading space
        assert_eq!(decode(b" .-"), b" a");
        assert_eq!(decode(b"  .-"), b" a");
        // trailing run of any length -> nothing (dropped, not even one space)
        assert_eq!(decode(b".- "), b"a");
        assert_eq!(decode(b".-  "), b"a");
    }

    /// `"END"`/`"SOS"` are reachable as decode outputs (their morse codes are
    /// unambiguous single tokens) but never as encode outputs, because `t2m`
    /// walks the input one character at a time and neither three-letter key
    /// can ever match a single character. Ground truth: `node run_morse.js`.
    #[test]
    fn end_and_sos_are_decode_only() {
        assert_eq!(decode(b".-.-."), b"END");
        assert_eq!(decode(b"...---..."), b"SOS");
        assert_eq!(
            decode(b".-  .-.-.  -...  ...---..."),
            b"a END b SOS"
        );
        // encode has no way to reach either code from single-char input
        assert!(!encode(b"END").windows(6).any(|w| w == b".-.-. "));
    }

    #[test]
    fn unrecognised_token_becomes_hash() {
        assert_eq!(decode(b".-.-.-.-.-.-.-.-"), b"#");
    }

    /// The source table's `" "` -> `" "` entry (`char[36] = ' '`, `morse[36] =
    /// ' '`) can never be reached in either direction: `t2m` special-cases a
    /// literal space *before* consulting the table, and `m2t`'s tokenizer can
    /// never produce a token that is itself a bare space (spaces are always
    /// separators, never accumulated into a token). It is intentionally not
    /// present in [`TABLE`].
    #[test]
    fn deliberately_omitted_dead_space_entry() {
        assert!(TABLE.iter().all(|(c, _)| *c != " "));
    }

    #[test]
    fn round_trip_through_decode_of_encode() {
        for plain in ["hello world", "sos", "the quick brown fox 12345"] {
            let m = encode(plain.as_bytes());
            assert_eq!(decode(&m), plain.as_bytes(), "plain={plain:?}");
        }
    }

    #[test]
    fn node_decodes_and_applies_default_artifacts() {
        let out = node()
            .apply(&Repr::bytes(b"... --- ...".to_vec()), &params! {})
            .unwrap();
        assert_eq!(out.data, b"sos\r\n");
    }

    #[test]
    fn node_trailing_can_be_disabled_via_param() {
        let out = node()
            .apply(
                &Repr::bytes(b"... --- ...".to_vec()),
                &params! {"trailing" => "none"},
            )
            .unwrap();
        assert_eq!(out.data, b"sos");
    }

    #[test]
    fn is_xf_family_and_not_layer_forming() {
        let n = node();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
