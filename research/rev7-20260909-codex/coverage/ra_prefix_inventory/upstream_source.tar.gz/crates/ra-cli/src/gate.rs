//! Conformance gating on the path a claim actually travels.
//!
//! `ra-attest` has implemented [`ra_attest::gate_coverage`] and tested it thoroughly
//! since the beginning. Nothing on the `ra sweep --emit-claim` -> `ra residual
//! --claims` path ever called it: `cmd_residual` unioned every loaded claim straight
//! into the aggregate. Because all eleven mcrypt primitives are conformance-PASS the
//! gate was the identity, so the central safety property —
//!
//! > an unproven primitive contributes zero coverage, regardless of what the claim
//! > asserts
//!
//! — held *coincidentally* rather than being enforced. A regressed primitive, or an
//! unproven twelfth, would have had its void coverage silently absorbed into the
//! residual, permanently deleting a region from the search on the strength of a
//! fabricated negative.
//!
//! This module is where a claim meets the gate. It does not implement gating; it
//! calls the one implementation in `ra-attest`.

use std::collections::BTreeMap;

use anyhow::Result;
use ra_attest::{GatedCoverage, ProvenPrimitives};
use ra_covalg::CoverageSet;

use crate::corpus::ConformanceState;

/// Where a claim's conformance provenance came from.
#[derive(Debug)]
pub enum Provenance {
    /// The claim records the conformance state it was emitted under.
    Recorded {
        suite_digest: String,
        proven: Vec<String>,
    },
    /// The claim is a worked example constructed in-process, not read from a file.
    InProcess,
    /// The claim was loaded from a file that records no conformance block. It is not
    /// self-describing, and is gated against *current* conformance instead.
    Absent,
}

/// One claim as it enters the aggregate: what it asserted, and what survived.
#[derive(Debug)]
pub struct GatedClaim {
    pub name: String,
    pub claimed: CoverageSet,
    pub gate: GatedCoverage,
    pub provenance: Provenance,
    /// Voided primitive -> why it carries no coverage.
    pub reasons: BTreeMap<String, String>,
}

impl GatedClaim {
    pub fn claimed_size(&self) -> u128 {
        self.claimed.size_exact()
    }

    pub fn effective_size(&self) -> u128 {
        self.gate.effective.size_exact()
    }

    /// The coverage that may enter the residual. Deliberately the only accessor that
    /// hands out a foldable set: `claimed` is an assertion, this is evidence.
    pub fn effective(&self) -> &CoverageSet {
        &self.gate.effective
    }
}

/// Pass claims through the conformance gate before any of them is folded.
///
/// **This is the gating point on the sweep -> residual path.** It is a hard error for
/// a claim to arrive with no `*.prim` dimension for the gate to bite on: gating such
/// a claim is a no-op that looks exactly like a clean pass, and admitting it would
/// let coverage into the residual that no conformance evidence ever touched. That is
/// the same shape of failure as the `Rijndael-256` / `rijndael-256` case mismatch
/// that once made a conformance check pass vacuously.
pub fn gate_claims(
    claims: Vec<(String, CoverageSet, Provenance)>,
    state: &ConformanceState,
) -> Result<Vec<GatedClaim>> {
    let proven = state.proven_primitives();
    let mut out = Vec::new();
    for (name, claimed, provenance) in claims {
        let gate = ra_attest::gate_coverage(&claimed, &proven);
        anyhow::ensure!(
            !gate.is_vacuous(),
            "claim {name:?} names no *.prim dimension, so conformance gating had \
             nothing to check and would pass it vacuously. A coverage set over cipher \
             parameterisations must name the primitives it covers; refusing rather \
             than folding ungated coverage into the residual."
        );
        let reasons = gate
            .voided
            .iter()
            .map(|p| (p.clone(), state.void_reason(p)))
            .collect();
        out.push(GatedClaim {
            name,
            claimed,
            gate,
            provenance,
            reasons,
        });
    }
    Ok(out)
}

/// Print what gating did to one claim: claimed size, effective size, and — when they
/// differ — which primitives were voided and why.
pub fn report(c: &GatedClaim, current: &ProvenPrimitives) {
    match &c.provenance {
        Provenance::Recorded {
            suite_digest,
            proven,
        } => {
            let drifted: Vec<&String> = proven.iter().filter(|p| !current.contains(p)).collect();
            println!(
                "   provenance = conformance suite {}, {} primitive(s) proven at emission",
                &suite_digest[..24.min(suite_digest.len())],
                proven.len()
            );
            if !drifted.is_empty() {
                println!(
                    "   DRIFT: {} primitive(s) proven when this claim was emitted are NOT \
                     proven now: {}\n          the claim is gated against CURRENT \
                     conformance, not against what it recorded",
                    drifted.len(),
                    drifted
                        .iter()
                        .map(|s| s.as_str())
                        .collect::<Vec<_>>()
                        .join(", ")
                );
            }
        }
        Provenance::Absent => {
            println!(
                "   provenance = NONE. This claim records no conformance block, so it does \
                 not\n                state which primitives were proven when it was \
                 emitted and is\n                NOT self-describing. Gated against CURRENT \
                 conformance instead of\n                trusted. Re-emit it to fix."
            );
        }
        Provenance::InProcess => {}
    }
    let claimed = c.claimed_size();
    let effective = c.effective_size();
    println!("   claimed   = {}", crate::fmt(claimed));
    println!(
        "   effective = {}  ({} primitive dimension(s) intersected with {} proven)",
        crate::fmt(effective),
        c.gate.prim_dimensions_seen,
        current.len()
    );
    if claimed == effective && c.gate.is_identity() {
        return;
    }
    println!(
        "   GATED: {} of claimed coverage carries no conformance evidence and is \
         EXCLUDED\n          from the aggregate and the residual.",
        crate::fmt(claimed - effective)
    );
    for (prim, why) in &c.reasons {
        println!("     VOID {prim}: {why}");
    }
    if c.gate.products_dropped > 0 {
        println!(
            "     {} product(s) dropped whole: every primitive they named is unproven",
            c.gate.products_dropped
        );
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ra_covalg::{product, Cover};
    use std::collections::BTreeSet;

    /// A conformance state with a synthetic unproven primitive, built without
    /// breaking a real one. `Rijndael-512` does not exist in this engine at all,
    /// which is the honest way to model "an unproven twelfth primitive".
    fn state_with(proven: &[&str], failed: &[(&str, &str)]) -> ConformanceState {
        state_with_vector(proven, &[], failed)
    }

    /// As [`state_with`], plus a set of VectorProven-only primitives — proven under
    /// the second class, with no corpus reproduction at all.
    fn state_with_vector(
        proven: &[&str],
        vector_proven: &[&str],
        failed: &[(&str, &str)],
    ) -> ConformanceState {
        ConformanceState {
            outcomes: Vec::new(),
            proven: proven.iter().map(|s| s.to_string()).collect(),
            failed: failed
                .iter()
                .map(|(k, v)| (k.to_string(), v.to_string()))
                .collect(),
            no_vector: Default::default(),
            classical: Vec::new(),
            vector_proven: vector_proven.iter().map(|s| s.to_string()).collect(),
            suite: BTreeMap::new(),
            suite_digest: "sha256:test".to_string(),
        }
    }

    fn t1(prims: &[&str]) -> CoverageSet {
        let mut set = CoverageSet::new();
        set.add(Cover::new(
            vec!["b64d", "dec"],
            vec![product! {
                "0.variant" => ["v00"],
                "1.key"     => ["Zombies"],
                "1.prim"    => prims,
                "1.mode"    => ["cfb","ecb"],
            }],
        ));
        set
    }

    /// A claim naming a primitive that does not reproduce contributes ZERO coverage
    /// for it. The whole point of the apparatus.
    #[test]
    fn an_unproven_primitive_contributes_zero_coverage() {
        let state = state_with(&["DES", "RC2"], &[]);
        let gated = gate_claims(
            vec![(
                "unproven-only".into(),
                t1(&["Rijndael-512"]),
                Provenance::InProcess,
            )],
            &state,
        )
        .unwrap();
        assert_eq!(gated[0].claimed_size(), 2, "1 prim x 2 modes claimed");
        assert_eq!(
            gated[0].effective_size(),
            0,
            "an unproven primitive must carry no coverage at all"
        );
        assert_eq!(gated[0].gate.products_dropped, 1);
        assert!(gated[0].effective().covers.is_empty());
    }

    /// A primitive proven only under VectorProven — no corpus vector at all, exactly
    /// AES's and 3DES's situation — contributes NONZERO coverage, and the class
    /// that admitted it is visible on the gate rather than folded into a single
    /// undifferentiated "proven" count.
    #[test]
    fn a_vector_proven_primitive_contributes_nonzero_coverage() {
        let state = state_with_vector(&["DES"], &["AES"], &[]);
        let gated = gate_claims(
            vec![("aes-only".into(), t1(&["AES"]), Provenance::InProcess)],
            &state,
        )
        .unwrap();
        assert_eq!(gated[0].claimed_size(), 2, "1 prim x 2 modes claimed");
        assert_eq!(
            gated[0].effective_size(),
            2,
            "VectorProven admits coverage exactly like CorpusProven does"
        );
        assert!(gated[0].gate.voided.is_empty());
        assert_eq!(
            gated[0].gate.admitted_class.get("AES"),
            Some(&ra_attest::ProvenClass::VectorProven)
        );
        assert!(gated[0].gate.rests_on_vector_proof());
    }

    /// A primitive proven under neither class still contributes exactly zero, even
    /// when VectorProven primitives exist elsewhere in the same conformance state —
    /// the two classes never launder each other's void primitives.
    #[test]
    fn a_primitive_unproven_under_both_classes_still_contributes_zero() {
        let state = state_with_vector(&["DES"], &["AES"], &[]);
        let gated = gate_claims(
            vec![(
                "mixed".into(),
                t1(&["AES", "Rijndael-512"]),
                Provenance::InProcess,
            )],
            &state,
        )
        .unwrap();
        // 2 prims x 2 modes claimed, only AES (VectorProven) survives => 1 x 2
        assert_eq!(gated[0].claimed_size(), 4);
        assert_eq!(gated[0].effective_size(), 2);
        assert_eq!(gated[0].gate.voided, BTreeSet::from(["Rijndael-512".to_string()]));
    }

    /// Claimed and effective differ by exactly the voided share for a mixed claim.
    #[test]
    fn claimed_and_effective_differ_by_exactly_the_voided_share() {
        let state = state_with(&["DES", "RC2"], &[("Twofish", "recovered text differs")]);
        let gated = gate_claims(
            vec![(
                "mixed".into(),
                t1(&["DES", "RC2", "Twofish", "Rijndael-512"]),
                Provenance::InProcess,
            )],
            &state,
        )
        .unwrap();
        // 4 prims x 2 modes claimed, 2 prims x 2 modes proven
        assert_eq!(gated[0].claimed_size(), 8);
        assert_eq!(gated[0].effective_size(), 4);
        assert_eq!(
            gated[0].gate.voided,
            ["Rijndael-512", "Twofish"]
                .iter()
                .map(|s| s.to_string())
                .collect()
        );
        // and each void is attributed to its own distinct reason
        assert!(gated[0].reasons["Twofish"].contains("conformance FAIL"));
        assert!(gated[0].reasons["Rijndael-512"].contains("not in this engine"));
    }

    /// The gate is case-insensitive across the two spellings this workspace uses,
    /// but it is not name-blind: an unknown name is voided whatever its case.
    #[test]
    fn the_gate_matches_across_spellings_but_is_not_name_blind() {
        let state = state_with(&["Rijndael-256"], &[]);
        let gated = gate_claims(
            vec![
                ("mcrypt spelling".into(), t1(&["rijndael-256"]), Provenance::InProcess),
                ("display spelling".into(), t1(&["Rijndael-256"]), Provenance::InProcess),
                ("not a primitive".into(), t1(&["RIJNDAEL-512"]), Provenance::InProcess),
            ],
            &state,
        )
        .unwrap();
        assert_eq!(gated[0].effective_size(), 2, "rijndael-256 == Rijndael-256");
        assert_eq!(gated[1].effective_size(), 2);
        assert_eq!(gated[2].effective_size(), 0, "case must not admit a stranger");
    }

    /// A claim the gate cannot bite on is refused, not passed. This is the vacuous
    /// pass in its general form: no `*.prim` dimension means no primitive was ever
    /// checked, and a no-op that reads as a clean gate is the failure mode this
    /// whole apparatus exists to prevent.
    #[test]
    fn a_claim_with_no_prim_dimension_cannot_pass_vacuously() {
        let mut set = CoverageSet::new();
        set.add(Cover::new(
            vec!["b64d", "dec"],
            // `1.primitive`, not `1.prim` — one letter from sailing through ungated
            vec![product! {"0.variant" => ["v00"], "1.primitive" => ["Rijndael-512"]}],
        ));
        let err = gate_claims(
            vec![("misspelled".into(), set, Provenance::InProcess)],
            &state_with(&["DES"], &[]),
        )
        .unwrap_err()
        .to_string();
        assert!(err.contains("vacuously"), "{err}");
    }

    /// Gating a fully proven claim is the identity, which is the situation today —
    /// and the reason the missing call site was invisible.
    #[test]
    fn a_fully_proven_claim_passes_through_untouched() {
        let state = state_with(&["DES", "RC2"], &[]);
        let claim = t1(&["DES", "RC2"]);
        let digest = claim.digest();
        let gated = gate_claims(
            vec![("proven".into(), claim, Provenance::InProcess)],
            &state,
        )
        .unwrap();
        assert!(gated[0].gate.is_identity());
        assert_eq!(gated[0].claimed_size(), gated[0].effective_size());
        assert_eq!(gated[0].effective().digest(), digest);
    }

    /// Both `*.prim` dimensions of a two-layer skeleton are gated, and the product is
    /// dropped whole when either empties — an unproven second layer cannot be
    /// laundered by a proven first one.
    #[test]
    fn both_layers_of_a_two_layer_skeleton_are_gated() {
        let mut set = CoverageSet::new();
        set.add(Cover::new(
            vec!["b64d", "dec", "xf", "codec", "dec"],
            vec![product! {
                "1.prim" => ["DES"], "2.xf" => ["identity"],
                "3.codec" => ["b64decode"], "4.prim" => ["Rijndael-512"],
            }],
        ));
        let gated = gate_claims(
            vec![("two layer".into(), set, Provenance::InProcess)],
            &state_with(&["DES"], &[]),
        )
        .unwrap();
        assert_eq!(gated[0].claimed_size(), 1);
        assert_eq!(gated[0].effective_size(), 0);
        assert_eq!(
            gated[0].gate.prim_dimensions_seen, 2,
            "both prim dimensions must be examined, not just the first"
        );
        assert!(gated[0].gate.voided.contains("Rijndael-512"));
    }
}
