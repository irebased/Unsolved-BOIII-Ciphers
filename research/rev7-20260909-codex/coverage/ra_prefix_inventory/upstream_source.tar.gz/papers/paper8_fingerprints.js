// Paper 8: Cipher Reuse and Tool Fingerprints
// Generates papers/08_Cipher_Reuse_And_Tool_Fingerprints.docx
//
//   export NODE_PATH=$(npm root -g)
//   node papers/paper8_fingerprints.js
//
// Revision 2: recomputed over all SIX map files (65 records). Revision 1 was
// written against a corpus that was half missing; section 1 retracts its
// headline error explicitly rather than silently correcting it.
//
// Revision 4: reconciled against the community "Zombies Sources" sheet, a
// primary source of direct human attribution that supersedes much of the
// menu-coverage inference. New section 9. Sections 9 to 15 of revision 3 are
// renumbered 10 to 16 and are otherwise untouched, because the sheet does not
// bear on them.
//
// Every number here is reproduced by the scripts in papers/analysis/.
// No em dashes anywhere in generated text (house style).

const path = require("path");
const S = require("./style.js");
const { docx, PAGE, numbering, title, subtitle, h1, h2, h3, p, mono, li, numItem, table, callout, spacer, makeHeaderFooter } = S;
const { Document, Packer, Paragraph, TextRun, BorderStyle } = docx;
const fs = require("fs");

const OUT = path.join(__dirname, "08_Cipher_Reuse_And_Tool_Fingerprints.docx");

const children = [];
const A = (...x) => children.push(...x);

A(title("Cipher Reuse and Tool Fingerprints"));
A(subtitle("What the Author's Toolkit Excludes, and What That Leaves for The Giant 4 and Revelations 7"));

A(p([
  { t: "Document 8 of 8 (Analysis). Revision 4. ", bold: true },
  "A meta-analysis of technique reuse across all six map groups, and of the web tools the puzzle author appears to have used, undertaken to constrain what the two unsolved ciphers can be. A tool's cipher menu is a far tighter constraint than \"any classical cipher\", so identifying the tools is worth more than identifying any single cipher.",
]));
A(p([
  "This revision adds a ",
  { t: "primary source", bold: true },
  ": the community's \"Zombies Sources\" sheet, 83 rows of direct human attribution recording, per cipher, which website or tool the people who worked the problem believe was used, with a confidence figure and a prose explanation. That is a better class of evidence than this document's menu inference, and where the two conflict the sheet wins. Section 9 reconciles them. Three of this project's independently derived findings turn out to be corroborated, one long-open question is answered, one of the two remaining unexplained ciphers is closed, and one attribution in the sheet conflicts with a 2026 menu and is left standing as a conflict.",
]));
A(callout("Three evidential statuses, kept apart throughout.", [
  { t: "Community attribution", bold: true },
  " means a human who worked the problem named a tool, with a stated confidence percentage. ",
  { t: "Independent derivation", bold: true },
  " means this project recovered something from the artefact itself, typically by reproduction. ",
  { t: "Menu inference", bold: true },
  " means a tool's menu contains the cipher, which is the weakest of the three and establishes explicability rather than attribution. Where an independent derivation and a community attribution agree, that is said explicitly, and it is the strongest thing in this document.",
], S.ACCENT));

// ---------------------------------------------------------------- 0
A(h1("0. The Limitation That Caps Everything Below"));
A(callout("Read this before the findings.", [
  "These ciphers were authored in early 2016. Web tools change substantially over a decade. In this round ",
  { t: "no toolkit's 2016 state was verified", bold: true },
  ". The Wayback Machine (web.archive.org) was not reachable from this environment, Braingle returned HTTP 403, and practicalcryptography.com refused the connection. Every tool observation below is therefore an observation of a ",
  { t: "2026", italics: true },
  " page unless explicitly stated otherwise.",
], S.ACCENT));

A(p([
  "This is a cap on confidence, not a caveat to be filed at the back. It bears unevenly on the findings, and the difference matters:",
]));
A(li([
  { t: "Unaffected. ", bold: true },
  "The Simplified Lorenz identification in section 7.2 does not rest on a page's wording. It rests on a structural match between the tool's published wheel geometry and a wheel geometry independently recovered from the ciphertext, plus an exact 48 of 48 reproduction. A 2016 snapshot could not strengthen it and its absence does not weaken it.",
]));
A(li([
  { t: "Affected, moderately. ", bold: true },
  "The whole of the coverage test in section 8, and the menu-based exclusions in section 13. A cipher absent from a 2026 menu might have been present in 2016, or vice versa. dcode.fr in particular has grown enormously over the decade, so its 2026 breadth almost certainly overstates its 2016 breadth.",
]));
A(li([
  { t: "Affected, fatally. ", bold: true },
  "Every attribution that depends on a tool's default parameter values or its interface wording. Defaults change silently and are the least durable evidence there is.",
]));

A(p([
  "One exclusion survives the blockage cleanly, and exclusions are the durable half of this exercise: ",
  { t: "Boxentriq launched in 2018", bold: true },
  " and therefore cannot be the source of anything in a corpus authored in early 2016. It is removed from the candidate set permanently rather than provisionally.",
]));
A(callout("What revision 4 changes about this blocker.", [
  "The blockage itself is unchanged: practicalcryptography.com still refuses the connection and Braingle still returns HTTP 403. What has changed is that the blocker is no longer the only route to a 2016 fact. The community sheet was written by people who ",
  { t: "used these sites in 2016 and recorded what they saw", bold: true },
  ", so on the specific points it covers it substitutes for a snapshot. That is why Practical Cryptography's straddling-checkerboard default can be tested in section 9.4 despite the site being unreachable, and it is the single most useful thing the sheet does for this document.",
], S.ACCENT));

// ---------------------------------------------------------------- 1
A(h1("1. Retraction"));
A(callout("WITHDRAWN.", [
  "Revision 1 of this document stated, as a headline finding, that ",
  { t: "\"no cipher at all is shared between any two maps\"", bold: true },
  ". That claim is ",
  { t: "false", bold: true },
  " and is withdrawn in full. It is not amended, footnoted or quietly restated; it should be treated as deleted, and any downstream reasoning that used it should be rechecked.",
], "7A3030"));

A(p([
  "The claim held only because half the corpus was absent. Revision 1 analysed 34 records from three maps (Gorod Krovi, The Giant, Revelations). The full corpus is ",
  { t: "65 records across six maps", bold: true },
  ": Shadows of Evil, The Giant, Der Eisendrache, Zetsubou No Shima, Gorod Krovi and Revelations. The three imported in this revision carry solution methods but no ciphertext, so they inform the meta-analysis and give the engine nothing to reproduce.",
]));
A(p("On the full corpus, four genuine ciphers are shared between maps:"));
A(table(
  ["Cipher", "Maps", "Records"],
  [
    ["straddling checkerboard", "Shadows of Evil, Revelations", "soe5, rev3"],
    ["Playfair", "Der Eisendrache, Revelations", "de3, rev11"],
    ["Trifid", "Shadows of Evil, Revelations", "soe2, rev11"],
    ["Navajo code talker", "Der Eisendrache, Gorod Krovi", "de5, gk3"],
  ],
  [2600, 4200, 2560]
));
A(p([
  "Two structural methods are also shared: ",
  { t: "base64", mono: true },
  " across three maps (de2, zns2, rev8) and ",
  { t: "octal", mono: true },
  " across two (gk2, rev10). Revision 1 correctly identified ",
  { t: "octal", mono: true },
  " as the only cross-map method it could see, and then drew from that a conclusion about ciphers which the missing data did not license.",
]));

A(h2("1.1 What the error was, and what it was not"));
A(p([
  "This was not a reasoning error over the data available. Over three maps the statement was arithmetically true. It was an error of ",
  { t: "scope", italics: true },
  ": a claim of the form \"no X anywhere\" was made from a sample that turned out to be 52% of the population, without a stated boundary on what \"anywhere\" ranged over. The lesson for this project is the same one its coverage algebra already encodes for search claims and had not been applied to descriptive ones. A universal claim needs its universe stated, and \"the corpus\" is not a universe if the corpus can grow.",
]));

A(h2("1.2 A normalisation hazard that nearly hid two of the four"));
A(p([
  "rev11 records its cipher as ",
  { t: "Trifid", mono: true },
  " and soe2 records ",
  { t: "trifid", mono: true },
  ". Compared as raw strings they are two singletons; compared case-folded they are one shared cipher. This project has been bitten by exactly this class of bug twice before, in the ",
  { t: "Rijndael-256", mono: true },
  " versus ",
  { t: "rijndael-256", mono: true },
  " vacuous conformance pass, and in a key-label mismatch between two subcommands. Every comparison in the analysis scripts now goes through a single ",
  { t: "norm()", mono: true },
  " that case-folds, strips accents and collapses separator runs.",
]));
A(callout("A consequence worth stating, because it corrects a figure.", [
  "The corpus has ",
  { t: "66 distinct raw method names but only 65 distinct methods", bold: true },
  ", and the single collision is precisely the Trifid pair. So the corpus-wide reuse ratio is 92 / 65 = ",
  { t: "1.42", bold: true },
  ", not 92 / 66 = 1.39. The 1.39 figure is the pre-normalisation count. The very pair that had to be normalised to find the shared ciphers is the pair that moves the total.",
], S.ACCENT));
A(p([
  "A second, related hazard is left deliberately unresolved. rev2 and rev8 record ",
  { t: "hex", mono: true },
  " while zns6 records ",
  { t: "hexadecimal", mono: true },
  ". These are the same technique under different recorded names, but they are synonyms rather than a spelling variation, so ",
  { t: "norm()", mono: true },
  " does not merge them. Merging them would add a third cross-map structural method and reduce the distinct count to 64. The figures above use the unmerged reading; the script reports the sensitivity explicitly rather than choosing silently.",
]));

// ---------------------------------------------------------------- 2
A(h1("2. Findings"));

A(numItem([
  { t: "Ciphers ARE shared between maps: four of them. ", bold: true },
  "See section 1. The strongest previous claim in this document is withdrawn.",
], "steps"));
A(numItem([
  { t: "Reuse remains low everywhere, and the per-map figures are confirmed. ", bold: true },
  "Every map has a ratio of exactly 1.00 except Zetsubou at 1.10 (two Vigeneres) and Revelations at 1.59. Corpus-wide 92 / 65 = 1.42; split by role, ciphers 58 / 50 = 1.16 and structural 34 / 15 = 2.27. Revelations' 1.59 is still entirely a structural artifact.",
], "steps"));
A(numItem([
  { t: "Every modern cipher in the entire corpus is in Revelations. ", bold: true },
  "All 13 mcrypt decryption steps are Revelations steps. The other five maps contribute 35 cipher steps and 0 modern ones. This is far stronger than the three-map version could show and is the most consequential new result.",
], "steps"));
A(numItem([
  { t: "The \"each technique used once\" rule is refuted, harder than before. ", bold: true },
  "Repeated ciphers rise from 3 to 8. Tested as a tendency on the only axis with a known menu, the mcrypt primitives, the observed variety still does not beat uniform random selection: p = 0.22, ",
  { t: "numerically unchanged", italics: true },
  ", because the three new maps contribute zero modern draws.",
], "steps"));
A(numItem([
  { t: "REV7's primitive probability does not move. ", bold: true },
  "Still at least 42%, still 8 of 19 mcrypt primitives unmodelled by this engine, still with no corpus cipher available to conformance-gate any of them.",
], "steps"));
A(numItem([
  { t: "dcode.fr is excluded on owner ground truth. ", bold: true },
  "The project owner states with high confidence that dcode.fr was not used. This is external knowledge about the artefact, attributed to the owner and not derived here, and is treated exactly as the 0/O font resolution was.",
], "steps"));
A(numItem([
  { t: "Taken together, the remaining toolkits DO explain the corpus: 35 of 39 classical methods, 90%. ", bold: true },
  "Four toolkits suffice, and the four uncovered methods include no cross-map cipher and only two real ciphers. An apparent 20-method gap left by removing dcode turned out to be an artefact of four researched toolkits never having been entered into the table.",
], "steps"));
A(numItem([
  { t: "But explaining the corpus is not the same as having been used. ", bold: true },
  "CacheSleuth alone covers 69%, and like dcode it is a general-purpose decoder advertising over 250 ciphers. The breadth objection that made dcode's high score uninformative applies to CacheSleuth unchanged. Coverage establishes explicability, not attribution.",
], "steps"));
A(numItem([
  { t: "The rumkin lead survives its retest, on better grounds than the original. ", bold: true },
  "With dcode excluded, Skip and flag semaphore are covered by rumkin and by nothing else, and both are ",
  { t: "verified absent", italics: true },
  " from CacheSleuth. That is stronger than the original \"Ubchi and Skip are rare\" argument. Rumkin still covers 0 of 5 in Shadows of Evil, so it is not the whole story.",
], "steps"));
A(numItem([
  { t: "TG3's tool is identified, at the same confidence as tools4noobs. ", bold: true },
  "The CIMT/MEP Simplified Lorenz Cipher Toolkit. Its K wheel has 14 positions and its S wheel 4; I recovered exactly those two lengths from the ciphertext before finding the tool, and TG3 then reproduces 48 of 48.",
], "steps"));
A(numItem([
  { t: "TG3's charset tension dissolves, and both new ciphertexts are authenticated. ", bold: true },
  "TG3 is ITA2 in Bletchley Park notation, not base64. TG5 reproduces 46 of 46 under a standard Enigma M3.",
], "steps"));
A(numItem([
  { t: "Three independently derived findings are corroborated by the community sheet. ", bold: true },
  "TG3 = CIMT (sheet: 100%), rev4's ADFGX key being simply ZOMBIES with 30957298 explaining nothing, and rev14's columnar matching no standard online encoder. Each was reached here from the artefact before the sheet was read. Two independent routes agreeing is the strongest evidence this document contains.",
], "steps"));
A(numItem([
  { t: "No real cipher in the corpus is left without an identified source. ", bold: true },
  "Purple gains a candidate in Brian Neal's PURPLE, a Python package rather than a web page, which is why a web-scoped search could never have found it. Quagmire III turns out to be rumkin all along. The two methods still uncovered are Der Eisendrache's \"math formulas\" and Zetsubou's DNA binary, neither of which is a cipher a tool would carry.",
], "steps"));
A(numItem([
  { t: "A menu enumeration counts pages, not capabilities, and that is the sheet's largest correction to this document's method. ", bold: true },
  "Quagmire III and keyed Caesar were both listed as uncovered. The sheet attributes both to rumkin's \"keymaker\", a setting on the pages this table had recorded as plain \"Caesar\" and \"Vigenere\". Every complete-menu flag in section 8 should therefore be read as complete at page level, and as systematically undercounting.",
], "steps"));
A(numItem([
  { t: "One attribution conflicts with a 2026 menu and is left standing as a conflict. ", bold: true },
  "The sheet gives five Der Eisendrache ciphers to Cryptool Online at 75 to 90 per cent, and this project's 2026 enumeration of that site found none of them. That is a disagreement, not a refutation, and section 0's blocker is precisely what stops it being decided.",
], "steps"));
A(numItem([
  { t: "dcode.fr's exclusion is corroborated, and by refutation rather than silence. ", bold: true },
  "It is named in none of the sheet's 83 Encoding Source cells, and where its explanations do reach for it they put it down: for zns1 \"the outputs do not match when I try to encipher the known plaintext\". An owner-attributed exclusion and an evidential one now coincide.",
], "steps"));
A(numItem([
  { t: "rev3's straddling checkerboard is attributable to Practical Cryptography, but not at the sheet's 100%. ", bold: true },
  "Our independently reconstructed board agrees with that site's default key at 17 of 19 attested cells, p under 1e-4, and reproduces it cell for cell at 16 of 19. It does not match exactly, so \"due to its use of the site's default key\" is corroborated in substance and overstated in degree.",
], "steps"));
A(numItem([
  { t: "The sheet's Revelations numbering answers four of fourteen rows and nothing else. ", bold: true },
  "Ten Revelations rows are \"Unknown / Unknown / N/A\". REV7 is one of them whichever it is, so no mapping work can extract an attribution for it.",
], "steps"));
A(numItem([
  { t: "TG4 has no community attribution either. ", bold: true },
  "Its row reads Unknown / Unknown / N/A, with the explanation \"We don't know enough about this cipher to know anything about what tools could have been used.\" That is a hard bound on what fingerprinting can offer for this project's actual target.",
], "steps"));

// ---------------------------------------------------------------- 3
A(h1("3. The Corpus, Counted"));
A(p([
  "65 records across six maps carry 101 solution steps, of which 92 name a method and 9 are prose descriptions of non-cipher puzzles. Reproduce every figure in this section with ",
  { t: "python3 papers/analysis/reuse_matrix.py", mono: true },
  ".",
]));

A(table(
  ["Map", "Records", "Named steps", "Distinct", "Ratio", "Cipher-only", "Structural-only"],
  [
    ["Shadows of Evil", "6", "5", "5", "1.00", "5 / 5 = 1.00", "none"],
    ["The Giant", "6", "2", "2", "1.00", "2 / 2 = 1.00", "none"],
    ["Der Eisendrache", "12", "11", "11", "1.00", "10 / 10 = 1.00", "1 / 1 = 1.00"],
    ["Zetsubou No Shima", "13", "11", "10", "1.10", "9 / 8 = 1.12", "2 / 2 = 1.00"],
    ["Gorod Krovi", "14", "12", "12", "1.00", "9 / 9 = 1.00", "3 / 3 = 1.00"],
    ["Revelations", "14", "51", "32", "1.59", "23 / 20 = 1.15", "28 / 12 = 2.33"],
    ["CORPUS", "65", "92", "65", "1.42", "58 / 50 = 1.16", "34 / 15 = 2.27"],
  ],
  [1700, 900, 1150, 900, 800, 1900, 2010]
));

A(p([
  "\"Cipher\" means a step of recorded type ",
  { t: "classical", mono: true },
  ", ",
  { t: "decrypt", mono: true },
  " or ",
  { t: "formula", mono: true },
  "; \"structural\" means ",
  { t: "decode", mono: true },
  ", ",
  { t: "encode", mono: true },
  " or ",
  { t: "transform", mono: true },
  ". The split is where the whole reuse question turns: it separates choosing a technique from moving bytes between representations.",
]));

A(h2("3.1 Singleton share, by role"));
A(table(
  ["Role", "Distinct methods", "Used once", "Used more than once", "Singleton share", "Steps"],
  [
    ["Cipher", "50", "42", "8", "84.0%", "58"],
    ["Structural", "15", "7", "8", "46.7%", "34"],
  ],
  [1500, 1700, 1300, 2100, 1500, 1260]
));
A(p([
  "The pattern Revision 1 identified survives the doubling of the corpus: ciphers are overwhelmingly singletons, structural steps are freely reused. What does not survive is the inference that was drawn from it.",
]));

A(h2("3.2 Every repeated cipher"));
A(table(
  ["Cipher", "Count", "Records", "Cross-map?"],
  [
    ["DES", "2", "rev2, rev9", "no"],
    ["RC2", "2", "rev1, rev5", "no"],
    ["substitution", "2", "rev3, rev6", "no"],
    ["Vigenere", "2", "zns3, zns4", "no"],
    ["Navajo code talker", "2", "de5, gk3", "YES"],
    ["Playfair", "2", "de3, rev11", "YES"],
    ["straddling checkerboard", "2", "soe5, rev3", "YES"],
    ["Trifid", "2", "soe2, rev11", "YES"],
  ],
  [2600, 900, 2800, 3060]
));

// ---------------------------------------------------------------- 4
A(h1("4. Testing the Rule, and Failing to Prove It"));
A(p([
  "The hypothesis is that the author operated a rule of \"each technique used once\" for ciphers while reusing structural steps freely. The shape of the data is consistent with it. That is not evidence for it, and this project has been burned before by inferences that were consistent with the data and wrong: an index-of-coincidence argument that its own standard error killed, and a permutation-invariance claim that held for three of four differences and was stated as though it held for all four. Section 1 of this document is now a third entry on that list.",
]));

A(h2("4.1 The strict rule is refuted, and more firmly than before"));
A(p([
  "Eight ciphers appear twice, up from three on the three-map corpus. Under a strict no-repeat rule the probability of that observation is exactly zero. The strict rule is dead, and with it the clean entailment \"REV7's primitive must be one of the unused eight\".",
]));

A(h2("4.2 As a tendency, it still does not beat chance"));
A(p([
  "The mcrypt primitives remain the only axis where the menu is known exactly and the draws are unambiguous. The three new maps contribute ",
  { t: "zero", bold: true },
  " draws to it, because every one of their 31 ciphers is classical. So this test is numerically identical to Revision 1's:",
]));
A(...mono("  n draws            13        (all in Revelations)\n  menu               19\n  distinct           11\n  E[distinct]         9.59     (uniform, with replacement)\n  P(distinct >= 11)   0.2232"));
A(callout("Verdict, unchanged.", [
  "p = 0.22. The corpus's modern-cipher variety is ",
  { t: "not distinguishable", bold: true },
  " from uniform random selection at any conventional threshold. Doubling the corpus did not help, because the doubling added no modern data. The owner's caution that the author simply varied technique remains the better-supported reading.",
], "7A3030"));

A(h2("4.3 Why the classical ciphers cannot rescue the test"));
A(p([
  "It is tempting to rerun the test on the 45 classical cipher draws, where 39 distinct methods appear. It cannot be done honestly, because the menu size is unknown and the answer depends entirely on it:",
]));
A(table(
  ["Assumed menu size", "E[distinct]", "P(distinct >= 39)"],
  [
    ["60", "31.84", "0.0010"],
    ["100", "36.38", "0.1658"],
    ["200", "40.39", "0.8464"],
    ["400", "42.61", "0.9940"],
  ],
  [3000, 3000, 3360]
));
A(p([
  "The conclusion swings from \"strongly significant\" to \"the author was less varied than chance\" across a range of menu sizes that are all defensible. dcode.fr alone advertises more than 200 ciphers. No conclusion is drawn from this table; it is printed to show why none can be.",
]));

A(h2("4.4 A taxonomy problem that limits every ratio in section 3"));
A(p([
  "The distinct-method count is a property of how the record was written as much as of what the author did. gk4 (\"pigpen\") and gk10 (\"Atbash\") are both monoalphabetic substitutions, recorded under different names and counted as two. rev3 and rev6 are both recorded as plain \"substitution\" and counted as one method used twice, although their alphabets are unrelated. zns12's \"keyed_vigenere_(quagmire_III)\" and zns3's \"Vigenere\" are recorded as different methods, which is defensible, while de9's \"Trithemius\" is arguably a third member of the same family recorded as a fourth thing.",
]));
A(p([
  "A reuse ratio computed over an inconsistent taxonomy cannot separate \"the author varied technique\" from \"the write-ups named things inconsistently\". The ratios are reported because they are correct as computed and because the owner asked for them, but they should not carry an inference on their own.",
]));

A(h2("4.5 The one piece of variety evidence that does not depend on any ratio"));
A(p([
  "Set the statistics aside and look at which primitives were chosen. ",
  { t: "rijndael-128 (that is, AES) and tripledes are both unused", bold: true },
  ", while rijndael-256, loki97, saferplus and xtea are all used. An author reaching for whatever was familiar would have hit AES and Triple DES first; they are the two best-known items on the menu. Avoiding both while using four obscure ones is qualitative evidence of deliberate variety seeking, and unlike the ratios it does not depend on the taxonomy or on the sample size. It supports the owner's framing rather than the singleton rule.",
]));

// ---------------------------------------------------------------- 5
A(h1("5. Recorded Versus Reconstructed"));
A(p([
  "A fingerprint built on a parameter the corpus itself records is stronger than one built on a parameter this project reconstructed, because the latter inherits our uncertainty and, worse, our choice of parameterisation.",
]));
A(table(
  ["Cipher", "Parameter", "Tier", "Note"],
  [
    ["rev1 beaufort", "52-char mixed-case alphabet A-Za-z, key ZOMBIES", "RECORDED", "The author's own record, not our inference. Strongest single fingerprint candidate in the corpus."],
    ["gk12 autokey", "key TRYTHIS, alphabet ZOMBIESAREEVERYWHERE", "RECORDED", "Both inputs recorded. The dedup policy that turns the second into a 26-letter alphabet is ours."],
    ["de4 bifid", "key Maxis, period 99 = ciphertext length", "RECORDED", "Whole-message period, as with rev11's Trifid. See section 7.3."],
    ["zns12 quagmire III", "key shinonuma, alphabet key AMUNOIHSZYXWVTRQPLKJGFEDCB", "RECORDED", "A reversed keyed alphabet. Covered by no verified toolkit."],
    ["de7 AMSCO", "key 198346572", "RECORDED", "Verbatim."],
    ["tg3 lorenz", "K-wheel = 9 and S-wheel = 4", "RECORDED", "Meaning reconstructed: see section 10.3."],
    ["tg5 enigma", "UKW B, rotors 123, rings AAD, key WAD, 10 plugs", "RECORDED", "Confirmed 46/46. Only the left-to-right reading is ours."],
    ["rev11 trifid", "alphabet adgbehcfijmpknqlorsvytwzux. , period = whole message", "RECONSTRUCTED", "Neither recorded. Recovered as a constraint system with a unique solution."],
    ["rev3 straddling", "layout C.D..YFE.W / NXM.T...U. / .SOGIAR.BH, digits {1,3}", "RECONSTRUCTED", "Neither recorded, plus an undocumented reverse step."],
    ["rev4 adfgx", "unkeyed I/J-merged square, symbols 11/14/21/22/53", "RECONSTRUCTED", "Record names only \"adfgx\" and an unexplained number 30957298."],
    ["rev2 bacon", "26-letter, A=0, B=1, MSB first", "RECONSTRUCTED", "Record names only \"bacon\". All four parameters derived."],
  ],
  [1500, 2500, 1400, 3960]
));
A(callout("A new corroboration from the imported maps.", [
  "de4's Bifid is recorded with ",
  { t: "\"a period of 99 (ciphertext length)\"", italics: true },
  ", that is, the whole message as one block. rev11's Trifid period was ",
  { t: "reconstructed", italics: true },
  " by this project as the whole message, and that reconstruction was a possible weak point. The corpus now independently records the same unusual choice for a sibling cipher in a different map. This does not confirm the Trifid alphabet, but it does confirm that whole-message periods are something this author actually did.",
], S.ACCENT));

A(h2("5.1 Two reconstructions tested for being mere re-descriptions"));
A(p([
  "Before claiming a parameterisation is unusual enough to fingerprint a tool, it must be checked that it is not a standard operation under different parameter names. Both suspect cases were tested arithmetically. Reproduce with ",
  { t: "python3 papers/analysis/equivalence_tests.py", mono: true },
  ".",
]));
A(p([
  { t: "rev14's columnar transposition is genuinely not standard. ", bold: true },
  "A standard keyed columnar on a complete W by R rectangle splits the text into W contiguous blocks of R characters, and inside each block consecutive positions are exactly W apart. The column key decides which block is which and cannot change that step, so testing the step tests all W factorial key orders at once. Every width dividing rev14's 162-character body was tested and none fits. Our map sends each run of 6 output positions to 6 consecutive input positions; a standard columnar sends it to an arithmetic progression of step W. Measured, the step is +1 at 108 of 161 consecutive pairs, where a standard columnar of width above 1 has step +1 nowhere inside a block.",
]));
A(p([
  { t: "gk12's autokey is not absorbable, but not discriminating either. ", bold: true },
  "An autokey over a mixed alphabet collapses to a plain-alphabet autokey exactly when the alphabet is affine on Z26. ",
  { t: "ZOMBIESARVYWHCDFGJKLNPQTUX", mono: true },
  " was tested against all 312 affine maps and is not one of them. But \"keyed-alphabet autokey\" is a textbook construction and the dedup policy used here is the standard textbook one, so the policy discriminates between nothing. The autokey fingerprint stays downgraded to weak.",
]));

// ---------------------------------------------------------------- 6
A(h1("6. The Fingerprint Mapping"));
A(p([
  { t: "Confirmed", bold: true },
  " means supported by evidence that does not depend on a page's current wording, typically a structural match plus a reproduction. ",
  { t: "Probable", bold: true },
  " means good evidence with an identified way it could be wrong. ",
  { t: "Speculative", bold: true },
  " means a hypothesis worth testing and nothing more.",
]));

A(p([
  { t: "Revision 4 adds a fifth column. ", bold: true },
  "Confidence is this document's assessment; ",
  { t: "Evidence", italics: true },
  " says what kind of thing the assessment rests on, which is the distinction the community sheet forces. A community attribution and a menu inference can both read \"PROBABLE\" and mean entirely different things.",
]));
A(table(
  ["Cipher", "The tell", "Tool", "Confidence", "Evidence", "What would settle it"],
  [
    ["All modern Revelations layers", "mcrypt cfb meaning CFB-8, IV = ASCII '0' x16, key Zombies, implicit b64decode at each hop", "tools4noobs.com", "CONFIRMED", "our reproduction", "Already settled. 11 of 11 primitives reproduce end to end."],
    ["tg3 simplified lorenz", "K wheel of 14 positions and S wheel of 4, recovered from the ciphertext before the tool was found", "CIMT / MEP Simplified Lorenz Toolkit", "CONFIRMED", "our derivation AND community, 100%", "Already settled. 48 of 48 reproduction, and the sheet reaches the same tool independently."],
    ["rev3 + soe5 straddling checkerboard", "rev3's board agrees with Practical Cryptography's default key at 17 of 19 attested cells; soe5's RECORDED spare positions 3 and 7 are that site's defaults", "practicalcryptography.com", "PROBABLE", "community, 100% and 100%, plus our reconstruction at p < 1e-4", "Reaching the site itself. No exact fit exists under any placement, so three cells are still unaccounted for. See 9.4."],
    ["de11 purple", "A real cipher machine, absent from every web menu checked", "Brian Neal's PURPLE (a Python package)", "PROBABLE", "community, 30%", "The sheet's own lowest confidence on any named tool. Not reproduced here. Closes the cipher that the web-only search could never have found."],
    ["rev13 affine", "Casing, punctuation and spacing all preserved; a case-preserving 26-letter affine a=15 b=19 reproduces the plaintext exactly", "rumkin.com", "PROBABLE", "community, 85%, and the behaviour VERIFIED in our data", "A behavioural fingerprint, which is a better class than menu coverage. Other tools may share the behaviour; that is the sheet's own stated reason for 85% rather than more."],
    ["tg5 enigma m3", "UKW-B, rotors I II III left to right, rings AAD, key WAD, 10 plugboard pairs", "practicalcryptography.com", "PROBABLE", "community, 100%", "Parameters confirmed 46/46 here. Eight simulators were checked and none used the recorded label set, but the site was unreachable and was not among them. Check whether its Enigma form defaults to two of the four recorded parameters."],
    ["soe2 trifid", "Needs the non-standard square, row, column read, 'treated as a variant on most platforms but is the only option here'", "Braingle", "PROBABLE", "community, 80%", "Braingle still returns HTTP 403. The sheet supplies the reason this project could not: Practical Cryptography documents Trifid but has no implementation."],
    ["rev1 beaufort", "52-character mixed-case alphabet A-Za-z, case-significant", "unidentified", "UNRESOLVED", "our RECORDED parameter", "The strongest tell in the corpus and still unexplained. Section 9.5 rules out the obvious shortcut: a case-preserving 26-letter Beaufort is NOT the same function, and disagrees on 26 of 64 characters."],
    ["rev6, rev9, rev10 zero-padded decimal", "Fixed-width three-digit decimal with leading zeros; 198 of rev6's 256 tokens would be shorter without padding", "unidentified", "UNRESOLVED", "our measurement, owner hypothesis", "A rendering behaviour, not a cipher, so it is searchable. No toolkit in the table is known to emit it. The same site is hypothesised to carry a substitution."],
    ["rev11 trifid", "27-symbol alphabet filled DOWN THE COLUMNS; period = whole message", "Braingle (suspected)", "SPECULATIVE", "our reconstruction, plus the sheet's soe2 attribution by proxy", "rev11 is one of the ten Revelations rows the sheet leaves blank, so it is not attributed directly. soe2 is the same cipher in another map and the sheet gives it to Braingle."],
    ["zns12 quagmire III", "Alphabet key AMUNOIHSZYXWVTRQPLKJGFEDCB, a reversed keyed alphabet", "rumkin.com, via its 'keymaker' alphabet generator", "PROBABLE", "community, 99%", "Was on the uncovered list only because rumkin's keymaker is a SETTING on the Vigenere page rather than a menu entry. Check whether keymaker with keyword 'shinonuma' emits that alphabet; the sheet says it does."],
    ["rev4 adfgx", "unkeyed square, and the five cipher letters themselves Polybius-encoded", "Braingle or Cryptool Online", "SPECULATIVE", "community, 40%", "The sheet's own confidence is 40% and its reasoning is explicitly provisional. It could not find an ADFGX tool grouping into 45s either."],
    ["rev2 bacon / rev11 playfair", "26-letter A=0 MSB-first; J-to-I with X padding", "unidentified", "SPECULATIVE", "menu inference only", "Majority defaults or bare parameter values. No discriminating power. Do not pursue."],
    ["rev14 columnar", "width 6, rotate 3, read bottom to top; matches no standard keyed columnar at any width or key order", "unidentified", "UNRESOLVED", "our exhaustive negative AND community negative", "Both parties exhausted the standard family and came up empty. The next move is to stop looking for a columnar."],
    ["gk12 autokey", "separate key and alphabet-keyword inputs", "rumkin.com", "WEAK", "community, 90%", "The sheet lists gk12 as unsolved, so its attribution predates or missed the solve. The dedup policy is universal; only the two-input shape discriminates."],
  ],
  [1250, 2050, 1300, 950, 1450, 2360]
));

A(callout("The shape of this table is itself the finding.", [
  "Two confirmed and nine unresolved or speculative. Fingerprinting worked decisively where a tool exposed an unusual ",
  { t: "structure", italics: true },
  " (wheel geometry, cipher mode semantics) and failed everywhere it depended on ",
  { t: "defaults or wording", italics: true },
  ". Pursue structural tells, not parameter values.",
], "7A3030"));

// ---------------------------------------------------------------- 7
A(h1("7. The Confirmed Fingerprints in Detail"));

A(h2("7.1 tools4noobs, for every modern Revelations layer"));
A(p([
  "Restated for completeness. The evidence is mcrypt's ",
  { t: "cfb", mono: true },
  " meaning CFB-8 rather than full-block feedback, an IV of sixteen 0x30 bytes rather than a null IV, the key ",
  { t: "Zombies", mono: true },
  " throughout, and an implicit base64 decode at every hop which the recorded chains all omit. Eleven of eleven primitives reproduce end to end. The full corpus strengthens this indirectly: tools4noobs is now known to account for 11 of the 20 cipher methods in Revelations and 0 of the 30 in the other five maps, which is exactly what a tool used for one map and no other looks like.",
]));

A(h2("7.2 The Simplified Lorenz Cipher Toolkit, for TG3"));
A(p([
  "Working from the newly supplied TG3 ciphertext and the recorded plaintext, section 10 recovers a keystream with an exact period of 28 which factors uniquely into a wheel of 14 positions and a wheel of 4. That geometry was derived before any tool was consulted. The tool then found is:",
]));
A(...mono("  Simplified Lorenz Cipher Toolkit\n  Centre for Innovation in Mathematics Teaching (CIMT), University of Plymouth,\n  with Bletchley Park National Codes Centre\n  MEP \"Codes and Ciphers\", Unit 19: Lorenz Cipher Machine\n  https://www.cimt.org.uk/resources/codes/lorenz/index.htm"));
A(p("Its published specification, quoted from the page:"));
A(li([{ t: "\"The first wheel, the K wheel, has 14 positions (numbered 1 to 14) and the second, the S wheel, has just 4 positions (1 to 4).\"", italics: true }]));
A(li([{ t: "\"56 combinations (14 x 4)\"", italics: true }, " of start positions."]));
A(li([{ t: "\"You can only use 'A' to 'Z' and '3', '4', '8', '9', '+' or '/'.\"", italics: true }]));
A(li([{ t: "\"If the K-wheel start-position is 7 i.e. letter 'G', K = GHIJKLMNABCDEFGHIJKLMNABCDEF...\"", italics: true }, " which pins the K wheel's cam pattern to the literal 14 letters A to N."]));
A(p("Three independent agreements, which together are conclusive:"));
A(numItem(["The wheel lengths 14 and 4 match the lengths recovered from the ciphertext exactly. The recovered key period of 28 is lcm(14, 4)."], "steps2"));
A(numItem(["The tool's alphabet is A to Z plus the six glyphs / 9 3 4 + 8. TG3's non-letter symbols are exactly { 3, 9, +, / }, a subset of those six and of nothing else natural."], "steps2"));
A(numItem([
  "Taking the K wheel from the tool's worked example and the start positions from TG3's record, the S wheel falls out as the 4-cam pattern ",
  { t: "AABB", mono: true },
  " and the cipher reproduces the recorded plaintext at 48 of 48 symbols.",
], "steps2"));
A(callout("Why the 2016 blockage does not bite here.", [
  "This attribution rests on wheel geometry and an exact reproduction, not on interface wording or defaults. A 2016 snapshot could show a differently worded page; it could not show a different number of cams, because the cams are what the ciphertext measures.",
], S.ACCENT));

A(h2("7.3 Braingle and rev11's Trifid: the anomaly is real, the attribution is not"));
A(p([
  "Two axes are easy to conflate here, and conflating them makes a real finding evaporate. The ",
  { t: "square fill", bold: true },
  " is how the 27 symbols are laid into the three squares, a property of the alphabet parameter. The ",
  { t: "transposition read", bold: true },
  " is the layer, row and column regrouping during encipherment, a property of the algorithm. The engine's Trifid is checked against the standard published vector, so its read is textbook. The finding concerns the fill: rev11's recovered alphabet is the plain alphabet a to z plus a full stop laid down the columns.",
]));
A(...mono("  a d g     j m p     s v y\n  b e h     k n q     t w z\n  c f i     l o r     u x ."));
A(p([
  "An observation that the layer/row/column read is standard says nothing about the fill. What is not established is the attribution to Braingle, which returned HTTP 403 and could not be inspected. Note also that a column-wise fill and a tool that reads row and column coordinates in the opposite order to the textbook are ",
  { t: "indistinguishable", bold: true },
  " from this data.",
]));

// ---------------------------------------------------------------- 8
A(h1("8. The Toolkit Coverage Test"));
A(p([
  "Rather than attributing ciphers to tools one at a time, ask of each candidate toolkit: what fraction of the corpus's cipher methods does its menu contain? Reproduce with ",
  { t: "python3 papers/analysis/toolkit_coverage.py", mono: true },
  ". All menus are 2026 menus, and section 0's blocker now matters more rather than less, because excluding the one broad general-purpose site leaves the result resting on narrower menus.",
]));

A(h2("8.1 dcode.fr is excluded on owner ground truth"));
A(callout("Attributed, not derived.", [
  "The project owner states with high confidence that ",
  { t: "dcode.fr was not used", bold: true },
  ". This is external knowledge about the artefact, of the same kind as the 0/O font resolution that fixed seven TG4 glyph positions: it is not derivable from the corpus, it is attributed to the owner, and it is recorded as such rather than inferred. dcode is removed from the table entirely.",
], S.ACCENT));
A(p([
  "This is consequential, because dcode was carrying the previous revision's table at 77% of classical methods. Its removal is also, separately, a relief for the argument: the previous revision had to spend a section explaining why dcode's high score was uninformative. That problem is now inherited by CacheSleuth instead, and section 8.4 says so.",
]));

A(h2("8.2 Four researched toolkits had never been encoded, which was a real defect"));
A(p([
  "Removing dcode initially appeared to leave roughly twenty classical methods with no identified source, including all three cross-map ciphers. That turned out to be an artefact of the table rather than a fact about the corpus: four toolkits that had been researched were never entered into it. They are now encoded, two of them verified live in this round.",
]));
A(p([
  "The table below is revision 4's, with the ten tools the community sheet names folded in. The two rows revision 3 carried as ",
  { t: "UNKNOWN", mono: true },
  " are both promoted, and neither by getting through to the site: Braingle from search snapshots of its per-cipher pages, Practical Cryptography from search snapshots plus a third-party tool that reproduces its form defaults. Section 9 is where the attributions themselves are weighed.",
]));
A(table(
  ["Toolkit", "Classical coverage", "Menu status", "Complete?"],
  [
    ["CacheSleuth", "27 / 39 = 69%", "VERIFIED LIVE 2026; ~37 entries spot-checked against a claimed 250+. Named in NONE of the sheet's 83 rows", "no"],
    ["Practical Cryptography", "18 / 39 = 46%", "Still refuses the connection. Menu from search snapshots and from a.tools, which reproduces its defaults. Named for 5 rows, two at 100%", "no"],
    ["rumkin.com", "17 / 39 = 44%", "VERIFIED LIVE 2026, complete menu enumerated, PLUS two capabilities the menu does not list (see 9.6). The sheet's most-attributed tool, 11 of 83", "at page level"],
    ["Braingle", "15 / 39 = 38%", "Direct fetch still HTTP 403; menu from search snapshots of its per-cipher pages", "no"],
    ["crypto.interactive-maths (Crypto Corner)", "12 / 39 = 31%", "VERIFIED LIVE 2026, ~22 entries spot-checked", "no"],
    ["geocachingtoolbox.com", "12 / 39 = 31%", "VERIFIED LIVE 2026, complete menu. Added on the owner's hypothesis; named in none of the sheet's rows but runner-up in two of its explanations", "YES"],
    ["Cryptool Online", "9 / 39 = 23%", "VERIFIED LIVE 2026, 29 applications enumerated but not trusted as exhaustive. Named for 8 rows, five of which its menu does not carry", "no"],
    ["CIMT / MEP Codes and Ciphers", "7 / 39 = 18%", "VERIFIED LIVE 2026, complete 20-unit menu", "YES"],
    ["cryptii v2", "7 / 39 = 18%", "VERIFIED LIVE 2026 at the v2 archive URL, complete 22-format menu. The 2013 build the author could actually have used", "YES"],
    ["cryptii v3", "5 / 39 = 13%", "NOT VERIFIED. Menu could not be enumerated; encoded from the research report only. A different object from v2", "no"],
    ["Brian Neal PURPLE", "1 / 39 = 3%", "A Python package, not a web page. Named for de11 at 30%, alongside an admitted reproduction failure", "YES"],
    ["PMacg", "1 / 39 = 3%", "Site not located by this project. Named for soe4 at 90%", "no"],
    ["Woodmann", "1 / 39 = 3%", "Reachable but its pages returned no content. Named for zns11 at 95%", "no"],
    ["tools4noobs.com", "0 / 39 = 0%", "Established by 11 end-to-end reproductions; an mcrypt front end carrying no classical cipher", "YES"],
    ["Limfinity", "0 / 39 = 0%", "HTTP 403. Named for four Hill ciphers in a BO2 map outside this corpus", "YES"],
    ["Google Translate", "0 / 39 = 0%", "Named for gk5, which is a translation puzzle rather than a cipher", "YES"],
    ["dcode.fr", "EXCLUDED", "Owner ground truth: not used. Now corroborated by the sheet, which names it nowhere and refutes it where it tries it", "n/a"],
    ["Boxentriq", "EXCLUDED", "Launched 2018, four years after authorship. Never named in the sheet either", "n/a"],
  ],
  [2600, 1400, 4000, 1360]
));
A(callout("The completeness flag is load-bearing, not bookkeeping.", [
  "A menu obtained by search or by spot-checking is ",
  { t: "not complete", bold: true },
  ", so for those toolkits \"not in the covers set\" means \"not known to be covered\", never \"verified absent\". Only rumkin, CIMT/MEP and tools4noobs had their menus fully enumerated, so only they may have absence inferred from silence. Braingle and practicalcryptography are encoded as ",
  { t: "unknown", bold: true },
  " rather than as covering nothing, which is the difference between a gap in the corpus and a gap in our fetching.",
], "7A3030"));

A(h2("8.3 Do they explain the corpus, taken together? Yes, at 95%"));
A(table(
  ["Question", "Answer"],
  [
    ["Classical methods covered by at least one encoded toolkit", "37 / 39 = 95%"],
    ["Whole cipher set, with the 11 mcrypt primitives folded back in", "48 / 50 = 96%"],
    ["Covered with only the previously encoded toolkits, dcode removed", "19 / 39, leaving 20 uncovered"],
    ["Covered once the four researched toolkits are encoded (revision 3)", "35 / 39, leaving 4 uncovered"],
    ["Covered once the sheet's ten and rumkin's keymaker are encoded (revision 4)", "37 / 39, leaving 2 uncovered"],
    ["Cross-map ciphers left unexplained", "none"],
    ["Real named ciphers left unexplained", "NONE. Both of revision 3's, Purple and Quagmire III, are resolved in section 9.6"],
  ],
  [5200, 4160]
));
A(p([
  "So the apparent crisis was an encoding artefact, and the substantive answer to the question is affirmative. The smallest set of toolkits reaching the maximum is four:",
]));
A(...mono("  best 1-toolkit set : 27/39 = 69%   CacheSleuth\n  best 2-toolkit set : 32/39 = 82%   CacheSleuth + rumkin\n  best 3-toolkit set : 34/39 = 87%   CacheSleuth + rumkin + Crypto Corner\n  best 4-toolkit set : 35/39 = 90%   ... + CIMT/MEP"));
A(p([
  "That progression is itself informative. No single toolkit passes 69%, which independently reconfirms the multi-source conclusion by a route that does not depend on dcode at all. And the four that matter are complementary rather than redundant: each supplies something the others do not.",
]));

A(h2("8.4 Explaining the corpus is not the same as having been used"));
A(callout("The breadth objection, transferred intact.", [
  "CacheSleuth advertises over 250 ciphers and is a general-purpose geocaching decoder. A toolkit that contains nearly everything will score highly against ",
  { t: "any", italics: true },
  " corpus, so its 69% is substantially a property of CacheSleuth rather than evidence about the author. This is the same objection that made dcode's 77% uninformative, and excluding dcode does not retire it. ",
  { t: "Coverage establishes explicability, not attribution.", bold: true },
], "7A3030"));
A(p([
  "What does carry attribution weight is a method that ",
  { t: "only one", italics: true },
  " toolkit covers, because a method many toolkits carry cannot discriminate between them. Those are:",
]));
A(table(
  ["Toolkit", "Methods only it covers", "Maps", "Does the sheet agree?"],
  [
    ["rumkin.com", "letter numbers, rotate, skip, Quagmire III", "Zetsubou, Gorod Krovi", "YES, all four: zns5 90%, gk7 100%, zns8 99%, zns12 99%"],
    ["CacheSleuth", "T-9", "Zetsubou", "NO. The sheet gives zns1 to a \"Custom tool\" at 20% and says dcode's output does not match"],
    ["CIMT / MEP", "simplified Lorenz", "The Giant", "YES, at 100%, and CONFIRMED here by reproduction"],
    ["Brian Neal PURPLE", "Purple", "Der Eisendrache", "It is the sheet's own suggestion, at 30% and with an admitted output mismatch"],
  ],
  [1700, 2900, 1500, 3260]
));
A(p([
  "This table changed shape entirely in revision 4, and the change is instructive. Revision 3 had CacheSleuth uniquely supplying ten methods across five maps, which made it look like the load-bearing toolkit; adding Practical Cryptography, Braingle, cryptii v2, Cryptool Online and geocachingtoolbox absorbed nine of those ten, leaving CacheSleuth uniquely responsible for one cipher in one map, and that one the sheet actively disputes. ",
  { t: "Uniqueness in a coverage table measures how thin the table is, not how likely the tool is.", bold: true },
  " The rumkin row, by contrast, survived the additions intact and is now endorsed on all four counts by a source that knows nothing of this argument.",
]));

A(h2("8.5 The rumkin lead, retested, now survives"));
A(p([
  "The previous revision rejected the rumkin hypothesis because dcode also carried Ubchi and Skip, so their rarity did no discriminating work. With dcode excluded that objection lapses, and the hypothesis was retested rather than reinstated by default.",
]));
A(p([
  "It survives, and on better evidence than the original argument. Two corpus methods, ",
  { t: "skip", mono: true },
  " (zns8) and ",
  { t: "flag semaphore", mono: true },
  " (de1), are covered by rumkin and by no other encoded toolkit, and both are ",
  { t: "verified absent from CacheSleuth", bold: true },
  " rather than merely unlisted. A verified absence in the leading alternative is much stronger than an argument from rarity. Rumkin also uniquely supplies pigpen, letter numbers and the grid rotation gk7 needs.",
]));
A(p([
  "Two limits keep this short of an attribution. Rumkin covers 0 of 5 classical methods in Shadows of Evil and 0 of 2 in The Giant, so it cannot be the whole story, exactly as the brief anticipated. And CacheSleuth's absences come from a spot-check of a 250-plus menu rather than a full enumeration, so \"verified absent\" here means \"read off the decoder list and not found\", not \"exhaustively excluded\".",
]));
A(callout("Revision 4: a second route reaches the same conclusion, and knows nothing of the first.", [
  "The community sheet makes rumkin its ",
  { t: "most-attributed identified tool, 11 of 83 rows", bold: true },
  ", ahead of every other named site, and it endorses every one of the four methods this argument says only rumkin supplies. It reaches that by a completely different method: it never counts menus, it reasons from output formatting, whitespace handling and default parameter values. The sheet's de10 note is the clearest example, and it is a fingerprint of exactly the kind section 6 says to pursue: ",
  { t: "\"Rumkin has really strange rules about how they handle whitespace in inputs (across all transposition ciphers, not just this one) that make them stick out like a sore thumb compared to other implementations.\"", italics: true },
  " Two independent routes agreeing is the strongest evidence available here, and it is stronger than either route alone by more than the sum.",
], S.ACCENT));

A(h2("8.6 A claim from the previous revision that is now superseded"));
A(callout("Superseded, and it was stated too strongly.", [
  "Revision 2 called the straddling checkerboard ",
  { t: "\"the sharpest single lead this document produces\"", italics: true },
  ", on the grounds that it was used in two maps and appeared on no verifiable menu. Both CacheSleuth and Crypto Corner carry it. The claim was not false given what the table then held, but the table was wrong: CacheSleuth had already been researched and simply had not been entered. The lead is withdrawn as a lead, and what remains of it is the ",
  { t: "tell", italics: true },
  " rather than the absence, which is stated in section 8.7.",
], S.ACCENT));

A(h2("8.7 The uncovered set, ranked by discriminating power"));
A(p([
  "Ranked with cross-map ciphers weighted highest, since a cipher used in two maps is far likelier to come from a tool the author actually had than a one-off; then real named ciphers above bespoke constructions; then whether an implementation tell is held to match candidates against.",
]));
A(table(
  ["Method", "Maps", "Status", "Assessment"],
  [
    ["modified binary (DNA sequence)", "Zetsubou", "not listed anywhere; no verified absence", "Bespoke. The record gives the mapping (G,T = 1; a,c = 0), which is the author's own invention. No tool would carry it. The sheet independently agrees, attributing zns9 to a \"Custom tool\" at 80%."],
    ["math formulas to obfuscate information", "Der Eisendrache", "not listed anywhere; no verified absence", "A prose description of a bespoke puzzle, not a named technique. The sheet independently agrees, attributing de8 to \"Manually encoded\" at 50%."],
  ],
  [2200, 1400, 2200, 3560]
));
A(callout("Both of revision 3's real unexplained ciphers are gone, and the residue is not cipher-shaped.", [
  "Quagmire III and Purple are resolved in section 9.6, by two quite different failures of this document's method: one because a menu enumeration counts pages rather than capabilities, one because the search was scoped to web pages at all. What is left is two bespoke constructions, and the community sheet reaches the same verdict on both by itself, calling one a custom tool and the other manually encoded. ",
  { t: "Neither party can name a source because there is no source to name.", bold: true },
], "7A3030"));
A(p([
  "The implementation tells stay attached to their ciphers whether or not the cipher is covered, because they are what will eventually identify a tool rather than merely permit one. After section 9 the ranking of them has changed. ",
  { t: "rev1's 52-character mixed-case Beaufort alphabet is now the strongest by a clear margin", bold: true },
  ": it is RECORDED rather than reconstructed, it is unexplained by any tool in the table, and section 9.5 closes the one shortcut that looked like explaining it. rev3's straddling checkerboard is no longer a tell but an answer, and its row selectors {1,3} turn out to have been the wrong thing to have been carrying: they are an artefact of this project's own base10 relabelling. rev11's Trifid alphabet filled down the columns with a whole-message period is unchanged, still reconstructed, and still corroborated as a habit by de4's recorded whole-message Bifid period.",
]));

A(h2("8.8 Per-map coverage"));
A(p("Classical cipher methods per map, and how many each toolkit's menu contains:"));
A(table(
  ["Map", "Methods", "CacheSleuth", "Practical Crypto", "rumkin", "Braingle", "Crypto Corner", "geocaching toolbox", "Cryptool Online", "cryptii v2", "CIMT / MEP", "Union"],
  [
    ["Shadows of Evil", "5", "5", "4", "0", "2", "2", "2", "0", "0", "0", "5 of 5"],
    ["The Giant", "2", "1", "1", "0", "0", "0", "0", "1", "1", "2", "2 of 2"],
    ["Der Eisendrache", "10", "6", "4", "4", "3", "2", "2", "1", "1", "0", "9 of 10"],
    ["Zetsubou No Shima", "8", "4", "1", "6", "3", "2", "3", "2", "1", "1", "7 of 8"],
    ["Gorod Krovi", "9", "7", "2", "4", "4", "3", "1", "2", "5", "2", "9 of 9"],
    ["Revelations", "9", "8", "9", "4", "5", "5", "6", "3", "0", "2", "9 of 9"],
  ],
  [1400, 700, 900, 950, 700, 750, 800, 950, 950, 750, 800, 720]
));
A(p([
  "Four of six maps are fully covered by the union, and the two with residue have exactly the two bespoke methods of section 8.7 as that residue. Three things in this table are worth reading rather than skimming. ",
  { t: "Practical Cryptography covers 9 of Revelations' 9 classical methods and 4 of Shadows of Evil's 5", bold: true },
  ", which is the strongest per-map showing of any general toolkit and is the row the community sheet independently makes attributions on. ",
  { t: "CIMT/MEP alone accounts for both of The Giant's", bold: true },
  ", the only complete single-toolkit per-map cell, confirmed for one of the two by reproduction and endorsed by the sheet at 100%. And rumkin now leads Zetsubou at 6 of 8, up from 4, entirely because of the keymaker correction in section 9.6.",
]));

// ---------------------------------------------------------------- 9 (NEW)
A(h1("9. The Community Attribution Sheet"));
A(p([
  "Everything above section 8 is ",
  { t: "inference", italics: true },
  ": a tool's menu contains a cipher, therefore the tool could have been the source. This section introduces a source of a different kind. Reproduce it with ",
  { t: "python3 papers/analysis/community_sources.py", mono: true },
  ".",
]));

A(h2("9.1 What the sheet is, and how much weight it carries"));
A(p([
  { t: "data/zombies_sources.csv", mono: true },
  " is the community's \"Zombies Sources\" sheet: 83 rows across World at War, Black Ops 1, Black Ops 2 and Black Ops 3, with columns Game, Map, Cipher, Type, Encoding Source, Confidence and Explanation. It records, per cipher, ",
  { t: "which website or tool the community believes was used", bold: true },
  ", with a confidence percentage and a prose justification. 62 of the 83 rows are Black Ops 3, which is this corpus.",
]));
A(p([
  "This is direct human attribution by people who worked the problem, much of it with the sites in front of them. Where it conflicts with this document's menu-coverage inference, ",
  { t: "the sheet is the stronger evidence", bold: true },
  " and this revision defers to it.",
]));
A(callout("It is a high-quality primary source with stated uncertainty, not ground truth.", [
  "15 of 83 Encoding Source cells read \"Unknown\". Confidences run from 25% to 100%. The author's own note on the Revelations rows is ",
  { t: "\"I will do a second draft later where I add more notes to these ciphers, because there are things we know, but for now I'm pretty knackered\"", italics: true },
  ". It is read here the way a careful witness statement is read: seriously, in detail, and with its own hedges preserved rather than rounded away.",
], S.ACCENT));

A(h2("9.2 The numbering does not match, and reading across by number would be wrong"));
A(p([
  "The sheet uses ",
  { t: "Reddit numbering", bold: true },
  "; this corpus uses ",
  { t: "irebased texture-file-alphabetical numbering", bold: true },
  ". For five of the six maps these coincide. For Revelations they do not, and every one of the four Revelations rows for which a mapping is known would be misread by number:",
]));
A(table(
  ["Sheet row", "Sheet Type", "Our record", "Our recorded chain"],
  [
    ["Rev #1", "Reverse / Affine", "rev13", "reverse, then affine a=15 b=19"],
    ["Rev #2", "Polybius / ADFGX", "rev4", "adfgx"],
    ["Rev #3", "Reverse / Columnar Transposition", "rev14", "columnar transposition"],
    ["Rev #4", "Reverse / ASCII = Octal / Straddling Checkerboard", "rev3", "base10, straddling checkerboard, substitution"],
  ],
  [1300, 3400, 1200, 3460]
));
A(p([
  "So the mapping is ",
  { t: "derived and asserted in code", bold: true },
  " rather than hand-transcribed. The script matches each sheet ",
  { t: "Type", mono: true },
  " against the recorded solution chains and accepts only unique matches; then asks, per map, whether every pair it found happens to satisfy sheet number equals corpus number, and extends by number only where that test passes; then closes any residue that is uniquely forced. The four rows above fall out of the first phase alone, and are then asserted against the independently verified list, so a regression in the matcher is a failure rather than a silently wrong document. The sheet's spelling \"Revalations\" and its casing of \"Zetsubou no Shima\" are handled by name normalisation, as is the curly apostrophe in \"Tupper's Formula\" and the approximately-equal sign in \"ASCII = Octal\", each of which defeats a naive lookup.",
]));
A(table(
  ["Map", "Sheet rows", "Mapped", "Numbering is identity?", "Unmapped"],
  [
    ["Shadows of Evil", "5", "5", "yes", "none"],
    ["The Giant", "5", "5", "yes", "none"],
    ["Der Eisendrache", "11", "11", "yes", "none"],
    ["Zetsubou no Shima", "13", "13", "yes", "none"],
    ["Gorod Krovi", "14", "14", "yes", "none"],
    ["Revelations", "14", "4", "NO", "10, all of Type \"Unknown\""],
    ["WaW, BO1, BO2", "21", "0", "n/a", "21, maps outside this corpus"],
    ["TOTAL", "83", "52", "", "31"],
  ],
  [1900, 1200, 1000, 2200, 3060]
));
A(callout("The ten unmapped Revelations rows are unmapped because they are empty, not because the mapping is hard.", [
  "All ten read Type \"Unknown\", Encoding Source \"Unknown\", Confidence \"N/A\". There is nothing in them to match against, and ten factorial orderings are equally consistent with the sheet, so the script refuses to pair them. This matters more than it looks: it means the ",
  { t: "consequences for REV7 do not depend on recovering the mapping at all", bold: true },
  ". Whichever of those ten rows is our rev7, it attributes nothing. Our rev1, rev2, rev5, rev6, rev7, rev8, rev9, rev10, rev11 and rev12 are all in that position.",
], "7A3030"));
A(p([
  "Two mappings are weaker than the rest and are labelled as such in the script's output. ",
  { t: "GK Scrap #1", mono: true },
  " and ",
  { t: "GK Scrap #2", mono: true },
  " both read Type \"Assembly\" against gk13 and gk14, whose recorded descriptions are identical strings, so the pairing is by order and either order is equally defensible. ",
  { t: "ZnS Scrap", mono: true },
  " is closed by elimination alone: the sheet calls it a grille, our zns13 is recorded as mapping prime numbers to letters, and the two descriptions do not obviously agree.",
]));

A(h2("9.3 Three findings this project derived independently, and the sheet confirms"));
A(p([
  "Each of the three was reached here from the artefact, and written up, before the sheet was read. Each is checked against the sheet's own words below rather than summarised.",
]));
A(table(
  ["Finding", "Our route", "The sheet's words", "Status"],
  [
    [
      "TG3's tool is the CIMT/MEP Simplified Lorenz toolkit",
      "Recovered a keystream of exact period 28 from the ciphertext, factored it uniquely as lcm(14,4), and only then looked for a tool with a 14-cam and a 4-cam wheel. Then reproduced 48 of 48.",
      "Source \"CIMT\" at 100%: \"This is the only place this cipher exists, as it's a custom implementation of a different more standard Lorenz cipher. As such it's hard to argue with.\"",
      "TWO INDEPENDENT ROUTES AGREE",
    ],
    [
      "rev4's ADFGX transposition key is simply ZOMBIES, and the recorded number 30957298 explains nothing",
      "Ranked ZOMBIES alphabetically to 7541326, reproduced the plaintext under exactly that seven-column order, and recorded 30957298 as unexplained rather than reinterpreting it.",
      "\"The key actually is Zombies... All the confusion came from poor (and quite frankly incorrect) explanations of how the key 30957298 somehow correlated to...\" and, on the permutation reading, \"which is utter nonsense logically\".",
      "TWO INDEPENDENT ROUTES AGREE",
    ],
    [
      "rev14's columnar transposition matches no standard keyed columnar",
      "Tested every width dividing 162 and, via the within-block step invariant, every column key order at each width simultaneously. Measured step is +1 at 108 of 161 adjacent pairs, where a standard columnar of width above 1 has step +1 nowhere inside a block.",
      "Source \"Unknown\": \"The true scheme (assuming it uses a web tool) is probably still unknown, as my testing with columnar encoders online have not output the way I need them to.\"",
      "TWO INDEPENDENT ROUTES AGREE, ON A NEGATIVE",
    ],
  ],
  [1800, 3000, 3000, 1560]
));
A(callout("The third is the most valuable of the three, because negatives are the hardest thing to agree on by accident.", [
  "A positive can be reached by two routes because the answer is findable. A negative can be reached by two routes only by two parties independently exhausting a space and coming up empty, and there is no shared bias that produces that. The sheet's author tried columnar encoders by hand; this project tested every width and, through a step invariant, every key order. Neither found a fit. ",
  { t: "rev14's transposition is not a standard keyed columnar, and that is now established twice over.", bold: true },
], S.ACCENT));

A(h2("9.4 What the sheet settles: rev3's straddling checkerboard"));
A(p([
  "The previous revision's top-ranked next action was to find out whether a tool's straddling checkerboard exposes configurable row selectors, and to what. The sheet answers the underlying question directly, for the row it calls Rev #4 and this corpus calls rev3:",
]));
A(callout("The sheet's claim.", [
  { t: "\"This 95% is misleading, we are 100% sure Practical Cryptography was used for the Straddling Checkerboard layer due to its use of the site's default key.\"", italics: true },
], S.ACCENT));
A(p([
  "practicalcryptography.com still refuses the connection from this environment, so the default was obtained from two secondary sources that each name it as their origin and that agree with each other: a.tools, which reproduces the site's pre-filled form defaults, and the Call of Duty wiki, which quotes the same values. The default key is ",
  { t: "FKMCPDYEHBIGQROSAZLUTJNWVX", mono: true },
  " with spare positions ",
  { t: "3 and 7", mono: true },
  ".",
]));
A(p([
  "There is a second, cleaner corroboration of the spare positions that does not go through rev3 at all. Our ",
  { t: "soe5", mono: true },
  " record carries the recorded configuration ",
  { t: "\"spare positions 3 and 7\"", mono: true },
  ", and the sheet's SoE #5 row says of the same cipher that the spare cells ",
  { t: "\"are also defaults of the site\"", italics: true },
  ". Two independent records, the same value, neither derived from the other.",
]));

A(h3("Why a string comparison would have been meaningless"));
A(p([
  "Our recovered layout is ",
  { t: "C.D..YFE.W / NXM.T...U. / .SOGIAR.BH", mono: true },
  " with straddle digits {1,3}, the unique parse. Comparing that to the default key as a string, and concluding from {1,3} against {3,7} that the claim is refuted, would be wrong twice over:",
]));
A(li([
  { t: "The digit labels are ours, not the author's. ", bold: true },
  "rev3's chain begins with ",
  { t: "base10", mono: true },
  ", which assigns digits to the ten ciphertext glyphs ",
  { t: "by order of appearance", italics: true },
  ". Relabelling the ten digits carries any checkerboard to an equivalent one, so the straddle digits {1,3} carry no information about the author's {3,7}. (A constant ASCII offset does not recover the true labelling either: rev3's glyph set spans 0x3C to 0x47 with D and E missing, and a constant offset cannot map a non-contiguous set onto the contiguous digits.)",
]));
A(li([
  { t: "The letters are the composite's, not the board's. ", bold: true },
  "The recorded ",
  { t: "substitution", mono: true },
  " step is not separately identifiable from the checkerboard, so our layout states the composite of the two. Any board is compatible with any composite via some substitution, which makes the letters, taken alone, vacuous.",
]));
A(p([
  "What survives a digit relabelling is the ",
  { t: "partition of letters by code length and row", bold: true },
  ": which letters get a one-digit code, and which of the two straddle rows the others sit in. No relabelling can move a letter between those blocks. That is testable, and it is the test run:",
]));
A(table(
  ["Test", "Result"],
  [
    ["Exact isomorphism, over all 45 spare pairs, both row orders, and all 378 placements of the two empty cells", "0 found. The claim is not literally true."],
    ["Block agreement: attested letters sitting in the block the PC default puts them in", "17 of 19"],
    ["Letters that disagree", "M and W, and nothing else"],
    ["Null: random 26-letter alphabets in the same 8/10/8 block shape, n = 100000", "expected agreement 9.24 of 19; P(agreement >= 17) = 0.00001"],
    ["Cells reproducing the default letter for letter, under the single digit relabelling the agreeing cells force", "16 of 19"],
  ],
  [5600, 3760]
));
A(callout("Verdict: corroborated in substance, overstated in degree.", [
  "The sheet's \"100% sure ... due to its use of the site's default key\" is not reproduced literally, and 100% is too strong: three cells do not fit any placement of that key. But 17 of 19 attested letters land in the right block and 16 of 19 reproduce the default cell for cell, against a null expectation near 9. This project's reconstruction and the community's attribution ",
  { t: "arrived at the same board by wholly different routes", bold: true },
  ", one from a 61-character plaintext and one from a memory of the site. The sheet's own SoE #5 row anticipates the residue, calling that map's alphabet ",
  { t: "\"weirdly similar (but not outright identical) to the default alphabet provided\"", italics: true },
  " and guessing at \"a flaw in the pseudorandom alphabet generation they have implemented\".",
], "7A3030"));

A(h2("9.5 A behavioural fingerprint, and the inference it does not license"));
A(p([
  "The sheet attributes Rev #1, our rev13, to Rumkin at 85%, on the ground that it ",
  { t: "\"has the perfect casing preserving / punctuation preserving / spacing preserving trio that it is so well identified with by now\"", italics: true },
  ". That is a ",
  { t: "behavioural", italics: true },
  " fingerprint rather than a menu one, and it is a better class of evidence than anything in section 8, because it is a property of what the tool does rather than of what it lists. It is checkable against our own data, and it checks out:",
]));
A(...mono("  rev13 reversed ciphertext vs recorded plaintext, 339 characters\n    every non-letter identical and in the same position   yes\n    every letter's case identical                         yes\n    carried through unchanged: 69 spaces, 11 punctuation marks, 8 capitals\n    a case-preserving 26-letter affine, a=15 b=19, reproduces the plaintext"));
A(p([
  "The tempting next step is to carry this to ",
  { t: "rev1", mono: true },
  ", whose ",
  { t: "RECORDED", bold: true },
  " Beaufort alphabet is the 52 mixed-case characters A-Za-z and which section 8.7 calls the strongest tell in the corpus, on the reasoning that a case-preserving tool is effectively operating on 52 characters. ",
  { t: "That step is invalid, and it was tested rather than waved away.", bold: true },
]));
A(...mono("  rev1 ciphertext, Beaufort under key ZOMBIES\n    52-character mixed-case alphabet   LeIXjxfrjSpfgR1RnFDIZr0t2JDCRjgueCZqdIiZwvNX\n    case-preserving 26-letter          LeIxJXfrjsPfGR1RnFdIzr0t2JDcrJgueCzQdIizWVnx\n    identical                          no, agreement 38 of 64"));
A(p([
  "A 52-symbol cyclic group and a 26-symbol group applied twice with case carried alongside are different functions, and they disagree on 26 of rev1's 64 characters. Case preservation is a property of how a tool handles characters it is not enciphering; a 52-character alphabet is a statement about the group the cipher operates in. rev1 and rev13 are different ciphers and the rev13 fingerprint does not transfer. ",
  { t: "rev1's 52-character alphabet remains unexplained and remains the strongest single tell in the corpus.", bold: true },
]));

A(h2("9.6 New tools, and what they do to the uncovered set"));
A(p([
  "The sheet names ten tools this document had never considered. All ten are now in the coverage table, each with its menu status and each with its evidential basis recorded in the ",
  { t: "status", mono: true },
  " string rather than blended into the coverage number.",
]));
A(table(
  ["Tool", "Sheet rows", "Classical coverage", "Menu status"],
  [
    ["Practical Cryptography", "5 (soe1, soe3, soe5, tg5, rev3), two at 100%", "18 / 39 = 46%", "Site still refuses the connection. Menu from search snapshots and from a.tools, which reproduces its defaults. Not complete."],
    ["Cryptool Online", "8, mostly Der Eisendrache", "14 / 39 = 36%", "VERIFIED LIVE 2026, complete 29-application menu. See the conflict in 9.7."],
    ["cryptii v2", "8, mostly Gorod Krovi", "7 / 39 = 18%", "VERIFIED LIVE 2026 at the v2 archive URL, complete 22-format menu. Not the same object as the cryptii v3 row."],
    ["Braingle", "2 (soe2, rev4)", "15 / 39 = 38%", "Direct fetch still HTTP 403. Menu from search snapshots of its per-cipher pages, so spot-checked. Promoted from UNKNOWN."],
    ["Brian Neal PURPLE", "1 (de11), at 30%, the sheet's lowest", "1 / 39 = 3%", "A Python package, first released around 2013. Not a web page, which is why the web-toolkit search could not find it. Read the confidence: see below."],
    ["Limfinity", "4, all Hill ciphers in Mob of the Dead", "0 / 39 = 0%", "HTTP 403. Covers nothing in these six maps; entered so its zero contribution is a stated fact."],
    ["PMacg", "1 (soe4), at 90%", "1 / 39 = 3%", "Site not located by this project. The sheet's reasoning is specific and checkable in principle."],
    ["Woodmann", "1 (zns11), at 95%", "1 / 39 = 3%", "Reachable but its pages returned no content. A reverse-engineering archive rather than a cipher toolkit."],
    ["Google Translate", "1 (gk5), at 90%", "0 / 39 = 0%", "gk5 is a translation puzzle, not a cipher method. A reminder that some records need a translator."],
    ["geocachingtoolbox.com", "0. Runner-up in two Explanations; the owner's \"geo toolbox\"", "12 / 39 = 31%", "VERIFIED LIVE 2026, complete menu. Added on the owner's hypothesis, not on the sheet's authority."],
  ],
  [1900, 2200, 1400, 3860]
));
A(p("The effect on the question section 8.3 asks is:"));
A(table(
  ["Table state", "Classical methods covered", "Uncovered"],
  [
    ["Revision 2's toolkits, dcode removed", "19 / 39", "20"],
    ["Plus the four researched-but-unencoded toolkits (revision 3)", "35 / 39 = 90%", "4"],
    ["Plus the ten the sheet names, and rumkin's keymaker (revision 4)", "37 / 39 = 95%", "2"],
    ["Whole cipher set, with the 11 mcrypt primitives folded back in", "48 / 50 = 96%", "2"],
  ],
  [4400, 2600, 2360]
));
A(callout("The percentage is not the finding. Which ciphers left the list is.", [
  "The two still uncovered are Der Eisendrache's \"math formulas to obfuscate information\" and Zetsubou's DNA-sequence binary, and neither is a cipher any tool would ever carry: one is a prose description of a bespoke puzzle and the other is the author's own G,T = 1 and a,c = 0 mapping. ",
  { t: "No real cipher in this corpus is now without an identified source.", bold: true },
  " Revision 3 said there were two. Both left, and they left by completely different routes, each instructive.",
], "7A3030"));
A(p([
  { t: "Quagmire III left because this document was measuring the wrong thing. ", bold: true },
  "The sheet attributes zns12 to rumkin at 99%, with the reason: ",
  { t: "\"Keyed alphabet is generated using Rumkin's keymaker settings. There aren't really other sites with settings as convenient as these for generating an alphabet based on keyword Shinonuma that look like our provided alphabet.\"", italics: true },
  " Rumkin's menu was fully enumerated by this project and does not list a Quagmire III, because the keymaker is a ",
  { t: "setting on the Vigenere page", italics: true },
  ", not a page of its own. The same explains zns7's keyed Caesar, attributed at 95%. ",
  { t: "A menu enumeration counts pages, not capabilities, and therefore undercounts.", bold: true },
  " That is the single largest correction the sheet makes to this document's method, and it applies to every ",
  { t: "complete", mono: true },
  " flag in section 8: they mean complete at page level. Both methods are now in rumkin's covers set on the sheet's testimony and are labelled as such, since they are not on the menu.",
]));
A(p([
  { t: "Purple left because the search was scoped to the wrong kind of thing, ", bold: true },
  "and it should be read with the sheet's own hedge attached rather than as a clean answer. The sheet gives de11 to Brian Neal's PURPLE at 30%, its lowest confidence on any named tool, and says in the same breath: ",
  { t: "\"Does not match outputting at all, does however match with the default key. However, the default keys here are much more standard than the other default keys we have used to identify other sites... I will be returning to this to see if I can find a tool with better output.\"", italics: true },
  " So de11's ",
  { t: "attribution", italics: true },
  " is not settled. What is settled is that a period-plausible implementation of Purple exists, which answers explicability and not authorship, and that it is ",
  { t: "not a web page", bold: true },
  ". This document's search was scoped to web toolkits throughout, and Purple is precisely the cipher least likely to sit on one.",
]));
A(p([
  "Two independent routes also converge on ",
  { t: "rumkin", bold: true },
  ". Section 8.5 revived it because Skip and flag semaphore are covered by rumkin and by no other encoded toolkit and are verified absent from CacheSleuth. The sheet, which knows nothing of that argument, makes rumkin its most-attributed identified tool at 11 of 83 rows, ahead of every other named site. The two routes are fully independent and they agree.",
]));
A(p([
  "A quieter observation cuts the other way. ",
  { t: "CacheSleuth leads the coverage table at 69% and is named in none of the sheet's 83 rows", bold: true },
  ", nor discussed in any of its explanations. That is not evidence of absence. It is a reminder that the toolkit which explains a corpus best is not thereby the toolkit anyone used, which is section 8.4's point arriving from a new direction.",
]));

A(h2("9.7 Where the sheet and this analysis conflict"));
A(p([
  "The two kinds of evidence are made to talk to each other systematically rather than anecdotally. For every mapped row whose named tool appears in the coverage table, the script asks whether the union of the named tools' menus carries each cipher-role method of the record. The union matters, because a row like rev3 names one tool per layer and it would be wrong to demand that either tool account for both.",
]));
A(table(
  ["Outcome", "Rows"],
  [
    ["The sheet's tool has the cipher on its menu", "26"],
    ["The sheet's tool does not", "7"],
  ],
  [6800, 2560]
));
A(p([
  "26 of 33 is a high rate of agreement between two evidence sources that share no method, and it is worth stating as a result in its own right: it means the coverage table's menus are broadly right about what these tools do. The seven disagreements are set out below. Two further rows that would have counted as disagreements are instead a correction to this document's method and are handled in 9.6.",
]));
A(table(
  ["Conflict", "The sheet says", "This analysis says", "Handling"],
  [
    [
      "Cryptool Online for five Der Eisendrache ciphers",
      "de3 Playfair 85%, de4 Bifid 90%, de5 Navajo 75%, de7 AMSCO 80%, de9 Trithemius 75%",
      "This project's 2026 enumeration of that site found none of those five. It did find the homophonic tool the sheet uses for de6 at 100%",
      "LEFT STANDING. Either the 2016 site was far broader than the 2026 one, which is exactly what section 0's blocker prevents checking, or the attribution is wrong. The covers set is written to the MENU rather than to the sheet, so the disagreement stays visible in the script's output instead of being encoded away. It is a disagreement, not a refutation: that menu is not complete, so 'not found' means 'not known to be covered'.",
    ],
    [
      "rev4's ADFGX",
      "Braingle for the Polybius layer, Cryptool Online for ADFGX, but only at 40%",
      "Neither menu carries ADFGX",
      "NO CONFLICT. The sheet says so itself: 'I was not able to identify an ADFGX tool that output in groups of 45, so I have gone with the previous prospect.' Both parties record the ADFGX layer as unattributed.",
    ],
    [
      "rev3's checkerboard at 100%",
      "\"we are 100% sure Practical Cryptography was used ... due to its use of the site's default key\"",
      "17 of 19 blocks and 16 of 19 cells agree with that default, but no exact fit exists under any placement",
      "PARTIALLY UPHELD. The attribution stands; the 100% does not. See 9.4.",
    ],
    [
      "gk12",
      "Type \"Unsolved\", attributed to Rumkin at 90%",
      "The corpus records gk12 as an autokey with key TRYTHIS over the alphabet ZOMBIESAREEVERYWHERE, both RECORDED",
      "OUR RECORD IS BETTER INFORMED. The sheet predates or missed the solve. Its Rumkin attribution is retained as a lead, since rumkin does carry an autokey.",
    ],
  ],
  [1500, 2700, 2700, 2860]
));
A(p([
  "One apparent conflict dissolves on inspection and is worth stating because the naive reading is the wrong one. ",
  { t: "TG5's Enigma is attributed to Practical Cryptography at 100%", bold: true },
  ", with the reasoning ",
  { t: "\"Uses the site's default settings for 2 out of the 4 Enigma key parameters, otherwise matches output.\"", italics: true },
  " Section 11 records that TG5's tool is unidentified after eight simulators were checked, none using the recorded label set of \"Reflector UKW B\" with \"Key settings\" and \"Ring settings\". These do not contradict each other: this project searched for a matching ",
  { t: "vocabulary", italics: true },
  " and the sheet matched on ",
  { t: "default parameter values", italics: true },
  ". Practical Cryptography was never among the eight, because it was unreachable. It is now the leading candidate for TG5 and the check is cheap once the site is reachable: does its Enigma form default to two of UKW-B, rotors I II III, rings AAD and key WAD?",
]));

A(h2("9.8 The owner's working hypotheses, and the tool that is missing from every menu"));
A(p([
  "The owner has supplied per-cipher hypotheses for Revelations. They repeatedly name a \"geo toolbox\", almost certainly geocachingtoolbox.com, which appears in no Encoding Source cell in the sheet and had never been in this document's table. It is now encoded and tested, and it earns its place: it is the runner-up in two of the sheet's own explanations, for soe3 (\"I only found Practical Cryptography and Geocaching Toolbox with a deranged alphabet generator\") and for a Black Ops 2 ADFGX.",
]));
A(table(
  ["Hypothesis", "Testable now?", "Result"],
  [
    ["rev2, rev4, rev7, rev11: geo toolbox for hex and ASCII conversions, reverse, ADFGX", "partly", "Its complete 2026 menu does carry ADFGX, affine, a text reverse and an ASCII conversion. It does NOT carry a hex conversion."],
    ["rev12: a webtool with ROT-6", "yes", "REFUTED for this site. geocachingtoolbox offers ROT13 only, not an arbitrary ROT-N."],
    ["rev13: a site with affine", "yes", "Consistent. Both geocachingtoolbox and rumkin carry affine; the sheet independently attributes rev13 to rumkin on behavioural grounds, which discriminates where the menu cannot."],
    ["rev1: Cryptool Online for the Beaufort alphabet settings", "yes", "REFUTED as stated. Cryptool Online's complete 2026 menu has no Beaufort at all, configurable or otherwise."],
    ["rev3: geo toolbox plus one other for the straddling checkerboard", "yes", "geocachingtoolbox is VERIFIED ABSENT for the straddling checkerboard. Section 9.4 attributes that layer to Practical Cryptography instead."],
    ["rev6, rev9, rev10: a missing zero-pad encoding tool", "no", "Not found. See below; this is the most concrete open lead in the document."],
  ],
  [3000, 1300, 5560]
));
A(h3("The zero-pad tell, measured"));
A(p([
  "The hypotheses name, for three separate ciphers, a tool that renders bytes as fixed-width zero-padded decimal. That is a ",
  { t: "rendering", italics: true },
  " choice rather than a cipher, which makes it a far better search term than any cipher name, and rev6's ciphertext is that format in the raw so it can be measured rather than asserted:",
]));
A(...mono("  rev6 ciphertext, first tokens   100 097 102 050 048 050\n  tokens                          256\n  distinct token widths           {3}\n  tokens a non-padding encoder would have shortened   198  (77%)"));
A(p([
  "Every token is exactly three digits and none is ever one or two, so this is padding and not coincidence. rev9's recorded chain places a ",
  { t: "decimal", mono: true },
  " decode immediately after its DES layer, so the same renderer produced rev9's intermediate; rev10 places an ",
  { t: "octal", mono: true },
  " step in the same position. This matters to the engine directly, because rev9's DES layer emits exactly this format.",
]));
A(callout("Searched, and not found.", [
  "No toolkit in the coverage table is known to emit fixed-width zero-padded decimal. geocachingtoolbox's ASCII conversion does not pad, and cryptii v2's Decimal format does not pad. The tool stays ",
  { t: "unidentified", bold: true },
  ", and it is the single most concrete searchable behaviour anyone has offered: one tool, three ciphers, an unusual and easily recognised output format, and a second requirement (the same site also carries a substitution) that would confirm it immediately.",
], S.ACCENT));

// ---------------------------------------------------------------- 10
A(h1("10. TG3: the Charset Tension, Resolved"));
A(p("The owner's observation was that TG3's ciphertext,"));
A(...mono("  NMFU3DNILVAXTPPH9AYHRXUM3PDBVMHN/CANVGPYS+3HGQKH"));
A(p([
  "is 48 characters over an alphabet of 25 including the digits 3 and 9 and the symbols + and /, which reads as a base64 subset, while its recorded solution is a simplified Lorenz, and Lorenz operates on 5-bit Baudot rather than base64. The tension is real on its face and it resolves completely.",
]));

A(h2("10.1 The alphabet is ITA2 in Bletchley Park notation, not base64"));
A(p([
  "ITA2 has 32 five-bit codes: 26 letters and six control codes. In the notation used in the General Report on Tunny, those six controls are written as printable glyphs:",
]));
A(table(
  ["Glyph", "Bits", "Meaning", "In TG3?"],
  [
    ["/", "00000", "null", "yes"],
    ["9", "00100", "space", "yes"],
    ["3", "00010", "carriage return", "yes"],
    ["4", "01000", "line feed", "no"],
    ["+", "11011", "figure shift", "yes"],
    ["8 (or -)", "11111", "letter shift", "no"],
  ],
  [1200, 1400, 2600, 4160]
));
A(p([
  "TG3's four non-letter symbols are exactly four of those six, and the CIMT toolkit's documented alphabet contains all four and nothing else. The base64 resemblance is a coincidence of glyph shapes. ",
  { t: "TG3 is Baudot all the way down, exactly as a Lorenz cipher requires.", bold: true },
]));

A(h2("10.2 The cipher is proved to be an XOR stream over ITA2"));
A(p([
  "The recorded plaintext, stripped of spaces, is 48 letters, matching the 48 ciphertext symbols one for one. Reading both in ITA2 numeric order and XORing gives:",
]));
A(...mono("  ciphertext  NMFU3DNILVAXTPPH9AYHRXUM3PDBVMHN/CANVGPYS+3HGQKH\n  plaintext   WHENFINISHEDWEWILLRETURNTOTHEHOUSEANDTHEINFINITE\n  keystream   83NJSK//QR4HAQSLPZ8YGGFTOCBF83NJSK//QR4HAQSLPZ8Y"));
A(p([
  "The keystream has an ",
  { t: "exact period of 28", bold: true },
  ": the last 20 symbols repeat the first 20 with zero exceptions. For a random ITA2 stream that has probability 32 to the minus 20, about 1 in 10 to the 30.",
]));
A(callout("The combiner is proved to be XOR, not modular addition.", [
  "At the 20 overlapping positions the plaintext differs between i and i+28 at 17 of 20, yet the XOR of ciphertext and plaintext is identical at all 20. Under modular addition the XOR difference would depend on the plaintext and could not repeat.",
], S.ACCENT));

A(h2("10.3 The recorded numbers are start positions, not wheel lengths"));
A(p([
  "lcm(9, 4) = 36, and the observed period is 28. Period-36 agreement in the recovered keystream is 0 of 12, so wheel lengths of 9 and 4 are refuted directly. Every alternative alignment was tested, including the hypothesis that the tool consumed the spaced 58-symbol message while the published ciphertext shows only the 48 letter positions, and lead-ins of 1, 2 and 3 symbols. (9, 4) fits none of them.",
]));
A(p([
  "Searching all factorisations with lcm 28 gives exactly one in which both wheels are shorter than the full period: ",
  { t: "4 and 14", bold: true },
  ". Since a start position of 9 requires a wheel of at least 9 positions, the 9 belongs to the 14-position wheel and the 4 to the 4-position wheel. Both are in range, and the toolkit's \"56 combinations (14 x 4)\" is precisely the space those two numbers index.",
]));

A(h2("10.4 End-to-end reproduction"));
A(...mono("  alphabet     /T3O9HNM4LRGIPCVEZDBSYFXAWJ+UQK8   (ITA2, numeric order 0..31)\n  K wheel      ABCDEFGHIJKLMN   14 cams, start position 9\n  S wheel      AABB              4 cams, start position 4\n  combiner     XOR of the ITA2 codes (teleprinter addition)\n  key period   lcm(14, 4) = 28\n\n  decrypted    WHENFINISHEDWEWILLRETURNTOTHEHOUSEANDTHEINFINITE\n  recorded     WHENFINISHEDWEWILLRETURNTOTHEHOUSEANDTHEINFINITE\n  match        48 / 48"));
A(p([
  "The S wheel pattern ",
  { t: "AABB", mono: true },
  " is derived rather than quoted, since the page does not print it; it is what the known plaintext forces once the K wheel and both start positions are fixed. That it comes out as a consistent 4-cam pattern is itself a check.",
]));

A(h2("10.5 The historical machine, for contrast"));
A(p([
  "The real SZ40/42 has twelve wheels: five chi of lengths 41, 31, 29, 26 and 23, five psi of 43, 47, 51, 53 and 59, and two motor wheels of 61 and 37, with the psi wheels stuttering under motor control. Its key period is about 1.6 times 10 to the 19. None of its wheel lengths is 4 or 14. Consistently, all five ITA2 impulses of the recovered keystream advance in lockstep, so this is one 5-bit wheel pair rather than ten independent binary wheels. \"Simplified\" is doing real work in the record's phrasing.",
]));

// ---------------------------------------------------------------- 11
A(h1("11. TG5: the Enigma Record Confirmed, the Tool Not"));
A(p([
  "TG5's newly supplied ciphertext is 46 characters, pure A to Z, matching the 46 letters of the recorded plaintext. No position has ciphertext equal to plaintext, which is necessary since Enigma can never encipher a letter to itself. The record does not say which end of \"Rotors 123\", \"Ring settings AAD\" and \"Key settings WAD\" is the fast rotor, so all readings were tried:",
]));
A(table(
  ["Reading", "Plugboard", "Match"],
  [
    ["rotors I II III left to right, rings AAD, key WAD", "as recorded", "46 / 46"],
    ["rotors I II III left to right, rings AAD, key WAD", "none", "5 / 46"],
    ["rotors III II I, rings DAA, key DAW", "none", "4 / 46"],
    ["rotors III II I, rings AAD, key WAD", "as recorded", "3 / 46"],
  ],
  [4800, 2400, 2160]
));
A(p([
  "The first row is exact and everything else is at chance, so the recorded parameters are confirmed, the left-to-right reading is established, and the newly supplied ciphertext is authenticated. The tool remains unidentified: eight simulators were checked and none uses the recorded label set of \"Reflector UKW B\" with \"Key settings\" and \"Ring settings\". The MEP Unit 20 web-links page was fetched and states \"There are currently no links\", so the natural bridge from the Lorenz finding is closed. It remains possible that the label set is the solver's own write-up vocabulary rather than any tool's interface, which would make the question unanswerable in principle.",
]));

// ---------------------------------------------------------------- 12
A(h1("12. The Giant Draws on a Curriculum, and No Other Map Does"));
A(p([
  "The Simplified Lorenz toolkit belongs to MEP \"Codes and Ciphers\", a 20-unit teaching sequence produced by CIMT with Bletchley Park National Codes Centre.",
]));
A(table(
  ["Unit", "Title", "Unit", "Title"],
  [
    ["1", "Substitution Ciphers", "11", "Transposition"],
    ["2", "Braille", "12", "One-Time Pads"],
    ["3", "EAN Bar Codes", "13", "Semaphore"],
    ["4", "ISBN Numbers", "14", "Morse Code"],
    ["5", "Binary Codes", "15", "Vehicle Registration Marks"],
    ["6", "Genetic Fingerprinting", "16", "Modern Encryption"],
    ["7", "Postcodes", "17", "Huffman Codes"],
    ["8", "ITF Symbols", "18", "Arithmetic Coding"],
    ["9", "Code 3 of 9", "19", "Lorenz Cipher Machine"],
    ["10", "Public Key Cryptography", "20", "Enigma Cipher"],
  ],
  [800, 3400, 800, 4360]
));
A(p([
  "Three of The Giant's five cipher-bearing puzzles map onto this list. TG1 is \"a barcode that produces a message when scanned\", and units 3, 8 and 9 are EAN bar codes, ITF symbols and Code 3 of 9. TG3 is unit 19. TG5 is unit 20. TG2 (periodic table) and TG6 (scarabs) are not.",
]));
A(callout("How far this may be pushed.", [
  "Unit 19 is a confirmed source because TG3 reproduces from it, and section 8.3 shows CIMT covers 2 of 2 of The Giant's ciphers, the only complete per-map coverage in the whole table. The TG1 and TG5 alignments remain ",
  { t: "suggestive, not confirmed", bold: true },
  ": barcodes and Enigma are obvious independent choices for a WWII-themed puzzle.",
], "7A3030"));
A(p([
  "The decisive negative is more useful. MEP's 20 units contain ",
  { t: "no", bold: true },
  " Beaufort, Bacon, straddling checkerboard, ADFGX, Playfair, Trifid, affine, autokey, Porta, Four-square, Bifid, AMSCO, Trithemius, Ubchi, Purple, Quagmire or Skip. The curriculum accounts for 7 of the corpus's 39 classical methods and for none at all in four of the six maps. It is a source for The Giant and, on present evidence, for nothing else.",
]));

// ---------------------------------------------------------------- 13
A(h1("13. What the Evidence Excludes"));
A(table(
  ["Exclusion", "Applies to", "Confidence", "Basis"],
  [
    ["dcode.fr was not used", "all 65 records", "OWNER GROUND TRUTH, now CORROBORATED", "Stated with high confidence by the project owner. The community sheet names it in none of its 83 Encoding Source cells and refutes it where it tries it: for zns1, \"the outputs do not match when I try to encipher the known plaintext\". Two independent routes, one attributed and one evidential."],
    ["Boxentriq is not a source for anything in the corpus", "all 65 records", "FIRM", "Launched 2018; corpus authored early 2016. Independent of any snapshot. Never named in the sheet either."],
    ["No real cipher in the corpus is without an identified source", "all", "PROVISIONAL", "SUPERSEDES revision 3's \"only two\". Quagmire III is rumkin's keymaker (sheet, 99%); Purple has a named Python implementation (sheet, 30%, with an admitted output mismatch). The two methods still uncovered are bespoke non-ciphers. Provisional because several of these attributions are the community's and are not reproduced here."],
    ["CacheSleuth was not used", "all", "NOT ESTABLISHED", "Named in none of the sheet's 83 rows and discussed in none of its explanations, despite leading this document's coverage table at 69%. That is suggestive and it is not evidence. Recorded so that it is not mistaken for evidence later."],
    ["MEP Codes and Ciphers is not the source of Revelations' classical ciphers", "rev1-rev14", "FIRM", "Covers 2 of Revelations' 20 cipher methods, and none of its distinctive ones."],
    ["rumkin.com is not the sole source of the corpus", "all", "FIRM", "Complete menu enumerated; misses 24 of 39 classical methods and covers 0 of 5 in Shadows of Evil."],
    ["No single toolkit covers more than 69% of the classical corpus", "all", "FIRM", "Section 8.3, and reached without relying on dcode at all. The sheet independently reaches the same multi-source conclusion: it names 11 distinct tools across 62 Black Ops 3 rows and no tool for more than 11 of 83."],
    ["The sheet attributes nothing to REV7 or TG4", "rev7, tg4", "FIRM", "TG4's row is Unknown / Unknown / N/A explicitly. REV7 is one of ten Revelations rows that are all Unknown / Unknown / N/A, so the conclusion holds without recovering which one it is."],
    ["Cryptool Online's 2026 menu carries de3, de4, de5, de7 or de9", "der_eisendrache", "REFUTED BY OUR ENUMERATION, CONTRADICTED BY THE SHEET", "The sheet attributes all five to it at 75 to 90 per cent. Recorded as a standing disagreement, not resolved. That menu is not complete, so this is not a refutation of the attribution."],
    ["Modern ciphers occur only in Revelations", "all", "FIRM", "13 of 13 modern steps are Revelations steps; 0 of 35 non-Revelations cipher steps are modern."],
    ["TG3 is not base64 and involves no base64 step", "tg3", "FIRM", "Alphabet is ITA2 in Bletchley notation; reproduces 48/48 without any base64."],
    ["TG3's wheels are not of length 9 and 4", "tg3", "FIRM", "Period would be 36; measured period is exactly 28, tested under every alignment hypothesis."],
    ["TG5 does not use the reversed rotor or ring reading", "tg5", "FIRM", "Reversed readings score 3 to 4 of 46, at chance."],
    ["rev14's transposition is not any standard complete-rectangle keyed columnar", "rev14", "FIRM", "Tested over every width dividing 162 and every column key order."],
    ["gk12's autokey is not reducible to a plain-alphabet autokey", "gk12", "FIRM", "The keyed alphabet is not affine on Z26."],
    ["A strict once-only cipher rule did not govern the author", "all", "FIRM", "Eight ciphers appear twice, four of them across maps."],
    ["No cipher is shared between any two maps", "all", "RETRACTED", "FALSE. See section 1. Four ciphers are shared."],
    ["The author's cipher variety exceeds chance", "all", "NOT ESTABLISHED", "p = 0.22 on the only axis with a known menu."],
    ["Any 2026 menu reflects the 2016 menu", "all tool claims", "NOT ESTABLISHED", "No snapshot was reachable. See section 0."],
  ],
  [3000, 1700, 1700, 2960]
));

// ---------------------------------------------------------------- 14
A(h1("14. Consequences for TG4 and REV7"));

A(h2("14.1 REV7"));
A(p([
  "REV7 is 1310 characters of hex plus whitespace, and the repair work established that its true ciphertext is 550 bytes rather than the recorded 546. Nothing in this revision changes its shape or its arithmetic.",
]));
A(callout("What the community sheet contributes to REV7: nothing, and the nothing is worth having stated.", [
  "Only 4 of the sheet's 14 Revelations rows carry a Type at all, and those four map to this corpus's rev3, rev4, rev13 and rev14. The other ten read ",
  { t: "Unknown / Unknown / N/A", mono: true },
  ", with the author's note that a second draft was intended but that they were \"pretty knackered\". So ",
  { t: "whichever of those ten rows is our rev7, it attributes nothing", bold: true },
  ", and that conclusion does not require recovering the Revelations mapping, which is fortunate because the sheet gives no basis on which to recover it. The same holds for rev1, rev2, rev5, rev6, rev8, rev9, rev10, rev11 and rev12.",
], "7A3030"));
A(p([
  "One indirect contribution survives that. The sheet's Revelations rows that ",
  { t: "are", italics: true },
  " filled in attribute rev3's checkerboard to Practical Cryptography and its base-conversion layer to cryptii v2, and describe the latter as \"faux bases\" or \"base spoofing\": the checkerboard output is encoded into octal, and then ",
  { t: "the octal digits are treated as ASCII values rather than converted to ASCII", bold: true },
  ". That is a composition pattern rather than a cipher, it is one the recorded chains do not name anywhere, and it is exactly the class of step a sweep skeleton has to be able to express. It belongs on the list of arrangements at item 7 of section 15, alongside the leading transform and the codec-transform-codec ordering.",
]));
A(p([
  "The owner's original chain of reasoning was: the once-only rule holds, therefore REV7's primitive comes from the 8 unused, therefore there is an actionable gap. The first link fails, and fails harder on the full corpus. The conclusion is nevertheless right, reached differently:",
]));
A(numItem([
  "The engine models 11 of the 19 mcrypt primitives. The 8 absent are cast-128, cast-256, enigma, gost, rijndael-128, rijndael-192, tripledes and wake. This is a fact about the engine, not an inference about the author.",
], "steps3"));
A(numItem([
  "Under uniform selection the probability that a fresh primitive is one of the 8 is 8/19, about 42%. Under the refuted strict rule it would be 100%. The honest floor is ",
  { t: "at least 42%", bold: true },
  ", and the full corpus does not move it, because the three imported maps contain no modern ciphers at all.",
], "steps3"));
A(numItem([
  "A sweep that cannot express 42% or more of the menu reports a clean negative over a space it never entered.",
], "steps3"));
A(callout("The bind, which is the real finding.", [
  "Under conformance gating an unproven primitive contributes zero coverage, and none of the 8 can ever be proven the way the other 11 were, because ",
  { t: "no solved cipher in the corpus uses any of them", bold: true },
  " and the full corpus now confirms that across all six maps. So implementing them is necessary but not sufficient: they must be validated against libmcrypt's own published self-test vectors, and the conformance suite must be extended to admit external vectors as a distinct, clearly labelled evidence class.",
], "7A3030"));
A(p([
  "The RC2 finding is the warning about exactly this plan: libmcrypt's effective key bits are always 1024 because RFC 2268's Phase 2 reduction is stripped out, so a primitive validated against the wrong library's vectors is a different cipher wearing the right name. Any external vector must come from libmcrypt, not RustCrypto or OpenSSL.",
]));

A(h2("14.2 TG4: a genuine tension, now sharper"));
A(callout("The community has no attribution for TG4 either, and says so in as many words.", [
  "TG4 maps cleanly, because the sheet's numbering is identity on The Giant and the identity is established by four other rows on that map matching by type. Its row reads Type ",
  { t: "Unknown", mono: true },
  ", Encoding Source ",
  { t: "Unknown", mono: true },
  ", Confidence ",
  { t: "N/A", mono: true },
  ", with the explanation ",
  { t: "\"We don't know enough about this cipher to know anything about what tools could have been used.\"", italics: true },
  " This is a hard bound on what the whole fingerprinting exercise can offer for this project's actual target. Every other cipher on The Giant is attributed, three of them at 100%, so the gap is specific to TG4 rather than to the map. ",
  { t: "There is no tool menu to narrow TG4 with, and no one has one.", bold: true },
], "7A3030"));
A(p([
  "That does not weaken the argument below; it removes one hoped-for shortcut and leaves the artefact's own bytes as the only evidence, which is where the argument already was.",
]));
A(p([
  "The strengthened result that every modern cipher in the corpus is in Revelations bears directly on whether TG4 should be searched as a modern cipher at all. The evidence points both ways and both directions are worth stating plainly.",
]));
A(h3("Against searching TG4 as modern: the base rate"));
A(p([
  "Five of six maps contain 35 cipher steps and not one modern cipher. The Giant's other two ciphers are a teaching-toolkit Lorenz and an Enigma, and three of its six records are not ciphers at all but a barcode, a periodic-table mapping and a scarab arrangement. By the rule of three, the 95% upper bound on the rate of modern ciphers outside Revelations is 3/35 = ",
  { t: "8.6%", bold: true },
  ". On its map alone, TG4 looks like a classical or non-cipher puzzle.",
]));
A(h3("For searching TG4 as modern: its own bytes"));
A(p([
  "TG4's ciphertext is 192 base64 characters over 62 distinct symbols. Under uniform random bytes the expected number of distinct base64 symbols in 192 draws is 60.9, and the Shannon entropy is 5.800 bits per symbol against a maximum of 6.0:",
]));
A(table(
  ["Ciphertext", "n", "Distinct", "E[distinct]", "Entropy (bits/symbol)"],
  [
    ["tg4 (unsolved)", "192", "62", "60.9", "5.800"],
    ["rev1 (modern, confirmed)", "64", "44", "40.6", "5.332"],
    ["rev5 (modern, confirmed)", "2208", "64", "64.0", "5.981"],
    ["rev9 (modern, confirmed)", "1080", "65", "64.0", "5.954"],
    ["tg5 (Enigma, A-Z)", "46", "22", "n/a", "4.276"],
    ["rev11 (Trifid, a-z)", "460", "25", "n/a", "4.569"],
  ],
  [2800, 1000, 1300, 1600, 2660]
));
A(p([
  "TG4 is statistically indistinguishable from uniform random bytes and sits with the confirmed modern ciphertexts, not with the classical ones. No classical cipher over a 26-letter alphabet can produce that. ",
  { t: "Direct evidence from the artefact outweighs a base rate computed over its neighbours", bold: true },
  ", so the existing programme, which treats TG4 as a tools4noobs mcrypt chain, should continue.",
]));
A(p([
  "What the base rate does earn is a named alternative that had no support before and now has some: TG4 may be base64 of something that is not a cipher at all. Compressed data, an image, or a binary blob would all present exactly this entropy profile, and The Giant is the map with the highest proportion of non-cipher puzzles in the corpus. This is a hypothesis, not a finding, and it is cheap to test relative to a sweep: check whether the 144 bytes carry any recognisable file signature or structure before assuming they are ciphertext.",
]));
A(p([
  "One further negative follows from section 10: whatever TG4 is, it is not a Lorenz of any kind and not an Enigma, because the CIMT toolkit's alphabet is 32 symbols and Enigma's is 26, while TG4's is 62 including lowercase. Both of The Giant's confirmed tools are excluded for TG4, so the map's apparent single-source character does not extend to it.",
]));

// ---------------------------------------------------------------- 15
A(h1("15. What to Do Next, Ranked"));
A(table(
  ["#", "Action", "Cost", "Why it ranks here"],
  [
    ["1", "Reach practicalcryptography.com from an unrestricted network and read three things off it: its straddling checkerboard defaults, its Enigma defaults, and whether its Trifid page has an implementation", "minutes, off this network", "DONE FOR ITEM 1 OF REVISION 3, which asked about CacheSleuth's and Crypto Corner's selectors and is now moot. The site is named by the sheet for five ciphers including two at 100%, and every one of those attributions turns on a default value. Its straddling default already agrees with our rev3 reconstruction at 17 of 19 cells; three cells do not fit and the site itself would say why. Its Enigma defaults would settle TG5, which section 11 leaves unresolved."],
    ["2", "Find the tool that renders bytes as fixed-width zero-padded decimal and also carries a substitution", "small", "The most concrete unclaimed lead in the document. It is a rendering behaviour, not a cipher, so it is searchable in a way cipher names are not; it accounts for three Revelations ciphers at once; and rev9's DES layer emits exactly this format, so it bears on the engine directly. rev6's ciphertext is the specimen: 256 tokens, every one three digits, 198 of them carrying a leading zero."],
    ["2b", "Test rumkin's keymaker with keyword shinonuma against zns12's recorded alphabet AMUNOIHSZYXWVTRQPLKJGFEDCB", "minutes", "The sheet asserts this at 99% and it is directly reproducible. It would convert a community attribution into a confirmed one, and it is the cheapest such conversion available."],
    ["2c", "Fetch one Wayback snapshot of rumkin's Beaufort page circa 2016", "minutes, once archive.org is reachable", "Settles the 52-character mixed-case Beaufort alphabet, which section 8.7 now ranks as the strongest tell in the corpus by a clear margin. Section 9.5 rules out the shortcut of treating it as case preservation, so nothing but a snapshot will do."],
    ["3", "Extend the conformance suite to admit external libmcrypt self-test vectors as a labelled evidence class", "small, design work", "Prerequisite for the 8 unused primitives to carry any coverage. Without it, implementing them is wasted work."],
    ["4", "Implement the 8 unused mcrypt primitives against libmcrypt vectors, not RustCrypto or OpenSSL", "moderate", "Closes a gap that is at least 42% of the primitive menu for both unsolved ciphers. Ordered after item 3 by necessity."],
    ["5", "Test TG4's 144 bytes for file signatures or non-cipher structure", "minutes", "Cheap, and newly motivated by the modern-ciphers-only-in-Revelations result. A negative costs almost nothing; a positive would redirect the entire programme."],
    ["6", "Add a leading transform slot to the sweep skeleton", "small", "The largest documented coverage gap for TG4: 2 of 11 reproduced chains open with a transform, and the engine already has the nodes."],
    ["7", "Add the two observed inter-layer arrangements (codec before xf, and codec-xf-codec)", "small", "2 of 11 reproduced chains need them; distinct skeletons, cheap to enumerate."],
    ["8", "Reproduce de11 against Brian Neal's PURPLE, and find out why the sheet says the output does not match", "small", "SUPERSEDES revision 3's \"hunt a source for Purple and Quagmire III\". Quagmire III is answered at item 2b. Purple has a named implementation and an admitted mismatch, which is a much more tractable problem than an absent tool: the sheet suspects spacing was fixed by hand."],
    ["9", "Normalise the corpus method taxonomy", "small", "Would let the reuse ratios carry an inference. Currently they cannot. Would also settle the hex / hexadecimal synonym."],
    ["10", "Do not pursue affine, Playfair or Bacon as fingerprints", "zero", "Majority defaults or bare parameter values. They discriminate between nothing."],
  ],
  [500, 3400, 1700, 3760]
));

// ---------------------------------------------------------------- 16
A(h1("16. Reproducing This Document"));
A(p([
  "Every figure quoted above is produced by a script in ",
  { t: "papers/analysis/", mono: true },
  ", each stdlib-only, each reading all six map files, and each runnable on its own:",
]));
A(table(
  ["Script", "Produces"],
  [
    ["reuse_matrix.py", "Sections 1 and 3: record and step counts, per-map and per-role reuse ratios, cross-map ciphers, every repeated method, the raw-versus-normalised count discrepancy, the hex/hexadecimal sensitivity, and the full 65-method inventory."],
    ["toolkit_coverage.py", "Section 8 in full: per-toolkit classical coverage over 18 toolkits, the encoded-versus-researched gap analysis, the minimal explaining set, unique contributions, the ranked uncovered set with its implementation tells, and per-map coverage. Encodes dcode as excluded on owner ground truth, and records for each toolkit whether it is present by menu inference or by community attribution."],
    ["community_sources.py", "Section 9 in full: the derived sheet-to-corpus mapping with its per-map numbering-identity test and its assertions, the attribution tallies, the row-by-row check of every attribution against the menu held for that tool, the three independent confirmations, the rev13 behavioural fingerprint and the rev1 non-equivalence, the Practical Cryptography straddling test with its permutation null, and the zero-pad measurement."],
    ["variety_test.py", "Section 4: the exact distribution of distinct values under uniform selection, p = 0.2232, the classical menu-size sensitivity table, and the modern-ciphers-by-map breakdown."],
    ["tg3_tg5_probe.py", "Sections 9.1, 9.2 and 10: the ITA2 alphabet test, the recovered keystream and its period, and the Enigma M3 reproduction over all reading conventions."],
    ["tg3_wheels.py", "Section 10.3: the exact-period computation and the search over all two-wheel factorisations with lcm 28."],
    ["tg3_spacing.py", "Section 10.3: the alignment hypotheses, including the spaced-message reading, under which (9, 4) is tested and refuted."],
    ["tg3_cimt.py", "Section 10.4: the end-to-end 48 of 48 reproduction from the toolkit's published wheel geometry."],
    ["equivalence_tests.py", "Section 5.1: the columnar permutation test over every width and key order, and the affineness test on the autokey alphabet."],
  ],
  [2200, 7160]
));
A(p([
  "The three imported map files carry a ",
  { t: "_provenance", mono: true },
  " field recording their upstream source. ",
  { t: "data/the_giant.json", mono: true },
  " remains ahead of upstream: it holds the TG3 and TG5 ciphertexts the owner supplied, each with a ",
  { t: "ciphertext_provenance", mono: true },
  " block and reconstructed-parameter block, recorded alongside rather than replacing the original ",
  { t: "configuration", mono: true },
  " strings.",
]));

A(spacer(60));
A(new Paragraph({
  border: { top: { style: BorderStyle.SINGLE, size: 4, color: "9A9A9A", space: 6 } },
  spacing: { before: 120 },
  children: [new TextRun({
    text: "End of Document 8, Revision 4. Revision 1's cross-map claim stays retracted in section 1 and Revision 2's straddling-checkerboard lead stays superseded in section 8.6. Revision 4 adds the community attribution sheet as a primary source in section 9: three of this project's independent derivations are corroborated by it, dcode's exclusion is corroborated by refutation rather than silence, rev3's checkerboard is attributed to Practical Cryptography at a strength the sheet did not claim, no real cipher in the corpus is left without an identified source, and one attribution to Cryptool Online is left standing as a disagreement. The reuse rule remains refuted at p = 0.22. TG4 and REV7 get nothing from the sheet, and it says so itself.",
    italics: true, size: 18, color: "6A6A6A", font: S.FONT,
  })],
}));

const doc = new Document({
  numbering,
  styles: { default: { document: { run: { font: S.FONT, size: 21, color: S.INK } } } },
  sections: [{ properties: { page: PAGE }, ...makeHeaderFooter("Cipher Reuse and Tool Fingerprints"), children }],
});
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(OUT, buf);
  console.log("wrote", OUT, buf.length, "bytes");
});
