//! Per-tool identity, and the selective invalidation it buys.
//!
//! The payoff of versioning each tool independently rather than versioning the
//! platform: when a single implementation is found defective you can compute
//! *exactly* which coverage is voided and re-run only that. Platform-level
//! versioning forces you to discard everything built on that platform version.
//!
//! Chain identity is the hash of the ordered tool identities plus the bound
//! parameters, so two workers running *different implementations* of the same
//! logical tool produce different chain ids. That is what makes their agreement
//! evidence rather than a tautology, and it is the basis of N-version
//! cross-validation — the only mechanism that catches an honest worker running a
//! defective implementation, since audits and canaries both pass for such a worker.

use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

#[derive(Clone, Copy, PartialEq, Eq, Debug, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum Conformance {
    Pass,
    Fail,
    Untested,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ToolFamily {
    /// Keyed decryption.
    Dec,
    /// Classical cipher.
    Cls,
    /// Representation-preserving transform.
    Xf,
    /// Decoder.
    Dcd,
}

#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub struct Tool {
    pub family: ToolFamily,
    pub name: String,
    pub version: String,
    /// Hash of the built artifact.
    pub impl_hash: String,
    pub conformance: Conformance,
    /// Cipher ids from the solved corpus that this tool was validated against.
    pub conformance_vectors: Vec<String>,
    pub supersedes: Option<String>,
}

impl Tool {
    pub fn new(
        family: ToolFamily,
        name: &str,
        version: &str,
        impl_hash: &str,
        conformance: Conformance,
        vectors: &[&str],
    ) -> Self {
        Self {
            family,
            name: name.to_string(),
            version: version.to_string(),
            impl_hash: impl_hash.to_string(),
            conformance,
            conformance_vectors: vectors.iter().map(|s| s.to_string()).collect(),
            supersedes: None,
        }
    }

    pub fn tool_id(&self) -> String {
        let fam = match self.family {
            ToolFamily::Dec => "dec",
            ToolFamily::Cls => "cls",
            ToolFamily::Xf => "xf",
            ToolFamily::Dcd => "dcd",
        };
        let short = &self.impl_hash[..12.min(self.impl_hash.len())];
        format!("{fam}:{}@{}#{short}", self.name, self.version)
    }

    /// Whether this tool may contribute coverage.
    ///
    /// `required_vectors` maps a primitive name to the corpus ciphers that actually
    /// exercise it. A tool citing vectors that do not exercise it is **not**
    /// admissible: that is the difference between "we tested something" and "we
    /// tested this".
    pub fn is_admissible(
        &self,
        required_vectors: &BTreeMap<String, Vec<String>>,
    ) -> Result<(), String> {
        if self.conformance != Conformance::Pass {
            return Err(format!("conformance={:?}", self.conformance));
        }
        if self.family == ToolFamily::Dec {
            // Case-insensitive lookup. The reference implementation keyed this table
            // literally, so a case mismatch (`Rijndael-256` vs `rijndael-256`) made
            // `expected` empty and the check pass *vacuously* — precisely the silent
            // void this whole mechanism exists to prevent.
            let expected = required_vectors
                .iter()
                .find(|(k, _)| k.eq_ignore_ascii_case(&self.name))
                .map(|(_, v)| v);
            match expected {
                None => {
                    return Err(format!(
                        "no conformance vectors are defined for decryption tool '{}', \
                         so its correctness cannot be established",
                        self.name
                    ))
                }
                Some(exp) => {
                    let overlap = self
                        .conformance_vectors
                        .iter()
                        .any(|v| exp.iter().any(|e| e.eq_ignore_ascii_case(v)));
                    if !overlap {
                        return Err(format!(
                            "cited vectors {:?} do not exercise {}; expected one of {:?}",
                            self.conformance_vectors, self.name, exp
                        ));
                    }
                }
            }
        }
        Ok(())
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum ToolStatus {
    Admissible,
    Inadmissible,
    Revoked,
    Unknown,
}

#[derive(Default)]
pub struct ToolRegistry {
    pub tools: BTreeMap<String, Tool>,
    pub revoked: BTreeMap<String, String>,
    pub conformance_vectors: BTreeMap<String, Vec<String>>,
}

impl ToolRegistry {
    pub fn new(conformance_vectors: BTreeMap<String, Vec<String>>) -> Self {
        Self {
            tools: BTreeMap::new(),
            revoked: BTreeMap::new(),
            conformance_vectors,
        }
    }

    pub fn register(&mut self, t: Tool) -> String {
        let id = t.tool_id();
        self.tools.insert(id.clone(), t);
        id
    }

    pub fn revoke(&mut self, tool_id: &str, reason: &str) {
        self.revoked
            .insert(tool_id.to_string(), reason.to_string());
    }

    pub fn status(&self, tool_id: &str) -> ToolStatus {
        if self.revoked.contains_key(tool_id) {
            return ToolStatus::Revoked;
        }
        match self.tools.get(tool_id) {
            None => ToolStatus::Unknown,
            Some(t) => match t.is_admissible(&self.conformance_vectors) {
                Ok(()) => ToolStatus::Admissible,
                Err(_) => ToolStatus::Inadmissible,
            },
        }
    }

    pub fn why_inadmissible(&self, tool_id: &str) -> Option<String> {
        self.tools
            .get(tool_id)?
            .is_admissible(&self.conformance_vectors)
            .err()
    }

    /// All registered implementations of one logical tool, for N-version assignment.
    pub fn implementations_of(&self, name: &str) -> Vec<&Tool> {
        self.tools.values().filter(|t| t.name == name).collect()
    }
}

/// A concrete pipeline: ordered tool ids plus the parameter binding.
#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub struct ChainRef {
    pub tool_ids: Vec<String>,
    pub params: BTreeMap<String, String>,
}

impl ChainRef {
    pub fn new(tool_ids: Vec<String>, params: BTreeMap<String, String>) -> Self {
        Self { tool_ids, params }
    }

    pub fn chain_id(&self) -> String {
        let canon = serde_json::to_string(&serde_json::json!({
            "t": self.tool_ids,
            "p": self.params,
        }))
        .unwrap_or_default();
        format!(
            "chain:{}",
            &hex::encode(Sha256::digest(canon.as_bytes()))[..24]
        )
    }

    pub fn uses(&self, tool_id: &str) -> bool {
        self.tool_ids.iter().any(|t| t == tool_id)
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum ClaimStatus {
    Active,
    Void,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Claim {
    pub claim_id: String,
    pub worker: String,
    pub chains: Vec<ChainRef>,
    pub candidates: u128,
    pub status: ClaimStatus,
}

/// Records coverage claims and supports selective invalidation.
pub struct Ledger {
    pub claims: Vec<Claim>,
}

impl Default for Ledger {
    fn default() -> Self {
        Self::new()
    }
}

impl Ledger {
    pub fn new() -> Self {
        Self { claims: Vec::new() }
    }

    pub fn submit(&mut self, claim_id: &str, worker: &str, chains: Vec<ChainRef>, candidates: u128) {
        self.claims.push(Claim {
            claim_id: claim_id.to_string(),
            worker: worker.to_string(),
            chains,
            candidates,
            status: ClaimStatus::Active,
        });
    }

    /// Revoke one tool version and report exactly which coverage is voided.
    pub fn invalidate_tool(
        &mut self,
        reg: &mut ToolRegistry,
        tool_id: &str,
        reason: &str,
    ) -> (Vec<String>, Vec<String>) {
        reg.revoke(tool_id, reason);
        let mut voided = Vec::new();
        let mut kept = Vec::new();
        for c in self.claims.iter_mut() {
            if c.chains.iter().any(|ch| ch.uses(tool_id)) {
                c.status = ClaimStatus::Void;
                voided.push(c.claim_id.clone());
            } else {
                kept.push(c.claim_id.clone());
            }
        }
        (voided, kept)
    }

    /// (active, void) candidate totals.
    pub fn totals(&self) -> (u128, u128) {
        let active = self
            .claims
            .iter()
            .filter(|c| c.status == ClaimStatus::Active)
            .map(|c| c.candidates)
            .sum();
        let void = self
            .claims
            .iter()
            .filter(|c| c.status == ClaimStatus::Void)
            .map(|c| c.candidates)
            .sum();
        (active, void)
    }
}

/// Load the conformance suite shipped in `data/conformance_suite.json`.
pub fn load_conformance_suite(json: &str) -> Result<BTreeMap<String, Vec<String>>, String> {
    let v: serde_json::Value = serde_json::from_str(json).map_err(|e| e.to_string())?;
    let vectors = v
        .get("vectors")
        .and_then(|x| x.as_object())
        .ok_or("conformance suite has no 'vectors' object")?;
    Ok(vectors
        .iter()
        .map(|(prim, entries)| {
            let ciphers = entries
                .as_array()
                .map(|a| {
                    a.iter()
                        .filter_map(|e| e.get("cipher")?.as_str().map(str::to_string))
                        .collect()
                })
                .unwrap_or_default();
            (prim.clone(), ciphers)
        })
        .collect())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn suite() -> BTreeMap<String, Vec<String>> {
        [
            ("Twofish", vec!["rev9"]),
            ("DES", vec!["rev2", "rev9"]),
            ("XTEA", vec!["rev12"]),
            // deliberately lowercase, as it appears in the shipped data file
            ("rijndael-256", vec!["rev1"]),
        ]
        .into_iter()
        .map(|(k, v)| (k.to_string(), v.into_iter().map(String::from).collect()))
        .collect()
    }

    fn hash(s: &str) -> String {
        hex::encode(Sha256::digest(s.as_bytes()))
    }

    #[test]
    fn passing_tool_with_a_valid_vector_is_admissible() {
        let t = Tool::new(
            ToolFamily::Dec,
            "Twofish",
            "1.2.0",
            &hash("twofishA"),
            Conformance::Pass,
            &["rev9"],
        );
        assert!(t.is_admissible(&suite()).is_ok());
    }

    /// The vector must actually exercise the primitive. Citing rev2 (a DES vector)
    /// for XTEA proves nothing about XTEA.
    #[test]
    fn tool_citing_an_irrelevant_vector_is_rejected() {
        let t = Tool::new(
            ToolFamily::Dec,
            "XTEA",
            "0.2.0",
            &hash("xtea"),
            Conformance::Pass,
            &["rev2"],
        );
        let e = t.is_admissible(&suite()).unwrap_err();
        assert!(e.contains("do not exercise"), "{e}");
    }

    #[test]
    fn untested_and_failing_tools_are_rejected() {
        for c in [Conformance::Untested, Conformance::Fail] {
            let t = Tool::new(ToolFamily::Dec, "Serpent", "0.1", &hash("s"), c, &["rev6"]);
            assert!(t.is_admissible(&suite()).is_err(), "{c:?} was admitted");
        }
    }

    /// **Regression for the vacuous-pass bug.**
    ///
    /// The reference implementation keyed its conformance table literally, so
    /// `Rijndael-256` missed the lowercase `rijndael-256` entry, leaving the expected
    /// set empty — and the guard `if expected and not overlap` then passed the tool
    /// with *no* evidence at all. Rijndael-256 is the likeliest primitive to be
    /// silently wrong, since no AES implementation can provide its 256-bit block.
    #[test]
    fn primitive_name_case_does_not_create_a_vacuous_pass() {
        let good = Tool::new(
            ToolFamily::Dec,
            "Rijndael-256",
            "1.0.0",
            &hash("rij"),
            Conformance::Pass,
            &["rev1"],
        );
        assert!(
            good.is_admissible(&suite()).is_ok(),
            "case-insensitive lookup should find the lowercase suite entry"
        );

        let bogus = Tool::new(
            ToolFamily::Dec,
            "Rijndael-256",
            "1.0.0",
            &hash("rij2"),
            Conformance::Pass,
            &["rev9"], // a Twofish vector; proves nothing about Rijndael-256
        );
        assert!(
            bogus.is_admissible(&suite()).is_err(),
            "an irrelevant vector must not pass just because the name case differs"
        );
    }

    /// A decryption tool with no vectors defined anywhere must not be admitted.
    #[test]
    fn unknown_primitive_cannot_self_certify() {
        let t = Tool::new(
            ToolFamily::Dec,
            "Wake",
            "1.0",
            &hash("wake"),
            Conformance::Pass,
            &["rev9"],
        );
        let e = t.is_admissible(&suite()).unwrap_err();
        assert!(e.contains("no conformance vectors"), "{e}");
    }

    /// Non-decryption tools need no cipher vector; `reverse` has nothing to validate.
    #[test]
    fn transform_tools_do_not_require_vectors() {
        let t = Tool::new(
            ToolFamily::Xf,
            "reverse",
            "1.0.0",
            &hash("rev"),
            Conformance::Pass,
            &[],
        );
        assert!(t.is_admissible(&suite()).is_ok());
    }

    #[test]
    fn two_implementations_of_one_primitive_get_distinct_chain_ids() {
        let a = Tool::new(
            ToolFamily::Dec,
            "Twofish",
            "1.2.0",
            &hash("twofishA"),
            Conformance::Pass,
            &["rev9"],
        );
        let b = Tool::new(
            ToolFamily::Dec,
            "Twofish",
            "0.9.1",
            &hash("twofishB"),
            Conformance::Pass,
            &["rev9"],
        );
        assert_ne!(a.tool_id(), b.tool_id());

        let p = BTreeMap::from([("key".to_string(), "Zombies".to_string())]);
        let c1 = ChainRef::new(vec![a.tool_id()], p.clone());
        let c2 = ChainRef::new(vec![b.tool_id()], p);
        assert_ne!(
            c1.chain_id(),
            c2.chain_id(),
            "agreement between implementations must not be a tautology"
        );
    }

    /// Document 6's headline: revoking one Twofish build voids the claims that used
    /// it and *retains* the rest. Platform-level versioning would void everything.
    #[test]
    fn selective_invalidation_preserves_unaffected_coverage() {
        let mut reg = ToolRegistry::new(suite());
        let tw_a = reg.register(Tool::new(
            ToolFamily::Dec,
            "Twofish",
            "1.2.0",
            &hash("twofishA"),
            Conformance::Pass,
            &["rev9"],
        ));
        let tw_b = reg.register(Tool::new(
            ToolFamily::Dec,
            "Twofish",
            "0.9.1",
            &hash("twofishB"),
            Conformance::Pass,
            &["rev9"],
        ));
        let des = reg.register(Tool::new(
            ToolFamily::Dec,
            "DES",
            "0.8.1",
            &hash("des"),
            Conformance::Pass,
            &["rev2", "rev9"],
        ));

        let p = BTreeMap::from([("mode".to_string(), "cfb".to_string())]);
        let c_a = ChainRef::new(vec![tw_a.clone()], p.clone());
        let c_b = ChainRef::new(vec![tw_b], p.clone());
        let c_d = ChainRef::new(vec![des], p);

        let mut led = Ledger::new();
        led.submit("claim-001", "alpha", vec![c_a.clone(), c_d.clone()], 120_000_000);
        led.submit("claim-002", "beta", vec![c_b, c_d.clone()], 118_000_000);
        led.submit("claim-003", "gamma", vec![c_a], 95_000_000);
        led.submit("claim-004", "delta", vec![c_d], 40_000_000);

        let (before_active, before_void) = led.totals();
        assert_eq!(before_active, 373_000_000);
        assert_eq!(before_void, 0);

        let (voided, kept) =
            led.invalidate_tool(&mut reg, &tw_a, "off-by-one in key schedule, fails rev9 on re-test");
        assert_eq!(voided, vec!["claim-001", "claim-003"]);
        assert_eq!(kept, vec!["claim-002", "claim-004"]);

        let (active, void) = led.totals();
        assert_eq!(void, 215_000_000);
        assert_eq!(active, 158_000_000);
        assert_eq!(reg.status(&tw_a), ToolStatus::Revoked);

        let preserved = active as f64 / before_active as f64;
        assert!(
            (preserved - 0.4236).abs() < 0.001,
            "expected ~42% preserved, got {:.1}%",
            preserved * 100.0
        );
    }

    #[test]
    fn unknown_tool_ids_are_reported_as_unknown() {
        let reg = ToolRegistry::new(suite());
        assert_eq!(reg.status("dec:Nope@1.0#abc"), ToolStatus::Unknown);
    }

    #[test]
    fn conformance_suite_loads_from_the_shipped_format() {
        let json = r#"{
            "schema": "bo3-conformance-suite/v1",
            "vectors": {
                "RC2": [
                    {"cipher": "rev1", "mode": "ECB"},
                    {"cipher": "rev5", "mode": "CFB"}
                ],
                "rijndael-256": [{"cipher": "rev1", "mode": "ECB"}]
            }
        }"#;
        let m = load_conformance_suite(json).unwrap();
        assert_eq!(m["RC2"], vec!["rev1", "rev5"]);
        assert_eq!(m["rijndael-256"], vec!["rev1"]);
    }
}
