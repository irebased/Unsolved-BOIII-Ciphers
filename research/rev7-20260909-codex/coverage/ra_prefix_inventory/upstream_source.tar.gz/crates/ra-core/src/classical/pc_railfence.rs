//! Practical Cryptography's ("practicalcryptography.com") Rail-fence Cipher
//! tool.
//!
//! Source: the page's own inline JavaScript, fetched directly over HTTP (the
//! site has no HTTPS; task scratchpad `pages/pc_rail_fence.html`, lines
//! ~78-116). `Encrypt`/`Decrypt` are transliterated verbatim below.
//!
//! # A different rail-fence implementation from the other two ports
//!
//! This is again the ordinary top-rail-first zigzag, and — like
//! `cc_railfence.rs` — has only a rail-count parameter, no offset. But its
//! *implementation strategy* is genuinely different from both `cc_railfence`
//! and `cryptool_railfence`: rather than simulating a grid, it walks the
//! plaintext/ciphertext index directly using a `skip` distance recomputed per
//! rail (`skip = 2*(key-line-1)`), alternating between `skip` and
//! `2*(key-1) - skip` every other visit to that rail. This is an equally
//! valid closed-form derivation of the same zigzag pattern, but is kept as
//! its own node per the task spec's instruction not to merge differing
//! implementations — and because the two are worth cross-checking against
//! each other's output as an implementation-independent proof of both.
//!
//! # Input normalisation is part of the algorithm here
//!
//! Both `Encrypt` and `Decrypt` start with
//! `.value.toLowerCase().replace(/[^a-z]/g, "")` — lower-case, then strip to
//! `a-z` only. That is the *only* normalisation the site performs (no
//! separate output case step; the ciphertext/plaintext are already lowercase
//! throughout). Modelled here as the node's default `InputNorm`.
//!
//! This filtering is the *page's* input normalisation, not the rail-fence
//! algorithm itself — a rail fence permutes positions and needs no alphabet
//! at all — so it is reproduced by default (site fidelity) via
//! [`crate::classical::toolfmt`]'s `strip_non_alphabet` param rather than a
//! hardcoded step; set it `false` to run the same permutation over any
//! medium, verified in
//! `pc_railfence_preserves_hex_medium_when_stripping_disabled` below.
//!
//! # Ground truth
//!
//! From the page's own worked example ("Example" section, verbatim): plaintext
//! `"defend the east wall of the castle"`, key 3 -> `"dnetlhseedheswloteateftaafcl"`;
//! key 4 -> `"dttfsedhswotatfneaalhcleelee"`.
//!
//! # Engine direction
//!
//! Decrypt-direction: [`PcRailfence::apply`] runs [`decrypt`]. [`encrypt`] is
//! reproduced test-only.

use crate::classical::toolfmt::{read_output_fmt, CaseFold, InputNorm, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

const PC_RAILFENCE_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(ParamSpec::req(
    "key",
    ParamType::Int,
    "number of rails, minimum 1 (the site's default is 3)"
),);

/// `Decrypt`, transliterated from `pages/pc_rail_fence.html`. `ciphertext` is
/// expected already lower-cased and filtered to `a-z` (case/alphabet
/// handling lives in the node's `apply`).
pub fn decrypt(ciphertext: &[u8], key: usize) -> Result<Vec<u8>> {
    if key == 0 {
        return Err(Error::bad_param("pc_railfence", "key", "must be at least 1"));
    }
    if key == 1 {
        return Ok(ciphertext.to_vec());
    }
    let n = ciphertext.len();
    // Site: `if(key > Math.floor(2*(len-1))){ alert(...); return; }` -- the
    // page simply refuses to run for a key this large relative to the text.
    if n >= 2 && key > 2 * (n - 1) {
        return Err(Error::bad_param(
            "pc_railfence",
            "key",
            format!("key is too large for a {n}-character ciphertext (site's own limit)"),
        ));
    }
    let mut pt: Vec<Option<u8>> = vec![None; n];
    let mut k = 0usize;
    let mut line = 0usize;
    while line < key - 1 {
        let skip = 2 * (key - line - 1);
        let mut j = 0usize;
        let mut i = line;
        while i < n {
            pt[i] = Some(ciphertext[k]);
            k += 1;
            if line == 0 || j % 2 == 0 {
                i += skip;
            } else {
                i += 2 * (key - 1) - skip;
            }
            j += 1;
        }
        line += 1;
    }
    let mut i = line;
    while i < n {
        pt[i] = Some(ciphertext[k]);
        k += 1;
        i += 2 * (key - 1);
    }
    Ok(pt.into_iter().map(|c| c.unwrap_or(b'?')).collect())
}

/// `Encrypt`, transliterated the same way. Test-only.
#[cfg(test)]
fn encrypt(plaintext: &[u8], key: usize) -> Vec<u8> {
    if key == 1 {
        return plaintext.to_vec();
    }
    let n = plaintext.len();
    let mut ciphertext = Vec::with_capacity(n);
    let mut line = 0usize;
    while line < key - 1 {
        let skip = 2 * (key - line - 1);
        let mut j = 0usize;
        let mut i = line;
        while i < n {
            ciphertext.push(plaintext[i]);
            if line == 0 || j % 2 == 0 {
                i += skip;
            } else {
                i += 2 * (key - 1) - skip;
            }
            j += 1;
        }
        line += 1;
    }
    let mut i = line;
    while i < n {
        ciphertext.push(plaintext[i]);
        i += 2 * (key - 1);
    }
    ciphertext
}

/// Practical Cryptography's Rail-fence Cipher tool, decrypting.
pub struct PcRailfence;

impl Node for PcRailfence {
    fn name(&self) -> &'static str {
        "pc_railfence"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        PC_RAILFENCE_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = params.req_i64("pc_railfence", "key")?;
        if key < 1 {
            return Err(Error::bad_param("pc_railfence", "key", "must be at least 1"));
        }

        let in_norm = crate::classical::toolfmt::read_input_norm(
            "pc_railfence",
            params,
            InputNorm {
                case: CaseFold::Lower,
                strip_outside_alphabet: Some("abcdefghijklmnopqrstuvwxyz".to_string()),
                ..InputNorm::default()
            },
        )?;
        let text = in_norm.apply(&input.data);

        let plain = decrypt(&text, key as usize)?;

        // Site writes into a plain <textarea id="p"> via .value =.
        let out_fmt: OutputFmt = read_output_fmt(
            "pc_railfence",
            params,
            OutputFmt {
                case: CaseFold::Preserve,
                grouping: None,
                trailing: Trailing::None,
            },
        )?;
        let out = out_fmt.apply(&plain);
        Ok(Repr::new(out, input.display))
    }
}

register_node!(PC_RAILFENCE => || Box::new(PcRailfence));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    /// Ground truth, verbatim from the page's own worked example.
    #[test]
    fn pc_railfence_site_worked_example_key3() {
        let pt = b"defendtheeastwallofthecastle";
        let ct = encrypt(pt, 3);
        assert_eq!(ct, b"dnetlhseedheswloteateftaafcl");
        assert_eq!(decrypt(&ct, 3).unwrap(), pt);
    }

    #[test]
    fn pc_railfence_site_worked_example_key4() {
        let pt = b"defendtheeastwallofthecastle";
        let ct = encrypt(pt, 4);
        assert_eq!(ct, b"dttfsedhswotatfneaalhcleelee");
        assert_eq!(decrypt(&ct, 4).unwrap(), pt);
    }

    #[test]
    fn pc_railfence_key_one_is_identity() {
        let pt = b"attackatdawn";
        assert_eq!(encrypt(pt, 1), pt);
        assert_eq!(decrypt(pt, 1).unwrap(), pt);
    }

    #[test]
    fn pc_railfence_round_trips_varied_keys_and_lengths() {
        let samples: &[&[u8]] = &[b"a", b"ab", b"attackatdawn", b"thequickbrownfoxjumpsoverthelazydog"];
        for pt in samples {
            let n = pt.len();
            for key in 1usize..=8 {
                // Stay within the site's own "key too large for this length" limit.
                if n >= 2 && key > 2 * (n - 1) {
                    continue;
                }
                let ct = encrypt(pt, key);
                let back = decrypt(&ct, key).unwrap();
                assert_eq!(&back, pt, "pt={pt:?} key={key}");
            }
        }
    }

    #[test]
    fn pc_railfence_node_decrypts_via_registry() {
        let ct = encrypt(b"defendtheeastwallofthecastle", 3);
        let n = registry().get("pc_railfence").unwrap();
        let p = params! {"key" => 3i64};
        let out = n.apply(&Repr::bytes(ct), &p).unwrap();
        assert_eq!(out.data, b"defendtheeastwallofthecastle");
    }

    #[test]
    fn pc_railfence_node_lowercases_and_filters_input() {
        let ct_clean = encrypt(b"defendtheeastwallofthecastle", 3);
        let ct_dirty = "DNE1TL-HSE!EDHESWLOTEATEFT,AAFCL";
        let filtered: Vec<u8> = ct_dirty
            .to_lowercase()
            .bytes()
            .filter(|b| b.is_ascii_lowercase())
            .collect();
        assert_eq!(filtered, ct_clean);

        let n = registry().get("pc_railfence").unwrap();
        let p = params! {"key" => 3i64};
        let out = n.apply(&Repr::bytes(ct_dirty.as_bytes().to_vec()), &p).unwrap();
        assert_eq!(out.data, b"defendtheeastwallofthecastle");
    }

    #[test]
    fn pc_railfence_rejects_zero_key() {
        let n = registry().get("pc_railfence").unwrap();
        let p = params! {"key" => 0i64};
        assert!(n.apply(&Repr::bytes(b"x".to_vec()), &p).is_err());
    }

    #[test]
    fn pc_railfence_preserves_display() {
        let ct = encrypt(b"defendtheeastwallofthecastle", 3);
        let n = registry().get("pc_railfence").unwrap();
        let p = params! {"key" => 3i64};
        let out = n.apply(&Repr::new(ct, Display::Hex), &p).unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    /// The payoff: with `strip_non_alphabet` explicitly disabled, this
    /// transposition operates on any medium, not just a-z text -- proven here
    /// against a 1092-character hex string, the length of rev7's ciphertext.
    #[test]
    fn pc_railfence_preserves_hex_medium_when_stripping_disabled() {
        let hex: String = (0..1092).map(|i| "0123456789abcdef".as_bytes()[i % 16] as char).collect();
        let n = registry().get("pc_railfence").unwrap();
        let p = params! {
            "key" => 3i64,
            "strip_non_alphabet" => false,
            "output_case" => "preserve",
        };
        let out = n.apply(&Repr::bytes(hex.clone().into_bytes()), &p).unwrap();
        assert_eq!(out.data.len(), 1092);
        let mut want: Vec<u8> = hex.into_bytes();
        want.sort();
        let mut got = out.data.clone();
        got.sort();
        assert_eq!(got, want, "must be a pure permutation: same multiset of bytes");
    }

    #[test]
    fn pc_railfence_is_xf_family_and_not_layer_forming() {
        let n = registry().get("pc_railfence").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
