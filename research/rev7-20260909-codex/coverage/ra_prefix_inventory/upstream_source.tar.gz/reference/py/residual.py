"""
residual.py  -  Define the modelled universe, register coverage claims,
                compute exactly what remains untried.

Usage:
    python3 residual.py            # worked example for TG4
"""
from covalg import Product, Cover, CoverageSet, prod, cover

# --------------------------------------------------------------------------
# DOMAIN VOCABULARY  (the canonical named sets; claims must reference these)
# --------------------------------------------------------------------------
V_TG4 = {f"v{i:02d}" for i in range(1, 17)}          # 16 transcription variants
V_PREF = {"v01"}                                      # Oswald-preferred variant

K_TG4 = {"TheGiant", "Zombies", "ZOMBIES", "thegiant", "TheGiant_b64", "zombies"}
K_GIANT = {"TheGiant"}
K_Z = {"Zombies"}

KD = {"nullpad", "repeatpad"}                         # key-derivation rule

P_OBS = {"DES", "RC2", "RC4", "Blowfish", "Blowfish-compat", "Twofish",
         "Serpent", "Loki97", "Saferplus", "XTEA", "Rijndael-256"}
P_STOCK = {"DES", "RC2", "RC4", "Blowfish"}           # available in stock libs
P_ALL = P_OBS | {"CAST-128", "CAST-256", "TripleDES", "Enigma", "Gost",
                 "Rijndael-128", "Rijndael-192", "Wake"}

M_OBS = {"cfb8", "ecb"}
M_ALL = M_OBS | {"cbc", "ofb", "nofb", "ncfb", "stream"}

IV_A = {"ascii0"}                                     # 3030..30
IV_ALL = {"ascii0", "null", "other"}

XF = {"identity", "reverse", "rot", "route4"}         # transform families

# --------------------------------------------------------------------------
# UNIVERSE  (mirrors the Document 4 tier model)
# --------------------------------------------------------------------------
SK_T1 = ("b64d", "dec")                       # decode then one modern layer
SK_T2 = ("b64d", "xf", "dec")                 # decode, transform, modern
SK_T3 = ("b64d", "dec", "xf", "dec")          # two modern layers

def universe_tg4(full=True) -> CoverageSet:
    P, M, IV = (P_ALL, M_ALL, IV_ALL) if full else (P_OBS, M_OBS, IV_A)
    U = CoverageSet()
    U.add(cover(SK_T1, prod(**{
        "0.variant": V_TG4, "1.key": K_TG4, "1.kd": KD,
        "1.prim": P, "1.mode": M, "1.iv": IV})))
    U.add(cover(SK_T2, prod(**{
        "0.variant": V_TG4, "1.xf": XF, "2.key": K_TG4, "2.kd": KD,
        "2.prim": P, "2.mode": M, "2.iv": IV})))
    U.add(cover(SK_T3, prod(**{
        "0.variant": V_TG4, "1.key": K_TG4, "1.kd": KD, "1.prim": P,
        "1.mode": M, "1.iv": IV, "2.xf": XF, "3.key": K_TG4, "3.kd": KD,
        "3.prim": P, "3.mode": M, "3.iv": IV})))
    return U

# --------------------------------------------------------------------------
# EXAMPLE CLAIMS
# --------------------------------------------------------------------------
def claim_A() -> CoverageSet:
    """'We brute forced every mcrypt combination on the giant with key TheGiant.'
    Reality of such a run: preferred transcription only, stock primitives only,
    observed modes only, single layer."""
    c = CoverageSet()
    c.add(cover(SK_T1, prod(**{
        "0.variant": V_PREF, "1.key": K_GIANT, "1.kd": {"nullpad"},
        "1.prim": P_STOCK, "1.mode": M_OBS, "1.iv": IV_A})))
    return c

def claim_B() -> CoverageSet:
    """A later run: all 16 transcriptions, key Zombies, full primitive menu,
    single layer, both key derivations, all IVs."""
    c = CoverageSet()
    c.add(cover(SK_T1, prod(**{
        "0.variant": V_TG4, "1.key": K_Z, "1.kd": KD,
        "1.prim": P_OBS, "1.mode": M_OBS, "1.iv": IV_ALL})))
    return c

def claim_C() -> CoverageSet:
    """Transform + modern, preferred transcription, reverse only, stock prims."""
    c = CoverageSet()
    c.add(cover(SK_T2, prod(**{
        "0.variant": V_PREF, "1.xf": {"reverse"}, "2.key": K_TG4,
        "2.kd": {"nullpad"}, "2.prim": P_STOCK, "2.mode": M_OBS, "2.iv": IV_A})))
    return c

# --------------------------------------------------------------------------
def fmt(n):
    for u, d in [("e12", 1e12), ("e9", 1e9), ("e6", 1e6), ("e3", 1e3)]:
        if n >= d:
            return f"{n/d:,.2f}{u}"
    return f"{n:,}"

if __name__ == "__main__":
    U = universe_tg4(full=True)
    print("=" * 78)
    print("UNIVERSE  (TG4, full mcrypt menu, tiers T1-T3)")
    print("=" * 78)
    for sk, cov in sorted(U.covers.items()):
        print(f"  <{' o '.join(sk)}>  size = {fmt(cov.size_exact())}")
    print(f"  TOTAL = {fmt(U.size_exact())}")
    print(f"  digest = {U.digest()[:26]}...")

    claims = [("A  single-layer, key TheGiant, stock prims", claim_A()),
              ("B  single-layer, key Zombies, all prims/IVs", claim_B()),
              ("C  reverse+modern, stock prims", claim_C())]

    print("\n" + "=" * 78)
    print("REGISTERED CLAIMS")
    print("=" * 78)
    combined = CoverageSet()
    for name, c in claims:
        print(f"\n{name}")
        print(f"   size   = {fmt(c.size_exact())}")
        print(f"   digest = {c.digest()[:26]}...")
        for line in c.notation().splitlines():
            print("   " + line)
        combined = combined.union(c)

    print("\n" + "=" * 78)
    print("AGGREGATE COVERAGE  (union, overlap removed exactly)")
    print("=" * 78)
    naive = sum(c.size_exact() for _, c in claims)
    exact = combined.size_exact()
    print(f"  naive sum of claims   = {fmt(naive)}")
    print(f"  exact union           = {fmt(exact)}")
    print(f"  double-counted        = {fmt(naive - exact)}  <- invisible if you only report counts")

    print("\n" + "=" * 78)
    print("RESIDUAL  =  UNIVERSE \\ AGGREGATE")
    print("=" * 78)
    R = U.difference(combined)
    for sk, cov in sorted(R.covers.items()):
        print(f"  <{' o '.join(sk)}>  remaining = {fmt(cov.size_exact())}  "
              f"({len(cov.products)} disjoint blocks)")
    print(f"  TOTAL REMAINING = {fmt(R.size_exact())}")
    pct = 100.0 * exact / U.size_exact()
    print(f"  coverage achieved = {pct:.4f}%   of modelled universe")
    print(f"  residual digest   = {R.digest()[:26]}...")

    print("\n" + "=" * 78)
    print("SAMPLE OF WHAT REMAINS  (first blocks of the T1 residual)")
    print("=" * 78)
    t1 = R.covers.get(SK_T1)
    if t1:
        for p in t1.products[:3]:
            print("  " + p.notation())
            print(f"     size {fmt(p.size())}")
