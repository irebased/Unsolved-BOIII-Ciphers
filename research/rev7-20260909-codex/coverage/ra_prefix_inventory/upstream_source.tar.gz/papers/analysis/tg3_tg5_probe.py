#!/usr/bin/env python3
"""Independent probes of the newly-supplied TG3 and TG5 ciphertexts.

TG3: test whether its "base64-ish" charset is really the Bletchley Park / General
     Report on Tunny ITA2 teleprinter notation, and recover the Lorenz keystream
     from the known plaintext to look for a two-wheel structure.
TG5: verify the recorded Enigma M3 settings reproduce the recorded plaintext.

Stdlib only.  Run: python3 papers/analysis/tg3_tg5_probe.py
"""
import collections

# ---------------------------------------------------------------- TG3 -------

# ITA2 five-bit codes in numeric order 0..31, written in the Bletchley Park
# "General Report on Tunny" notation: 26 letters plus six specials.
#   /  = null (00000)      9 = space (00100)     3 = carriage return (00010)
#   4  = line feed (01000) + = figure shift      - = letter shift
ITA2 = "/T3O9HNM4LRGIPCVEZDBSYFXAWJ+UQK-"
CODE = {c: i for i, c in enumerate(ITA2)}

TG3_CT = "NMFU3DNILVAXTPPH9AYHRXUM3PDBVMHN/CANVGPYS+3HGQKH"
TG3_PT = "When finished we will return to the house and the infinite"

TG5_CT = "VXFPNFSVOHBMJBOHYDPLBBRNDJWOWIWUUJJJHVYKAGZAIY"
TG5_PT = "A city of fire surrounds the warrior the last of his kind"


def tg3():
    print("=" * 72)
    print("TG3  --  simplified Lorenz, recorded 'K-wheel = 9 and S-wheel = 4'")
    print("=" * 72)
    ct = TG3_CT
    pt = "".join(c for c in TG3_PT.upper() if c.isalpha())
    alpha = sorted(set(ct))
    print(f"ciphertext length      : {len(ct)}")
    print(f"plaintext, letters only: {len(pt)}")
    print(f"ciphertext alphabet    : {len(alpha)} symbols  {''.join(alpha)}")
    specials = sorted(set(ct) - set("ABCDEFGHIJKLMNOPQRSTUVWXYZ"))
    print(f"non-letter symbols     : {specials}")
    print()
    print("Bletchley/Tunny ITA2 notation uses exactly these six non-letters:")
    print("   / null   9 space   3 CR   4 LF   + FIGS   - LTRS")
    inside = all(c in CODE for c in ct)
    print(f"every TG3 symbol is a legal ITA2/Tunny glyph : {inside}")
    print(f"TG3's non-letters are a subset of them       : "
          f"{set(specials) <= set('/934+-')}")
    b64 = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/")
    print(f"TG3's non-letters are a subset of base64     : "
          f"{set(specials) <= b64}   <- coincidence of glyphs, see below")
    print()

    if len(ct) != len(pt):
        print("!! length mismatch, cannot align")
        return
    ks = [CODE[c] ^ CODE[p] for c, p in zip(ct, pt)]
    print("Recovered keystream (ct XOR pt in ITA2), as Tunny glyphs:")
    print("   " + "".join(ITA2[k] for k in ks))
    print("   " + " ".join(f"{k:02d}" for k in ks[:24]))
    print("   " + " ".join(f"{k:02d}" for k in ks[24:]))
    print()
    print("Self-encipherment check (Lorenz is an XOR stream, so ct==pt is legal")
    print(f"wherever the key symbol is null): ct[i]==pt[i] at "
          f"{sum(1 for a, b in zip(ct, pt) if a == b)} of {len(ct)} positions")
    print()
    print("Period search over the recovered keystream")
    print("  a two-wheel simplified Lorenz with wheels of length m and n has")
    print("  keystream period lcm(m, n); for m=9, n=4 that is 36.")
    print(f"  {'p':>3}  {'matches':>9}  {'of':>4}   rate")
    best = []
    for p in range(1, len(ks)):
        pairs = [(i, i + p) for i in range(len(ks) - p)]
        m = sum(1 for i, j in pairs if ks[i] == ks[j])
        rate = m / len(pairs)
        best.append((rate, p, m, len(pairs)))
        if p in (4, 9, 36, 12, 18) or rate > 0.15:
            print(f"  {p:>3}  {m:>9}  {len(pairs):>4}   {rate:.3f}")
    best.sort(reverse=True)
    print("  top 5 by rate:", [(p, f"{r:.3f}") for r, p, _, _ in best[:5]])
    print()
    print("Per-bit period search (each of the 5 ITA2 impulses separately);")
    print("a chi/psi wheel model makes each impulse independently periodic.")
    for bit in range(5):
        stream = [(k >> (4 - bit)) & 1 for k in ks]
        rows = []
        for p in (4, 9, 36):
            pairs = [(i, i + p) for i in range(len(stream) - p)]
            m = sum(1 for i, j in pairs if stream[i] == stream[j])
            rows.append(f"p={p}: {m}/{len(pairs)}={m / len(pairs):.2f}")
        print(f"  impulse {bit + 1}: " + "   ".join(rows))
    print()
    c = collections.Counter(ks)
    print(f"distinct keystream symbols: {len(c)} of 32")
    print(f"most common: {c.most_common(6)}")


# ---------------------------------------------------------------- TG5 -------

ROTORS = {
    "I": ("EKMFLGDQVZNTOWYHXUSPAIBRCJ", "Q"),
    "II": ("AJDKSIRUXBLHWTMCQGZNPYFVOE", "E"),
    "III": ("BDFHJLCPRTXVZNYEIWGAKMUSQO", "V"),
    "IV": ("ESOVPZJAYQUIRHXLNFTGKDCMWB", "J"),
    "V": ("VZBRGITYUPSDNHLXAWMJQOFECK", "Z"),
}
UKW = {
    "B": "YRUHQSLDPXNGOKMIEBFZCWVJAT",
    "C": "FVPJIAOYEDRZXWGCTKUQSBNMHL",
}
A = ord("A")


class Enigma:
    """Enigma M3.  rotors given LEFT to RIGHT (slow, middle, fast)."""

    def __init__(self, rotors, reflector, rings, key, plugs):
        self.w = [ROTORS[r] for r in rotors]
        self.ukw = UKW[reflector]
        self.ring = [ord(c) - A for c in rings]
        self.pos = [ord(c) - A for c in key]
        self.pb = {c: c for c in range(26)}
        for pair in plugs.split():
            a, b = ord(pair[0]) - A, ord(pair[1]) - A
            self.pb[a], self.pb[b] = b, a

    def _step(self):
        r_notch = self.w[2][1]
        m_notch = self.w[1][1]
        at_r = self.pos[2] == ord(r_notch) - A
        at_m = self.pos[1] == ord(m_notch) - A
        if at_m:  # double step
            self.pos[1] = (self.pos[1] + 1) % 26
            self.pos[0] = (self.pos[0] + 1) % 26
        elif at_r:
            self.pos[1] = (self.pos[1] + 1) % 26
        self.pos[2] = (self.pos[2] + 1) % 26

    def _fwd(self, i, c):
        s = (c + self.pos[i] - self.ring[i]) % 26
        o = ord(self.w[i][0][s]) - A
        return (o - self.pos[i] + self.ring[i]) % 26

    def _bwd(self, i, c):
        s = (c + self.pos[i] - self.ring[i]) % 26
        o = self.w[i][0].index(chr(s + A))
        return (o - self.pos[i] + self.ring[i]) % 26

    def char(self, ch):
        self._step()
        c = self.pb[ord(ch) - A]
        for i in (2, 1, 0):
            c = self._fwd(i, c)
        c = ord(self.ukw[c]) - A
        for i in (0, 1, 2):
            c = self._bwd(i, c)
        return chr(self.pb[c] + A)

    def run(self, text):
        return "".join(self.char(c) for c in text)


def tg5():
    print()
    print("=" * 72)
    print("TG5  --  Enigma M3, recorded UKW-B / rotors 123 / rings AAD / key WAD")
    print("=" * 72)
    ct = TG5_CT
    pt = "".join(c for c in TG5_PT.upper() if c.isalpha())
    print(f"ciphertext length      : {len(ct)}")
    print(f"plaintext, letters only: {len(pt)}")
    print(f"ciphertext alphabet    : {len(set(ct))} symbols, pure A-Z: "
          f"{set(ct) <= set('ABCDEFGHIJKLMNOPQRSTUVWXYZ')}")
    coll = sum(1 for a, b in zip(ct, pt) if a == b)
    print(f"positions where ct[i]==pt[i]: {coll}   "
          f"(Enigma NEVER enciphers a letter to itself; must be 0)")
    print()
    plugs = "PO ML IU KJ NH YT GB VF RE DC"
    print("Trying the recorded settings under every rotor-order / ring-order")
    print("reading convention, since the record does not say which end is which.")
    hits = []
    for rot in (["I", "II", "III"], ["III", "II", "I"]):
        for rings in ("AAD", "DAA"):
            for key in ("WAD", "DAW"):
                for pl in (plugs, ""):
                    try:
                        out = Enigma(rot, "B", rings, key, pl).run(ct)
                    except Exception as e:  # noqa: BLE001
                        print("  err", e)
                        continue
                    score = sum(1 for a, b in zip(out, pt) if a == b)
                    tag = (f"rotors={'-'.join(rot)} rings={rings} key={key} "
                           f"plugs={'yes' if pl else 'no'}")
                    hits.append((score, tag, out))
    hits.sort(reverse=True)
    for score, tag, out in hits[:6]:
        print(f"  {score:>2}/{len(pt)}  {tag}")
        print(f"          {out}")
    print()
    print(f"  recorded plaintext: {pt}")


if __name__ == "__main__":
    tg3()
    tg5()
