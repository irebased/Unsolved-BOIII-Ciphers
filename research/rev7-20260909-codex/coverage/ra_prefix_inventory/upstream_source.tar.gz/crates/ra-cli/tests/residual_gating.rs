//! Conformance gating is enforced on the path a real user takes.
//!
//! `ra-attest` has always implemented and tested the gate. Nothing on the
//! `ra sweep --emit-claim` -> `ra residual --claims` path ever called it, and because
//! all eleven mcrypt primitives are conformance-PASS the omission was invisible: the
//! gate would have been the identity anyway.
//!
//! These tests therefore drive the **real binary**, not the library. A test that only
//! exercised `ra_attest::gate_coverage` would have passed throughout the entire period
//! the defect existed, and so would a test on any helper `cmd_residual` merely
//! happens to call. The question being asked here is "does `ra residual` gate?", and
//! the only way to ask it is to run `ra residual`.

use std::path::PathBuf;
use std::process::{Command, Output};

fn data_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../data")
}

fn scratch(name: &str) -> PathBuf {
    let dir = std::env::temp_dir().join(format!("ra-gating-{}-{}", std::process::id(), name));
    std::fs::create_dir_all(&dir).expect("scratch dir");
    dir
}

/// A T1 claim over one point of the universe, naming whatever primitives it is given.
///
/// `conformance` is spliced in verbatim so a test can emit a claim with a provenance
/// block, without one, or with a stale one.
fn claim_json(prims: &[&str], key: &str, kd: &str, mode: &str, iv: &str, conformance: &str) -> String {
    let prims: Vec<String> = prims.iter().map(|p| format!("{p:?}")).collect();
    format!(
        r#"{{
  "target": "tg4",
  "oracle": "printable-0.75",
  "variant": "v00",
  {conformance}
  "coverage_claimed": {{
    "skeletons": [
      {{
        "skeleton": ["b64d", "dec"],
        "products": [
          {{
            "0.variant": ["v01"],
            "1.key": [{key:?}],
            "1.kd": [{kd:?}],
            "1.mode": [{mode:?}],
            "1.iv": [{iv:?}],
            "1.prim": [{}]
          }}
        ]
      }}
    ]
  }}
}}"#,
        prims.join(", ")
    )
}

fn write_claim(dir: &std::path::Path, name: &str, body: &str) -> PathBuf {
    let p = dir.join(name);
    std::fs::write(&p, body).expect("write claim");
    p
}

fn residual(claims: &[&PathBuf]) -> Output {
    let mut cmd = Command::new(env!("CARGO_BIN_EXE_ra"));
    cmd.arg("--data").arg(data_dir()).arg("residual").arg("--full");
    if !claims.is_empty() {
        let joined: Vec<String> = claims
            .iter()
            .map(|p| p.to_string_lossy().into_owned())
            .collect();
        cmd.arg("--claims").arg(joined.join(","));
    }
    cmd.output().expect("run ra residual")
}

fn stdout_of(out: &Output) -> String {
    String::from_utf8_lossy(&out.stdout).into_owned()
}

/// Pull the per-claim `claimed` / `effective` pair out of the block naming `file`.
fn sizes_for(stdout: &str, file: &str) -> (String, String) {
    let block: Vec<&str> = stdout
        .lines()
        .skip_while(|l| !l.contains(file))
        .take(12)
        .collect();
    let grab = |prefix: &str| -> String {
        block
            .iter()
            .find(|l| l.trim_start().starts_with(prefix))
            .unwrap_or_else(|| panic!("no {prefix} line for {file} in:\n{}", block.join("\n")))
            .split('=')
            .nth(1)
            .unwrap()
            .split_whitespace()
            .next()
            .unwrap()
            .to_string()
    };
    (grab("claimed"), grab("effective"))
}

fn exact_union(stdout: &str) -> u128 {
    stdout
        .lines()
        .find(|l| l.trim_start().starts_with("exact union"))
        .expect("exact union line")
        .split('=')
        .nth(1)
        .unwrap()
        .trim()
        .parse()
        .expect("exact union is a plain integer at this scale")
}

const NO_BLOCK: &str = "";

/// The conformance block a current `ra sweep --emit-claim` writes.
fn recorded_block(proven: &[&str]) -> String {
    let proven: Vec<String> = proven.iter().map(|p| format!("{p:?}")).collect();
    format!(
        r#""conformance": {{
    "suite_digest": "sha256:stale",
    "proven_primitives": [{}],
    "unproven_primitives": [],
    "all_swept_primitives_proven": true
  }},"#,
        proven.join(", ")
    )
}

// ---------------------------------------------------------------------------
// The missing integration test
// ---------------------------------------------------------------------------

/// A claim naming a primitive that does not reproduce contributes **zero** coverage
/// for that primitive when folded by `cmd_residual`.
///
/// The unproven primitive is synthetic — `Rijndael-512` is not in this engine's
/// vocabulary and no vector can prove it — rather than a real primitive broken to
/// order. Breaking a real one would make the test depend on sabotage that must then
/// be undone; injecting an unproven name models "an unproven twelfth primitive was
/// added", which is the failure actually being defended against.
#[test]
fn an_unproven_primitive_contributes_zero_coverage_to_the_residual() {
    let dir = scratch("unproven");
    let c = write_claim(
        &dir,
        "unproven.json",
        &claim_json(
            &["Rijndael-512"],
            "thegiant",
            "natural",
            "nofb",
            "null",
            NO_BLOCK,
        ),
    );
    let out = residual(&[&c]);
    assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
    let s = stdout_of(&out);

    let (claimed, effective) = sizes_for(&s, "unproven.json");
    assert_eq!(claimed, "1", "the claim asserts one candidate");
    assert_eq!(effective, "0", "an unproven primitive must carry zero coverage");
    assert!(s.contains("VOID Rijndael-512"), "the void must be attributed:\n{s}");

    // And the aggregate is unmoved: the point of gating is that void coverage cannot
    // subtract from the residual. 100 is the union of the four worked examples alone
    // — a function of how many readings TG4's `0.variant` axis admits, which is data,
    // not code: 128 pre-canonical, then 2 ({v4c, v6c}) under the first canonical
    // transcription (which left offset 90 open), and now 1 (`v10`) under the official,
    // fully-resolved transcription adopted 2026-07-30. Worked example B is the only one
    // of the four that sweeps the whole admissible set rather than one fixed reading,
    // so it is the one whose size halved (88 -> 44) when the readings went from 2 to 1,
    // which is exactly the 44 the union dropped by (144 -> 100). If this number moves
    // again, check `data/the_giant.json`'s `ciphertext_canonical` before suspecting the
    // gate: an admissible-reading count change is expected to move it; a wrong gate is
    // not.
    assert_eq!(
        exact_union(&s),
        116,
        "void coverage must not enter the aggregate"
    );
}

/// The same claim naming a *proven* primitive does move the aggregate, so the test
/// above is measuring the gate rather than a claim that was inert for some other
/// reason (outside the universe, duplicated by a worked example, malformed).
#[test]
fn the_same_claim_with_a_proven_primitive_does_enter_the_aggregate() {
    let dir = scratch("proven");
    let c = write_claim(
        &dir,
        "proven.json",
        &claim_json(&["DES"], "thegiant", "natural", "nofb", "null", NO_BLOCK),
    );
    let out = residual(&[&c]);
    assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
    let s = stdout_of(&out);
    let (claimed, effective) = sizes_for(&s, "proven.json");
    assert_eq!((claimed.as_str(), effective.as_str()), ("1", "1"));
    // 116 (see `an_unproven_primitive_contributes_zero_coverage_to_the_residual`) + 1.
    assert_eq!(
        exact_union(&s),
        117,
        "a proven claim adds exactly its one candidate"
    );
}

/// Claimed and effective sizes differ exactly as expected for a mixed claim.
#[test]
fn claimed_and_effective_differ_for_a_mixed_claim() {
    let dir = scratch("mixed");
    let c = write_claim(
        &dir,
        "mixed.json",
        &claim_json(
            &["DES", "Rijndael-512", "Twofish"],
            "thegiant",
            "natural",
            "nofb",
            "null",
            NO_BLOCK,
        ),
    );
    let out = residual(&[&c]);
    assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
    let s = stdout_of(&out);
    let (claimed, effective) = sizes_for(&s, "mixed.json");
    assert_eq!(claimed, "3", "three primitives, one candidate each");
    assert_eq!(effective, "2", "DES and Twofish survive; Rijndael-512 does not");
    assert!(s.contains("VOID Rijndael-512"));
    assert!(
        !s.contains("VOID DES") && !s.contains("VOID Twofish"),
        "proven primitives must not be voided:\n{s}"
    );
    // 116 (see `an_unproven_primitive_contributes_zero_coverage_to_the_residual`) + 2.
    assert_eq!(exact_union(&s), 118, "exactly the two proven points land");
}

// ---------------------------------------------------------------------------
// Provenance
// ---------------------------------------------------------------------------

/// A claim carrying no conformance block is gated against *current* conformance and
/// flagged, not silently trusted.
#[test]
fn a_claim_without_a_conformance_block_is_flagged_not_trusted() {
    let dir = scratch("noblock");
    let c = write_claim(
        &dir,
        "noblock.json",
        &claim_json(&["DES"], "thegiant", "natural", "nofb", "null", NO_BLOCK),
    );
    let s = stdout_of(&residual(&[&c]));
    assert!(
        s.contains("provenance = NONE"),
        "a claim with no conformance block must say so:\n{s}"
    );
    assert!(s.contains("not self-describing") || s.contains("NOT self-describing"));
    // still gated, and still folded on its merits
    let (claimed, effective) = sizes_for(&s, "noblock.json");
    assert_eq!((claimed.as_str(), effective.as_str()), ("1", "1"));
}

/// A claim that records its conformance state has it reported, and drift against
/// current conformance is called out rather than trusted.
#[test]
fn a_recorded_conformance_block_is_reported_and_drift_is_flagged() {
    let dir = scratch("block");
    let c = write_claim(
        &dir,
        "block.json",
        &claim_json(
            &["DES"],
            "thegiant",
            "natural",
            "nofb",
            "null",
            &recorded_block(&["DES", "Rijndael-512"]),
        ),
    );
    let s = stdout_of(&residual(&[&c]));
    assert!(s.contains("provenance = conformance suite"), "{s}");
    assert!(
        s.contains("DRIFT") && s.contains("Rijndael-512"),
        "a primitive proven at emission but not now must be flagged:\n{s}"
    );
}

// ---------------------------------------------------------------------------
// Non-vacuity
// ---------------------------------------------------------------------------

/// A gate that finds nothing to check has not passed a claim; it has failed to gate
/// it. Prior art: `Rijndael-256` against a table keyed `rijndael-256` once made a
/// conformance check pass **vacuously** (ARCHITECTURE.md, deviation 3). The general
/// form of that hazard is a claim the gate cannot bite on at all, and it must be
/// refused rather than folded.
#[test]
fn a_claim_the_gate_cannot_bite_on_is_refused() {
    let dir = scratch("vacuous");
    // `1.primitive`, one letter from sailing through ungated
    let body = claim_json(&["DES"], "thegiant", "natural", "nofb", "null", NO_BLOCK)
        .replace("\"1.prim\"", "\"1.primitive\"");
    let c = write_claim(&dir, "vacuous.json", &body);
    let out = residual(&[&c]);
    assert!(
        !out.status.success(),
        "a claim with no *.prim dimension must not be folded"
    );
    let all = stdout_of(&out) + &String::from_utf8_lossy(&out.stderr);
    assert!(all.contains("vacuously"), "{all}");
}

/// The two spellings this workspace uses for the same primitive must both be
/// admitted, and a stranger must not be admitted by case-folding alone.
#[test]
fn the_gate_is_case_insensitive_without_being_name_blind() {
    let dir = scratch("case");
    let lower = write_claim(
        &dir,
        "lower.json",
        &claim_json(&["rijndael-256"], "thegiant", "natural", "nofb", "null", NO_BLOCK),
    );
    let upper = write_claim(
        &dir,
        "upper.json",
        &claim_json(&["RIJNDAEL-512"], "thegiant", "natural", "nofb", "null", NO_BLOCK),
    );
    let s = stdout_of(&residual(&[&lower, &upper]));
    assert_eq!(
        sizes_for(&s, "lower.json"),
        ("1".to_string(), "1".to_string()),
        "the mcrypt spelling names a proven primitive and must be admitted:\n{s}"
    );
    assert_eq!(
        sizes_for(&s, "upper.json"),
        ("1".to_string(), "0".to_string()),
        "case-folding must not admit a primitive nothing proves:\n{s}"
    );
}

// ---------------------------------------------------------------------------
// Anti-regression: the gate is reachable from the residual path
// ---------------------------------------------------------------------------

/// The defect was not a wrong gate; it was a correct gate nothing called. This test
/// asserts reachability directly: `ra residual` must run conformance, must report the
/// gate, and must compute the aggregate from effective coverage.
///
/// If a future refactor unions claims straight into the aggregate again, every
/// assertion here fails even though `ra-attest`'s own tests keep passing — which is
/// the distinction the exercise turns on.
#[test]
fn the_conformance_gate_is_reachable_from_the_residual_path() {
    let s = stdout_of(&residual(&[]));
    assert!(
        s.contains("CONFORMANCE GATE:"),
        "ra residual must execute conformance, not assume it:\n{s}"
    );
    // AES (`rijndael-128`), 3DES (`tripledes`), CAST-128, IDEA and now Salsa20 are
    // real, registered primitives with no corpus cipher to reproduce any of them,
    // so all are expected to sit in the unproven remainder by design — gating is
    // no longer the identity, and that is exactly what conformance gating exists
    // to report. If this figure moves again, check the proven/unproven split (a
    // newly added, still-unproven primitive) before suspecting the gating logic
    // itself.
    assert!(
        s.contains("11 of 16 mcrypt primitives reproduce right now"),
        "the gate must report the state it is gating against:\n{s}"
    );
    assert!(
        s.contains("UNPROVEN AES:"),
        "AES must be reported as unproven, not silently counted:\n{s}"
    );
    assert!(
        s.contains("UNPROVEN 3DES:"),
        "3DES must be reported as unproven, not silently counted:\n{s}"
    );
    assert!(
        s.contains("UNPROVEN Salsa20:"),
        "Salsa20 must be reported as unproven, not silently counted:\n{s}"
    );
    // Every registered claim, worked example or loaded file, reports both numbers.
    let claimed = s.lines().filter(|l| l.trim_start().starts_with("claimed   =")).count();
    let effective = s.lines().filter(|l| l.trim_start().starts_with("effective =")).count();
    assert_eq!(claimed, 4, "four worked-example claims, each gated:\n{s}");
    assert_eq!(effective, 4);
}

// ---------------------------------------------------------------------------
// A claim carries its own conformance provenance
// ---------------------------------------------------------------------------

fn repo_claim(name: &str) -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../claims").join(name)
}

fn verify(path: &std::path::Path) -> Output {
    Command::new(env!("CARGO_BIN_EXE_ra"))
        .arg("--data")
        .arg(data_dir())
        .arg("verify-claim")
        .arg(path)
        .output()
        .expect("run ra verify-claim")
}

/// `ra sweep --emit-claim` records the conformance state it ran under, and
/// `ra verify-claim` reports it. The precedent is `enumeration_order`: a claim must
/// carry what is needed to check it.
#[test]
fn an_emitted_claim_records_its_conformance_state_and_verify_reports_it() {
    let dir = scratch("emit");
    let out_path = dir.join("emitted.json");
    let out = Command::new(env!("CARGO_BIN_EXE_ra"))
        .arg("--data")
        .arg(data_dir())
        .args([
            "sweep",
            "--target",
            "rev7",
            "--tier",
            "t1",
            "--prims",
            "des",
            "--modes",
            "cfb",
            "--keys",
            "Zombies",
            "--kd",
            "natural",
            "--ivs",
            "ascii0",
        ])
        .arg("--emit-claim")
        .arg(&out_path)
        .output()
        .expect("run ra sweep");
    assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));

    let doc: serde_json::Value =
        serde_json::from_str(&std::fs::read_to_string(&out_path).unwrap()).unwrap();
    let block = &doc["conformance"];
    assert!(
        block["suite_digest"].as_str().unwrap().starts_with("sha256:"),
        "a claim must record which conformance suite it ran under: {doc}"
    );
    let proven: Vec<&str> = block["proven_primitives"]
        .as_array()
        .expect("proven_primitives")
        .iter()
        .map(|v| v.as_str().unwrap())
        .collect();
    assert_eq!(
        proven.len(),
        11,
        "the eleven corpus-confirmed primitives reproduce today: {proven:?}"
    );
    assert!(proven.contains(&"DES"));
    // AES (`rijndael-128`) and 3DES (`tripledes`) are registered and real but have
    // no corpus cipher to reproduce either of them, so both are expected to sit in
    // the global unproven remainder even though this sweep never named them. A
    // future move in this count means a newly added primitive is still unproven,
    // not a regression in one of the eleven that already reproduce — check
    // `proven` above first.
    let unproven: Vec<&str> = block["unproven_primitives"]
        .as_array()
        .unwrap()
        .iter()
        .map(|v| v.as_str().unwrap())
        .collect();
    // Grows whenever an UNPROVEN primitive is added. That is the gate working as
// designed: a primitive with no corpus reproduction carries zero coverage, so
// gating stops being the identity. If this list shrinks unexpectedly, suspect
// a primitive silently gaining a reproduction it has not earned.
    assert_eq!(unproven, vec!["AES", "3DES", "CAST-128", "IDEA", "Salsa20"], "{doc}");
    assert_eq!(block["all_swept_primitives_proven"], true);
    assert_eq!(block["swept_primitives"][0], "DES");

    let v = verify(&out_path);
    assert!(v.status.success(), "{}", String::from_utf8_lossy(&v.stderr));
    let s = stdout_of(&v);
    assert!(s.contains("conformance"), "{s}");
    assert!(s.contains("RECORDED : 11 proven"), "{s}");
    assert!(
        s.contains("every primitive proven at emission is still proven now"),
        "{s}"
    );
    assert!(s.contains("effective ="), "verify must report effective size:\n{s}");
}

/// Every claim committed before the conformance block existed must still load and
/// still verify. One of them represents a five-hour run; invalidating it to add a
/// field would be a worse outcome than the defect being fixed.
#[test]
fn the_committed_claims_still_verify_without_a_conformance_block() {
    for name in [
        "tg4-t1t2.json",
        "tg4-t3.json",
        "tg4-t1t2-all-variants.json",
        "rev7-t1t2.json",
        "rev7-t3.json",
    ] {
        let p = repo_claim(name);
        let out = verify(&p);
        assert!(
            out.status.success(),
            "{name} must still verify: {}",
            String::from_utf8_lossy(&out.stderr)
        );
        let s = stdout_of(&out);
        assert!(s.trim_end().ends_with("OK"), "{name}:\n{s}");
        assert!(
            s.contains("RECORDED : none"),
            "{name} predates the block, and that must be said out loud:\n{s}"
        );
        // it is still gated, and today gating is the identity
        let claimed = s.lines().find(|l| l.contains("claimed   =")).unwrap();
        let effective = s.lines().find(|l| l.contains("effective =")).unwrap();
        assert_eq!(
            claimed.split('=').nth(1).unwrap().trim(),
            effective.split('=').nth(1).unwrap().split_whitespace().next().unwrap(),
            "{name}: gating is the identity today, so no committed claim may shrink:\n{s}"
        );
    }
}

/// The exact union of the worked examples, pinned. It moved once already: 144 -> 100
/// when the official, fully-resolved `ciphertext_canonical` was adopted 2026-07-30 and
/// TG4's `0.variant` axis narrowed from 2 admissible readings (`{v4c, v6c}`) to 1
/// (`v10`) — see the comment on `an_unproven_primitive_contributes_zero_coverage_to_the_residual`
/// for the exact accounting. Before suspecting the gate, diff `data/the_giant.json`'s
/// `ciphertext_canonical` against what it was; only if that is unchanged does a moved
/// number here indicate a real regression.
///
/// It moved a second time, 100 -> 116, when conformance gained a **second proof
/// class**. Coverage used to require reproducing a solved corpus chain, which
/// conflated "is this implementation correct?" (answerable by the algorithm's own
/// normative vectors) with "did the puzzle author use this primitive?" (a prior about
/// the puzzle, not a property of the code). That was circular for the two unsolved
/// ciphers, which may use a primitive the solved corpus never did. So a primitive
/// checked against its own published vectors is now `VectorProven` and carries
/// coverage, tagged distinctly from `CorpusProven` and never merged with it.
///
/// Quantified: four primitives changed class — AES (FIPS-197 C.1 + libmcrypt's own
/// self-test), 3DES (libmcrypt's self-test), CAST-128 (RFC 2144 Appendix B.1) and
/// Salsa20 (Bernstein's reference vectors). Each contributes 4 candidates within
/// claim B (one `1.mode` x one `1.kd`-pair worth), so the union rises by exactly
/// 4 x 4 = 16, and claim B's effective coverage rises from 44 to 60 of its claimed 64.
///
/// Gating still bites, which is what keeps this test meaningful rather than
/// decorative: **IDEA** is proven under neither class — no corpus chain, and no
/// normative vector cited — so it alone is still voided, withholding the remaining 4.
/// If a future reader sees this number move again, check the class split
/// (`ra conformance`) before suspecting the gating logic.
///
/// A THIRD legitimate reason this digest moves, added 2026-08-02: TG4's canonical
/// transcription itself was corrected by the project owner (to the reading labelled
/// `v2c`, see `data/the_giant.json`'s `ciphertext_canonical_provenance` and its
/// `ciphertext_canonical_history`). The modelled universe's `0.variant` dimension is
/// DERIVED from that ciphertext rather than written down, which is the property that
/// keeps the residual honest when the record is corrected -- so a corrected reading
/// is expected to move the digest and is not a regression. Check the corpus record
/// before suspecting the gate.
///
/// The residual *digest* below does move independently of gating, and this is the
/// second, separate reason it can legitimately move: the modelled universe's own
/// `1.kd` axis is built from `KeyDerivation::ALL` (`crates/ra-cli/src/main.rs`),
/// which grew across three commits as the hash-derived family was completed:
/// 4 (raw-byte only) -> 7 (+ `md5`/`sha1`/`sha256` raw digests) -> 13 (+ their 6
/// lower/upper hex-string forms) -> **15** (+ `evp-md5`/`evp-sha256`,
/// `EVP_BytesToKey` — see `crates/ra-prim/src/keyderiv.rs`). `UNIVERSE` grows at
/// each step even though none of the four worked-example claims (which spell their
/// own `1.kd` lists literally, and so are unaffected) changed. Before suspecting the
/// gate over *this* digest, check whether `KeyDerivation::ALL`'s length changed; if
/// it did not, the move is a real regression. (The exact union and
/// claimed/effective/voided figures above are the number to trust for "did gating
/// itself do something new" — they are unmoved by `KeyDerivation::ALL` growing,
/// only the raw universe size is.)
#[test]
fn gating_is_the_identity_and_the_residual_is_unmoved_except_for_unproven_primitives() {
    let s = stdout_of(&residual(&[]));
    assert_eq!(exact_union(&s), 116);
    assert!(
        s.contains("residual digest   = sha256:1358d5d5224d06f76ce"),
        "the residual digest over the worked examples must not move for a reason \
         other than KeyDerivation::ALL's length, an unproven primitive joining the \
         vocabulary, or TG4's canonical transcription being corrected:\n{s}"
    );
    // Only IDEA is voided now. AES, 3DES, CAST-128 and Salsa20 are VectorProven --
    // each is checked against its algorithm's own normative vectors -- so they carry
    // coverage on that basis. IDEA has neither a corpus chain nor a cited normative
    // vector, so it is the one primitive still contributing exactly zero, which is
    // what keeps this test honest: the gate must still bite on something.
    assert!(
        s.contains("VOID IDEA:"),
        "IDEA is proven under neither class and must still be voided:\n{s}"
    );
    for carried in ["AES", "3DES", "CAST-128", "Salsa20"] {
        assert!(
            !s.contains(&format!("VOID {carried}:")),
            "{carried} is VectorProven and must NOT be voided any more:\n{s}"
        );
    }
    assert!(
        s.contains("claimed   = 64"),
        "claim B's claimed size grows as new primitives join the vocabulary:\n{s}"
    );
    assert!(
        s.contains("effective = 60  (1 primitive dimension(s) intersected with 15 proven)"),
        "only IDEA's 4 of claim B's 64 are withheld, against 15 proven \
         (11 CorpusProven + 4 VectorProven):\n{s}"
    );
    assert!(
        s.contains("4 of claimed coverage was VOIDED by conformance gating"),
        "{s}"
    );
}
