const S = require("./style.js");
const { docx, PAGE, numbering, title, subtitle, h1, h2, h3, p, mono, li, numItem, table, callout, spacer, makeHeaderFooter } = S;
const { Document, Packer, Paragraph, TextRun, BorderStyle } = docx;
const fs = require("fs");

const children = [];
const A = (...x) => children.push(...x);

A(title("Distributed Verification Architecture"));
A(subtitle("Per-Tool Versioning, a Central Ledger, and Trustworthy Claims from Untrusted Workers"));
A(p([
  { t: "Document 6 of 6 (Architecture). ", bold: true },
  "This document specifies how coverage claims from independently operated compute nodes can be admitted into a shared ledger without trusting the nodes. It extends the notation of Document 5 with per-tool versioning, and replaces client-side integrity assumptions with server-side verification. The central design decision is that the system verifies work rather than attesting identity, because attesting identity on hardware the operator controls is not achievable.",
]));

// 1 Threat model
A(h1("1. The Threat Model Is Inverted"));
A(p([
  "The intuitive concern in a volunteer compute network is that a participant submits a false positive. That concern is misplaced. A positive claim is a constructive proof: it asserts that a specific pipeline applied to a specific input yields a specific plaintext. Any party can re-execute that single pipeline in microseconds and confirm or refute it. Fabricating a hit is self-defeating, because it is refuted by the first verifier who looks, and it costs the fabricator their standing.",
]));
A(p([
  "The dangerous claim is the negative one. An assertion that a block of one hundred million candidates was swept and contained nothing cannot be checked by inspection. If false, it poisons the residual: the community permanently removes a region from the search, and that region may contain the answer. A fabricated negative is silent, durable, and directly harmful to the objective.",
]));
A(callout("Design consequence.", [
  "Verification effort belongs almost entirely on negative claims. Positive claims need only a re-execution check, which is trivial. This inverts where the engineering goes relative to intuition, and it is why the mechanisms in Section 4 are all concerned with proving that work was actually performed.",
], S.ACCENT));

// 2 Compilation
A(h1("2. Why Compiling the Engine Does Not Provide Integrity"));
A(p([
  "Code executing on hardware controlled by an adversary is not a security boundary. A compiled binary can be patched, run under a debugger, or bypassed entirely by posting crafted payloads directly at the ledger interface, which never observes the binary at all. Any signing key embedded in a distributed binary is extractable by the operator of the machine it runs on. This is the same problem faced by client-side anti-cheat and content protection, and it has no general solution.",
]));
A(p([
  "Compilation also carries a cost specific to this project. The dossier's conformance argument depends on implementations being independently auditable, because seven of the eleven confirmed primitives have no stock implementation and must be reviewed to be trusted. Shipping opaque binaries removes exactly the property the verification model relies on.",
]));
A(h2("2.1 What to do instead"));
A(table(
  ["Mechanism", "What it provides"],
  [
    ["Open source engine", "Independent audit of primitive implementations, which conformance gating requires"],
    ["Reproducible builds", "A verifiable mapping from audited source to binary hash, so the ledger can confirm which source a worker ran"],
    ["Per-tool content hashes", "Identification of the exact implementation used at each layer of a chain"],
    ["Server-side verification", "Integrity that does not depend on client behaviour at all"],
  ],
  [2600, 6648]
));
A(callout("Reframing.", [
  "Reproducible builds deliver what compilation was intended to deliver, and more. Compilation makes tampering harder to see. Reproducible builds make honesty possible to prove, because a binary hash maps back to reviewable source. The goal is not to hide the engine but to make its output checkable.",
]));

// 3 Per-tool versioning
A(h1("3. Per-Tool Versioning and Selective Invalidation"));
A(p([
  "Versioning each tool independently rather than versioning the platform is correct, and its payoff is larger than redundancy checking alone. A tool identity binds family, name, version, and the content hash of the built artifact:",
]));
A(...mono("dec:Twofish@1.2.0#58933589d80e\nxf:reverse@1.0.0#b57c646d3f82\ndcd:base64@1.0.0#b74bd3146d69"));
A(p([
  "A chain is the ordered composition of tool identities plus bound parameters, and the chain identity is the hash of that composition. Two workers running different implementations of the same logical primitive therefore produce different chain identities, which is what makes agreement between them evidence rather than tautology.",
]));
A(h2("3.1 Selective invalidation"));
A(p([
  "The concrete payoff appears when an implementation is found defective. Because the ledger records which tool identities each claim depends on, revoking one version voids exactly the claims that used it. In the reference scenario, four claims totalling 373 million candidates are on the ledger when a defect is found in one Twofish build:",
]));
A(table(
  ["Versioning strategy", "Voided", "Retained"],
  [
    ["Platform-level version", "373,000,000 (all)", "0"],
    ["Per-tool version", "215,000,000", "158,000,000 (42% preserved)"],
  ],
  [3000, 3100, 3148]
));
A(callout("Why this matters here specifically.", [
  "Document 1 flagged that a single incorrect assumption invalidates every result that inherited it. Per-tool versioning converts that from a catastrophic property into a bounded one. The blast radius of a defect becomes computable, and re-work is surgical rather than total.",
]));

// 4 Verification mechanisms
A(h1("4. Verifying Negative Claims"));
A(h2("4.1 Merkle commitment with spot audit"));
A(p([
  "The worker enumerates its assigned block deterministically, computes an output digest per candidate, builds a Merkle tree over the leaves, and commits the root before any challenge is issued. Because a consistent root requires every leaf, committing it is evidence that every candidate was evaluated. The ledger then selects k random indices, and for each one independently recomputes that candidate from scratch, checking the result against both the revealed leaf and the committed root.",
]));
A(p("Detection probability against a worker who honestly computed only a fraction of its block:"));
A(table(
  ["Honest fraction", "k = 10", "k = 20", "k = 40", "k = 80"],
  [
    ["99%", "9.6%", "18.2%", "33.1%", "55.2%"],
    ["95%", "40.1%", "64.2%", "87.1%", "98.3%"],
    ["90%", "65.1%", "87.8%", "98.5%", "99.98%"],
    ["75%", "94.4%", "99.7%", "99.999%", "100%"],
    ["50%", "99.9%", "100%", "100%", "100%"],
  ],
  [2200, 1762, 1762, 1762, 1762]
));
A(p([
  "Verifier cost is k evaluations regardless of block size, so the asymmetry strongly favours the ledger. Detection compounds across submissions, so a worker who skips a small fraction repeatedly is caught with probability approaching one.",
]));
A(h2("4.2 Planted-solution canaries"));
A(p([
  "Spot audits confirm that computed values are correct, but a sufficiently determined fabricator could compute honestly and still misreport the presence of a hit. Canaries close that gap. The ledger periodically issues a work unit whose target is synthetic: a known plaintext encrypted through a chain that lies inside the assigned block. An honest sweep must report that hit. A fabricated negative cannot. The worker cannot distinguish a canary from a live unit, because both are opaque byte strings drawn from the same domain.",
]));
A(table(
  ["Canary rate", "10 units", "25 units", "50 units", "100 units"],
  [
    ["2%", "18.3%", "39.7%", "63.6%", "86.7%"],
    ["5%", "40.1%", "72.3%", "92.3%", "99.4%"],
    ["10%", "65.1%", "92.8%", "99.5%", "100%"],
    ["20%", "89.3%", "99.6%", "100%", "100%"],
  ],
  [2200, 1762, 1762, 1762, 1762]
));
A(p([
  "The only cost is the compute spent on canary units, which is the canary rate as a fraction of network throughput. A rate of five percent detects a persistent fabricator with 92 percent probability within fifty units.",
]));
A(h2("4.3 N-version redundant assignment"));
A(p([
  "Neither audits nor canaries catch an honest worker running a defective implementation, because such a worker computes faithfully and reports truthfully; the primitive itself is wrong. This is the silent-void failure mode identified in Document 5, and only redundancy detects it. Each block is assigned to two or more workers using distinct tool identities for the same logical primitive. Agreement on the committed root is evidence both implementations are correct. Disagreement localises the defect to a specific tool version and triggers selective invalidation.",
]));
A(callout("Coverage of the three mechanisms.", [
  "Spot audit catches fabricated computation. Canaries catch fabricated reporting. N-version assignment catches honest execution of defective code. All three are needed; none subsumes another.",
], S.ACCENT));

// 5 Identity
A(h1("5. Engine Identity: Accountability Rather Than Attestation"));
A(p([
  "The requirement that the ledger authenticate the engine in a way users cannot hijack cannot be met by software alone. Genuine remote attestation requires a hardware root of trust, meaning a TPM, a secure enclave, or a cloud attestation service. Requiring that of volunteer participants would exclude most of them and would still not cover the case of a legitimate enclave running modified logic supplied by its operator.",
]));
A(p([
  "The workable substitute is accountability. Identity is a keypair registered with the ledger; the worker signs every submission. The keypair proves continuity of a participant across submissions, which is all that is required. It does not need to prove that the participant is running unmodified code, because the mechanisms in Section 4 verify the work rather than the worker.",
]));
A(table(
  ["Property", "Provided by", "Notes"],
  [
    ["Submission continuity", "Registered keypair, signed submissions", "Keys are registered per worker, never embedded in a distributed binary"],
    ["Trust level", "Audit history", "New identities start untrusted"],
    ["Sybil resistance", "Reputation cost of a fresh identity", "A new key gets low-value blocks and an elevated canary rate until history accrues"],
    ["Defect isolation", "Per-tool identities in each claim", "Enables selective invalidation on revocation"],
  ],
  [2200, 2900, 4148]
));
A(h2("5.1 Graduated trust"));
A(numItem([{ t: "Probationary. ", bold: true }, "New key. Elevated canary rate, full redundant assignment, claims held pending a second independent confirmation before entering the residual."], "steps"));
A(numItem([{ t: "Established. ", bold: true }, "Clean audit history over a threshold of units. Standard canary rate, redundancy on a sampled basis."], "steps"));
A(numItem([{ t: "Revoked. ", bold: true }, "Any audit failure or canary miss. All historical claims from that key are re-opened in the residual, not merely the failing one, because a demonstrated willingness to fabricate invalidates the prior evidence."], "steps"));

// 6 Limits
A(h1("6. Honest Limits"));
A(p([
  "The architecture bounds harm; it does not eliminate it. Three residual exposures should be stated plainly.",
]));
A(li([{ t: "A patient adversary can build reputation. ", bold: true }, "A participant who performs genuine work for an extended period and then fabricates a small number of negatives will evade detection for a time. Redundant assignment on a sampled basis is the mitigation, and it reduces rather than removes the exposure."]));
A(li([{ t: "Reputation systems can be gamed by resourced actors. ", bold: true }, "Multiple identities each doing real work can accumulate standing. The cost is real compute, which is the intended deterrent, but it is not a barrier to a motivated party."]));
A(li([{ t: "Consensus does not establish correctness. ", bold: true }, "If two workers independently choose the same defective third-party implementation, N-version agreement produces false confidence. Requiring implementation diversity, and recording it explicitly per tool identity, is the mitigation."]));
A(callout("The backstop.", [
  "The objective is self-verifying. Whoever finds the plaintext produces a proof anyone can check in one operation, and no ledger state can suppress that. The worst consequence of a poisoned residual is therefore delay, not permanent loss. Periodically re-opening regions marked closed, assigned to different workers, bounds that delay at a cost the network can choose.",
]));

// 7 Architecture
A(h1("7. Architecture Summary"));
A(table(
  ["Component", "Centralised", "Responsibility"],
  [
    ["Ledger", "Yes", "Universe definition, residual, block assignment, audit challenges, canary issuance, reputation"],
    ["Tool registry", "Yes", "Per-tool identities, conformance status, revocation"],
    ["Engine", "No", "Self-hosted. Deterministic enumeration, Merkle commitment, signed submission"],
    ["Compute", "No", "Volunteer hardware, no trust assumed"],
    ["Verification", "Yes", "Spot recomputation, canary checking, cross-worker comparison"],
  ],
  [1900, 1500, 5848]
));
A(h2("7.1 Submission flow"));
A(numItem(["Worker requests a block. Ledger assigns a disjoint residual block, possibly a canary, with a nonce."], "steps2"));
A(numItem(["Worker enumerates deterministically, evaluates every candidate, builds the Merkle tree."], "steps2"));
A(numItem(["Worker submits root, tool identities used, oracle identifier, hit list, signed with its registered key."], "steps2"));
A(numItem(["Ledger issues k random challenge indices. Worker returns leaves plus Merkle paths."], "steps2"));
A(numItem(["Ledger recomputes challenged candidates independently, verifies paths against the committed root, and checks canary outcomes."], "steps2"));
A(numItem(["On pass, the claim is gated through conformance (Document 5) and subtracted from the residual. On failure, the key is revoked and its history re-opened."], "steps2"));

A(h1("8. Reference Implementation"));
A(table(
  ["File", "Contents"],
  [
    ["tools/toolreg.py", "Tool identities, chain identity, ledger, selective invalidation"],
    ["tools/verify.py", "Merkle commitment, spot audit, canary and detection tables, live demo"],
    ["tools/covalg.py", "Coverage algebra (Document 5)"],
    ["data/coverage-attestation-v1.schema.json", "Attestation envelope schema"],
  ],
  [3400, 5848]
));

A(spacer(60));
A(new Paragraph({
  border: { top: { style: BorderStyle.SINGLE, size: 4, color: "9A9A9A", space: 6 } },
  spacing: { before: 120 },
  children: [new TextRun({ text: "End of Document 6. Run python3 toolreg.py and python3 verify.py to reproduce every figure in this paper.", italics: true, size: 18, color: "6A6A6A", font: S.FONT })],
}));

const doc = new Document({
  numbering,
  styles: { default: { document: { run: { font: S.FONT, size: 21, color: S.INK } } } },
  sections: [{ properties: { page: PAGE }, ...makeHeaderFooter("Distributed Verification Architecture"), children }],
});
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/claude/BO3_Cipher_Dossier/papers/06_Distributed_Verification.docx", buf);
  console.log("wrote 06_Distributed_Verification.docx", buf.length, "bytes");
});
