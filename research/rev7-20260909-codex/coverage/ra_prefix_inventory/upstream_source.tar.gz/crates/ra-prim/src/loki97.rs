//! LOKI97 (mcrypt name `loki97`): 128-bit block, 128/192/256-bit key, 16 rounds.
//!
//! # Conformance status: PASS, against rev5
//!
//! ```text
//! b64decode -> rc2/cfb -> reverse -> hex_to_base64 -> b64decode -> blowfish/cfb
//!           -> b64decode -> loki97/cfb
//! ```
//!
//! recovers rev5's recorded plaintext ("August, 1946. OSS report final T-7. All of
//! the Group 935 and Division 9 facilities we were able to procure have been
//! dismantled and crated..."). This is the vector that turns rev5's RC2 and
//! Blowfish checks from shape-based into plaintext-backed, because the whole chain
//! now terminates in known text. See `tests/corpus.rs`.
//!
//! # Provenance
//!
//! A direct port of libmcrypt's own `modules/algorithms/loki97.c` (Brian Gladman's
//! AES-submission-era implementation, `gladman@seven77.demon.co.uk`, 14 Jan 1999,
//! adapted to the libmcrypt API by Nikos Mavroyanopoulos), which is the behaviour
//! the corpus's ciphertexts were actually produced against. Working from the LOKI97
//! paper alone would not have reproduced it: the structural quirks below are
//! properties of this C file, not of the specification.
//!
//! Notes for anyone auditing this against that C source:
//!
//! - **Word order is reversed on load, and reversed-plus-swapped on store.** The C
//!   loads the 16-byte buffer as four native `word32`s and assigns
//!   `blk[3] = _blk[0] … blk[0] = _blk[3]`, then stores
//!   `_blk[0] = blk[1], _blk[1] = blk[0], _blk[2] = blk[3], _blk[3] = blk[2]` — a
//!   word-order reversal composed with the Feistel end-of-cipher half-swap. Each
//!   `word32` is read little-endian, because the `WORDS_BIGENDIAN` branch
//!   byte-swaps precisely to make a big-endian host behave like a little-endian
//!   one. `load_block` and `store_block` reproduce both permutations directly
//!   on bytes, so the result is host-endianness independent.
//! - **The key is loaded pairwise-swapped too**: `k4 = (in_key[0] << 32) |
//!   in_key[1]`, `k3` from words 2/3, `k2` from 4/5, `k1` from 6/7, with each word
//!   again a little-endian read.
//! - **libmcrypt's key schedule is the 256-bit one for every key size.** Its own
//!   comment says so ("256 bit version only") and it reads all eight `in_key`
//!   words while ignoring the `key_len` argument. That is not a latent buffer
//!   overrun, because `internal_init_mcrypt` in `lib/mcrypt.c` allocates the key
//!   buffer with `mxcalloc(1, mcrypt_enc_get_key_size(td))` — 32 zeroed bytes for
//!   loki97 — and copies only `lenofkey` bytes in. So a short key is silently
//!   zero-extended to 32 bytes, which is exactly what [`Loki97::new`] does.
//!
//!   **Consequence worth recording:** under this crate's null-padding key
//!   derivations, LOKI97 is *insensitive* to the choice between
//!   [`NullPadNextSupported`](crate::KeyDerivation::NullPadNextSupported) (16
//!   bytes) and [`NullPadMax`](crate::KeyDerivation::NullPadMax) (32 bytes) — both
//!   arrive at the same 32-byte zero-extended buffer, hence the same subkeys. The
//!   two *repeat*-padding policies do differ. This is checked in
//!   `tests::short_keys_are_zero_extended_to_32_bytes`.
//! - **The S-boxes are generated, not transcribed**, following this crate's
//!   [`crate::gf`] policy. `sb1` is `x -> ((x ^ 0x1fff)^3` in GF(2^13) with
//!   generating polynomial `0x2911`, truncated to a byte; `sb2` is the same with
//!   GF(2^11), mask `0x7ff` and polynomial `0x0aa7`. A mistyped byte in an 8192- or
//!   2048-entry literal table is wrong everywhere and looks fine, which this
//!   project treats as a serious defect.
//! - **`byte(x,n)` in the C is `(byte)((x) >> (8*n))`**, i.e. a masked shift; the
//!   `<< 8`/`<< 24` shifts of `byte`-typed S-box outputs are C integer promotions.
//!   Both are spelled explicitly here on `u32`.

use crate::prim::BlockPrim;
use std::sync::OnceLock;

const S1_SIZE: u32 = 13;
const S1_LEN: usize = 1 << S1_SIZE;
const S1_MASK: u32 = (S1_LEN as u32) - 1;
/// `S1_MASK & ~0xff` — the high bits of an `sb1` index, which the key supplies.
const S1_HMASK: u32 = S1_MASK & !0xff;
const S1_POLY: u32 = 0x2911;

const S2_SIZE: u32 = 11;
const S2_LEN: usize = 1 << S2_SIZE;
const S2_MASK: u32 = (S2_LEN as u32) - 1;
const S2_HMASK: u32 = S2_MASK & !0xff;
const S2_POLY: u32 = 0x0aa7;

/// libmcrypt's `delta[2] = { 0x7f4a7c15, 0x9e3779b9 }` as one 64-bit value: index 0
/// is the low word. This is LOKI97's golden-ratio constant.
const DELTA: u64 = 0x9e37_79b9_7f4a_7c15;

/// Multiply in GF(2^`tpow`) modulo `mpol`, exactly as libmcrypt's `ff_mult`.
///
/// The reduction test happens *after* the shift, so `mpol` is expected to carry its
/// `1 << tpow` term (`0x2911` for GF(2^13), `0x0aa7` for GF(2^11)).
fn ff_mult(mut a: u32, mut b: u32, tpow: u32, mpol: u32) -> u32 {
    let mut s = 0u32;
    let m = 1u32 << tpow;
    while b != 0 {
        if b & 1 != 0 {
            s ^= a;
        }
        b >>= 1;
        a <<= 1;
        if a & m != 0 {
            a ^= mpol;
        }
    }
    s
}

/// The two keyed S-boxes and the bit-permutation lookup, all derived at runtime.
struct Tables {
    /// `sb1[i] = low byte of ((i ^ 0x1fff)^3 in GF(2^13))`.
    sb1: [u8; S1_LEN],
    /// `sb2[i] = low byte of ((i ^ 0x7ff)^3 in GF(2^11))`.
    sb2: [u8; S2_LEN],
    /// `prm[i][0]` / `prm[i][1]`: LOKI97's permutation P, spread so that the eight
    /// bits of one S-box output land in eight different byte positions of the
    /// 64-bit result. Split into the low and high 32-bit halves, matching the C.
    prm0: [u32; 256],
    prm1: [u32; 256],
}

fn build_tables() -> Tables {
    let mut sb1 = [0u8; S1_LEN];
    for (i, slot) in sb1.iter_mut().enumerate() {
        let j = (i as u32) ^ S1_MASK;
        let v = ff_mult(j, j, S1_SIZE, S1_POLY);
        *slot = ff_mult(v, j, S1_SIZE, S1_POLY) as u8;
    }

    let mut sb2 = [0u8; S2_LEN];
    for (i, slot) in sb2.iter_mut().enumerate() {
        let j = (i as u32) ^ S2_MASK;
        let v = ff_mult(j, j, S2_SIZE, S2_POLY);
        *slot = ff_mult(v, j, S2_SIZE, S2_POLY) as u8;
    }

    let mut prm0 = [0u32; 256];
    let mut prm1 = [0u32; 256];
    for i in 0..256u32 {
        prm0[i as usize] = ((i & 1) << 7) | ((i & 2) << 14) | ((i & 4) << 21) | ((i & 8) << 28);
        prm1[i as usize] =
            ((i & 16) << 3) | ((i & 32) << 10) | ((i & 64) << 17) | ((i & 128) << 24);
    }

    Tables {
        sb1,
        sb2,
        prm0,
        prm1,
    }
}

fn tables() -> &'static Tables {
    static T: OnceLock<Tables> = OnceLock::new();
    T.get_or_init(build_tables)
}

/// libmcrypt's `byte(x, n)`: the `n`-th least significant byte of `x`.
#[inline]
fn byte_of(x: u32, n: u32) -> usize {
    ((x >> (8 * n)) & 0xff) as usize
}

/// LOKI97's round function `f`, XORed into `res` — the C's `f_fun` writes with
/// `res[i] ^= …`, and every caller relies on that accumulation.
///
/// `key[0]` (the low word) drives a bitwise multiplexer selecting between the two
/// halves of the input; `key[1]` (the high word) supplies the top bits of the
/// second S-box layer's indices, which is what makes the S-boxes *keyed*.
fn f_fun(res: &mut u64, inp: u64, key: u64) {
    let t = tables();
    let (key0, key1) = (key as u32, (key >> 32) as u32);
    let (in0, in1) = (inp as u32, (inp >> 32) as u32);

    let tt0 = (in0 & !key0) | (in1 & key0);
    let tt1 = (in1 & !key0) | (in0 & key0);

    // First S-box layer, feeding the permutation. The eight 11/13-bit windows
    // overlap, which is where LOKI97's expansion comes from.
    let mut pp0;
    let mut pp1;
    let mut i = t.sb1[(((tt1 >> 24) | (tt0 << 8)) & S1_MASK) as usize] as usize;
    pp0 = t.prm0[i] >> 7;
    pp1 = t.prm1[i] >> 7;
    i = t.sb2[((tt1 >> 16) & S2_MASK) as usize] as usize;
    pp0 |= t.prm0[i] >> 6;
    pp1 |= t.prm1[i] >> 6;
    i = t.sb1[((tt1 >> 8) & S1_MASK) as usize] as usize;
    pp0 |= t.prm0[i] >> 5;
    pp1 |= t.prm1[i] >> 5;
    i = t.sb2[(tt1 & S2_MASK) as usize] as usize;
    pp0 |= t.prm0[i] >> 4;
    pp1 |= t.prm1[i] >> 4;
    i = t.sb2[(((tt0 >> 24) | (tt1 << 8)) & S2_MASK) as usize] as usize;
    pp0 |= t.prm0[i] >> 3;
    pp1 |= t.prm1[i] >> 3;
    i = t.sb1[((tt0 >> 16) & S1_MASK) as usize] as usize;
    pp0 |= t.prm0[i] >> 2;
    pp1 |= t.prm1[i] >> 2;
    i = t.sb2[((tt0 >> 8) & S2_MASK) as usize] as usize;
    pp0 |= t.prm0[i] >> 1;
    pp1 |= t.prm1[i] >> 1;
    i = t.sb1[(tt0 & S1_MASK) as usize] as usize;
    pp0 |= t.prm0[i];
    pp1 |= t.prm1[i];

    // Second S-box layer: each permuted byte is extended upward with key bits.
    let r0 = t.sb1[byte_of(pp0, 0) | ((key1 << 8) & S1_HMASK) as usize] as u32
        | (t.sb1[byte_of(pp0, 1) | ((key1 << 3) & S1_HMASK) as usize] as u32) << 8
        | (t.sb2[byte_of(pp0, 2) | ((key1 >> 2) & S2_HMASK) as usize] as u32) << 16
        | (t.sb2[byte_of(pp0, 3) | ((key1 >> 5) & S2_HMASK) as usize] as u32) << 24;
    let r1 = t.sb1[byte_of(pp1, 0) | ((key1 >> 8) & S1_HMASK) as usize] as u32
        | (t.sb1[byte_of(pp1, 1) | ((key1 >> 13) & S1_HMASK) as usize] as u32) << 8
        | (t.sb2[byte_of(pp1, 2) | ((key1 >> 18) & S2_HMASK) as usize] as u32) << 16
        | (t.sb2[byte_of(pp1, 3) | ((key1 >> 21) & S2_HMASK) as usize] as u32) << 24;

    *res ^= ((r1 as u64) << 32) | r0 as u64;
}

/// The 48 64-bit subkeys, three per round.
///
/// Direct port of `_mcrypt_set_key`. `key` must already be 32 bytes: libmcrypt's
/// schedule is the 256-bit one unconditionally, and short keys reach it
/// zero-extended (see the module docs).
fn expand_key(key32: &[u8; 32]) -> [u64; 48] {
    let w = |i: usize| u32::from_le_bytes(key32[4 * i..4 * i + 4].try_into().unwrap()) as u64;

    // k4 <- words 0,1; k3 <- 2,3; k2 <- 4,5; k1 <- 6,7, each as (high << 32) | low
    // with the *lower*-indexed word supplying the high half.
    let mut k4 = (w(0) << 32) | w(1);
    let mut k3 = (w(2) << 32) | w(3);
    let mut k2 = (w(4) << 32) | w(5);
    let mut k1 = (w(6) << 32) | w(7);

    let mut del = DELTA;
    let mut l_key = [0u64; 48];
    for slot in l_key.iter_mut() {
        let tt = k1.wrapping_add(k3).wrapping_add(del);
        del = del.wrapping_add(DELTA);
        let sk = k4;
        k4 = k3;
        k3 = k2;
        k2 = k1;
        k1 = sk;
        f_fun(&mut k1, tt, k3);
        *slot = k1;
    }
    l_key
}

/// `blk[3] = _blk[0] … blk[0] = _blk[3]` with little-endian words, returned as the
/// two 64-bit Feistel halves `(blk[0..2], blk[2..4])`.
fn load_block(block: &[u8]) -> (u64, u64) {
    let w = |i: usize| u32::from_le_bytes(block[4 * i..4 * i + 4].try_into().unwrap()) as u64;
    let b0 = (w(2) << 32) | w(3);
    let b1 = (w(0) << 32) | w(1);
    (b0, b1)
}

/// `_blk[0] = blk[1], _blk[1] = blk[0], _blk[2] = blk[3], _blk[3] = blk[2]` — the
/// word-order reversal of [`load_block`] composed with the Feistel half-swap.
fn store_block(block: &mut [u8], b0: u64, b1: u64) {
    let words = [(b0 >> 32) as u32, b0 as u32, (b1 >> 32) as u32, b1 as u32];
    for (i, w) in words.iter().enumerate() {
        block[4 * i..4 * i + 4].copy_from_slice(&w.to_le_bytes());
    }
}

pub struct Loki97 {
    subkeys: [u64; 48],
}

impl Loki97 {
    /// `key` must be exactly 16, 24 or 32 bytes; shorter-than-32 keys are
    /// zero-extended to 32, reproducing libmcrypt's zeroed key buffer.
    pub fn new(key: &[u8]) -> Option<Self> {
        if !matches!(key.len(), 16 | 24 | 32) {
            return None;
        }
        let mut key32 = [0u8; 32];
        key32[..key.len()].copy_from_slice(key);
        Some(Self {
            subkeys: expand_key(&key32),
        })
    }
}

impl BlockPrim for Loki97 {
    fn block_size(&self) -> usize {
        16
    }

    fn encrypt_block(&self, block: &mut [u8]) {
        let (mut b0, mut b1) = load_block(block);
        // r_fun(l, r, k): l += k[0]; r ^= f(l, k[1]); l += k[2].
        // Even rounds take l = b0, odd rounds l = b1.
        for r in 0..16 {
            let k = &self.subkeys[3 * r..3 * r + 3];
            if r % 2 == 0 {
                b0 = b0.wrapping_add(k[0]);
                f_fun(&mut b1, b0, k[1]);
                b0 = b0.wrapping_add(k[2]);
            } else {
                b1 = b1.wrapping_add(k[0]);
                f_fun(&mut b0, b1, k[1]);
                b1 = b1.wrapping_add(k[2]);
            }
        }
        store_block(block, b0, b1);
    }

    fn decrypt_block(&self, block: &mut [u8]) {
        let (mut b0, mut b1) = load_block(block);
        // ir_fun(l, r, k): l -= k[2]; r ^= f(l, k[1]); l -= k[0], walked backwards.
        // The parity is *inverted* relative to encryption, because both directions
        // use the same load and store maps and the store map carries the half-swap.
        for r in (0..16).rev() {
            let k = &self.subkeys[3 * r..3 * r + 3];
            if r % 2 == 0 {
                b1 = b1.wrapping_sub(k[2]);
                f_fun(&mut b0, b1, k[1]);
                b1 = b1.wrapping_sub(k[0]);
            } else {
                b0 = b0.wrapping_sub(k[2]);
                f_fun(&mut b1, b0, k[1]);
                b0 = b0.wrapping_sub(k[0]);
            }
        }
        store_block(block, b0, b1);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// libmcrypt's own compiled-in self-test (`_mcrypt_self_test` in `loki97.c`):
    /// a 256-bit key `keyword[j] = (j*2+10) % 256`, plaintext `j % 256`, checked
    /// against the literal `#define CIPHER` the C ships as its conformance anchor.
    ///
    /// This is the strongest external check available — the reference
    /// implementation checking itself, not a vector re-derived from the same
    /// reading of the same code — so a match pins the round function, both S-box
    /// derivations, the permutation table, the key schedule and the word-order
    /// conventions all at once.
    #[test]
    fn matches_libmcrypt_self_test() {
        let key: Vec<u8> = (0..32u32).map(|j| ((j * 2 + 10) % 256) as u8).collect();
        let pt: Vec<u8> = (0..16u32).map(|j| (j % 256) as u8).collect();
        let want = hex::decode("8cb28c958024bae27a94c698f96f12a9").unwrap();

        let c = Loki97::new(&key).unwrap();
        let mut b = pt.clone();
        c.encrypt_block(&mut b);
        assert_eq!(
            hex::encode(&b),
            hex::encode(&want),
            "libmcrypt self-test ciphertext mismatch"
        );
        c.decrypt_block(&mut b);
        assert_eq!(b, pt);
    }

    #[test]
    fn round_trips_at_every_supported_key_size() {
        for &len in &[16usize, 24, 32] {
            let key: Vec<u8> = (0..len as u8).collect();
            let c = Loki97::new(&key).unwrap();
            let pt: Vec<u8> = (0..16u8).map(|b| b.wrapping_mul(7)).collect();
            let mut b = pt.clone();
            c.encrypt_block(&mut b);
            assert_ne!(b, pt, "key length {len} was a no-op");
            c.decrypt_block(&mut b);
            assert_eq!(b, pt, "key length {len} failed to round trip");
        }
    }

    #[test]
    fn rejects_invalid_key_lengths() {
        for len in [0usize, 1, 7, 8, 15, 17, 20, 23, 25, 31, 33, 64] {
            assert!(
                Loki97::new(&vec![0u8; len]).is_none(),
                "key length {len} should be rejected"
            );
        }
        for len in [16usize, 24, 32] {
            assert!(Loki97::new(&vec![0u8; len]).is_some());
        }
    }

    /// libmcrypt's `set_key` ignores `key_len` and always reads 32 bytes out of a
    /// `calloc`ed buffer, so a 16-byte key and its 32-byte null-padded extension
    /// are the *same* key. Recorded because it means LOKI97 cannot discriminate
    /// between this crate's two null-padding derivation policies.
    #[test]
    fn short_keys_are_zero_extended_to_32_bytes() {
        let short = b"Zombies\0\0\0\0\0\0\0\0\0".to_vec(); // 16 bytes
        assert_eq!(short.len(), 16);
        let mut long = short.clone();
        long.resize(32, 0);

        let a = Loki97::new(&short).unwrap();
        let b = Loki97::new(&long).unwrap();
        assert_eq!(a.subkeys, b.subkeys);

        // ...and a 24-byte null padding lands there too.
        let mut mid = short.clone();
        mid.resize(24, 0);
        assert_eq!(Loki97::new(&mid).unwrap().subkeys, a.subkeys);
    }

    /// The S-boxes are 8192- and 2048-entry byte tables built by cubing in
    /// GF(2^13) and GF(2^11). They are *not* permutations — they map a 13- or
    /// 11-bit input to 8 bits, so each output value must appear 32 (resp. 8) times
    /// if the cubing map is the bijection LOKI97 claims. Checking that balance is
    /// the meaningful bijectivity statement here, and it fails loudly if a
    /// polynomial or mask is wrong.
    #[test]
    fn sbox_generation_is_balanced_and_correctly_sized() {
        let t = tables();
        assert_eq!(t.sb1.len(), 8192);
        assert_eq!(t.sb2.len(), 2048);

        let mut c1 = [0u32; 256];
        for &v in t.sb1.iter() {
            c1[v as usize] += 1;
        }
        for (v, &n) in c1.iter().enumerate() {
            assert_eq!(n, 32, "sb1 value {v} occurs {n} times, expected 32");
        }

        let mut c2 = [0u32; 256];
        for &v in t.sb2.iter() {
            c2[v as usize] += 1;
        }
        for (v, &n) in c2.iter().enumerate() {
            assert_eq!(n, 8, "sb2 value {v} occurs {n} times, expected 8");
        }
    }

    /// Cubing in GF(2^n) for odd `n` is a bijection on the full 13-/11-bit range,
    /// which is the property the byte-truncated S-boxes inherit their balance from.
    /// Verified on the untruncated map rather than assumed.
    #[test]
    fn cubing_is_a_bijection_on_the_full_field() {
        for &(size, poly, mask) in &[(S1_SIZE, S1_POLY, S1_MASK), (S2_SIZE, S2_POLY, S2_MASK)] {
            let n = (mask + 1) as usize;
            let mut seen = vec![false; n];
            for i in 0..n as u32 {
                let cube = ff_mult(ff_mult(i, i, size, poly), i, size, poly);
                assert!(cube <= mask, "cube {cube:#x} escaped GF(2^{size})");
                assert!(
                    !seen[cube as usize],
                    "cubing in GF(2^{size}) is not injective"
                );
                seen[cube as usize] = true;
            }
        }
    }

    /// The permutation table must spread the eight bits of a byte into eight
    /// distinct byte positions of the 64-bit output, and be injective over 256
    /// inputs — the property that makes P a permutation of 64 bits once all eight
    /// S-box outputs are ORed together.
    #[test]
    fn permutation_table_is_injective_and_spreads_bits() {
        let t = tables();
        let mut seen = std::collections::HashSet::new();
        for i in 0..256usize {
            assert!(seen.insert((t.prm0[i], t.prm1[i])), "prm collides at {i}");
            let combined = ((t.prm1[i] as u64) << 32) | t.prm0[i] as u64;
            assert_eq!(
                combined.count_ones(),
                (i as u8).count_ones(),
                "prm[{i}] changed the bit count"
            );
        }
        // Every set bit lands in bit position 7 of some byte, so shifting by 0..7
        // in `f_fun` fills the eight byte-slots without overlap.
        assert_eq!(
            ((t.prm1[255] as u64) << 32) | t.prm0[255] as u64,
            0x8080_8080_8080_8080
        );
        assert_eq!(t.prm0[0], 0);
        assert_eq!(t.prm1[0], 0);
    }

    /// A one-byte plaintext change must diffuse across the whole block.
    #[test]
    fn diffuses_across_the_whole_block() {
        let c = Loki97::new(&[0x11u8; 16]).unwrap();
        let mut a = [0u8; 16];
        let mut b = [0u8; 16];
        b[0] = 1;
        c.encrypt_block(&mut a);
        c.encrypt_block(&mut b);
        let differing = a.iter().zip(b.iter()).filter(|(x, y)| x != y).count();
        assert!(differing > 8, "changed only {differing} bytes");
    }

    /// The subkey schedule must actually vary with the key material.
    #[test]
    fn distinct_keys_give_distinct_subkeys() {
        let a = Loki97::new(&[0u8; 32]).unwrap();
        let mut k = [0u8; 32];
        k[31] = 1;
        let b = Loki97::new(&k).unwrap();
        assert_ne!(a.subkeys, b.subkeys);
        assert_eq!(a.subkeys.len(), 48);
    }
}
