#!/usr/bin/env python3
"""TG3: recover and structurally decompose the simplified-Lorenz keystream.

The keystream (ciphertext XOR plaintext, read in the Bletchley Park / General
Report on Tunny ITA2 notation) is exactly 28-periodic.  28 = 4 x 7 and
gcd(4,7)=1, so by CRT the index i mod 28 is equivalent to the pair
(i mod 4, i mod 7); a two-wheel Lorenz key K[i mod 4] XOR S[i mod 7] is then
exactly a "rank-1" 4x7 matrix over GF(2)^5, which is a closed-form test, not
a search.

Stdlib only.  Run: python3 papers/analysis/tg3_wheels.py
"""
import math

ITA2 = "/T3O9HNM4LRGIPCVEZDBSYFXAWJ+UQK-"
CODE = {c: i for i, c in enumerate(ITA2)}

CT = "NMFU3DNILVAXTPPH9AYHRXUM3PDBVMHN/CANVGPYS+3HGQKH"
PT = "".join(
    c for c in "When finished we will return to the house and the infinite".upper()
    if c.isalpha()
)
KS = [CODE[c] ^ CODE[p] for c, p in zip(CT, PT)]
N = len(KS)


def exact_period(seq):
    for p in range(1, len(seq) + 1):
        if all(seq[i] == seq[i + p] for i in range(len(seq) - p)):
            return p
    return len(seq)


def rank1(m, n):
    """Test ks[i] = K[i mod m] ^ S[i mod n] exactly.  Returns (K, S) or None.

    The incidence graph on (i mod m, i mod n) can be disconnected when
    gcd(m, n) > 1, so seed and propagate once per connected component.
    """
    K = [None] * m
    S = [None] * n
    obs = {}
    for i, v in enumerate(KS):
        obs.setdefault((i % m, i % n), v)
    while True:
        # seed one unvisited component
        seeds = [(a, b) for (a, b) in obs if K[a] is None and S[b] is None]
        if seeds:
            a, b = seeds[0]
            S[b] = 0
            K[a] = obs[(a, b)]
        changed = True
        while changed:
            changed = False
            for (a, b), v in obs.items():
                if K[a] is None and S[b] is not None:
                    K[a], changed = v ^ S[b], True
                elif S[b] is None and K[a] is not None:
                    S[b], changed = v ^ K[a], True
        if not seeds:
            break
    K = [0 if x is None else x for x in K]
    S = [0 if x is None else x for x in S]
    if all(KS[i] == K[i % m] ^ S[i % n] for i in range(N)):
        return K, S
    return None


def show(name, w):
    return f"{name} (len {len(w)}) = " + "".join(ITA2[x] for x in w) + \
        "   [" + " ".join(f"{x:2d}" for x in w) + "]"


def main():
    print("== recovered keystream ==")
    print("  glyphs :", "".join(ITA2[k] for k in KS))
    p = exact_period(KS)
    print(f"  exact period over all {N} symbols: {p}")
    print(f"  tail repeats head for {N - p} symbols, zero exceptions")
    print(f"  p(random ITA2 stream) = 32^-{N - p} ~ 1e-{(N - p) * 1.505:.0f}")
    print()
    print("  The combiner is proved to be XOR, not modular addition: the")
    print("  plaintext at i and i+28 differs at every one of the 20 overlapping")
    print("  positions, yet ct XOR pt is identical there.  Under addition the")
    print("  XOR difference would depend on the plaintext and could not repeat.")
    pt_diff = sum(1 for i in range(N - p) if PT[i] != PT[i + p])
    print(f"  positions where pt[i] != pt[i+28] : {pt_diff} of {N - p}")
    print()

    key28 = KS[:28]
    print("== the 28-symbol key ==")
    print("  " + show("key", key28))
    print()

    print("== exact two-wheel decompositions with lcm(m,n) = 28 ==")
    any_fit = False
    for m in range(2, 29):
        for n in range(2, 29):
            if math.lcm(m, n) != 28 or m > n:
                continue
            r = rank1(m, n)
            verdict = "FITS" if r else "no"
            if r:
                any_fit = True
            print(f"  m={m:>2} n={n:>2}  ->  {verdict}")
            if r:
                K, S = r
                print("      " + show("K", K))
                print("      " + show("S", S))
    if not any_fit:
        print("  none.  The 28-symbol key is NOT the XOR of two shorter wheels")
        print("  that both advance once per character.")
    print()

    print("== the 4 x 7 CRT matrix, as Tunny glyphs ==")
    print("      " + "  ".join(f"b={b}" for b in range(7)))
    for a in range(4):
        row = [key28[i] for i in range(28) if i % 4 == a]
        idx = sorted(range(28), key=lambda i: (i % 4, i % 7))
        row = [key28[[i for i in range(28) if i % 4 == a and i % 7 == b][0]]
               for b in range(7)]
        print(f"  a={a}  " + "    ".join(ITA2[x] for x in row))
    print()
    print("  rank-1 residual  M[a][b] ^ M[a][0] ^ M[0][b] ^ M[0][0]")
    print("  (all zero <=> the key is K[i mod 4] XOR S[i mod 7])")
    M = [[key28[[i for i in range(28) if i % 4 == a and i % 7 == b][0]]
          for b in range(7)] for a in range(4)]
    nz = 0
    for a in range(4):
        cells = []
        for b in range(7):
            r = M[a][b] ^ M[a][0] ^ M[0][b] ^ M[0][0]
            nz += r != 0
            cells.append(f"{r:2d}")
        print(f"  a={a}  " + " ".join(cells))
    print(f"  non-zero residuals: {nz} of 28")
    print()

    print("== does the key relate to the corpus keyword ZOMBIES (7 letters)? ==")
    zom = [CODE[c] for c in "ZOMBIES"]
    print("  ZOMBIES in ITA2:", zom)
    for off in range(7):
        d = [key28[i] ^ zom[(i + off) % 7] for i in range(28)]
        per = exact_period(d)
        print(f"  offset {off}: key XOR ZOMBIES-repeated has exact period {per}"
              + ("   <- would mean a 7-letter running key" if per <= 4 else ""))
    print()

    print("== per-impulse exact periods ==")
    for b in range(5):
        s = [(k >> (4 - b)) & 1 for k in KS]
        print(f"  impulse {b + 1}: period {exact_period(s):>2}  "
              + "".join(str(x) for x in s[:28]))
    print()
    print("  Impulses 1 and 3 are 14-periodic, 2/4/5 are 28-periodic.  All five")
    print("  advance in lockstep, so this is one 5-bit wheel pair, not the ten")
    print("  independent binary wheels of a real SZ40.  Hence 'simplified'.")
    print()
    print("== real SZ40/42 wheel lengths, for contrast ==")
    print("  chi  41 31 29 26 23      psi  43 47 51 53 59      mu  61 37")
    print("  none is 4, 7, 9, 14 or 28; the historical machine's key period is")
    print("  ~1.6e19.  A period of 28 is only reachable by a toy model.")


if __name__ == "__main__":
    main()
