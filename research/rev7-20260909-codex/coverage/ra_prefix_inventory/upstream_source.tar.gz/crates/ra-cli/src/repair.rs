//! `ra repair` — search over *transcription repairs* jointly with cipher parameters.
//!
//! # Why this is a distinct command rather than a sweep flag
//!
//! Every sweep in this workspace takes the recorded ciphertext as given. That is a
//! real assumption, and the corpus shows it fails: rev2 needs a character removed,
//! rev8 needs `63` inserted between the 131st and 132nd bigram (and carries a
//! *second*, undocumented single-byte defect besides). A sweep over the wrong bytes
//! covers nothing, however large it is — and reports a clean negative while doing it.
//!
//! So a repair is not a preprocessing detail; it is a **coverage dimension**. The
//! dossier already has the right slot for it: `0.variant`. This command enumerates
//! that dimension explicitly, jointly with the cipher axes, and emits the result as
//! a coverage set like any other claim.
//!
//! # The alignment trick that makes it affordable
//!
//! Enumerating two independent gaps at once multiplies. Enumerating them in sequence
//! does not — *provided* the first gap alone restores byte alignment over a prefix
//! long enough to identify a layer.
//!
//! For REV7 it does. See [`RepairArgs`] and `notes/rev7-repair-search.md`; the
//! arithmetic is computed rather than asserted by `ra repair --grid`, and pinned by
//! [`tests::rev7_grid_arithmetic_is_what_the_hypothesis_needs`].
//!
//! # What the scored window does and does not license
//!
//! Scoring bytes `[a, b)` of the output eliminates a parameter combination only under
//! the standing assumption that a correct first layer is recognisable *there*. That is
//! the same assumption `ra sweep` makes over the whole stream, but the window is
//! narrower, so it is recorded in the emitted claim rather than left implicit.
//!
//! One consequence is load-bearing and easy to get wrong: a `reverse` transform is
//! **not** compatible with a prefix window. Reversing the full stream puts its tail
//! at the front, and under the sequential decomposition that tail is exactly the part
//! still unknown. `--xf reverse` here reverses the *extracted window*, which is a
//! different hypothesis; the command warns when that is what you asked for.

use std::collections::BTreeMap;
use std::path::Path;

use anyhow::{bail, Context, Result};
use clap::Args;
use ra_core::{Display, Repr};
use ra_covalg::{Cover, CoverageSet, Product};
use ra_merkle::{leaf_hash, StreamingMerkle};
use ra_prim::{KeyDerivation, Mode};
use rayon::prelude::*;

/// Candidates per parallel batch. Bounds resident memory: the Merkle leaves of one
/// batch are held, folded in index order, and dropped, so a 10^8-candidate run costs
/// megabytes rather than gigabytes. Large enough that the batch still saturates every
/// core.
const BATCH: u64 = 1 << 18;

/// Score histogram resolution, over `[0, 1]`.
const BUCKETS: usize = 50;

#[derive(Args)]
pub struct RepairArgs {
    /// Corpus cipher id to attack, e.g. rev7.
    #[arg(long)]
    pub target: String,

    /// Print the transcription grid analysis and the repair arithmetic, then stop.
    /// Everything it prints is computed from the corpus, not asserted.
    #[arg(long)]
    pub grid: bool,

    /// Where to splice the unknown characters, in the *compacted* display text
    /// (whitespace removed). Comma-separated; each entry is either `char:<n>` for a
    /// raw character offset, or `line:<l>,slot:<s>` for the start of the `s`'th
    /// whitespace group on line `l`. `slot:*` expands to every position a whole
    /// missing group could occupy on that line, including after the last one.
    #[arg(long, value_delimiter = ',', default_value = "char:0")]
    pub site: Vec<String>,

    /// How many unknown display characters to enumerate at the site. Zero means "no
    /// repair", which is the null control.
    #[arg(long, default_value_t = 0)]
    pub unknowns: u32,

    /// Repair alphabet. Defaults to the target's own display alphabet.
    #[arg(long)]
    pub alphabet: Option<String>,

    /// Repairs already established, applied before the enumerated one.
    /// Repeatable, `<site>=<chars>`, e.g. `--fix char:0=A1B`. Offsets are resolved
    /// against the *original* compacted text, so the order they are given in does
    /// not matter.
    #[arg(long)]
    pub fix: Vec<String>,

    /// Output byte range to score, `<start>..<end>`. `<end>` is also how many bytes
    /// of the repaired stream are decrypted, so it must stay inside the region the
    /// repairs so far have made byte-aligned. Defaults to the whole stream.
    #[arg(long)]
    pub bytes: Option<String>,

    /// Primitives to try. Defaults to every implemented one.
    #[arg(long, value_delimiter = ',')]
    pub prims: Option<Vec<String>>,

    /// Modes to try, in mcrypt spelling ("cfb" means CFB-8).
    #[arg(long, value_delimiter = ',', default_value = "cfb")]
    pub modes: Vec<String>,

    /// Candidate keys.
    #[arg(long, value_delimiter = ',', default_value = "Zombies")]
    pub keys: Vec<String>,

    /// Key-derivation policies.
    #[arg(long, value_delimiter = ',', default_value = "null-pad-max")]
    pub kd: Vec<String>,

    /// IVs, as named domain values: ascii0, null.
    #[arg(long, value_delimiter = ',', default_value = "ascii0")]
    pub ivs: Vec<String>,

    /// Transform applied to the extracted window before decrypting: identity or
    /// reverse. See the module docs on why `reverse` is not meaningful over a
    /// partial window.
    #[arg(long, value_delimiter = ',', default_value = "identity")]
    pub xf: Vec<String>,

    /// Scoring oracles, comma-separated. A candidate is a hit if it passes any of
    /// them, and the report says which.
    #[arg(long, value_delimiter = ',', default_value = "printable-0.75")]
    pub oracle: Vec<String>,

    /// Report at most this many hits, and keep this many best-scoring candidates
    /// even when nothing passes — a null result is only interpretable next to the
    /// best score it achieved.
    #[arg(long, default_value_t = 20)]
    pub max_hits: usize,

    /// Write the resulting coverage claim here as JSON.
    #[arg(long)]
    pub emit_claim: Option<std::path::PathBuf>,
}

/// A target's display text with whitespace removed, plus the whitespace grouping the
/// transcription used. Both halves matter: the grouping is the evidence for where
/// characters went missing, and the compacted text is what actually decodes.
pub struct Transcription {
    /// Display characters, whitespace removed.
    pub compact: Vec<u8>,
    /// Per source line, one `(offset into `compact`, length)` per whitespace group.
    pub lines: Vec<Vec<(usize, usize)>>,
}

impl Transcription {
    /// Split `raw` into lines and whitespace groups, recording each group's offset in
    /// the compacted text.
    pub fn of(raw: &str) -> Self {
        let mut compact = Vec::new();
        let mut lines = Vec::new();
        for line in raw.lines() {
            let mut groups = Vec::new();
            for tok in line.split_ascii_whitespace() {
                groups.push((compact.len(), tok.len()));
                compact.extend_from_slice(tok.as_bytes());
            }
            if !groups.is_empty() {
                lines.push(groups);
            }
        }
        Transcription { compact, lines }
    }

    /// Group length -> how many groups have it. A rigid grid shows one entry.
    pub fn group_census(&self) -> BTreeMap<usize, usize> {
        let mut m = BTreeMap::new();
        for g in self.lines.iter().flatten() {
            *m.entry(g.1).or_insert(0) += 1;
        }
        m
    }

    /// Groups per line -> how many lines have it.
    pub fn width_census(&self) -> BTreeMap<usize, usize> {
        let mut m = BTreeMap::new();
        for l in &self.lines {
            *m.entry(l.len()).or_insert(0) += 1;
        }
        m
    }

    /// The most common group length and line width, which is the grid the
    /// transcription is *mostly* on. `None` when there is no majority shape.
    pub fn modal(census: &BTreeMap<usize, usize>) -> Option<usize> {
        census.iter().max_by_key(|(_, n)| **n).map(|(k, _)| *k)
    }

    /// Where does the compacted text fall short of the modal grid, and by how much?
    ///
    /// Reports one entry per anomalous group or line, so the "two identifiable
    /// places" claim about REV7 is a computed output rather than a premise.
    pub fn anomalies(&self) -> Vec<Anomaly> {
        let mut out = Vec::new();
        let Some(gw) = Self::modal(&self.group_census()) else {
            return out;
        };
        let Some(lw) = Self::modal(&self.width_census()) else {
            return out;
        };
        for (li, groups) in self.lines.iter().enumerate() {
            for (gi, &(off, len)) in groups.iter().enumerate() {
                if len != gw {
                    out.push(Anomaly {
                        line: li,
                        kind: AnomalyKind::ShortGroup { slot: gi, len },
                        offset: off,
                        deficit: gw.saturating_sub(len),
                    });
                }
            }
            // The final line is legitimately short: the stream simply ends there.
            let last = li + 1 == self.lines.len();
            if groups.len() != lw && !(last && groups.len() < lw) {
                out.push(Anomaly {
                    line: li,
                    kind: AnomalyKind::NarrowLine { groups: groups.len() },
                    offset: groups.first().map(|g| g.0).unwrap_or(0),
                    deficit: lw.saturating_sub(groups.len()) * gw,
                });
            }
        }
        out
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum AnomalyKind {
    ShortGroup { slot: usize, len: usize },
    NarrowLine { groups: usize },
}

#[derive(Debug, PartialEq, Eq)]
pub struct Anomaly {
    pub line: usize,
    pub kind: AnomalyKind,
    /// Offset in the compacted text where the anomaly begins.
    pub offset: usize,
    /// Display characters missing if the modal grid is the truth.
    pub deficit: usize,
}

/// One resolved insertion point.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Site {
    pub label: String,
    /// Offset into the *original* compacted text.
    pub offset: usize,
}

/// Resolve one `--site` entry. `line:<l>,slot:*` expands to every position on that
/// line a whole missing group could occupy, which is one more than the number of
/// groups present.
pub fn parse_site(t: &Transcription, spec: &str) -> Result<Vec<Site>> {
    if let Some(rest) = spec.strip_prefix("char:") {
        let n: usize = rest
            .parse()
            .with_context(|| format!("site {spec:?}: expected char:<offset>"))?;
        if n > t.compact.len() {
            bail!(
                "site {spec:?}: offset {n} is past the end of a {}-character stream",
                t.compact.len()
            );
        }
        return Ok(vec![Site { label: spec.to_string(), offset: n }]);
    }
    if let Some(rest) = spec.strip_prefix("line:") {
        let (l, s) = rest
            .split_once("slot:")
            .map(|(a, b)| (a.trim_end_matches(','), b))
            .with_context(|| format!("site {spec:?}: expected line:<l>,slot:<s>"))?;
        let li: usize = l
            .parse()
            .with_context(|| format!("site {spec:?}: line index {l:?} is not a number"))?;
        let groups = t
            .lines
            .get(li)
            .with_context(|| format!("site {spec:?}: line {li} does not exist"))?;
        // The offset just past the last group is the position "after everything".
        let end = groups.last().map(|(o, n)| o + n).unwrap_or(0);
        let at = |i: usize| groups.get(i).map(|(o, _)| *o).unwrap_or(end);
        if s == "*" {
            return Ok((0..=groups.len())
                .map(|i| Site { label: format!("line:{li},slot:{i}"), offset: at(i) })
                .collect());
        }
        let si: usize = s
            .parse()
            .with_context(|| format!("site {spec:?}: slot {s:?} is not a number or `*`"))?;
        if si > groups.len() {
            bail!(
                "site {spec:?}: slot {si} is past line {li}'s {} groups",
                groups.len()
            );
        }
        return Ok(vec![Site { label: format!("line:{li},slot:{si}"), offset: at(si) }]);
    }
    bail!("site {spec:?}: expected char:<offset> or line:<l>,slot:<s>")
}

/// Write the `idx`'th length-`k` word over `alphabet` into `out`, most significant
/// digit first.
///
/// A bijection from `0 .. |alphabet|^k` onto the words of length `k`, which is what
/// makes a challenged candidate regenerable from its index alone.
pub fn repair_word(alphabet: &[u8], k: u32, idx: u64, out: &mut Vec<u8>) {
    out.clear();
    out.resize(k as usize, alphabet[0]);
    let base = alphabet.len() as u64;
    let mut r = idx;
    for slot in (0..k as usize).rev() {
        out[slot] = alphabet[(r % base) as usize];
        r /= base;
    }
}

/// Splice every repair into the compacted display text.
///
/// `edits` are `(offset in the original compacted text, characters)`. They are
/// applied in offset order, so the result does not depend on the order they are
/// supplied in — which is what lets an established `--fix` and the enumerated repair
/// be specified independently. Edits at equal offsets keep their given order.
pub fn splice(compact: &[u8], edits: &[(usize, &[u8])], out: &mut Vec<u8>) {
    out.clear();
    let mut order: Vec<usize> = (0..edits.len()).collect();
    order.sort_by_key(|&i| edits[i].0);
    let mut cur = 0usize;
    for i in order {
        let (off, text) = edits[i];
        let off = off.min(compact.len()).max(cur);
        out.extend_from_slice(&compact[cur..off]);
        out.extend_from_slice(text);
        cur = off;
    }
    out.extend_from_slice(&compact[cur..]);
}

/// The default repair alphabet for a display: the characters that display can hold.
///
/// Deliberately *not* [`crate::variants::display_alphabet`], which answers a different
/// question. That one asks which characters are *admissible* — it accepts both cases of
/// hex, because a transcribed `a` and `A` denote the same nibble. This one is the set to
/// **enumerate**, where including both cases would double the repair space while
/// evaluating each byte twice, and REV7's 45.4-million-candidate negative was measured
/// over the 16-character alphabet.
fn display_alphabet(d: Display) -> &'static str {
    match d {
        Display::Hex => "0123456789ABCDEF",
        Display::Decimal => "0123456789",
        Display::Octal => "01234567",
        Display::Base64 => "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
        Display::Bytes => "0123456789ABCDEF",
    }
}

fn parse_range(s: &str, len: usize) -> Result<(usize, usize)> {
    let (a, b) = s
        .split_once("..")
        .with_context(|| format!("--bytes {s:?}: expected <start>..<end>"))?;
    let start: usize = if a.is_empty() { 0 } else { a.parse().with_context(|| format!("--bytes {s:?}"))? };
    let end: usize = if b.is_empty() { len } else { b.parse().with_context(|| format!("--bytes {s:?}"))? };
    if start >= end {
        bail!("--bytes {s:?}: empty range");
    }
    Ok((start, end))
}

/// A candidate worth reporting: either it passed an oracle, or it is among the best
/// scores seen. Both are needed — a null result is only interpretable next to the
/// best score it achieved.
struct Cand {
    index: u64,
    score: f64,
    passed: Vec<&'static str>,
    class: String,
    site: String,
    word: String,
    prim: String,
    mode: String,
    key: String,
    kd: String,
    iv: String,
    xf: String,
    preview: String,
}

/// Bounded top-`k` by score, plus the count of everything that passed an oracle.
struct Top {
    cap: usize,
    best: Vec<Cand>,
    hits: u64,
    /// Score distribution; bucket `i` covers `[i/BUCKETS, (i+1)/BUCKETS)`.
    hist: [u64; BUCKETS],
    evaluated: u64,
    inapplicable: u64,
}

impl Top {
    fn new(cap: usize) -> Self {
        Top {
            cap: cap.max(1),
            best: Vec::new(),
            hits: 0,
            hist: [0; BUCKETS],
            evaluated: 0,
            inapplicable: 0,
        }
    }

    fn observe(&mut self, c: Cand) {
        if !c.passed.is_empty() {
            self.hits += 1;
        }
        let b = ((c.score * BUCKETS as f64) as usize).min(BUCKETS - 1);
        self.hist[b] += 1;
        self.evaluated += 1;
        self.rank(c);
    }

    /// Keep the `cap` best-ranked candidates. Does not touch the counters, so it is
    /// also the merge path for candidates another batch already counted.
    fn rank(&mut self, c: Cand) {
        if self.best.len() < self.cap {
            self.best.push(c);
            return;
        }
        let Some((i, _)) = self
            .best
            .iter()
            .enumerate()
            .min_by(|(_, x), (_, y)| cmp_rank(x, y))
        else {
            return;
        };
        if cmp_rank(&self.best[i], &c) == std::cmp::Ordering::Less {
            self.best[i] = c;
        }
    }

    fn merge(&mut self, other: Top) {
        self.hits += other.hits;
        self.evaluated += other.evaluated;
        self.inapplicable += other.inapplicable;
        for (a, b) in self.hist.iter_mut().zip(other.hist.iter()) {
            *a += b;
        }
        for c in other.best {
            self.rank(c);
        }
    }
}

/// Order candidates worst-first. Passing an oracle outranks any score, since a pass
/// is a categorical claim and the score is only a diagnostic.
fn cmp_rank(a: &Cand, b: &Cand) -> std::cmp::Ordering {
    (!a.passed.is_empty(), a.score)
        .partial_cmp(&(!b.passed.is_empty(), b.score))
        .unwrap_or(std::cmp::Ordering::Equal)
}

/// Everything the enumeration depends on, resolved once so candidate `i` is a pure
/// function of `i` and this.
struct Axes<'a> {
    sites: Vec<Site>,
    alphabet: Vec<u8>,
    unknowns: u32,
    words: u64,
    prims: Vec<String>,
    modes: Vec<Mode>,
    keys: &'a [crate::sweep::KeyCandidate],
    kds: Vec<KeyDerivation>,
    ivs: Vec<(String, Vec<u8>)>,
    xf: &'a [String],
}

impl Axes<'_> {
    fn total(&self) -> u64 {
        self.sites.len() as u64
            * self.words
            * self.prims.len() as u64
            * self.modes.len() as u64
            * self.keys.len() as u64
            * self.kds.len() as u64
            * self.ivs.len() as u64
            * self.xf.len() as u64
    }
}

/// Where candidate `i` sits on each axis. Indices rather than references, so the
/// decomposition is trivially checkable as a bijection.
#[derive(Debug, PartialEq, Eq, Hash, Clone, Copy)]
pub struct Coords {
    pub site: usize,
    pub word: u64,
    pub prim: usize,
    pub mode: usize,
    pub key: usize,
    pub kd: usize,
    pub iv: usize,
    pub xf: usize,
}

/// Deterministic index decomposition, in the same spirit as `sweep::decode_index`:
/// candidate `i` depends only on `i` and the axis *sizes*, so an auditor can
/// regenerate a single challenged candidate without replaying the search.
pub fn decode_index(i: u64, sizes: &[u64; 8]) -> Coords {
    let mut r = i;
    let mut take = |n: u64| {
        let v = r % n;
        r /= n;
        v
    };
    let iv = take(sizes[6]) as usize;
    let kd = take(sizes[5]) as usize;
    let key = take(sizes[4]) as usize;
    let mode = take(sizes[3]) as usize;
    let prim = take(sizes[2]) as usize;
    let word = take(sizes[1]);
    let site = take(sizes[0]) as usize;
    let xf = take(sizes[7]) as usize;
    Coords { site, word, prim, mode, key, kd, iv, xf }
}

impl Axes<'_> {
    fn sizes(&self) -> [u64; 8] {
        [
            self.sites.len() as u64,
            self.words,
            self.prims.len() as u64,
            self.modes.len() as u64,
            self.keys.len() as u64,
            self.kds.len() as u64,
            self.ivs.len() as u64,
            self.xf.len() as u64,
        ]
    }
}

pub fn run(data: &Path, args: RepairArgs) -> Result<()> {
    let target = crate::corpus::load_target(data, &args.target)?;
    let t = Transcription::of(&target.raw);

    if args.grid {
        report_grid(&target, &t);
        return Ok(());
    }

    // ---- resolve every axis up front ----------------------------------------
    let mut sites = Vec::new();
    for spec in &args.site {
        sites.extend(parse_site(&t, spec)?);
    }
    if sites.is_empty() {
        bail!("--site resolved to nothing");
    }

    let alphabet: Vec<u8> = args
        .alphabet
        .clone()
        .unwrap_or_else(|| display_alphabet(target.display).to_string())
        .into_bytes();
    if alphabet.is_empty() {
        bail!("--alphabet is empty");
    }
    let words = (alphabet.len() as u64)
        .checked_pow(args.unknowns)
        .context("repair space overflows u64; reduce --unknowns")?;
    if args.unknowns == 0 && sites.len() > 1 {
        // every site would produce the identical unrepaired stream
        sites.truncate(1);
    }

    // Established repairs, resolved against the original compacted text.
    let mut fixes: Vec<(usize, Vec<u8>)> = Vec::new();
    for f in &args.fix {
        let (site, chars) = f
            .split_once('=')
            .with_context(|| format!("--fix {f:?}: expected <site>=<chars>"))?;
        let resolved = parse_site(&t, site)?;
        if resolved.len() != 1 {
            bail!("--fix {f:?}: site must resolve to exactly one offset");
        }
        fixes.push((resolved[0].offset, chars.as_bytes().to_vec()));
    }

    let prims: Vec<String> = match &args.prims {
        Some(p) => p.clone(),
        None => ra_prim::implemented().map(|i| i.mcrypt_name.to_string()).collect(),
    };
    let modes: Vec<Mode> = args
        .modes
        .iter()
        .map(|m| Mode::parse(m).with_context(|| format!("unknown mode {m:?}")))
        .collect::<Result<_>>()?;
    let kds: Vec<KeyDerivation> = args
        .kd
        .iter()
        .map(|k| KeyDerivation::parse(k).with_context(|| format!("unknown key-derivation {k:?}")))
        .collect::<Result<_>>()?;
    let ivs: Vec<(String, Vec<u8>)> = args
        .ivs
        .iter()
        .map(|name| match name.as_str() {
            "ascii0" => Ok((name.clone(), vec![b'0'; 16])),
            "null" => Ok((name.clone(), vec![0u8; 16])),
            other => bail!("unknown IV domain value {other:?}; use ascii0 or null"),
        })
        .collect::<Result<_>>()?;
    for x in &args.xf {
        if x != "identity" && x != "reverse" {
            bail!("unknown transform {x:?}; use identity or reverse");
        }
    }
    let oracles: Vec<&'static ra_oracle::OracleSpec> = args
        .oracle
        .iter()
        .map(|id| ra_oracle::oracle(id).with_context(|| format!("unknown oracle {id:?}")))
        .collect::<Result<_>>()?;

    // The glyph-ambiguity space of the *recorded* transcription, derived exactly as
    // `ra sweep` derives it. REV7's is empty — hex excludes `O`, `I` and `l`, so a
    // transcribed `0` there can only be a zero — which is why not enumerating it
    // jointly with the repair words costs this command nothing.
    let glyphs = crate::variants::VariantSpace::derive(
        &t.compact,
        target.display,
        &format!("{}-exact", target.display_hint),
    )?;

    // ---- establish the repaired stream length and the scored window ----------
    let mut scratch = Vec::new();
    let fix_edits: Vec<(usize, &[u8])> = fixes.iter().map(|(o, c)| (*o, c.as_slice())).collect();
    let probe_word = vec![alphabet[0]; args.unknowns as usize];
    let mut edits = fix_edits.clone();
    edits.push((sites[0].offset, probe_word.as_slice()));
    splice(&t.compact, &edits, &mut scratch);
    let repaired_chars = scratch.len();
    let stream_bytes = Repr::new(scratch.clone(), target.display).canonical_bytes().len();

    let (start, end) = match &args.bytes {
        Some(s) => parse_range(s, stream_bytes)?,
        None => (0, stream_bytes),
    };
    if end > stream_bytes {
        bail!("--bytes end {end} exceeds the {stream_bytes}-byte repaired stream");
    }

    // Resolve keys exactly as `ra sweep` does, so both subcommands feed the key
    // schedule identical bytes. `TheGiant_b64` denotes base64("TheGiant"), not the
    // twelve literal characters — passing the label through would have swept a key
    // the universe model does not contain, and quietly narrowed this negative claim.
    let resolved_keys: Vec<crate::sweep::KeyCandidate> = args
        .keys
        .iter()
        .map(|k| crate::sweep::KeyCandidate::resolve(k))
        .collect();

    let axes = Axes {
        sites,
        alphabet,
        unknowns: args.unknowns,
        words,
        prims,
        modes,
        keys: &resolved_keys,
        kds,
        ivs,
        xf: &args.xf,
    };
    let sizes = axes.sizes();
    let total = axes.total();

    // ---- report the plan before spending anything on it ---------------------
    println!("repair {}: {}", target.id, target.display_hint);
    println!(
        "  recorded    : {} display chars -> {} bytes",
        t.compact.len(),
        Repr::new(t.compact.clone(), target.display).canonical_bytes().len()
    );
    println!(
        "  repaired    : {} display chars -> {} bytes  ({} established fix(es) + {} unknown at {} site(s))",
        repaired_chars,
        stream_bytes,
        fixes.len(),
        axes.unknowns,
        axes.sites.len()
    );
    println!("  scored      : bytes [{start}, {end}) of the decrypted output");
    // `ra sweep` and `ra repair` must share one notion of "variant", or a claim from
    // each would name the same region differently and the digests would stop detecting
    // duplicate work. Both derive the glyph-ambiguity space from the ciphertext with
    // `crate::variants`; this command's `0.variant` values then additionally name the
    // repair word. What it does *not* do is enumerate the glyph readings jointly with
    // the repair words, so a target that has both is reported here rather than left
    // implicit.
    if glyphs.is_ambiguous() {
        println!(
            "\n  WARNING: this transcription also has {} ambiguous glyph positions {:?},\n  \
             i.e. {} admissible readings, and this command repairs only the recorded one.\n  \
             The other {} are NOT covered by this run. Use `ra sweep --variants all` for\n  \
             that axis; the two are not enumerated jointly.",
            glyphs.positions().len(),
            glyphs.positions(),
            glyphs.count(),
            glyphs.count() - 1,
        );
    } else {
        println!(
            "  glyphs      : no ambiguity in a {} display, so the recorded reading is the \
             only one ({})",
            target.display_hint,
            glyphs.label(0)
        );
    }
    println!(
        "  repair space: {}^{} = {} word(s) x {} site(s)",
        axes.alphabet.len(),
        axes.unknowns,
        crate::fmt(words as u128),
        axes.sites.len()
    );
    println!(
        "  cipher space: {} prim x {} mode x {} key x {} kd x {} iv x {} xf",
        axes.prims.len(),
        axes.modes.len(),
        axes.keys.len(),
        axes.kds.len(),
        axes.ivs.len(),
        axes.xf.len()
    );
    println!("  candidates  : {}", crate::fmt(total as u128));
    for o in &oracles {
        println!("  oracle      : {} (block_aware={})", o.id, o.block_aware);
    }
    let window = end - start;
    println!(
        "  P(random {window}-byte window >= 0.75 printable) = {:.3e}; expected false \
         positives over this space = {:.3e}",
        ra_oracle::p_ratio_printable(window, 0.75),
        ra_oracle::expected_false_positives(total as f64, ra_oracle::p_ratio_printable(window, 0.75))
    );
    if args.xf.iter().any(|x| x == "reverse") && (start, end) != (0, stream_bytes) {
        println!(
            "\n  WARNING: --xf reverse over a partial window reverses the *window*, not\n  \
             the stream. Under the sequential decomposition the stream's tail is still\n  \
             unknown, so the reverse skeleton is NOT covered by this run."
        );
    }
    println!();

    // ---- enumerate ----------------------------------------------------------
    let mut merkle = StreamingMerkle::new(1 << 16);
    let mut top = Top::new(args.max_hits.max(1));

    let mut batch_start = 0u64;
    while batch_start < total {
        let batch_end = (batch_start + BATCH).min(total);
        let results: Vec<(ra_merkle::Hash, Option<Cand>, bool)> = (batch_start..batch_end)
            .into_par_iter()
            .map(|i| {
                let c = decode_index(i, &sizes);
                let site = &axes.sites[c.site];
                let mut word = Vec::new();
                repair_word(&axes.alphabet, axes.unknowns, c.word, &mut word);

                let mut stream = Vec::new();
                let mut edits = fix_edits.clone();
                edits.push((site.offset, word.as_slice()));
                splice(&t.compact, &edits, &mut stream);

                let mut buf = Repr::new(stream, target.display).canonical_bytes();
                buf.truncate(end);
                if axes.xf[c.xf] == "reverse" {
                    buf.reverse();
                }

                let prim = &axes.prims[c.prim];
                let mode = axes.modes[c.mode];
                let kc = &axes.keys[c.key];
                let key = &kc.bytes;
                let kd = axes.kds[c.kd];
                let (iv_name, iv) = &axes.ivs[c.iv];
                let out = crate::corpus::decrypt_once(prim, mode, key, iv, kd, &buf);

                let word_s = String::from_utf8_lossy(&word).to_string();
                let params = format!(
                    "site={},word={},xf={},prim={},mode={},key={},kd={},iv={}",
                    site.label, word_s, axes.xf[c.xf], prim, mode, kc.label, kd, iv_name
                );
                let Some(o) = out else {
                    return (leaf_hash(i, &params, "inapplicable"), None, true);
                };
                let leaf = leaf_hash(i, &params, &hex::encode(ra_merkle::h(&o)));

                let scored = &o[start.min(o.len())..end.min(o.len())];
                let bs = ra_prim::prim_info(prim)
                    .and_then(|p| mode.self_synchronising().then_some(p.block_size));
                // Rank on the *continuous* metric, never on a pass/fail one: a null
                // result is only interpretable as a distance from the random-byte
                // baseline, and a 0/1 metric cannot express that. `passed` is kept
                // separately so no oracle's verdict is lost.
                let mut rank = None;
                let mut class = String::new();
                let mut passed = Vec::new();
                for spec in &oracles {
                    let s = spec.score(scored, bs);
                    if s.passed {
                        passed.push(spec.id);
                    }
                    if class.is_empty() {
                        class = s.class.as_str().to_string();
                    }
                    if matches!(spec.metric, ra_oracle::Metric::PrintableAsciiRatio) {
                        rank = Some(rank.map_or(s.score, |r: f64| r.max(s.score)));
                    }
                }
                // No printable-ratio oracle was requested; measure it anyway so the
                // distribution report still means something.
                let best = match rank {
                    Some(r) => r,
                    None => ra_oracle::oracle("printable-1.00")
                        .expect("printable-1.00 is a built-in oracle")
                        .score(scored, bs)
                        .score,
                };
                let cand = Cand {
                    index: i,
                    score: best,
                    passed,
                    class,
                    site: site.label.clone(),
                    word: word_s,
                    prim: prim.clone(),
                    mode: mode.to_string(),
                    key: kc.label.clone(),
                    kd: kd.to_string(),
                    iv: iv_name.clone(),
                    xf: axes.xf[c.xf].clone(),
                    preview: String::from_utf8_lossy(&scored[..64.min(scored.len())])
                        .chars()
                        .filter(|ch| !ch.is_control())
                        .collect(),
                };
                (leaf, Some(cand), false)
            })
            .collect();

        // fold in index order, so the commitment is independent of scheduling
        let mut batch_top = Top::new(args.max_hits.max(1));
        for (leaf, cand, inapp) in results {
            merkle.add(leaf);
            if inapp {
                batch_top.inapplicable += 1;
                batch_top.evaluated += 1;
                batch_top.hist[0] += 1;
            } else if let Some(c) = cand {
                batch_top.observe(c);
            }
        }
        top.merge(batch_top);
        batch_start = batch_end;
    }

    report(&mut top, &merkle, args.max_hits, window);

    // ---- emit the claim as a set, not a count -------------------------------
    let mut variants: Vec<String> = Vec::new();
    let variant_count = axes.sites.len() as u128 * words as u128;
    if variant_count <= 65_536 {
        let mut w = Vec::new();
        for s in &axes.sites {
            for idx in 0..words {
                repair_word(&axes.alphabet, axes.unknowns, idx, &mut w);
                variants.push(format!(
                    "{}/repair({}+{})={}",
                    target.id,
                    s.label,
                    axes.unknowns,
                    String::from_utf8_lossy(&w)
                ));
            }
        }
    }

    if let Some(path) = &args.emit_claim {
        if variants.is_empty() {
            bail!(
                "refusing to emit a claim over {} repair variants: this command states \
                 coverage by listing the variant dimension exactly, and will not \
                 substitute a summary that cannot be differenced. Narrow --site or \
                 --unknowns.",
                crate::fmt(variant_count)
            );
        }
        let slot = if axes.xf.len() > 1 || axes.xf[0] != "identity" { "2" } else { "1" };
        let mut skeleton = vec!["b64d".to_string()];
        if slot == "2" {
            skeleton.push("xf".to_string());
        }
        skeleton.push("dec".to_string());
        let mut dims: Vec<(String, Vec<String>)> = vec![
            ("0.variant".to_string(), variants),
            (format!("{slot}.prim"), display_names(&axes.prims)),
            (format!("{slot}.mode"), args.modes.clone()),
            (format!("{slot}.key"), args.keys.clone()),
            (format!("{slot}.kd"), args.kd.clone()),
            (format!("{slot}.iv"), args.ivs.clone()),
        ];
        if slot == "2" {
            dims.push(("1.xf".to_string(), args.xf.clone()));
        }
        let mut claim = CoverageSet::new();
        claim.add(Cover::new(skeleton, vec![Product::new(dims)]));

        println!("\ncoverage claim");
        println!("  size   = {}", crate::fmt(claim.size_exact()));
        println!("  digest = {}", claim.digest());

        let doc = serde_json::json!({
            "target": target.id,
            "search": "repair",
            "oracles": args.oracle,
            // the window is part of the claim: a combination is eliminated only under
            // the assumption that a correct first layer is recognisable inside it
            "scored_window_bytes": [start, end],
            "repaired_stream_bytes": stream_bytes,
            // Derived with the same code `ra sweep` uses, so the two commands cannot
            // disagree about what is ambiguous. The repair words are the `0.variant`
            // values; the glyph readings are a *second* transcription axis this command
            // does not enumerate, so it is recorded as uncovered rather than omitted.
            "glyph_ambiguity": {
                "ambiguous_positions": glyphs.positions(),
                "admissible_readings": glyphs.count(),
                "readings_covered": 1,
                "recorded_reading": glyphs.label(0),
            },
            "established_fixes": args.fix,
            "merkle_root": hex::encode(merkle.root()),
            "candidates_evaluated": merkle.len(),
            "hits": top.hits,
            "best_score": top.best.iter().map(|c| c.score).fold(0.0f64, f64::max),
            "coverage_claimed": claim.to_json(),
            "coverage_claimed_digest": claim.digest(),
        });
        std::fs::write(path, serde_json::to_string_pretty(&doc)?)
            .with_context(|| format!("writing {}", path.display()))?;
        println!("  wrote claim to {}", path.display());
    }
    Ok(())
}

fn report(top: &mut Top, merkle: &StreamingMerkle, max_hits: usize, window: usize) {
    println!("commitment");
    println!("  candidates : {}", merkle.len());
    println!("  merkle root: {}", hex::encode(merkle.root()));
    println!(
        "  resident   : {} bytes ({:.5} per candidate)",
        merkle.memory_bytes(),
        merkle.memory_bytes() as f64 / merkle.len().max(1) as f64
    );
    if top.inapplicable > 0 {
        println!(
            "  inapplicable: {} (a key length the primitive rejects; still committed to)",
            top.inapplicable
        );
    }

    top.best.sort_by(|a, b| cmp_rank(b, a).then(a.index.cmp(&b.index)));

    let baseline = 95.0 / 256.0;
    println!("\nscore distribution (printable ratio over the {window}-byte window)");
    println!("  random-byte expectation = {baseline:.4}");
    let n = top.evaluated.max(1);
    let mut cum = 0u64;
    for (i, &c) in top.hist.iter().enumerate() {
        cum += c;
        if c == 0 {
            continue;
        }
        let lo = i as f64 / BUCKETS as f64;
        println!(
            "  [{:.2}, {:.2})  {:>12}  {:>7.3}%   cum {:>7.3}%",
            lo,
            lo + 1.0 / BUCKETS as f64,
            c,
            100.0 * c as f64 / n as f64,
            100.0 * cum as f64 / n as f64
        );
    }
    let best = top.best.first().map(|c| c.score).unwrap_or(0.0);
    println!(
        "  best score = {best:.4}  ({:+.4} vs the random baseline)",
        best - baseline
    );

    println!("\nhits (passed an oracle): {}", top.hits);
    if top.hits == 0 {
        println!("  (none)");
        println!(
            "\n  NEGATIVE RESULT. The best score is reported above; read it against the\n  \
             random-byte baseline of {baseline:.4}, not against zero. A best score in the\n  \
             neighbourhood of the baseline means the repair space searched contains no\n  \
             first layer this oracle can see — it is not a weak lead.\n  \
             As with any negative here, it is worth exactly as much as the conformance\n  \
             of the primitives it used: run `ra conformance` before believing it."
        );
    }
    println!("\ntop {} by score:", top.best.len().min(max_hits));
    for c in top.best.iter().take(max_hits) {
        let flag = if c.passed.is_empty() { "" } else { " *** PASSED" };
        println!(
            "  #{:<10} score={:.4} class={:<9} repair[{}]={:<8} {}/{} key={} kd={} iv={} xf={}{}",
            c.index, c.score, c.class, c.site, c.word, c.prim, c.mode, c.key, c.kd, c.iv, c.xf, flag
        );
        if !c.passed.is_empty() {
            println!("      oracles passed: {}", c.passed.join(", "));
        }
        println!("      {}", c.preview);
    }
}

/// Print the transcription grid and the repair arithmetic, all computed.
///
/// This exists so the grid hypothesis is *tested* rather than assumed: it reports
/// the census, the anomalies against the modal grid, and — the decisive part — the
/// parity of each candidate repair, since a hex stream needs an even character count
/// and that alone rules most combinations out.
fn report_grid(target: &crate::corpus::Target, t: &Transcription) {
    println!("{}  transcription grid ({})", target.id, target.display_hint);
    println!("  lines            : {}", t.lines.len());
    println!("  groups           : {}", t.lines.iter().map(|l| l.len()).sum::<usize>());
    println!("  display chars    : {}", t.compact.len());
    println!("  group length     : {:?}", t.group_census());
    println!("  groups per line  : {:?}", t.width_census());

    // An independent check on the grid, not using character counts at all: if the
    // transcription is row-faithful (one source line per row of the original, rather
    // than a fresh re-wrap of whatever groups survived), then the number of grid slots
    // is fixed by the modal width and the final line's width. Any shortfall against
    // the groups actually recorded is a dropped group, located on whichever line is
    // narrow. A re-wrap would instead push the shortfall onto the *last* line, so the
    // two readings are distinguishable.
    let recorded_groups: usize = t.lines.iter().map(|l| l.len()).sum();
    if let (Some(w), Some(last)) = (
        Transcription::modal(&t.width_census()),
        t.lines.last().map(|l| l.len()),
    ) {
        let slots = (t.lines.len() - 1) * w + last;
        println!(
            "\n  grid slots       : {} lines x {w} + {last} on the last = {slots}",
            t.lines.len() - 1
        );
        println!("  groups recorded  : {recorded_groups}");
        if slots > recorded_groups {
            let rewrap_last = recorded_groups - (t.lines.len() - 1) * w;
            println!(
                "  => {} group(s) short of the grid. A row-faithful transcription that\n     \
                 dropped a group leaves the final line at {last}; a fresh re-wrap of the\n     \
                 {recorded_groups} surviving groups would have left it at {}. Recorded: {last}, so the\n     \
                 grid has {slots} slots and the shortfall is a dropped group, not a re-wrap.",
                slots - recorded_groups,
                rewrap_last
            );
        }
    }

    let anomalies = t.anomalies();
    let per_char = match target.display {
        Display::Hex => 2,
        Display::Decimal | Display::Octal => 3,
        _ => 1,
    };
    println!("\n  anomalies against the modal grid: {}", anomalies.len());
    for a in &anomalies {
        match &a.kind {
            AnomalyKind::ShortGroup { slot, len } => println!(
                "    line {:<3} slot {:<3} is {len} chars (short by {}) at char offset {}",
                a.line, slot, a.deficit, a.offset
            ),
            AnomalyKind::NarrowLine { groups } => println!(
                "    line {:<3} has {groups} groups (short by one group = {} chars), \
                 slot unknown, line starts at char offset {}",
                a.line, a.deficit, a.offset
            ),
        }
    }
    if anomalies.is_empty() {
        println!("    none: the transcription is on a rigid grid with nothing missing.");
        return;
    }

    // Parity is the discriminator. Enumerate every subset of the anomalies and report
    // which repairs can possibly yield a whole number of units.
    println!(
        "\n  repair arithmetic ({} chars per unit, so a valid stream needs a multiple of {})",
        per_char, per_char
    );
    let n = anomalies.len();
    for mask in 0u32..(1 << n) {
        let added: usize = (0..n).filter(|i| mask >> i & 1 == 1).map(|i| anomalies[i].deficit).sum();
        let total = t.compact.len() + added;
        let which: Vec<String> = (0..n)
            .filter(|i| mask >> i & 1 == 1)
            .map(|i| format!("line{}", anomalies[i].line))
            .collect();
        let label = if which.is_empty() { "none (as recorded)".to_string() } else { which.join("+") };
        let ok = total % per_char == 0;
        println!(
            "    repair {:<22} {:>5} chars = {:>6.1} units  {}",
            label,
            total,
            total as f64 / per_char as f64,
            if ok { "CONSISTENT" } else { "IMPOSSIBLE (not a whole number of units)" }
        );
    }

    // How far does alignment reach once the anomalies are repaired in offset order?
    // This is the sequencing argument: if the first repair already aligns a prefix
    // long enough to identify a layer, the two gaps need not be enumerated jointly.
    println!("\n  cumulative alignment reach, repairing in offset order");
    let mut sorted: Vec<&Anomaly> = anomalies.iter().collect();
    sorted.sort_by_key(|a| a.offset);
    for (i, a) in sorted.iter().enumerate() {
        let before: usize = sorted[..=i].iter().map(|x| x.deficit).sum();
        // characters known-good once the repairs up to and including this one are made,
        // i.e. everything up to the next unrepaired anomaly
        let reach = match sorted.get(i + 1) {
            Some(next) => next.offset + before,
            None => t.compact.len() + before,
        };
        println!(
            "    through line {:<3} (+{} chars, {} cumulative): chars [0, {}) are aligned \
             = {} units{}",
            a.line,
            a.deficit,
            before,
            reach,
            reach / per_char,
            if reach % per_char == 0 { "" } else { "  (NOT a unit boundary)" }
        );
    }
}

/// Map mcrypt names to the display names claims use, so a coverage set is comparable
/// across harnesses. Mirrors `sweep::display_names`; kept local because the two
/// commands must be able to evolve independently.
fn display_names(prims: &[String]) -> Vec<String> {
    prims
        .iter()
        .map(|p| {
            ra_prim::prim_info(p)
                .map(|i| i.display_name.to_string())
                .unwrap_or_else(|| p.clone())
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use base64::Engine as _;

    const REV7: &str = "83 B57B2 C3434\n6E79A 1136E 36860\nD9A2F 9554F";

    /// The two commands must also agree about what is *ambiguous*, not only about key
    /// bytes — a second notion of "variant" would let two claims name the same region
    /// differently and the digest would stop detecting duplicate work.
    ///
    /// This is also where REV7's independence from the TG4 glyph correction is
    /// checked: hex excludes `O`, `I` and `l`, so a repair search over REV7 loses
    /// nothing by not enumerating glyph readings jointly with repair words.
    #[test]
    fn glyph_ambiguity_is_derived_with_the_same_code_as_the_sweep() {
        let t = Transcription::of(REV7);
        let glyphs =
            crate::variants::VariantSpace::derive(&t.compact, Display::Hex, "hex-exact").unwrap();
        assert!(
            !glyphs.is_ambiguous(),
            "REV7's hex transcription has no glyph ambiguity to enumerate"
        );
        assert_eq!(glyphs.count(), 1);
        assert_eq!(glyphs.label(0), "hex-exact");
        // Not even a *resolved* confusable is found, because `O` is not a hex digit at
        // all. That is the display-awareness point: the same characters read as base64
        // would put every `0` in the resolved set.
        assert!(
            crate::variants::VariantSpace::resolved_positions(&t.compact, Display::Hex).is_empty()
        );
        assert!(
            !crate::variants::VariantSpace::resolved_positions(&t.compact, Display::Base64)
                .is_empty(),
            "read as base64, REV7's zeros would be 0/O candidates"
        );

        // the repair alphabet is a different question from admissibility, and must
        // stay the 16 characters REV7's recorded negative was measured over
        assert_eq!(display_alphabet(Display::Hex).len(), 16);
        assert!(crate::variants::display_alphabet(Display::Hex).len() > 16);
    }

    /// `ra repair` and `ra sweep` must feed the key schedule identical bytes for the
    /// same domain label, or their negative claims cover different spaces while
    /// appearing to cover the same one.
    ///
    /// This regressed once already: `repair` passed the label `TheGiant_b64` through
    /// as twelve literal characters while `sweep` resolved it to base64("TheGiant").
    /// One of six key candidates was therefore the wrong bytes, silently narrowing
    /// the claim. Sharing one resolver is the fix; this test is the guard.
    #[test]
    fn key_resolution_is_shared_with_the_sweep() {
        for label in [
            "Zombies",
            "TheGiant",
            "ZOMBIES",
            "thegiant",
            "zombies",
            "TheGiant_b64",
        ] {
            let k = crate::sweep::KeyCandidate::resolve(label);
            assert_eq!(k.label, label, "the claim must keep the domain label");
            if let Some(stem) = label.strip_suffix("_b64") {
                assert_ne!(
                    k.bytes, label.as_bytes(),
                    "a _b64 label must not be swept as its literal characters"
                );
                assert_eq!(
                    k.bytes,
                    base64::engine::general_purpose::STANDARD
                        .encode(stem)
                        .into_bytes()
                );
            } else {
                assert_eq!(k.bytes, label.as_bytes());
            }
        }
    }

    #[test]
    fn transcription_records_group_offsets_in_compacted_coordinates() {
        let t = Transcription::of(REV7);
        assert_eq!(t.compact.len(), 2 + 5 * 7);
        assert_eq!(t.lines.len(), 3);
        assert_eq!(t.lines[0], vec![(0, 2), (2, 5), (7, 5)]);
        assert_eq!(t.lines[1], vec![(12, 5), (17, 5), (22, 5)]);
        assert_eq!(t.lines[2], vec![(27, 5), (32, 5)]);
        assert_eq!(t.group_census(), BTreeMap::from([(2, 1), (5, 7)]));
    }

    /// The enumeration must be a bijection over its index space, or the search
    /// silently under-covers while the emitted claim asserts the whole product.
    /// Precedent: `sweep::tests::index_decomposition_is_a_bijection`.
    #[test]
    fn index_decomposition_is_a_bijection() {
        let sizes = [3u64, 8, 5, 2, 3, 4, 2, 2];
        let total: u64 = sizes.iter().product();
        let mut seen = std::collections::HashSet::new();
        for i in 0..total {
            let c = decode_index(i, &sizes);
            assert!(c.site < 3 && c.word < 8 && c.prim < 5 && c.mode < 2);
            assert!(c.key < 3 && c.kd < 4 && c.iv < 2 && c.xf < 2);
            assert!(seen.insert(c), "index {i} duplicates an earlier combination");
        }
        assert_eq!(seen.len() as u64, total, "must cover the full product");
    }

    /// A degenerate axis must not collapse the enumeration.
    #[test]
    fn index_decomposition_is_a_bijection_with_singleton_axes() {
        let sizes = [1u64, 4096, 1, 1, 1, 1, 1, 1];
        let total: u64 = sizes.iter().product();
        let mut seen = std::collections::HashSet::new();
        for i in 0..total {
            assert!(seen.insert(decode_index(i, &sizes).word));
        }
        assert_eq!(seen.len() as u64, total);
    }

    /// `repair_word` must be a bijection onto the words of length `k`, for the same
    /// reason: the claim lists `|A|^k` variants and the search must visit each once.
    #[test]
    fn repair_word_is_a_bijection_over_its_index_space() {
        let alphabet = b"0123456789ABCDEF";
        for k in 0..=3u32 {
            let n = 16u64.pow(k);
            let mut seen = std::collections::HashSet::new();
            let mut w = Vec::new();
            for i in 0..n {
                repair_word(alphabet, k, i, &mut w);
                assert_eq!(w.len(), k as usize);
                assert!(w.iter().all(|c| alphabet.contains(c)));
                assert!(seen.insert(w.clone()), "index {i} repeats a word at k={k}");
            }
            assert_eq!(seen.len() as u64, n, "k={k} must cover 16^{k} words");
        }
    }

    #[test]
    fn repair_word_is_a_big_endian_numeral() {
        let mut w = Vec::new();
        repair_word(b"0123456789ABCDEF", 3, 0, &mut w);
        assert_eq!(w, b"000");
        repair_word(b"0123456789ABCDEF", 3, 1, &mut w);
        assert_eq!(w, b"001");
        repair_word(b"0123456789ABCDEF", 3, 0x1AF, &mut w);
        assert_eq!(w, b"1AF");
        repair_word(b"0123456789ABCDEF", 3, 4095, &mut w);
        assert_eq!(w, b"FFF");
    }

    #[test]
    fn splice_is_order_independent_and_lengths_add() {
        let base = b"ABCDEFGH";
        let mut a = Vec::new();
        let mut b = Vec::new();
        splice(base, &[(0, b"xx"), (4, b"yyy")], &mut a);
        splice(base, &[(4, b"yyy"), (0, b"xx")], &mut b);
        assert_eq!(a, b);
        assert_eq!(a, b"xxABCDyyyEFGH".to_vec());
        assert_eq!(a.len(), base.len() + 2 + 3);
    }

    #[test]
    fn splice_at_the_very_end_appends() {
        let mut out = Vec::new();
        splice(b"AB", &[(2, b"Z")], &mut out);
        assert_eq!(out, b"ABZ".to_vec());
    }

    /// The fast splice must agree with `ra_core`'s own `insert` node, so the search
    /// is not quietly using different semantics from the chain the corpus records.
    #[test]
    fn splice_agrees_with_the_insert_node() {
        ra_prim::link();
        let node = ra_core::registry().get("insert").unwrap();
        let base = b"83B57B2C3434";
        for pos in 0..=base.len() {
            let mut mine = Vec::new();
            splice(base, &[(pos, b"A1B")], &mut mine);
            let got = node
                .apply(
                    &Repr::new(base.to_vec(), Display::Hex),
                    &ra_core::params! {"text" => "A1B", "pos" => pos as i64, "unit" => "byte"},
                )
                .unwrap();
            assert_eq!(mine, got.data, "disagreement at pos {pos}");
        }
    }

    /// A repaired stream must have exactly the length the hypothesis predicts, and
    /// decode to exactly the predicted number of bytes.
    #[test]
    fn a_repaired_stream_has_the_predicted_length() {
        let t = Transcription::of(REV7);
        let recorded = t.compact.len();
        assert_eq!(recorded, 37);
        let mut out = Vec::new();
        splice(&t.compact, &[(0, b"A1B")], &mut out);
        assert_eq!(out.len(), recorded + 3, "three characters were inserted");
        // 40 chars is 20 whole hex bytes
        assert_eq!(Repr::new(out, Display::Hex).canonical_bytes().len(), 20);
    }

    #[test]
    fn sites_resolve_by_char_and_by_line_slot() {
        let t = Transcription::of(REV7);
        assert_eq!(parse_site(&t, "char:7").unwrap(), vec![Site { label: "char:7".into(), offset: 7 }]);
        assert_eq!(parse_site(&t, "line:1,slot:0").unwrap()[0].offset, 12);
        assert_eq!(parse_site(&t, "line:1,slot:2").unwrap()[0].offset, 22);
        // one past the last group is "after everything on the line"
        assert_eq!(parse_site(&t, "line:1,slot:3").unwrap()[0].offset, 27);
        assert!(parse_site(&t, "line:1,slot:4").is_err());
        assert!(parse_site(&t, "char:999").is_err());
        assert!(parse_site(&t, "nonsense").is_err());
    }

    /// A wildcard slot must cover every position a whole missing group could occupy,
    /// which is one more than the number of groups present.
    #[test]
    fn wildcard_slot_covers_every_position_a_missing_group_could_take() {
        let t = Transcription::of(REV7);
        let sites = parse_site(&t, "line:1,slot:*").unwrap();
        assert_eq!(sites.len(), 4, "3 groups means 4 possible insertion points");
        assert_eq!(
            sites.iter().map(|s| s.offset).collect::<Vec<_>>(),
            vec![12, 17, 22, 27]
        );
    }

    #[test]
    fn anomalies_are_detected_against_the_modal_grid() {
        // 3 lines of 3 groups of 5, except line 0 slot 0 is short and line 1 is narrow
        let t = Transcription::of("83 BBBBB CCCCC\nDDDDD EEEEE\nFFFFF 11111 22222");
        let a = t.anomalies();
        assert_eq!(a.len(), 2);
        assert_eq!(a[0].kind, AnomalyKind::ShortGroup { slot: 0, len: 2 });
        assert_eq!(a[0].deficit, 3);
        assert_eq!(a[0].offset, 0);
        assert_eq!(a[1].kind, AnomalyKind::NarrowLine { groups: 2 });
        assert_eq!(a[1].deficit, 5);
    }

    /// A short *final* line is the stream ending, not a defect.
    #[test]
    fn a_short_final_line_is_not_an_anomaly() {
        let t = Transcription::of("AAAAA BBBBB CCCCC\nDDDDD EEEEE FFFFF\n11111");
        assert!(t.anomalies().is_empty());
    }

    #[test]
    fn range_parsing() {
        assert_eq!(parse_range("0..384", 550).unwrap(), (0, 384));
        assert_eq!(parse_range("..", 550).unwrap(), (0, 550));
        assert_eq!(parse_range("100..", 550).unwrap(), (100, 550));
        assert!(parse_range("384..384", 550).is_err());
        assert!(parse_range("384", 550).is_err());
    }

    /// **The hypothesis under test, as arithmetic over the real corpus.**
    ///
    /// REV7 is transcribed on a 14x5 grid. Two lines break it, and the parity of a
    /// hex stream decides which repairs are even possible: only the *joint* repair
    /// yields a whole number of bytes. Equally load-bearing is the second assertion —
    /// repairing the first gap alone byte-aligns a 385-byte prefix regardless of the
    /// second, which is what turns a product into a sequence.
    ///
    /// If this test ever fails, the corpus record changed and the whole search needs
    /// re-deriving.
    #[test]
    fn rev7_grid_arithmetic_is_what_the_hypothesis_needs() {
        let raw = std::fs::read_to_string(
            std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../data/revelations.json"),
        )
        .unwrap();
        let v: serde_json::Value = serde_json::from_str(&raw).unwrap();
        let ct = v
            .as_array()
            .unwrap()
            .iter()
            .find(|r| r["id"] == "rev7")
            .unwrap()["ciphertext"]
            .as_str()
            .unwrap();
        let t = Transcription::of(ct);

        // the grid, as recorded
        assert_eq!(t.compact.len(), 1092, "REV7 is 1092 hex characters");
        assert_eq!(t.lines.len(), 16);
        assert_eq!(t.group_census(), BTreeMap::from([(2, 1), (5, 218)]));
        assert_eq!(t.width_census(), BTreeMap::from([(10, 1), (13, 1), (14, 14)]));

        // exactly two anomalies, in the two places the hypothesis names
        let a = t.anomalies();
        assert_eq!(a.len(), 2, "exactly two breaks in the grid");
        assert_eq!(a[0].line, 0);
        assert_eq!(a[0].kind, AnomalyKind::ShortGroup { slot: 0, len: 2 });
        assert_eq!(a[0].offset, 0);
        assert_eq!(a[0].deficit, 3);
        assert_eq!(a[1].line, 11);
        assert_eq!(a[1].kind, AnomalyKind::NarrowLine { groups: 13 });
        assert_eq!(a[1].deficit, 5);

        // PARITY: hex needs an even count, so only the joint repair is possible
        assert_eq!(1092 % 2, 0, "as recorded, parity is fine (546 bytes)");
        assert_eq!((1092 + 3) % 2, 1, "line 0 alone is impossible");
        assert_eq!((1092 + 5) % 2, 1, "line 11 alone is impossible");
        assert_eq!((1092 + 3 + 5) % 2, 0, "only the joint repair is consistent");
        assert_eq!(1092 + 8, 1100);
        assert_eq!(1100 / 5, 220, "220 whole groups");
        assert_eq!(15 * 14 + 10, 220, "a 15x14 grid plus a 10-group final line");
        assert_eq!(1100 / 2, 550, "550 bytes, not 546");

        // ALIGNMENT: gap 1 alone byte-aligns everything before gap 2
        let lines_0_to_10: usize = t.lines[..11].iter().flatten().map(|g| g.1).sum();
        assert_eq!(lines_0_to_10, 767);
        assert_eq!(lines_0_to_10 + 3, 770);
        assert_eq!(770 % 2, 0, "gap 1 alone makes the prefix byte-aligned");
        assert_eq!(770 / 2, 385, "385 whole bytes, independent of gap 2");
        assert_eq!(a[1].offset + 3, 770, "gap 2 lies exactly at that boundary");
        // and 384 of those 385 bytes are a whole number of blocks for every block
        // size in the vocabulary, so ECB and CBC candidates are not penalised by a
        // trailing partial block
        for bs in [1usize, 8, 16, 32] {
            assert_eq!(384 % bs, 0, "384 bytes is a whole number of {bs}-byte blocks");
        }
    }

    /// Read a corpus ciphertext, compacted to display characters.
    fn corpus_hex(id: &str) -> Vec<u8> {
        let raw = std::fs::read_to_string(
            std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../data/revelations.json"),
        )
        .unwrap();
        let v: serde_json::Value = serde_json::from_str(&raw).unwrap();
        let ct = v.as_array().unwrap().iter().find(|r| r["id"] == id).unwrap()["ciphertext"]
            .as_str()
            .unwrap()
            .to_string();
        Transcription::of(&ct).compact
    }

    fn printable_ratio(prim: &str, mode: Mode, key: &str, stream: &[u8]) -> f64 {
        let bytes = Repr::new(stream.to_vec(), Display::Hex).canonical_bytes();
        let out = ra_prim::decrypt(
            prim,
            mode,
            key.as_bytes(),
            &[b'0'; 16],
            KeyDerivation::NullPadMax,
            &bytes,
        )
        .unwrap();
        let bs = mode
            .self_synchronising()
            .then(|| ra_prim::prim_info(prim).unwrap().block_size);
        ra_oracle::oracle("printable-0.75").unwrap().score(&out, bs).score
    }

    /// **The positive control for this whole command, on real corpus bytes.**
    ///
    /// rev12 is the corpus's only cipher whose first layer is a single mcrypt
    /// decrypt with no preceding transform, which makes it the one vector that can
    /// exercise `repair` end to end. Delete three hex characters from the front of it
    /// and the stream is nibble-shifted from byte zero on, so nothing scores above
    /// noise — which is exactly the premise of the REV7 hypothesis. Re-enumerate
    /// three unknowns at the deletion site and the layer reappears.
    ///
    /// The second assertion is the one that changes how a negative result must be
    /// read. *Every* one of the 4096 repair values recovers the layer, not just the
    /// true one, because a wrong value corrupts only a bounded prefix and every
    /// mcrypt mode then recovers — CFB-8 self-synchronises, ECB confines the damage
    /// to block 0, and the output-feedback modes to the two altered bytes. So a
    /// window this long identifies the *layer* almost independently of the repair
    /// value: finding nothing is therefore a statement about the cipher axes, not an
    /// artefact of having guessed the missing characters wrongly.
    #[test]
    fn a_deleted_gap_is_recoverable_and_the_layer_survives_a_wrong_gap_value() {
        ra_prim::link();
        let full = corpus_hex("rev12");
        let mutilated = full[3..].to_vec();

        // (a) intact, the layer is obvious
        let intact = printable_ratio("xtea", Mode::Cfb8, "Zombies", &full);
        assert!(intact > 0.98, "rev12's XTEA layer should be plain text: {intact}");

        // (b) three characters short, it is invisible — the premise under test
        let broken = printable_ratio("xtea", Mode::Cfb8, "Zombies", &mutilated);
        assert!(
            broken < 0.55,
            "a nibble-shifted stream must look like noise, got {broken}"
        );

        // (c) re-enumerate the gap: every value recovers the layer, and the true
        //     value is among the very best
        let alphabet = b"0123456789ABCDEF";
        let mut word = Vec::new();
        let mut stream = Vec::new();
        let mut scores = Vec::with_capacity(4096);
        for i in 0..4096u64 {
            repair_word(alphabet, 3, i, &mut word);
            splice(&mutilated, &[(0, word.as_slice())], &mut stream);
            assert_eq!(stream.len(), full.len(), "the repair must restore the length");
            scores.push(printable_ratio("xtea", Mode::Cfb8, "Zombies", &stream));
        }
        let worst = scores.iter().cloned().fold(f64::INFINITY, f64::min);
        assert!(
            worst > 0.9,
            "every repair value should identify the layer; worst was {worst}"
        );
        let best = scores.iter().cloned().fold(0.0f64, f64::max);
        // the true repair is "452" (rev12's own leading characters)
        let true_idx = 0x452u64;
        assert!(
            (scores[true_idx as usize] - best).abs() < 1e-12,
            "the true repair should be maximal: {} vs {best}",
            scores[true_idx as usize]
        );
    }

    /// **Why the gap-1 enumeration barely matters, and the negative is therefore much
    /// broader than the space literally enumerated.**
    ///
    /// Repairing REV7's first group touches only the first *three* bytes of the
    /// stream: whatever the five characters of that group turn out to be, the group
    /// is followed by `B57B2...`, so bytes 3 onward are fixed. Every mcrypt mode
    /// confines the resulting plaintext damage to a bounded prefix — ECB to block 0,
    /// CBC and nCFB to blocks 0 and 1, CFB-8 to `3 + block_size` bytes, and the
    /// output-feedback modes to the three altered bytes, since their keystream does
    /// not depend on the ciphertext at all.
    ///
    /// This test measures that bound on real REV7 bytes rather than deducing it. The
    /// consequence is the one that matters for the claim: a first layer that scores
    /// `s` under the *true* repair scores at least `s - 64/384 = s - 0.167` under
    /// **any** of the 16^5 possible values of that group. rev12's genuine layer
    /// scores 0.985, so it would still clear a 0.75 threshold at any repair value.
    /// A negative over this window is therefore a negative over the whole gap-1
    /// space, not only over the values enumerated.
    #[test]
    fn a_wrong_gap1_value_perturbs_only_a_bounded_prefix_in_every_mode() {
        ra_prim::link();
        let compact = corpus_hex("rev7");
        let mut a = Vec::new();
        let mut b = Vec::new();
        // two maximally different repairs of the whole five-character first group
        splice(&compact, &[(0, b"000")], &mut a);
        splice(&compact, &[(0, b"FFF")], &mut b);
        // ...and one that rewrites the recorded `83` too, i.e. an arbitrary group
        let mut c = compact[2..].to_vec();
        let mut c_full = b"7A9E1".to_vec();
        c_full.append(&mut c);

        let bytes_a = Repr::new(a, Display::Hex).canonical_bytes();
        let bytes_b = Repr::new(b, Display::Hex).canonical_bytes();
        let bytes_c = Repr::new(c_full, Display::Hex).canonical_bytes();

        // the premise: only the first three ciphertext bytes can differ
        assert_eq!(bytes_a[3..384], bytes_b[3..384]);
        assert_eq!(bytes_a[3..384], bytes_c[3..384]);

        for prim in ["des", "twofish", "rijndael-256", "arcfour", "loki97"] {
            for mode in Mode::ALL {
                // `stream` names a native stream cipher with no block-mode
                // wrapper; it is inapplicable to every block primitive here and
                // correctly errors rather than being a no-op to measure.
                if mode == Mode::Stream && prim != "arcfour" {
                    continue;
                }
                let d = |data: &[u8]| {
                    ra_prim::decrypt(
                        prim,
                        mode,
                        b"Zombies",
                        &[b'0'; 16],
                        KeyDerivation::NullPadMax,
                        &data[..384],
                    )
                    .unwrap()
                };
                let (pa, pb, pc) = (d(&bytes_a), d(&bytes_b), d(&bytes_c));
                let diff = |x: &[u8], y: &[u8]| {
                    (0..384).filter(|&i| x[i] != y[i]).count()
                };
                let worst = diff(&pa, &pb).max(diff(&pa, &pc));
                assert!(
                    worst <= 64,
                    "{prim}/{mode}: a wrong first group perturbed {worst} of 384 bytes, \
                     which breaks the argument that the negative covers the whole gap-1 space"
                );
            }
        }
    }

    /// **The alternative reading the hypothesis has to beat**, and a second,
    /// independent refutation of it.
    ///
    /// A hex stream chunked into fives *from the right* would leave the first group
    /// short and every other group full — precisely what REV7 shows — with nothing
    /// missing at all. `1092 = 218*5 + 2`, so that reading is self-consistent on the
    /// character count alone, and it must be taken seriously rather than waved away.
    ///
    /// Two things kill it, and neither uses the hypothesis it is being tested
    /// against.
    ///
    /// 1. **Parity.** Right-aligned chunking still has to explain line 11's missing
    ///    group, and `1092 + 5` is odd, which no hex stream can be.
    /// 2. **The final line's width, which counts no characters at all.** Right-aligned
    ///    chunking is a re-chunk of the surviving text, so laying 219 groups out
    ///    fourteen to a row ends with a row of **nine**. REV7's last line holds
    ///    **ten**. A row-faithful transcription of a 220-slot grid that dropped one
    ///    group from row 11 ends with a row of ten and leaves every other row
    ///    untouched — which is exactly the recorded shape, line for line.
    #[test]
    fn the_right_aligned_alternative_is_refuted_two_independent_ways() {
        let t = Transcription::of(&String::from_utf8(corpus_hex_raw("rev7")).unwrap());
        let recorded_groups: usize = t.lines.iter().map(|l| l.len()).sum();
        assert_eq!(recorded_groups, 219);
        assert_eq!(t.lines.last().unwrap().len(), 10);

        // (1) right-aligned chunking accounts for the short first group by itself...
        assert_eq!(1092 % 5, 2);
        assert_eq!(1092 / 5, 218);
        assert_eq!(218 + 1, recorded_groups);
        // ...but cannot also account for line 11, because 1092 + 5 is odd
        assert_eq!((1092 + 5) % 2, 1);

        // (2) the layout test, independent of every character count.
        // A fresh re-wrap of the 219 surviving groups, 14 to a row:
        let rows = t.lines.len();
        assert_eq!(recorded_groups - (rows - 1) * 14, 9, "a re-wrap ends with 9");
        // A row-faithful transcription of a 220-slot grid that lost one group:
        assert_eq!(220 - (rows - 1) * 14, 10, "a 220-slot grid ends with 10");
        // Recorded is 10, so the grid has 220 slots and one group was dropped.
        assert_eq!(t.lines.last().unwrap().len(), 10);
        assert_eq!(220 * 5, 1100);
        assert_eq!(1100 / 2, 550);
    }

    /// Raw ciphertext for a corpus id, whitespace and newlines intact.
    fn corpus_hex_raw(id: &str) -> Vec<u8> {
        let raw = std::fs::read_to_string(
            std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../data/revelations.json"),
        )
        .unwrap();
        let v: serde_json::Value = serde_json::from_str(&raw).unwrap();
        v.as_array().unwrap().iter().find(|r| r["id"] == id).unwrap()["ciphertext"]
            .as_str()
            .unwrap()
            .as_bytes()
            .to_vec()
    }
}
