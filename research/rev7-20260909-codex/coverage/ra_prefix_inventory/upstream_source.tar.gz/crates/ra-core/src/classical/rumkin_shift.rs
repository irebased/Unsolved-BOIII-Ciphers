//! rumkin.com's shift family: Affine, Caesar (plain/keyed/ROT13), Atbash, Vigenère
//! (plain/keyed/autokey/Gronsfeld).
//!
//! # Ported from the site's real JavaScript, not from prose
//!
//! `docs/toolsites/rumkin_full.json` now carries the actual library sources
//! (`affine.js`, `caesar.js`, `vigenere.js`, `util.js`) recovered from the 2015
//! Wayback captures. Earlier work had only each page's *inline* script, which
//! contains no cipher code at all — the algorithms live in separately-loaded
//! library files, so `Tr`/`InsertCRLF` had previously to be reconstructed from the
//! pages' prose. These nodes are transcriptions of the recovered source.
//!
//! # Three site quirks that a "clean" implementation would get wrong
//!
//! 1. **Caesar swaps the alphabets on decode.** `Caesar()` builds a keyed alphabet,
//!    and when `encdec < 0` it sets `inc = len - inc` *and exchanges `key` and
//!    `alphabet`*. Decoding is therefore not simply encoding with `-inc` once a key
//!    is present; see `caesar_keyed_decode_swaps_alphabets`.
//! 2. **Affine's modular inverse hardcodes 26.** The site's loop is
//!    `while ((mult * i) % 26 != 1) i += 2;` — literally `26`, not
//!    `alphabet.length`, and stepping by 2 so only odd multipliers are ever found.
//!    Over a non-26 alphabet the site computes a wrong inverse, and faithfulness
//!    means reproducing that rather than silently fixing it. See
//!    `affine_inverse_hardcodes_26_like_the_site`.
//! 3. **Non-alphabetic characters never consume a Vigenère key position.** The
//!    guard is `if (limit != ' ' && pass.length)`, so punctuation and digits pass
//!    through and the key does not advance.
//!
//! # Case is preserved, and drives which case comes out
//!
//! All three look the character up in the alphabet directly; failing that, they
//! retry with `toUpperCase()` and lowercase the *result*. So a lowercase input
//! yields lowercase output even though the tables are uppercase.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: transforms at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

/// The site's default alphabet, uppercase, as `util.js` spells it.
pub const AZ: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

/// `util.js`'s `MakeKeyedAlphabet(key, alphabet)`.
///
/// The key is uppercased and prefixed to the alphabet; characters are kept in
/// first-seen order, and only if they are members of `alphabet`. A key of `None`
/// returns the alphabet unchanged.
pub fn make_keyed_alphabet(key: Option<&str>, alphabet: &str) -> Vec<u8> {
    let alpha: Vec<u8> = alphabet.bytes().map(|b| b.to_ascii_uppercase()).collect();
    let key = match key {
        None => return alpha,
        Some(k) => k,
    };
    let mut out: Vec<u8> = Vec::with_capacity(alpha.len());
    for c in key.bytes().map(|b| b.to_ascii_uppercase()).chain(alpha.iter().copied()) {
        if !out.contains(&c) && alpha.contains(&c) {
            out.push(c);
        }
    }
    out
}

/// `util.js`'s `OnlyAlpha(str)` — keep A-Z/a-z, drop everything else.
pub fn only_alpha(s: &str) -> Vec<u8> {
    s.bytes().filter(|b| b.is_ascii_alphabetic()).collect()
}

fn alphabet_of(params: &Params) -> String {
    params.opt_str("alphabet").unwrap_or(AZ).to_ascii_uppercase()
}

fn encdec(node: &'static str, params: &Params) -> Result<i64> {
    match params.opt_str("direction").unwrap_or("decrypt") {
        "encrypt" => Ok(1),
        "decrypt" => Ok(-1),
        o => Err(Error::bad_param(node, "direction", format!("got {o:?}"))),
    }
}

// ------------------------------------------------------------------ Caesar

const CAESAR: &str = "rumkin_caesar";
const CAESAR_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("n", ParamType::Int, "shift amount (the site's N field)"),
    ParamSpec::opt("key", ParamType::Str, "keyword altering the alphabet (the site's \
                                           Keyed Caesar); omit for plain Caesar"),
    ParamSpec::opt("alphabet", ParamType::Str, "alphabet (default A-Z)"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// `caesar.js`'s `Caesar(encdec, text, inc, key, alphabet)`.
///
/// Serves three of the site's tools: **Caesar** (no key), **Keyed Caesar** (with a
/// key), and **ROT13** (`n = 13`, no key).
pub struct RumkinCaesar;

impl Node for RumkinCaesar {
    fn name(&self) -> &'static str { CAESAR }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_shift(caesar.js)" }
    fn params_schema(&self) -> &'static [ParamSpec] { CAESAR_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let alphabet = alphabet_of(params);
        let mut alpha: Vec<u8> = alphabet.bytes().collect();
        if alpha.is_empty() {
            return Err(Error::bad_param(CAESAR, "alphabet", "must not be empty"));
        }
        let mut inc = params.req_i64(CAESAR, "n")?;
        let mut key = make_keyed_alphabet(params.opt_str("key"), &alphabet);
        if encdec(CAESAR, params)? < 0 {
            inc = alpha.len() as i64 - inc;
            std::mem::swap(&mut key, &mut alpha);
        }
        let n = alpha.len() as i64;
        let out: Vec<u8> = input
            .data
            .iter()
            .map(|&c| {
                if let Some(i) = alpha.iter().position(|&x| x == c) {
                    key[((i as i64 + inc).rem_euclid(n)) as usize]
                } else if let Some(i) = alpha.iter().position(|&x| x == c.to_ascii_uppercase()) {
                    key[((i as i64 + inc).rem_euclid(n)) as usize].to_ascii_lowercase()
                } else {
                    c
                }
            })
            .collect();
        Ok(Repr::new(out, Display::Bytes))
    }
}

// ------------------------------------------------------------------ Atbash

const ATBASH: &str = "rumkin_atbash";

/// rumkin's **Atbash**: `A<->Z`, `B<->Y`, …, case preserved, non-letters untouched.
pub struct RumkinAtbash;

impl Node for RumkinAtbash {
    fn name(&self) -> &'static str { ATBASH }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_shift(atbash)" }
    fn params_schema(&self) -> &'static [ParamSpec] { &[] }

    fn apply(&self, input: &Repr, _p: &Params) -> Result<Repr> {
        let out: Vec<u8> = input
            .data
            .iter()
            .map(|&c| {
                if c.is_ascii_uppercase() { b'Z' - (c - b'A') }
                else if c.is_ascii_lowercase() { b'z' - (c - b'a') }
                else { c }
            })
            .collect();
        Ok(Repr::new(out, input.display))
    }
}

// ------------------------------------------------------------------ Affine

const AFFINE: &str = "rumkin_affine";
const AFFINE_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("a", ParamType::Int, "multiplier (the site's 'multiply by' field)"),
    ParamSpec::req("b", ParamType::Int, "increment (the site's 'plus' field)"),
    ParamSpec::opt("key", ParamType::Str, "keyword altering the output alphabet"),
    ParamSpec::opt("alphabet", ParamType::Str, "alphabet (default A-Z)"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// `affine.js`'s `Affine(encdec, text, mult, inc, key, alphabet)`.
///
/// **Reproduces the site's hardcoded `% 26` inverse**, including its `i += 2` step,
/// which means: over a non-26 alphabet the inverse is computed against the wrong
/// modulus, and an even multiplier never terminates the site's loop. This node
/// returns an error in the case the site would hang, rather than hanging.
pub struct RumkinAffine;

impl Node for RumkinAffine {
    fn name(&self) -> &'static str { AFFINE }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_shift(affine.js,%26-inverse)" }
    fn params_schema(&self) -> &'static [ParamSpec] { AFFINE_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let alphabet = alphabet_of(params);
        let alpha: Vec<u8> = alphabet.bytes().collect();
        let n = alpha.len() as i64;
        if n == 0 {
            return Err(Error::bad_param(AFFINE, "alphabet", "must not be empty"));
        }
        let mut mult = params.req_i64(AFFINE, "a")?;
        let mut inc = params.req_i64(AFFINE, "b")?;
        if encdec(AFFINE, params)? < 0 {
            // The site's literal loop: `while ((mult * i) % 26 != 1) i += 2;`
            let mut i: i64 = 1;
            let mut found = None;
            while i < 1000 {
                if (mult * i).rem_euclid(26) == 1 { found = Some(i); break; }
                i += 2;
            }
            mult = found.ok_or_else(|| Error::bad_param(
                AFFINE, "a",
                format!("the site's inverse loop `while ((a*i) % 26 != 1) i += 2` never \
                         terminates for a={mult}: it steps through ODD i only and tests \
                         against a hardcoded 26. An even multiplier, or one sharing a \
                         factor with 26, hangs the real page; this node reports it instead."),
            ))?;
            inc = (mult * (n - inc)).rem_euclid(n);
        }
        let key = make_keyed_alphabet(params.opt_str("key"), &alphabet);
        let out: Vec<u8> = input
            .data
            .iter()
            .map(|&c| {
                if let Some(i) = alpha.iter().position(|&x| x == c) {
                    key[((mult * i as i64 + inc).rem_euclid(n)) as usize]
                } else if let Some(i) = alpha.iter().position(|&x| x == c.to_ascii_uppercase()) {
                    key[((mult * i as i64 + inc).rem_euclid(n)) as usize].to_ascii_lowercase()
                } else {
                    c
                }
            })
            .collect();
        Ok(Repr::new(out, Display::Bytes))
    }
}

// ---------------------------------------------------------------- Vigenère

const VIG: &str = "rumkin_vigenere";
const VIG_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("pass", ParamType::Str, "the password (non-letters are stripped)"),
    ParamSpec::opt("key", ParamType::Str, "keyword altering the alphabet (the site's \
                                           Keyed Vigenère)"),
    ParamSpec::opt("autokey", ParamType::Bool, "autokey mode (default false)"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// `vigenere.js`'s `Vigenere(encdec, text, pass, key, autokey)`.
///
/// Serves **Vigenère**, **Keyed Vigenère**, **Vigenère Autokey**, and (by passing a
/// digit password) **Gronsfeld**, which the site implements as a Vigenère whose
/// password digits map to letters.
///
/// The autokey feed differs by direction, exactly as the source does: encoding
/// appends the *plaintext* letter before the shift, decoding appends the *recovered*
/// letter after it.
pub struct RumkinVigenere;

impl Node for RumkinVigenere {
    fn name(&self) -> &'static str { VIG }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_shift(vigenere.js)" }
    fn params_schema(&self) -> &'static [ParamSpec] { VIG_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let ed = encdec(VIG, params)?;
        let autokey = params.opt_bool("autokey", false);
        let mut pass: Vec<u8> = only_alpha(params.req_str(VIG, "pass")?)
            .into_iter()
            .map(|b| b.to_ascii_uppercase())
            .collect();
        let key = make_keyed_alphabet(params.opt_str("key"), AZ);
        let mut out = Vec::with_capacity(input.data.len());
        for &c in input.data.iter() {
            let lower = c.is_ascii_lowercase();
            if !c.is_ascii_alphabetic() || pass.is_empty() {
                // non-alpha never consumes a key position
                out.push(c);
                continue;
            }
            let b = c.to_ascii_uppercase();
            if autokey && ed > 0 {
                pass.push(b);
            }
            let bi = key.iter().position(|&x| x == b).unwrap_or(0) as i64;
            let pi = key.iter().position(|&x| x == pass[0]).unwrap_or(0) as i64;
            let v = (bi + ed * pi).rem_euclid(26) as usize;
            let mut r = key[v];
            if autokey && ed < 0 {
                pass.push(r);
            }
            if lower {
                r = r.to_ascii_lowercase();
            }
            if !autokey {
                let f = pass[0];
                pass.push(f);
            }
            pass.remove(0);
            out.push(r);
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

// --------------------------------------------------------------- Gronsfeld

const GRONS: &str = "rumkin_gronsfeld";
const GRONS_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("pass", ParamType::Str, "digit password; `vigenere.js`'s \
                                            GronsfeldToVigenere maps 0-9 onto A-J"),
    ParamSpec::opt("key", ParamType::Str, "keyword altering the alphabet"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// The site's **Gronsfeld**, which is not a separate algorithm: `vigenere.js`'s
/// `GronsfeldToVigenere(p)` rewrites the digit password as letters (`0`->`A` ..
/// `9`->`J`) and the ordinary Vigenère runs on it.
///
/// Non-digits in the password are **dropped**, not treated as zero — so `"1-2"` is
/// the two-letter key `BC`, not three characters.
pub struct RumkinGronsfeld;

impl Node for RumkinGronsfeld {
    fn name(&self) -> &'static str { GRONS }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_shift(gronsfeld via vigenere.js)" }
    fn params_schema(&self) -> &'static [ParamSpec] { GRONS_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let pass: String = params
            .req_str(GRONS, "pass")?
            .bytes()
            .filter(|b| b.is_ascii_digit())
            .map(|b| (b'A' + (b - b'0')) as char)
            .collect();
        if pass.is_empty() {
            return Err(Error::bad_param(GRONS, "pass", "no digits in the password"));
        }
        let mut p = Params::new().set("pass", pass.as_str());
        if let Some(k) = params.opt_str("key") { p = p.set("key", k); }
        if let Some(d) = params.opt_str("direction") { p = p.set("direction", d); }
        RumkinVigenere.apply(input, &p)
    }
}

register_node!(RUMKIN_GRONSFELD => || Box::new(RumkinGronsfeld));
register_node!(RUMKIN_CAESAR => || Box::new(RumkinCaesar));
register_node!(RUMKIN_ATBASH => || Box::new(RumkinAtbash));
register_node!(RUMKIN_AFFINE => || Box::new(RumkinAffine));
register_node!(RUMKIN_VIGENERE => || Box::new(RumkinVigenere));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn n(name: &str) -> &'static dyn Node { registry().get(name).unwrap() }

    #[test]
    fn all_are_xf() {
        for x in [CAESAR, ATBASH, AFFINE, VIG] {
            assert_eq!(n(x).family(), Family::Xf);
        }
    }

    /// `MakeKeyedAlphabet` keeps first-seen key letters, then the rest of the
    /// alphabet, and ignores characters outside it.
    #[test]
    fn keyed_alphabet_matches_util_js() {
        assert_eq!(make_keyed_alphabet(Some("ZOMBIES"), AZ), b"ZOMBIESACDFGHJKLNPQRTUVWXY");
        assert_eq!(make_keyed_alphabet(Some("hello!"), AZ), b"HELOABCDFGIJKMNPQRSTUVWXYZ");
        assert_eq!(make_keyed_alphabet(None, AZ), AZ.as_bytes());
    }

    /// Plain Caesar with no key is ROT-N, and round-trips.
    #[test]
    fn caesar_plain_is_rot_n() {
        let enc = n(CAESAR)
            .apply(&Repr::bytes(b"Attack at dawn!".to_vec()),
                   &params! {"n" => 3i64, "direction" => "encrypt"})
            .unwrap();
        assert_eq!(enc.data, b"Dwwdfn dw gdzq!");
        let back = n(CAESAR).apply(&enc, &params! {"n" => 3i64}).unwrap();
        assert_eq!(back.data, b"Attack at dawn!");
    }

    /// ROT13 is the same node at n=13 and is self-inverse.
    #[test]
    fn rot13_is_caesar_13() {
        let e = n(CAESAR)
            .apply(&Repr::bytes(b"Hello".to_vec()), &params! {"n" => 13i64, "direction" => "encrypt"})
            .unwrap();
        assert_eq!(e.data, b"Uryyb");
    }

    /// The quirk: with a key present, decode swaps `key` and `alphabet` rather than
    /// simply shifting the other way. A keyed encode must round-trip through the
    /// node's own decode, which only holds if the swap is reproduced.
    #[test]
    fn caesar_keyed_decode_swaps_alphabets() {
        let p = params! {"n" => 5i64, "key" => "ZOMBIES"};
        let enc = n(CAESAR)
            .apply(&Repr::bytes(b"Attack at dawn".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        let back = n(CAESAR).apply(&enc, &p).unwrap();
        assert_eq!(back.data, b"Attack at dawn");
        // and it is NOT the same as an unkeyed shift
        let plain = n(CAESAR)
            .apply(&Repr::bytes(b"Attack at dawn".to_vec()),
                   &params! {"n" => 5i64, "direction" => "encrypt"})
            .unwrap();
        assert_ne!(enc.data, plain.data);
    }

    #[test]
    fn atbash_is_an_involution_and_keeps_case() {
        let t = n(ATBASH).apply(&Repr::bytes(b"Attack, 42!".to_vec()), &Params::new()).unwrap();
        assert_eq!(t.data, b"Zggzxp, 42!");
        let back = n(ATBASH).apply(&t, &Params::new()).unwrap();
        assert_eq!(back.data, b"Attack, 42!");
    }

    #[test]
    fn affine_round_trips_with_an_odd_coprime_multiplier() {
        let p = params! {"a" => 5i64, "b" => 8i64};
        let enc = n(AFFINE)
            .apply(&Repr::bytes(b"Attack at dawn".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        let back = n(AFFINE).apply(&enc, &p).unwrap();
        assert_eq!(back.data, b"Attack at dawn");
    }

    /// The site's inverse loop tests `% 26` literally and steps by 2. For a
    /// multiplier that shares a factor with 26 the real page loops forever; this
    /// node reports it and says why rather than hanging.
    #[test]
    fn affine_inverse_hardcodes_26_like_the_site() {
        let e = n(AFFINE)
            .apply(&Repr::bytes(b"abc".to_vec()), &params! {"a" => 13i64, "b" => 1i64})
            .unwrap_err();
        let s = format!("{e}");
        assert!(s.contains("never \n                         terminates") || s.contains("never"), "{s}");
        assert!(s.contains("hardcoded 26"), "{s}");
    }

    /// Non-alphabetic characters pass through AND do not advance the password.
    #[test]
    fn vigenere_punctuation_does_not_consume_the_key() {
        let clean = n(VIG)
            .apply(&Repr::bytes(b"ATTACK".to_vec()),
                   &params! {"pass" => "LEMON", "direction" => "encrypt"})
            .unwrap();
        let dirty = n(VIG)
            .apply(&Repr::bytes(b"A T,T-A.C K".to_vec()),
                   &params! {"pass" => "LEMON", "direction" => "encrypt"})
            .unwrap();
        let letters: Vec<u8> = dirty.data.into_iter().filter(|b| b.is_ascii_alphabetic()).collect();
        assert_eq!(letters, clean.data);
    }

    /// The textbook vector, which pins the shift direction.
    #[test]
    fn vigenere_textbook_vector() {
        let e = n(VIG)
            .apply(&Repr::bytes(b"ATTACKATDAWN".to_vec()),
                   &params! {"pass" => "LEMON", "direction" => "encrypt"})
            .unwrap();
        assert_eq!(e.data, b"LXFOPVEFRNHR");
        let d = n(VIG).apply(&e, &params! {"pass" => "LEMON"}).unwrap();
        assert_eq!(d.data, b"ATTACKATDAWN");
    }

    /// Autokey feeds differently by direction; a round trip is the only honest check.
    #[test]
    fn vigenere_autokey_round_trips() {
        let p = params! {"pass" => "NINE", "autokey" => true};
        let e = n(VIG)
            .apply(&Repr::bytes(b"Attack at dawn".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        let d = n(VIG).apply(&e, &p).unwrap();
        assert_eq!(d.data, b"Attack at dawn");
    }

    /// Keyed Vigenère differs from plain, and still round-trips.
    /// Gronsfeld is Vigenère with 0-9 rewritten as A-J; non-digits are dropped.
    #[test]
    fn gronsfeld_maps_digits_to_a_through_j() {
        let g = n(GRONS)
            .apply(&Repr::bytes(b"ATTACK".to_vec()),
                   &params! {"pass" => "1-2", "direction" => "encrypt"})
            .unwrap();
        // "1-2" -> "BC", the hyphen dropped rather than treated as a zero
        let v = n(VIG)
            .apply(&Repr::bytes(b"ATTACK".to_vec()),
                   &params! {"pass" => "BC", "direction" => "encrypt"})
            .unwrap();
        assert_eq!(g.data, v.data);
        let back = n(GRONS).apply(&g, &params! {"pass" => "1-2"}).unwrap();
        assert_eq!(back.data, b"ATTACK");
    }

    #[test]
    fn vigenere_keyed_differs_and_round_trips() {
        let p = params! {"pass" => "LEMON", "key" => "ZOMBIES"};
        let e = n(VIG)
            .apply(&Repr::bytes(b"ATTACKATDAWN".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_ne!(e.data, b"LXFOPVEFRNHR");
        assert_eq!(n(VIG).apply(&e, &p).unwrap().data, b"ATTACKATDAWN");
    }
}
