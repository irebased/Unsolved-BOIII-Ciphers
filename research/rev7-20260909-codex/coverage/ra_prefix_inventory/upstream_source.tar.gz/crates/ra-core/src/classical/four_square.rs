//! Four-square: two keyed 5x5 squares either side of two fixed plain squares,
//! matching practicalcryptography.com's implementation
//! (`http://practicalcryptography.com/ciphers/classical-era/four-square/`).
//!
//! # The site's own convention
//!
//! practicalcryptography.com's page takes the two keyed squares
//! (`keysquare1`, `keysquare2`) as **raw 25-letter fields**, exactly like its
//! Playfair page's `keysquare` — the puzzle-maker types or randomly generates
//! the finished square, there is no keyword-to-square derivation anywhere in
//! the page's own JavaScript. `key1`/`key2` here follow the same convention
//! this crate's `xf:playfair` already established for that same site: pass
//! the keyword and the classic dedup-then-fill-remainder construction runs,
//! but pass the literal 25-letter square and it passes through unchanged (a
//! permutation has nothing left to dedup or fill), so the parameter is a
//! strict superset of what the site's own field accepts.
//!
//! The two "plain" squares (top-left, bottom-right in the classical diagram)
//! are always the fixed, unkeyed, I/J-merged alphabet on this site — there is
//! no field for them at all, so [`PLAIN_SQUARE`] is not a default that can be
//! overridden, it is simply what the site's `rt` constant is.
//!
//! # Digraph rule
//!
//! For plaintext pair `(a, b)`: look up `a`'s (row, col) and `b`'s (row, col)
//! in the plain square, then the ciphertext pair is
//! `key1[row(a), col(b)]`, `key2[row(b), col(a)]` — the classical rectangle
//! rule, unconditionally (unlike Playfair, there is no same-row/same-column
//! special case, because a four-square digraph is never looked up in the same
//! square twice).
//!
//! # Padding
//!
//! Confirmed by extracting the site's `Encrypt()`/`Decrypt()` verbatim and
//! executing under Node: an **odd-length message gets exactly one trailing
//! `x`** appended before pairing (`while(plaintext.length % 2 != 0)
//! plaintext += "x"`), and — unlike Playfair — **there is no doubled-letter
//! split**: a plaintext pair `"ee"` is encrypted as the rectangle for `(e,
//! e)` directly (row/col of `e` used for both halves) and decrypts back to
//! `"ee"` cleanly, because the rectangle rule never depends on the two
//! letters differing. `four_square_double_letter_pair_round_trips_untouched`
//! below pins this down; it is a real behavioural difference from Playfair
//! that is easy to assume by analogy and get wrong.
//!
//! # `alphabet` is authoritative for the two keyed squares
//!
//! `key1`/`key2` used to be built from a hardcoded `b'a'..=b'z'` filler range
//! inside `Square::build`, with no parameter behind it. `alphabet` (default
//! the classical 26-letter form) now drives that filler and the ciphertext-side
//! input filter, so a differently-shaped keyed square -- e.g. a 4x4 pair over
//! 16 hex digits -- is a real, working construction. The two **plain** squares
//! deliberately do **not** take `alphabet`: they stay built over the fixed
//! classical alphabet regardless, because (per the site convention documented
//! above) there is no field for them at all, on either the real site or this
//! node. See `hex_alphabet_reshapes_only_the_keyed_squares` below: plaintext
//! stays ordinary letters (looked up in the fixed plain squares) while the
//! ciphertext it round-trips through is genuinely hex-shaped (looked up in the
//! `alphabet`-shaped keyed squares).
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: a keyed re-representation at stated parameters, exhaustive
//! at those parameters, no search.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const NAME: &str = "four_square";

/// The classical merge: `J` is folded onto `I` in the fixed plain squares.
pub const DEFAULT_MERGE: &str = "ji";
/// The classical padding letter, appended once to an odd-length input.
pub const DEFAULT_PAD: &str = "x";
/// The classical base alphabet: 26 letters, which after the default J-onto-I
/// merge gives the textbook 5x5 squares. Exposed as a parameter, not baked
/// into `Square::build`'s filler range, for the same reason as
/// `xf:playfair`'s `DEFAULT_ALPHABET`: so a differently-shaped grid is a
/// real, working construction rather than English-letters-only.
pub const DEFAULT_ALPHABET: &str = "abcdefghijklmnopqrstuvwxyz";
/// The fixed, unkeyed I/J-merged alphabet used for both plain squares
/// (top-left and bottom-right of the classical four-square diagram).
/// practicalcryptography.com's `rt` constant.
pub const PLAIN_SQUARE: &str = "abcdefghiklmnopqrstuvwxyz";

const SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::req(
        "key1",
        ParamType::Str,
        "keyword (or literal 25-letter square) for the top-right keyed square",
    ),
    ParamSpec::req(
        "key2",
        ParamType::Str,
        "keyword (or literal 25-letter square) for the bottom-left keyed square",
    ),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "base symbol set the keyed squares are built from, before the merge folds \
         one away (default the 26-letter alphabet, giving the textbook 5x5 \
         squares). Only the keyed squares use this -- the two plain squares are \
         always the site's own fixed I/J-merged alphabet, since the site has no \
         field for them at all. The alphabet's length, after the merge, must be \
         a perfect square, and it must match the plain squares' side so the \
         rectangle rule has one consistent grid shape to work over.",
    ),
    ParamSpec::opt(
        "merge",
        ParamType::Str,
        "two distinct symbols \"ab\": 'a' is folded onto 'b' in every square \
         (default \"ji\", the classical J-onto-I merge)",
    ),
    ParamSpec::opt(
        "pad",
        ParamType::Str,
        "single padding symbol appended once to an odd-length input (default \"x\")",
    ),
    ParamSpec::opt(
        "direction",
        ParamType::Str,
        "\"decrypt\" (default) or \"encrypt\"",
    ),
);

/// A resolved square: any side length whose square is the (post-merge)
/// alphabet size, not just the classical 5.
struct Square {
    cells: Vec<u8>,
    index: std::collections::HashMap<u8, usize>,
    side: usize,
}

impl Square {
    /// Same construction as `xf:playfair`'s `Square::build`: a keyword (or a
    /// literal already-full-size permutation, which passes through
    /// unchanged), the merge symbol folded away, remaining `alphabet`
    /// symbols filling in the order `alphabet` lists them. Symbols outside
    /// `alphabet` are ignored, whether from `key` or anywhere else.
    fn build(key: &str, alphabet: &str, merge: (u8, u8)) -> Result<Self> {
        let (dropped, kept) = merge;
        let members: std::collections::HashSet<u8> =
            alphabet.bytes().map(|b| b.to_ascii_lowercase()).collect();
        let mut cells: Vec<u8> = Vec::with_capacity(members.len());
        let mut seen = std::collections::HashSet::new();
        for c in key.bytes().chain(alphabet.bytes()) {
            let mut c = c.to_ascii_lowercase();
            if !members.contains(&c) {
                continue;
            }
            if c == dropped {
                c = kept;
            }
            if seen.insert(c) {
                cells.push(c);
            }
        }
        let side = (cells.len() as f64).sqrt().round() as usize;
        if side * side != cells.len() {
            return Err(Error::bad_param(
                NAME,
                "alphabet",
                format!(
                    "{} symbols (after the merge) is not a perfect square, so a \
                     1:1 grid of rows and columns can't hold it",
                    cells.len()
                ),
            ));
        }
        let mut index = std::collections::HashMap::with_capacity(cells.len());
        for (i, &c) in cells.iter().enumerate() {
            index.insert(c, i);
        }
        Ok(Self { cells, index, side })
    }

    fn pos(&self, c: u8) -> Option<(usize, usize)> {
        self.index.get(&c).map(|&i| (i / self.side, i % self.side))
    }

    fn at(&self, row: usize, col: usize) -> u8 {
        self.cells[row * self.side + col]
    }
}

fn letter_absent(c: u8) -> Error {
    Error::node_failed(
        NAME,
        format!(
            "letter '{}' is not in the plain square, so it cannot appear in a \
             four-square text",
            c as char
        ),
    )
}

/// Keep only symbols in the declared `alphabet`, lowercase them, fold the
/// merged symbol away — the site drops everything else before pairing, same
/// as `xf:playfair`. Testing membership in `alphabet` rather than
/// `is_ascii_alphabetic` is what lets a non-letter alphabet actually reach
/// the squares instead of being silently dropped here.
fn normalise(data: &[u8], alphabet_members: &std::collections::HashSet<u8>, merge: (u8, u8)) -> Vec<u8> {
    data.iter()
        .map(|c| c.to_ascii_lowercase())
        .filter(|c| alphabet_members.contains(c))
        .map(|c| if c == merge.0 { merge.1 } else { c })
        .collect()
}

/// Append `pad` once if the length is odd. Unlike `xf:playfair::prepare`,
/// there is no doubled-letter split — see the module docs.
fn prepare(letters: &[u8], pad: u8) -> Vec<u8> {
    let mut out = letters.to_vec();
    if out.len() % 2 != 0 {
        out.push(pad);
    }
    out
}

fn merge_pair(params: &Params) -> Result<(u8, u8)> {
    let s = params.opt_str("merge").unwrap_or(DEFAULT_MERGE);
    let b = s.as_bytes();
    // Not restricted to `is_ascii_alphabetic`: the keyed squares' base
    // alphabet is a parameter now, so the merge pair only needs to be two
    // distinct bytes to be meaningful over it.
    if b.len() != 2 {
        return Err(Error::bad_param(
            NAME,
            "merge",
            format!("expected exactly two bytes, got {s:?}"),
        ));
    }
    let (dropped, kept) = (b[0].to_ascii_lowercase(), b[1].to_ascii_lowercase());
    if dropped == kept {
        return Err(Error::bad_param(
            NAME,
            "merge",
            "the two symbols must differ; merging a symbol onto itself would leave \
             the full alphabet, which does not fit a 1:1 grid unless its length was \
             already a perfect square",
        ));
    }
    Ok((dropped, kept))
}

fn pad_letter(params: &Params) -> Result<u8> {
    let s = params.opt_str("pad").unwrap_or(DEFAULT_PAD);
    let b = s.as_bytes();
    if b.len() != 1 {
        return Err(Error::bad_param(
            NAME,
            "pad",
            format!("expected a single byte, got {s:?}"),
        ));
    }
    Ok(b[0].to_ascii_lowercase())
}

pub struct FourSquare;

impl Node for FourSquare {
    fn name(&self) -> &'static str {
        NAME
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/four_square(practicalcryptography.com,fixed-plain-squares)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let merge = merge_pair(params)?;
        let pad = pad_letter(params)?;
        if pad == merge.0 {
            return Err(Error::bad_param(
                NAME,
                "pad",
                "the padding letter is the merged-away letter, so it can never appear \
                 in the plain square",
            ));
        }
        // The plain squares are always built over the fixed classical 26-letter
        // alphabet -- the site has no field for them at all (see module docs),
        // so `alphabet` must not reach them. Only the two keyed squares use it.
        let plain = Square::build(PLAIN_SQUARE, DEFAULT_ALPHABET, merge)?;
        let plain_members: std::collections::HashSet<u8> =
            DEFAULT_ALPHABET.bytes().collect();
        let alphabet = params.opt_str("alphabet").unwrap_or(DEFAULT_ALPHABET);
        let alphabet_members: std::collections::HashSet<u8> =
            alphabet.bytes().map(|b| b.to_ascii_lowercase()).collect();
        let key1 = Square::build(params.req_str(NAME, "key1")?, alphabet, merge)?;
        let key2 = Square::build(params.req_str(NAME, "key2")?, alphabet, merge)?;

        let direction = params.opt_str("direction").unwrap_or("decrypt");
        // Encryption looks plaintext up in the fixed plain squares; decryption
        // looks ciphertext up in the (possibly reshaped) keyed squares -- so
        // which byte set counts as "in the alphabet" depends on direction.
        let letters = normalise(
            &input.data,
            if direction == "encrypt" {
                &plain_members
            } else {
                &alphabet_members
            },
            merge,
        );
        if letters.is_empty() {
            return Err(Error::node_failed(
                NAME,
                "input has no ASCII letters, so there is no digraph text to work on",
            ));
        }

        let text = match direction {
            "encrypt" => prepare(&letters, pad),
            "decrypt" => {
                if letters.len() % 2 != 0 {
                    return Err(Error::node_failed(
                        NAME,
                        format!(
                            "a four-square ciphertext must have an even number of \
                             letters; got {}",
                            letters.len()
                        ),
                    ));
                }
                letters
            }
            other => {
                return Err(Error::bad_param(
                    NAME,
                    "direction",
                    format!("expected \"decrypt\" or \"encrypt\", got {other:?}"),
                ))
            }
        };

        let mut out = Vec::with_capacity(text.len());
        for pair in text.chunks_exact(2) {
            if direction == "encrypt" {
                let (ra, ca) = plain.pos(pair[0]).ok_or_else(|| letter_absent(pair[0]))?;
                let (rb, cb) = plain.pos(pair[1]).ok_or_else(|| letter_absent(pair[1]))?;
                out.push(key1.at(ra, cb));
                out.push(key2.at(rb, ca));
            } else {
                let (ra, ca) = key1.pos(pair[0]).ok_or_else(|| letter_absent(pair[0]))?;
                let (rb, cb) = key2.pos(pair[1]).ok_or_else(|| letter_absent(pair[1]))?;
                out.push(plain.at(ra, cb));
                out.push(plain.at(rb, ca));
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(FOUR_SQUARE => || Box::new(FourSquare));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn node() -> &'static dyn Node {
        registry().get(NAME).unwrap()
    }

    #[test]
    fn is_xf_family_and_not_layer_forming() {
        let n = node();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    /// Ground truth from practicalcryptography.com's own `Encrypt()`/`Decrypt()`
    /// (`http://practicalcryptography.com/ciphers/classical-era/four-square/`),
    /// extracted verbatim and executed under Node: `key1="example"`,
    /// `key2="keyword"`, plaintext `"hide the gold in the tree stump"`
    /// (25 letters, odd, so a trailing `x` is appended) encrypts to
    /// `DAPWRBXCGIMBKPFYQQPOSPQLIZ`, and decrypting that returns
    /// `HIDETHEGOLDINTHETREESTUMPX` (uppercase, since the site's page
    /// uppercases both directions' output).
    #[test]
    fn matches_practicalcryptography_com_convention() {
        let n = node();
        let p = params! {"key1" => "example", "key2" => "keyword"};
        let out = n
            .apply(&Repr::bytes(b"DAPWRBXCGIMBKPFYQQPOSPQLIZ".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"hidethegoldinthetreestumpx");

        let enc = n
            .apply(
                &Repr::bytes(b"hide the gold in the tree stump".to_vec()),
                &params! {"key1" => "example", "key2" => "keyword", "direction" => "encrypt"},
            )
            .unwrap();
        assert_eq!(enc.data, b"dapwrbxcgimbkpfyqqpospqliz");
    }

    /// The behavioural difference from Playfair the module docs call out: a
    /// doubled letter is not split, because the rectangle rule never needs
    /// the two letters of a pair to differ.
    #[test]
    fn double_letter_pair_round_trips_untouched() {
        let n = node();
        let enc = params! {"key1" => "example", "key2" => "keyword", "direction" => "encrypt"};
        let dec = params! {"key1" => "example", "key2" => "keyword"};
        let coded = n.apply(&Repr::bytes(b"ee".to_vec()), &enc).unwrap();
        assert_eq!(n.apply(&coded, &dec).unwrap().data, b"ee");
    }

    /// Passing a literal 25-letter square as `key1`/`key2` reproduces exactly
    /// what practicalcryptography.com's raw `keysquare1`/`keysquare2` fields
    /// hold — the site never derives a square from a keyword itself.
    #[test]
    fn literal_square_passes_through_key_construction_unchanged() {
        let literal = "examplbcdfghiknoqrstuvwyz";
        let from_keyword = Square::build("example", DEFAULT_ALPHABET, (b'j', b'i')).unwrap();
        let from_literal = Square::build(literal, DEFAULT_ALPHABET, (b'j', b'i')).unwrap();
        assert_eq!(from_keyword.cells, from_literal.cells);
    }

    #[test]
    fn odd_length_is_padded_once_not_per_doubled_pair() {
        assert_eq!(prepare(b"abc", b'x'), b"abcx");
        assert_eq!(prepare(b"ee", b'x'), b"ee"); // even already: no padding at all
    }

    #[test]
    fn round_trip_recovers_normalised_input() {
        let n = node();
        let original = b"Attack at Dawn!".to_vec();
        let p_enc = params! {"key1" => "GERMAN", "key2" => "SECRET", "direction" => "encrypt"};
        let p_dec = params! {"key1" => "GERMAN", "key2" => "SECRET"};
        let enc = n.apply(&Repr::bytes(original), &p_enc).unwrap();
        let back = n.apply(&enc, &p_dec).unwrap();
        assert_eq!(back.data, b"attackatdawn");
    }

    /// The declared `alphabet` is authoritative for the two keyed squares: a
    /// hex-digit alphabet builds a working 4x4 pair of keyed squares (the
    /// fixed plain squares stay classical letters, per the site's own
    /// design -- see the module docs), and a plaintext message round trips
    /// through a hex-symbol ciphertext.
    #[test]
    fn hex_alphabet_reshapes_only_the_keyed_squares() {
        let n = node();
        let common = params! {
            "key1" => "BEEF",
            "key2" => "CAFE",
            // 17 symbols so folding one away leaves a perfect square (16 = 4x4).
            "alphabet" => "0123456789ABCDEFG",
            "merge" => "GF", // the message below never needs 'g'
        };
        let enc = common.clone().set("direction", "encrypt");

        let ct = n.apply(&Repr::bytes(b"attack".to_vec()), &enc).unwrap();
        assert!(
            ct.data.iter().all(|b| b"0123456789abcdef".contains(b)),
            "ciphertext should be entirely hex symbols, not the plaintext letters \
             passed through unencoded, {ct:?}"
        );

        let back = n.apply(&ct, &common).unwrap();
        assert_eq!(back.data, b"attack");
    }

    #[test]
    fn malformed_parameters_error_rather_than_defaulting() {
        let n = node();
        let d = Repr::bytes(b"abcd".to_vec());
        for bad in [
            params! {"key1" => "GERMAN"},
            params! {"key2" => "GERMAN"},
            params! {"key1" => "GERMAN", "key2" => "SECRET", "merge" => "j"},
            params! {"key1" => "GERMAN", "key2" => "SECRET", "pad" => "xy"},
            params! {"key1" => "GERMAN", "key2" => "SECRET", "direction" => "sideways"},
            Params::new(),
        ] {
            assert!(n.apply(&d, &bad).is_err(), "{bad:?} should be rejected");
        }
    }

    #[test]
    fn odd_length_ciphertext_is_rejected_rather_than_silently_padded() {
        let n = node();
        let p = params! {"key1" => "GERMAN", "key2" => "SECRET"};
        assert!(n.apply(&Repr::bytes(b"abc".to_vec()), &p).is_err());
        assert!(n.apply(&Repr::bytes(b"abcd".to_vec()), &p).is_ok());
    }
}
