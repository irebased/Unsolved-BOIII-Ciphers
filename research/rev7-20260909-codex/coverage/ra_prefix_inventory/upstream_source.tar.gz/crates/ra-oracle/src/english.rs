//! Quadgram log-probability fitness — the standard cryptanalytic English scorer.
//!
//! # Corpus and its honest limitations
//!
//! The frequency table in [`quadgram_data`](crate::quadgram_data) is derived
//! entirely in-repo, from two sources concatenated together:
//!
//! 1. The ~61 solved plaintexts recorded in `data/*.json` across this project's
//!    corpus (Der Eisendrache, Gorod Krovi, Revelations, SOE, The Giant,
//!    Zetsubou), including the four known Giant riddles this oracle exists to
//!    recognise.
//! 2. A few dozen hand-written English sentences (see the crate's git history
//!    for the build script and source text) added purely to broaden quadgram
//!    coverage beyond this corpus's narrow register.
//!
//! That is **~16,500 letters** total — tiny next to a real corpus (Peter
//! Norvig's `english_quadgrams.txt`, the usual choice for this technique, is
//! built from a Google Books n-gram sample of *hundreds of billions* of
//! letters). The practical implications:
//!
//! - It is unusually good at recognising text in *this* register: short,
//!   declarative, slightly archaic riddle-and-lore sentences about mountains,
//!   war, science facilities and the like. That is exactly the register the
//!   Giant's plaintexts are in, which is why it is fit for this purpose.
//! - It is weaker than a standard-corpus scorer at recognising arbitrary
//!   English — technical jargon, dialogue, modern slang, or any register
//!   underrepresented in the 61 source plaintexts, will score lower than it
//!   would against Norvig's table, and unseen quadgrams (the large majority
//!   of the 456,976 possible 4-letter combinations are absent from a table
//!   this size) all fall back to one shared floor probability rather than a
//!   graded estimate.
//! - Do not present a "no hit found" result from this oracle as evidence that
//!   no English plaintext exists in a search space; only that no *English in
//!   the calibrated register* was found. See the calibration test below for
//!   the actual false-positive rate this implies.
//!
//! # Scoring
//!
//! The candidate is uppercased and every non-letter byte is dropped (spaces,
//! punctuation, digits, control bytes), matching standard practice for this
//! technique: it makes the scorer robust to formatting and case, and to a
//! partly-corrupt decrypt where individual bytes are wrong but the surviving
//! letters are still English.
//!
//! The score is `(1/n) * sum(log10 P(quadgram))` over the `n` overlapping
//! 4-letter windows — normalised per scored letter so candidates of different
//! lengths compare on the same scale. Unseen quadgrams are given a shared
//! floor probability (`0.01 / total_count`, the standard Laplace-style floor
//! for this technique) rather than zero, so one novel word does not zero out
//! an otherwise-fitting candidate.
//!
//! # The letter-count gate, and why the average alone is not enough
//!
//! A per-character average is a *mean over very few samples* when a candidate
//! is mostly non-letter bytes: a 112-byte tail of high-entropy binary output
//! only yields ~20-25 letters after stripping (uniform random bytes are
//! letters ~20.3% of the time), i.e. ~20 overlapping quadgrams. At that
//! sample size, a single lucky match against a common English quadgram (e.g.
//! "TION") swings the average enough to reach deep into the range genuine
//! English occupies — measured directly: a 40,000,000-trial Monte Carlo of
//! uniform-random 112-byte strings found samples scoring as high as **-4.68**
//! before this gate existed, comfortably above genuine 10%-corrupted English
//! (worst observed floor -5.17 over 200,000 corruption trials). That was
//! [the defect](https://en.wikipedia.org/wiki/False_positive) reported against
//! `english-quadgram` in production: an opaque 112-byte candidate scored
//! -5.3085 and passed.
//!
//! The fix is not just a higher threshold (see `ENGLISH_QUADGRAM_THRESHOLD`'s
//! docs for why raising it alone cannot fully separate the two
//! distributions at this length) — it is refusing to trust the average at
//! all below [`MIN_SCORED_LETTERS`] letters, the same way a printable-ratio
//! oracle would be meaningless on a 3-byte candidate. With the gate in place,
//! the same 40,000,000-trial Monte Carlo (restricted to the ~6% of samples
//! that still clear 30 letters by chance) never exceeded -5.39.

use crate::quadgram_data::{QUADGRAM_COUNTS, QUADGRAM_TOTAL};

/// Minimum number of stripped letters required before a quadgram average is
/// trusted at all. Below this, `passed` is forced false regardless of score —
/// see the module docs for the Monte Carlo evidence this is load-bearing, not
/// a formality. All four known Giant plaintexts clear this by a wide margin
/// (40-54 letters each); genuine English of the register this oracle targets
/// always will.
pub(crate) const MIN_SCORED_LETTERS: usize = 30;

/// Number of ASCII letters `bytes` would contribute to a quadgram score, i.e.
/// the length of [`quadgram_score`]'s internal `letters` buffer without
/// building it. Used by the oracle to apply [`MIN_SCORED_LETTERS`].
pub(crate) fn letter_count(bytes: &[u8]) -> usize {
    bytes.iter().filter(|b| b.is_ascii_alphabetic()).count()
}

/// Floor probability assigned to a quadgram absent from the table.
fn floor_probability() -> f64 {
    0.01 / QUADGRAM_TOTAL as f64
}

fn quadgram_log10_prob(quad: [u8; 4]) -> f64 {
    let key = std::str::from_utf8(&quad).expect("quad is always 4 ASCII uppercase letters");
    match QUADGRAM_COUNTS.binary_search_by(|(k, _)| (*k).cmp(key)) {
        Ok(i) => (QUADGRAM_COUNTS[i].1 as f64 / QUADGRAM_TOTAL as f64).log10(),
        Err(_) => floor_probability().log10(),
    }
}

/// Score assigned to a candidate with fewer than 4 letters after stripping —
/// there is no quadgram signal to measure, so it is scored as though it were
/// entirely unseen quadgrams, i.e. no better than the noise floor.
pub(crate) fn insufficient_letters_score() -> f64 {
    floor_probability().log10()
}

/// Uppercase, strip non-letters, and score by average quadgram log10
/// probability. Higher (less negative) is more English-like, matching the
/// existing convention that `score >= threshold` means "passed".
pub fn quadgram_score(bytes: &[u8]) -> f64 {
    let letters: Vec<u8> = bytes
        .iter()
        .filter(|b| b.is_ascii_alphabetic())
        .map(|b| b.to_ascii_uppercase())
        .collect();
    if letters.len() < 4 {
        return insufficient_letters_score();
    }
    let n = letters.len() - 3;
    let sum: f64 = letters
        .windows(4)
        .map(|w| quadgram_log10_prob([w[0], w[1], w[2], w[3]]))
        .sum();
    sum / n as f64
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn known_giant_plaintexts_score_far_above_noise() {
        let known = [
            "The mountain must be searched for the frozen one.",
            "In the cell below the waves is where honor suffers.",
            "When finished we will return to the house and the infinite",
            "A city of fire surrounds the warrior the last of his kind",
        ];
        for pt in known {
            let s = quadgram_score(pt.as_bytes());
            assert!(s > -4.0, "{pt:?} scored {s}, expected > -4.0");
        }
    }

    #[test]
    fn table_lookup_matches_linear_scan() {
        // Binary search must agree with a naive scan; guards against the table
        // silently drifting out of sorted order after a future regeneration.
        for w in QUADGRAM_COUNTS.windows(2) {
            assert!(w[0].0 < w[1].0, "table not sorted at {:?}/{:?}", w[0], w[1]);
        }
    }

    #[test]
    fn short_input_hits_the_floor_not_a_panic() {
        assert_eq!(quadgram_score(b"ab"), insufficient_letters_score());
        assert_eq!(quadgram_score(b""), insufficient_letters_score());
    }

    #[test]
    fn unseen_quadgram_uses_the_floor_not_zero() {
        // "QQQQ" should not appear in an English corpus.
        let s = quadgram_log10_prob(*b"QQQQ");
        assert!((s - floor_probability().log10()).abs() < 1e-12);
    }
}
