//! Key-derivation policies.
//!
//! The tools4noobs front end accepted an arbitrary-length key ("Zombies", 7 bytes)
//! for algorithms with fixed key sizes, so *something* extended it. A different
//! policy sweeps a different space, so this matters a great deal.
//!
//! # Resolved: the authentic policy is [`KeyDerivation::NullPadNextSupported`]
//!
//! Established empirically, not assumed. rev9's Twofish layer recovers its known
//! plaintext ("My love we are now flowing among the stars...") **only** when the
//! 7-byte passphrase is null-padded to 16 — the smallest key size Twofish supports.
//! Padding to Twofish's *maximum* of 32 produces noise. rev10's SAFER+ layer
//! corroborates this independently: it recovers its known plaintext only at the
//! same 16-byte null-padded key.
//!
//! This matters beyond bookkeeping: the dossier's own reference tool
//! (`reference/py/mcrypt_node.py`) pads to `mcrypt_enc_get_key_size`, which returns
//! the **maximum**. Any sweep built on it therefore used the wrong key for every
//! multi-key-size primitive — Twofish, Serpent, Loki97, Saferplus and Rijndael-256 —
//! and would have missed the answer while reporting the space as covered. That is
//! precisely the silent-void failure the coverage papers warn about, sitting inside
//! the reference implementation.
//!
//! # One primitive where the distinction is degenerate
//!
//! LOKI97 is immune to the choice between the two null-padding policies: libmcrypt's
//! `loki97.c` runs the 256-bit key schedule for every key size and reads a buffer
//! `internal_init_mcrypt` allocated with `mxcalloc(1, 32)`, so padding to 16 and
//! padding to 32 arrive at the same key. rev5's Loki97 layer therefore corroborates
//! nothing about this dimension, and must not be cited as if it did. See
//! [`crate::loki97`].
//!
//! All four raw-byte policies are retained as an enumerable coverage dimension,
//! because "confirmed for Twofish and Serpent" is not "confirmed for every
//! primitive", and a claim should be able to state which policy it actually swept.
//!
//! # A fifth family: hash-derived key material
//!
//! Every policy above assumes the passphrase itself is the byte string mcrypt's key
//! schedule absorbs. A large share of browser and PHP crypto front ends hash the
//! passphrase first instead — `key = md5($pass)`, sometimes as the raw digest,
//! sometimes as the *hex string* of the digest fed back in as if it were the
//! passphrase, and OpenSSL-derived wrappers (`openssl_encrypt`, many JS libraries)
//! commonly use `EVP_BytesToKey` instead of hashing directly. [`KeyDerivation::Md5`]
//! and its siblings hash the passphrase first and then apply exactly the
//! [`KeyDerivation::NullPadNextSupported`] adaptation to the result — the
//! corpus-confirmed padding policy — so a 32-byte SHA-256 digest still gets cut
//! down to whatever size the target primitive actually supports, smallest first.
//! See [`KeyDerivation::material`] and [`KeyDerivation::pad_policy`].
//!
//! Sources for the hash functions themselves: RustCrypto's `md-5`, `sha1`, `sha2`
//! crates, each pinned to a `digest 0.10`-compatible version so they share one
//! `Digest` import with no version-skew wrapper (contrast the `cipher` situation
//! documented in the workspace root `Cargo.toml`). `EVP_BytesToKey` is OpenSSL's own
//! KDF (`crypto/evp/evp_key.c`): `D_1 = H(password)`, `D_i = H(D_{i-1} || password)`
//! for `i > 1` (no salt, matching `openssl enc -k <pass> -nosalt`, which is what a
//! web tool that never asks for a salt is doing), concatenated and truncated to the
//! requested length.

use std::fmt;

use md5::Md5;
use serde::{Deserialize, Serialize};
use sha1::Sha1;
use sha2::{Digest, Sha256};

use crate::prim::PrimInfo;

#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum KeyDerivation {
    /// Pass the key at its natural length. This is what PHP's `mcrypt_encrypt`
    /// does when the key is within the algorithm's maximum: it copies `key_len`
    /// bytes and lets libmcrypt's key schedule absorb a short key. Algorithms with
    /// a fixed key size may reject it.
    Natural,
    /// Null-pad to the algorithm's maximum key size. This is what the dossier's
    /// `mcrypt_node.py` does, because it pads to `mcrypt_enc_get_key_size`, which
    /// returns the *maximum*.
    NullPadMax,
    /// Null-pad to the smallest key size the algorithm actually supports. Commonly
    /// cited as the PHP behaviour, and distinct from [`Self::NullPadMax`] for any
    /// algorithm with more than one supported size (Twofish: 16/24/32).
    NullPadNextSupported,
    /// Repeat the key until it fills the maximum key size.
    RepeatPadMax,
    /// `key = MD5(passphrase)`, raw digest bytes, then [`Self::NullPadNextSupported`].
    Md5,
    /// `key = SHA1(passphrase)`, raw digest bytes, then [`Self::NullPadNextSupported`].
    Sha1,
    /// `key = SHA256(passphrase)`, raw digest bytes, then [`Self::NullPadNextSupported`].
    Sha256,
    /// `key = lowercase_hex(MD5(passphrase))`, i.e. the digest rendered as a 32-byte
    /// ASCII hex string and *that* string's bytes fed to the key schedule — the
    /// common web-tool bug/feature of never decoding the hex back to raw bytes.
    Md5HexLower,
    /// As [`Self::Md5HexLower`], with the hex string uppercased.
    Md5HexUpper,
    Sha1HexLower,
    Sha1HexUpper,
    Sha256HexLower,
    Sha256HexUpper,
    /// OpenSSL's `EVP_BytesToKey`, MD5-based, unsalted — derives exactly
    /// `info.max_key_size` bytes directly, so no further [`Self::pad_policy`]
    /// adaptation applies (see the early return in [`Self::derive`]).
    EvpMd5,
    /// As [`Self::EvpMd5`], with SHA-256 as the underlying digest
    /// (`openssl enc -k <pass> -nosalt -md sha256`).
    EvpSha256,
}

impl KeyDerivation {
    pub const ALL: [KeyDerivation; 15] = [
        KeyDerivation::Natural,
        KeyDerivation::NullPadMax,
        KeyDerivation::NullPadNextSupported,
        KeyDerivation::RepeatPadMax,
        KeyDerivation::Md5,
        KeyDerivation::Sha1,
        KeyDerivation::Sha256,
        KeyDerivation::Md5HexLower,
        KeyDerivation::Md5HexUpper,
        KeyDerivation::Sha1HexLower,
        KeyDerivation::Sha1HexUpper,
        KeyDerivation::Sha256HexLower,
        KeyDerivation::Sha256HexUpper,
        KeyDerivation::EvpMd5,
        KeyDerivation::EvpSha256,
    ];

    pub fn as_str(self) -> &'static str {
        match self {
            KeyDerivation::Natural => "natural",
            KeyDerivation::NullPadMax => "null-pad-max",
            KeyDerivation::NullPadNextSupported => "null-pad-next-supported",
            KeyDerivation::RepeatPadMax => "repeat-pad-max",
            KeyDerivation::Md5 => "md5",
            KeyDerivation::Sha1 => "sha1",
            KeyDerivation::Sha256 => "sha256",
            KeyDerivation::Md5HexLower => "md5-hex",
            KeyDerivation::Md5HexUpper => "md5-hex-upper",
            KeyDerivation::Sha1HexLower => "sha1-hex",
            KeyDerivation::Sha1HexUpper => "sha1-hex-upper",
            KeyDerivation::Sha256HexLower => "sha256-hex",
            KeyDerivation::Sha256HexUpper => "sha256-hex-upper",
            KeyDerivation::EvpMd5 => "evp-md5",
            KeyDerivation::EvpSha256 => "evp-sha256",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        // the short aliases match the dossier's `kd` coverage dimension
        match s {
            "natural" => Some(KeyDerivation::Natural),
            "null-pad-max" | "nullpad" | "nullpadmax" => Some(KeyDerivation::NullPadMax),
            "null-pad-next-supported" | "nullpadnext" => Some(KeyDerivation::NullPadNextSupported),
            "repeat-pad-max" | "repeatpad" | "repeatpadmax" => Some(KeyDerivation::RepeatPadMax),
            "md5" => Some(KeyDerivation::Md5),
            "sha1" => Some(KeyDerivation::Sha1),
            "sha256" => Some(KeyDerivation::Sha256),
            "md5-hex" | "md5hex" => Some(KeyDerivation::Md5HexLower),
            "md5-hex-upper" | "md5hexupper" => Some(KeyDerivation::Md5HexUpper),
            "evp-md5" | "evpmd5" | "evp" | "evp-bytes-to-key" => Some(KeyDerivation::EvpMd5),
            "evp-sha256" | "evpsha256" => Some(KeyDerivation::EvpSha256),
            "sha1-hex" | "sha1hex" => Some(KeyDerivation::Sha1HexLower),
            "sha1-hex-upper" | "sha1hexupper" => Some(KeyDerivation::Sha1HexUpper),
            "sha256-hex" | "sha256hex" => Some(KeyDerivation::Sha256HexLower),
            "sha256-hex-upper" | "sha256hexupper" => Some(KeyDerivation::Sha256HexUpper),
            _ => None,
        }
    }

    /// The raw-byte policies pass the passphrase through unchanged; the hash-derived
    /// policies replace it with a digest, or the hex-encoded *text* of a digest
    /// (`Self::material`'s output *is* the key-schedule input's raw material, before
    /// key-size adaptation).
    fn material(self, passphrase: &[u8]) -> Vec<u8> {
        match self {
            KeyDerivation::Natural
            | KeyDerivation::NullPadMax
            | KeyDerivation::NullPadNextSupported
            | KeyDerivation::RepeatPadMax => passphrase.to_vec(),
            KeyDerivation::Md5 => Md5::digest(passphrase).to_vec(),
            KeyDerivation::Sha1 => Sha1::digest(passphrase).to_vec(),
            KeyDerivation::Sha256 => Sha256::digest(passphrase).to_vec(),
            KeyDerivation::Md5HexLower => hex::encode(Md5::digest(passphrase)).into_bytes(),
            KeyDerivation::Md5HexUpper => hex::encode_upper(Md5::digest(passphrase)).into_bytes(),
            KeyDerivation::Sha1HexLower => hex::encode(Sha1::digest(passphrase)).into_bytes(),
            KeyDerivation::Sha1HexUpper => hex::encode_upper(Sha1::digest(passphrase)).into_bytes(),
            KeyDerivation::Sha256HexLower => hex::encode(Sha256::digest(passphrase)).into_bytes(),
            KeyDerivation::Sha256HexUpper => {
                hex::encode_upper(Sha256::digest(passphrase)).into_bytes()
            }
            // `derive` returns before calling `material` for either EVP variant —
            // they compute their own, `info`-dependent material directly.
            KeyDerivation::EvpMd5 | KeyDerivation::EvpSha256 => {
                unreachable!("derive() must not route EVP variants through material()")
            }
        }
    }

    /// Which of the four raw-byte adaptation policies applies to this variant's
    /// [`Self::material`] once it is computed. Every hash-derived variant uses
    /// [`Self::NullPadNextSupported`] — the corpus-confirmed policy — rather than
    /// multiplying out all four against every hash, which would claim coverage this
    /// engine has no corpus evidence for.
    fn pad_policy(self) -> KeyDerivation {
        match self {
            KeyDerivation::Natural
            | KeyDerivation::NullPadMax
            | KeyDerivation::NullPadNextSupported
            | KeyDerivation::RepeatPadMax => self,
            KeyDerivation::Md5
            | KeyDerivation::Sha1
            | KeyDerivation::Sha256
            | KeyDerivation::Md5HexLower
            | KeyDerivation::Md5HexUpper
            | KeyDerivation::Sha1HexLower
            | KeyDerivation::Sha1HexUpper
            | KeyDerivation::Sha256HexLower
            | KeyDerivation::Sha256HexUpper => KeyDerivation::NullPadNextSupported,
            KeyDerivation::EvpMd5 | KeyDerivation::EvpSha256 => {
                unreachable!("derive() must not route EVP variants through pad_policy()")
            }
        }
    }

    /// Produce the byte string actually handed to the key schedule.
    pub fn derive(self, key: &[u8], info: &PrimInfo) -> Vec<u8> {
        // EVP_BytesToKey derives exactly the number of bytes asked of it, the same
        // way OpenSSL derives exactly enough key material for the cipher it was
        // told to target; there is nothing left for `pad_policy` to adapt
        // afterwards, so this returns directly rather than flowing into the
        // material/pad_policy split the other ten variants share.
        match self {
            KeyDerivation::EvpMd5 => return evp_bytes_to_key::<Md5>(key, info.max_key_size),
            KeyDerivation::EvpSha256 => return evp_bytes_to_key::<Sha256>(key, info.max_key_size),
            _ => {}
        }
        let material = self.material(key);
        let max = info.max_key_size;
        if material.is_empty() {
            return vec![0u8; max];
        }
        if material.len() >= max {
            return material[..max].to_vec();
        }
        match self.pad_policy() {
            KeyDerivation::Natural => material,
            KeyDerivation::NullPadMax => pad_null(&material, max),
            KeyDerivation::NullPadNextSupported => {
                // An empty list means every length up to the maximum is supported
                // (RC2, RC4, Blowfish), so the natural length already *is* the next
                // supported size and padding would corrupt the key schedule.
                if info.supported_key_sizes.is_empty() {
                    return material;
                }
                let target = info
                    .supported_key_sizes
                    .iter()
                    .copied()
                    .find(|&s| s >= material.len())
                    .unwrap_or(max);
                pad_null(&material, target)
            }
            KeyDerivation::RepeatPadMax => {
                let mut out = Vec::with_capacity(max);
                while out.len() < max {
                    let take = (max - out.len()).min(material.len());
                    out.extend_from_slice(&material[..take]);
                }
                out
            }
            // `pad_policy` only ever returns one of the four raw-byte variants above.
            hash_derived => unreachable!("pad_policy() returned {hash_derived:?}"),
        }
    }
}

fn pad_null(key: &[u8], target: usize) -> Vec<u8> {
    let mut out = key.to_vec();
    out.resize(target.max(key.len()), 0);
    out
}

/// OpenSSL's `EVP_BytesToKey`, unsalted: `D_1 = H(password)`,
/// `D_i = H(D_{i-1} || password)`, output = `D_1 || D_2 || ...` truncated to `len`
/// bytes. Matches `openssl enc -k <password> -nosalt -md <md5|sha256>`.
fn evp_bytes_to_key<D: Digest + Clone>(password: &[u8], len: usize) -> Vec<u8> {
    let mut out = Vec::with_capacity(len + <D as Digest>::output_size());
    let mut prev: Vec<u8> = Vec::new();
    while out.len() < len {
        let mut hasher = D::new();
        hasher.update(&prev);
        hasher.update(password);
        prev = hasher.finalize().to_vec();
        out.extend_from_slice(&prev);
    }
    out.truncate(len);
    out
}

impl fmt::Display for KeyDerivation {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::prim::prim_info;

    #[test]
    fn policies_differ_for_multi_key_size_algorithms() {
        // Twofish supports 16/24/32, so next-supported (16) != max (32).
        let tf = prim_info("twofish").unwrap();
        let k = b"Zombies";
        assert_eq!(KeyDerivation::Natural.derive(k, tf).len(), 7);
        assert_eq!(KeyDerivation::NullPadMax.derive(k, tf).len(), 32);
        assert_eq!(KeyDerivation::NullPadNextSupported.derive(k, tf).len(), 16);
        assert_eq!(KeyDerivation::RepeatPadMax.derive(k, tf).len(), 32);

        assert_eq!(
            KeyDerivation::NullPadMax.derive(k, tf)[..8],
            *b"Zombies\x00"
        );
        assert_eq!(
            KeyDerivation::RepeatPadMax.derive(k, tf)[..9],
            *b"ZombiesZo"
        );
    }

    /// DES has exactly one key size, which collapses the two null-padding policies
    /// onto each other. Repeat-padding still differs, even here: a 7-byte key in an
    /// 8-byte slot becomes `Zombies\0` under null-pad but `ZombiesZ` under
    /// repeat-pad. So a fixed key size narrows the key-derivation question to two
    /// candidates rather than eliminating it.
    #[test]
    fn fixed_key_size_collapses_null_padding_but_not_repeat_padding() {
        let des = prim_info("des").unwrap();
        let d: Vec<Vec<u8>> = KeyDerivation::ALL
            .iter()
            .map(|p| p.derive(b"Zombies", des))
            .collect();

        assert_eq!(d[1], b"Zombies\x00".to_vec(), "null-pad-max");
        assert_eq!(d[1], d[2], "both null-padding policies must agree");
        assert_eq!(d[3], b"ZombiesZ".to_vec(), "repeat-pad-max still differs");
        assert_ne!(d[1], d[3]);
        assert_eq!(d[0].len(), 7, "natural length is unpadded");
    }

    /// The corpus-confirmed derivation for rev9's DES layer. `probe`-verified:
    /// this key with CFB-8 and the ASCII-zero IV yields the whitespace-separated
    /// decimal groups that rev9's next documented step consumes.
    #[test]
    fn rev9_des_key_is_null_padded() {
        let des = prim_info("des").unwrap();
        assert_eq!(
            KeyDerivation::NullPadMax.derive(b"Zombies", des),
            b"Zombies\x00".to_vec()
        );
    }

    #[test]
    fn oversized_keys_are_truncated_to_max() {
        let des = prim_info("des").unwrap();
        assert_eq!(
            KeyDerivation::NullPadMax.derive(b"0123456789", des),
            b"01234567".to_vec()
        );
    }

    /// **Regression.** RC2, RC4 and Blowfish accept any key length, encoded here as
    /// an empty `supported_key_sizes`. Treating "no discrete sizes" as "fall back to
    /// the maximum" padded a 7-byte key out to 128 or 256 bytes and destroyed the key
    /// schedule — RC4 then failed to reproduce rev10 even though the implementation
    /// was correct. For these primitives the natural length already *is* the next
    /// supported size.
    #[test]
    fn any_length_primitives_are_not_padded() {
        for name in ["rc2", "arcfour", "blowfish"] {
            let info = prim_info(name).unwrap();
            assert!(
                info.supported_key_sizes.is_empty(),
                "{name} should accept any key length"
            );
            let derived = KeyDerivation::NullPadNextSupported.derive(b"Zombies", info);
            assert_eq!(
                derived,
                b"Zombies".to_vec(),
                "{name} key must not be padded under next-supported"
            );
        }
    }

    /// The corpus-confirmed policy for a multi-key-size primitive: rev9's Twofish
    /// layer recovers its plaintext at 16 bytes and produces noise at 32.
    #[test]
    fn rev9_twofish_key_is_padded_to_the_smallest_supported_size() {
        let tf = prim_info("twofish").unwrap();
        let derived = KeyDerivation::NullPadNextSupported.derive(b"Zombies", tf);
        assert_eq!(derived.len(), 16);
        assert_eq!(derived, b"Zombies\0\0\0\0\0\0\0\0\0".to_vec());
        // and the policy the reference implementation used, which does not work
        assert_eq!(KeyDerivation::NullPadMax.derive(b"Zombies", tf).len(), 32);
    }

    #[test]
    fn parse_accepts_dossier_aliases() {
        assert_eq!(
            KeyDerivation::parse("nullpad"),
            Some(KeyDerivation::NullPadMax)
        );
        assert_eq!(
            KeyDerivation::parse("repeatpad"),
            Some(KeyDerivation::RepeatPadMax)
        );
        assert!(KeyDerivation::parse("nonsense").is_none());
    }

    // -----------------------------------------------------------------------
    // Hash-derived family, stage 1: raw digest bytes.
    // -----------------------------------------------------------------------

    /// RFC 1321 test vector: `MD5("abc")`.
    #[test]
    fn md5_matches_rfc1321() {
        let want = hex::decode("900150983cd24fb0d6963f7d28e17f72").unwrap();
        assert_eq!(Md5::digest(b"abc").to_vec(), want);
    }

    /// FIPS 180-4 test vector: `SHA-1("abc")`.
    #[test]
    fn sha1_matches_fips180() {
        let want = hex::decode("a9993e364706816aba3e25717850c26c9cd0d89d").unwrap();
        assert_eq!(Sha1::digest(b"abc").to_vec(), want);
    }

    /// FIPS 180-4 test vector: `SHA-256("abc")`.
    #[test]
    fn sha256_matches_fips180() {
        let want = hex::decode("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
            .unwrap();
        assert_eq!(Sha256::digest(b"abc").to_vec(), want);
    }

    /// `parse` accepts the three raw-digest `--kd` names, and each actually changes
    /// the key material relative to the raw passphrase.
    #[test]
    fn hash_derived_policies_parse_and_change_the_key() {
        let des = prim_info("des").unwrap();
        let raw = KeyDerivation::NullPadMax.derive(b"Zombies", des);
        for (name, variant) in [
            ("md5", KeyDerivation::Md5),
            ("sha1", KeyDerivation::Sha1),
            ("sha256", KeyDerivation::Sha256),
        ] {
            assert_eq!(KeyDerivation::parse(name), Some(variant));
            let derived = variant.derive(b"Zombies", des);
            assert_ne!(
                derived, raw,
                "{name} must not equal the raw-byte derivation"
            );
            assert_eq!(derived.len(), 8, "{name}: DES has one supported key size");
        }
    }

    /// The digest is computed over the passphrase, then adapted to the target
    /// primitive's smallest supported key size exactly as `NullPadNextSupported`
    /// would adapt a raw passphrase — MD5's 16-byte digest already fits Twofish's
    /// smallest size (16) with no padding, while a fixed-size primitive like DES
    /// truncates it to 8.
    #[test]
    fn hash_material_is_adapted_with_null_pad_next_supported() {
        let twofish = prim_info("twofish").unwrap();
        let des = prim_info("des").unwrap();
        let md5_full = Md5::digest(b"Zombies").to_vec();
        assert_eq!(md5_full.len(), 16);

        let via_twofish = KeyDerivation::Md5.derive(b"Zombies", twofish);
        assert_eq!(
            via_twofish, md5_full,
            "16-byte digest fits Twofish's smallest size exactly"
        );

        let via_des = KeyDerivation::Md5.derive(b"Zombies", des);
        assert_eq!(
            via_des,
            md5_full[..8].to_vec(),
            "DES truncates to its one size, 8"
        );
    }

    /// SHA-256's 32-byte digest exceeds DES's 8-byte maximum, exercising the
    /// truncate-to-max guard at the top of `derive` rather than the padding match.
    #[test]
    fn oversized_digest_is_truncated_to_the_primitives_maximum() {
        let des = prim_info("des").unwrap();
        let full = Sha256::digest(b"Zombies").to_vec();
        assert_eq!(
            KeyDerivation::Sha256.derive(b"Zombies", des),
            full[..8].to_vec()
        );
    }

    // -----------------------------------------------------------------------
    // Hash-derived family, stage 2: hex-string forms.
    // -----------------------------------------------------------------------

    /// Every `-hex`/`-hex-upper` name parses, and the material is genuinely the hex
    /// *text* of the digest (twice as long as the raw digest, ASCII-only), not the
    /// digest itself.
    #[test]
    fn hex_variants_parse_and_produce_hex_text() {
        let cases = [
            ("md5-hex", KeyDerivation::Md5HexLower, 16),
            ("md5-hex-upper", KeyDerivation::Md5HexUpper, 16),
            ("sha1-hex", KeyDerivation::Sha1HexLower, 20),
            ("sha1-hex-upper", KeyDerivation::Sha1HexUpper, 20),
            ("sha256-hex", KeyDerivation::Sha256HexLower, 32),
            ("sha256-hex-upper", KeyDerivation::Sha256HexUpper, 32),
        ];
        // Rijndael-256 accepts a 32-byte key outright, so even the longest hex string
        // (SHA-256, 64 ASCII chars) is visible before the max-size truncation guard
        // trims it — the right primitive to see the untruncated material on.
        let rijndael256 = prim_info("rijndael-256").unwrap();
        for (name, variant, digest_len) in cases {
            assert_eq!(KeyDerivation::parse(name), Some(variant), "{name}");
            let material = variant.material(b"Zombies");
            assert_eq!(
                material.len(),
                digest_len * 2,
                "{name}: hex text is 2x the digest"
            );
            assert!(material.is_ascii(), "{name}: hex text must be ASCII");
            let derived = variant.derive(b"Zombies", rijndael256);
            assert_eq!(derived.len(), 32.min(digest_len * 2), "{name}");
        }
    }

    /// The lowercase and uppercase forms of the same hash are different key material
    /// — ASCII case differs byte for byte — so they are genuinely distinct sweep
    /// points, not aliases of each other.
    #[test]
    fn hex_case_variants_differ() {
        let info = prim_info("rijndael-256").unwrap();
        let lower = KeyDerivation::Sha256HexLower.derive(b"Zombies", info);
        let upper = KeyDerivation::Sha256HexUpper.derive(b"Zombies", info);
        assert_ne!(lower, upper);
        assert_eq!(
            String::from_utf8(lower.clone())
                .unwrap()
                .to_ascii_uppercase(),
            String::from_utf8(upper.clone()).unwrap()
        );
    }

    /// The hex string is exactly `hex::encode`/`hex::encode_upper` of the same digest
    /// the raw-digest variant produces, cross-checking `Self::material` against the
    /// published vectors pinned above rather than against itself.
    #[test]
    fn hex_material_matches_hex_encoding_of_the_published_vectors() {
        let md5_abc = hex::decode("900150983cd24fb0d6963f7d28e17f72").unwrap();
        assert_eq!(
            KeyDerivation::Md5HexLower.material(b"abc"),
            hex::encode(&md5_abc).into_bytes()
        );
        assert_eq!(
            KeyDerivation::Md5HexUpper.material(b"abc"),
            hex::encode_upper(&md5_abc).into_bytes()
        );
    }

    // -----------------------------------------------------------------------
    // Hash-derived family, stage 3: EVP_BytesToKey (MD5- and SHA-256-based).
    // -----------------------------------------------------------------------

    /// `openssl enc -aes-256-cbc -k password -P -nosalt -md md5` prints
    /// `key=5F4DCC3B5AA765D61D8327DEB882CF992B95990A9151374ABD8FF8C5A7A0FE08`
    /// (32 bytes: two MD5 rounds, since one MD5 round is only 16), run against this
    /// session's OpenSSL (LibreSSL 3.3.6) as the independent cross-check for the
    /// documented `EVP_BytesToKey` algorithm.
    #[test]
    fn evp_md5_matches_openssl_nosalt_two_round_case() {
        let got = evp_bytes_to_key::<Md5>(b"password", 32);
        let want = hex::decode("5f4dcc3b5aa765d61d8327deb882cf992b95990a9151374abd8ff8c5a7a0fe08")
            .unwrap();
        assert_eq!(got, want);
    }

    /// The 16-byte case is a single MD5 round, and `MD5("password")` is a famous
    /// enough vector to state from memory and still check independently: it is the
    /// leading half of the 32-byte vector above.
    #[test]
    fn evp_md5_one_round_is_a_bare_md5() {
        let got = evp_bytes_to_key::<Md5>(b"password", 16);
        assert_eq!(got, Md5::digest(b"password").to_vec());
    }

    /// `openssl enc -aes-256-cbc -k Zombies -P -nosalt -md md5` prints
    /// `key=3655BF74DA567FF2FEF53D200B67B8A7025AD9D76AEB95E4D19841CDDFB03840`
    /// (32 bytes) and `openssl enc -des-ecb -k Zombies -P -nosalt -md md5` prints
    /// `key=3655BF74DA567FF2` (8 bytes) — the corpus passphrase, cross-checked at
    /// both a two-round length and a single-round truncation, reached through the
    /// registered `KeyDerivation::EvpMd5` exactly as `--kd evp-md5` would use it.
    #[test]
    fn evp_md5_matches_openssl_for_the_corpus_passphrase() {
        let rijndael256 = prim_info("rijndael-256").unwrap();
        let des = prim_info("des").unwrap();
        assert_eq!(
            KeyDerivation::EvpMd5.derive(b"Zombies", rijndael256),
            hex::decode("3655bf74da567ff2fef53d200b67b8a7025ad9d76aeb95e4d19841cddfb03840")
                .unwrap()
        );
        assert_eq!(
            KeyDerivation::EvpMd5.derive(b"Zombies", des),
            hex::decode("3655bf74da567ff2").unwrap()
        );
    }

    /// `openssl enc -aes-256-cbc -k Zombies -P -nosalt -md sha256` prints
    /// `key=F0DD1D97E8328693FC332A6477757CF2B03C70C16F85EDC9B34D74221ECAF809`.
    /// SHA-256's 32-byte output covers every key size this engine has (max 32), so
    /// this is always a single round in practice — `EVP_BytesToKey` with SHA-256 at
    /// 32 bytes degenerates to a bare `SHA256(passphrase)`, which is itself the
    /// FIPS-180 vector pinned above applied to a different input.
    #[test]
    fn evp_sha256_matches_openssl_and_is_a_bare_sha256_at_32_bytes() {
        let rijndael256 = prim_info("rijndael-256").unwrap();
        let want = hex::decode("f0dd1d97e8328693fc332a6477757cf2b03c70c16f85edc9b34d74221ecaf809")
            .unwrap();
        assert_eq!(
            KeyDerivation::EvpSha256.derive(b"Zombies", rijndael256),
            want
        );
        assert_eq!(want, Sha256::digest(b"Zombies").to_vec());
    }

    /// `EVP_BytesToKey` targets the primitive's own maximum key size, mirroring what
    /// OpenSSL does when asked to derive a key for a specific cipher configuration —
    /// there is no shorter "next supported size" concept for a KDF that derives
    /// exactly as many bytes as it is asked for.
    #[test]
    fn evp_targets_the_primitives_max_key_size() {
        let des = prim_info("des").unwrap();
        let twofish = prim_info("twofish").unwrap();
        assert_eq!(KeyDerivation::EvpMd5.derive(b"Zombies", des).len(), 8);
        assert_eq!(KeyDerivation::EvpMd5.derive(b"Zombies", twofish).len(), 32);
        assert_eq!(
            KeyDerivation::EvpSha256.derive(b"Zombies", twofish).len(),
            32
        );
    }

    #[test]
    fn evp_variants_parse() {
        assert_eq!(KeyDerivation::parse("evp-md5"), Some(KeyDerivation::EvpMd5));
        assert_eq!(
            KeyDerivation::parse("evp-sha256"),
            Some(KeyDerivation::EvpSha256)
        );
    }

    /// The full, final vocabulary: all fifteen policies parse and round-trip through
    /// `as_str`, and `ALL` names every one of them exactly once.
    #[test]
    fn all_fifteen_policies_parse_and_round_trip() {
        assert_eq!(KeyDerivation::ALL.len(), 15);
        let mut seen = std::collections::HashSet::new();
        for kd in KeyDerivation::ALL {
            assert_eq!(
                KeyDerivation::parse(kd.as_str()),
                Some(kd),
                "{}",
                kd.as_str()
            );
            assert!(seen.insert(kd), "duplicate in ALL: {}", kd.as_str());
        }
    }
}
