//! AMSCO, Cadenus, Redefence, Swagman, CM Bifid, Grandpré, Syllabary, Numbered Key.
//!
//! # Why these nodes exist
//!
//! The first four complete the ACA transposition family. They matter less for solving
//! than for *excluding*: a transposition cannot change letter frequencies, so a single
//! chi-squared test rules out every one of them at once when the ciphertext's unigrams
//! are not English. Having them here makes that argument checkable rather than
//! asserted — you can run them and see.
//!
//! The last four emit or consume digits, which is why they were previously
//! unreachable: nothing in the classical set produced a numeric representation from
//! keyed tables.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: transforms at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const A26: &str = "abcdefghijklmnopqrstuvwxyz";

fn letters(data: &[u8]) -> Vec<u8> {
    data.iter()
        .filter(|c| c.is_ascii_alphabetic())
        .map(|c| c.to_ascii_lowercase())
        .collect()
}

/// Column order from a keyword: alphabetical rank, ties broken left to right.
fn key_order(key: &[u8]) -> Vec<usize> {
    let mut ix: Vec<usize> = (0..key.len()).collect();
    ix.sort_by_key(|&i| (key[i], i));
    ix
}

fn keyword(node: &'static str, params: &Params) -> Result<Vec<u8>> {
    let k: Vec<u8> = params
        .req_str(node, "key")?
        .bytes()
        .filter(|b| b.is_ascii_alphabetic())
        .map(|b| b.to_ascii_lowercase())
        .collect();
    if k.is_empty() {
        return Err(Error::bad_param(node, "key", "no ASCII letters in key"));
    }
    Ok(k)
}

fn dir(node: &'static str, params: &Params) -> Result<bool> {
    match params.opt_str("direction").unwrap_or("decrypt") {
        "encrypt" => Ok(true),
        "decrypt" => Ok(false),
        o => Err(Error::bad_param(node, "direction", format!("got {o:?}"))),
    }
}

const KEY_DIR: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "keyword; its alphabetical order is the column order"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

// ---------------------------------------------------------------- AMSCO

const AMSCO: &str = "amsco";

/// AMSCO: a columnar transposition whose cells hold alternately one and two letters.
///
/// The alternation runs across the grid and flips at the start of each row, so cell
/// sizes depend on both the row and the column count. That is the only thing that
/// distinguishes it from plain columnar — and it is enough to defeat a solver that
/// assumes uniform cells.
pub struct Amsco;

/// Cell sizes for an AMSCO grid, row-major.
fn amsco_cells(n: usize, w: usize, start_two: bool) -> Vec<usize> {
    let mut sizes = Vec::new();
    let mut total = 0usize;
    let mut row = 0usize;
    while total < n {
        for c in 0..w {
            if total >= n { break; }
            let two = ((row + c) % 2 == 0) == start_two;
            let s = if two { 2 } else { 1 }.min(n - total);
            sizes.push(s);
            total += s;
        }
        row += 1;
    }
    sizes
}

impl Node for Amsco {
    fn name(&self) -> &'static str { AMSCO }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/amsco(alternating-1-2-cells)" }
    fn params_schema(&self) -> &'static [ParamSpec] {
        const S: &[ParamSpec] = &[
            ParamSpec::req("key", ParamType::Str, "keyword; alphabetical order is the column order"),
            ParamSpec::opt("start_two", ParamType::Bool, "first cell holds two letters (default false)"),
            ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
        ];
        S
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = keyword(AMSCO, params)?;
        let w = key.len();
        let t = letters(&input.data);
        if t.is_empty() {
            return Err(Error::node_failed(AMSCO, "input has no ASCII letters"));
        }
        let start_two = params.opt_bool("start_two", false);
        let sizes = amsco_cells(t.len(), w, start_two);
        let order = key_order(&key);
        let enc = dir(AMSCO, params)?;

        // cell i belongs to column i % w; build per-column cell contents
        if enc {
            let mut cells: Vec<Vec<u8>> = Vec::with_capacity(sizes.len());
            let mut p = 0usize;
            for &s in sizes.iter() {
                cells.push(t[p..p + s].to_vec());
                p += s;
            }
            let mut out = Vec::with_capacity(t.len());
            for &col in order.iter() {
                for (i, c) in cells.iter().enumerate() {
                    if i % w == col {
                        out.extend(c.iter().copied());
                    }
                }
            }
            Ok(Repr::new(out, Display::Bytes))
        } else {
            let mut col_len = vec![0usize; w];
            for (i, &s) in sizes.iter().enumerate() {
                col_len[i % w] += s;
            }
            let mut chunks: Vec<Vec<u8>> = vec![Vec::new(); w];
            let mut p = 0usize;
            for &col in order.iter() {
                chunks[col] = t[p..p + col_len[col]].to_vec();
                p += col_len[col];
            }
            let mut taken = vec![0usize; w];
            let mut out = Vec::with_capacity(t.len());
            for (i, &s) in sizes.iter().enumerate() {
                let col = i % w;
                out.extend(chunks[col][taken[col]..taken[col] + s].iter().copied());
                taken[col] += s;
            }
            Ok(Repr::new(out, Display::Bytes))
        }
    }
}

// ---------------------------------------------------------------- Redefence

const REDEFENCE: &str = "redefence";

/// Redefence: a rail fence whose rails are read out in a key-given order rather than
/// top to bottom.
pub struct Redefence;

fn rail_rows(n: usize, rails: usize) -> Vec<usize> {
    let mut which = Vec::with_capacity(n);
    let (mut r, mut down) = (0usize, true);
    for _ in 0..n {
        which.push(r);
        if rails == 1 {
            continue;
        }
        if down {
            if r + 1 == rails { down = false; r -= 1; } else { r += 1; }
        } else if r == 0 { down = true; r += 1; } else { r -= 1; }
    }
    which
}

impl Node for Redefence {
    fn name(&self) -> &'static str { REDEFENCE }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/redefence(keyed-rail-order)" }
    fn params_schema(&self) -> &'static [ParamSpec] { KEY_DIR }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = keyword(REDEFENCE, params)?;
        let rails = key.len();
        let t = letters(&input.data);
        if t.is_empty() {
            return Err(Error::node_failed(REDEFENCE, "input has no ASCII letters"));
        }
        let which = rail_rows(t.len(), rails);
        let order = key_order(&key);
        let enc = dir(REDEFENCE, params)?;
        if enc {
            let mut out = Vec::with_capacity(t.len());
            for &r in order.iter() {
                for (i, &w) in which.iter().enumerate() {
                    if w == r { out.push(t[i]); }
                }
            }
            Ok(Repr::new(out, Display::Bytes))
        } else {
            let mut counts = vec![0usize; rails];
            for &w in which.iter() { counts[w] += 1; }
            let mut rows: Vec<Vec<u8>> = vec![Vec::new(); rails];
            let mut p = 0usize;
            for &r in order.iter() {
                rows[r] = t[p..p + counts[r]].to_vec();
                p += counts[r];
            }
            let mut taken = vec![0usize; rails];
            let mut out = Vec::with_capacity(t.len());
            for &w in which.iter() {
                out.push(rows[w][taken[w]]);
                taken[w] += 1;
            }
            Ok(Repr::new(out, Display::Bytes))
        }
    }
}

// ---------------------------------------------------------------- Cadenus

const CADENUS: &str = "cadenus";

/// Cadenus: a columnar transposition in which each column is also cyclically rotated
/// by an amount read from a second keyword.
///
/// The block height is the alphabet length (25 classically), so the text length must
/// be a multiple of `key.len() * 25`. Rejecting other lengths is deliberate: padding
/// silently would change the transposition.
pub struct Cadenus;

impl Node for Cadenus {
    fn name(&self) -> &'static str { CADENUS }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/cadenus(columnar+per-column-rotation)" }
    fn params_schema(&self) -> &'static [ParamSpec] {
        const S: &[ParamSpec] = &[
            ParamSpec::req("key", ParamType::Str, "keyword; alphabetical order is the column order"),
            ParamSpec::opt("rotations", ParamType::Str, "keyword giving each column's rotation \
                                                        (default: the same key)"),
            ParamSpec::opt("height", ParamType::Int, "block height (default 25)"),
            ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
        ];
        S
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = keyword(CADENUS, params)?;
        let w = key.len();
        let h = params.opt_i64("height", 25);
        if h < 1 {
            return Err(Error::bad_param(CADENUS, "height", "must be at least 1"));
        }
        let h = h as usize;
        let rot_key: Vec<u8> = match params.opt_str("rotations") {
            Some(s) => s.bytes().filter(|b| b.is_ascii_alphabetic())
                        .map(|b| b.to_ascii_lowercase()).collect(),
            None => key.clone(),
        };
        let t = letters(&input.data);
        if t.is_empty() || t.len() % (w * h) != 0 {
            return Err(Error::node_failed(
                CADENUS,
                format!("length must be a non-zero multiple of key*height = {}", w * h),
            ));
        }
        let order = key_order(&key);
        let rots: Vec<usize> = (0..w)
            .map(|i| (rot_key[i % rot_key.len()] - b'a') as usize % h)
            .collect();
        let enc = dir(CADENUS, params)?;
        let mut out = vec![0u8; t.len()];
        for blk in 0..t.len() / (w * h) {
            let base = blk * w * h;
            if enc {
                // rows -> rotate each column -> read columns in key order
                let mut cols: Vec<Vec<u8>> = vec![Vec::with_capacity(h); w];
                for r in 0..h {
                    for c in 0..w {
                        cols[c].push(t[base + r * w + c]);
                    }
                }
                for c in 0..w { cols[c].rotate_left(rots[c]); }
                let mut p = base;
                for &c in order.iter() {
                    for &ch in cols[c].iter() { out[p] = ch; p += 1; }
                }
            } else {
                let mut cols: Vec<Vec<u8>> = vec![Vec::new(); w];
                let mut p = base;
                for &c in order.iter() {
                    cols[c] = t[p..p + h].to_vec();
                    p += h;
                }
                for c in 0..w { cols[c].rotate_right(rots[c]); }
                for r in 0..h {
                    for c in 0..w {
                        out[base + r * w + c] = cols[c][r];
                    }
                }
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

// ---------------------------------------------------------------- Swagman

const SWAGMAN: &str = "swagman";

/// Swagman: a transposition driven by an n×n Latin square.
///
/// The text is taken in blocks of n², and within each block the letter at row `r`,
/// column `c` moves to the row named by `square[r][c]`. A non-Latin square would make
/// the map non-invertible, so the square is validated rather than trusted.
pub struct Swagman;

impl Node for Swagman {
    fn name(&self) -> &'static str { SWAGMAN }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/swagman(latin-square)" }
    fn params_schema(&self) -> &'static [ParamSpec] {
        const S: &[ParamSpec] = &[
            ParamSpec::req("square", ParamType::Str, "n rows of n digits 1..n, rows separated \
                                                      by commas, e.g. \"123,231,312\""),
            ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
        ];
        S
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let rows: Vec<Vec<usize>> = params
            .req_str(SWAGMAN, "square")?
            .split(',')
            .filter(|s| !s.trim().is_empty())
            .map(|s| s.trim().bytes().filter(|b| b.is_ascii_digit())
                      .map(|b| (b - b'0') as usize).collect())
            .collect();
        let n = rows.len();
        if n == 0 || rows.iter().any(|r| r.len() != n) {
            return Err(Error::bad_param(SWAGMAN, "square", "must be n rows of n digits"));
        }
        for r in rows.iter() {
            let mut s: Vec<usize> = r.clone();
            s.sort_unstable();
            if s != (1..=n).collect::<Vec<usize>>() {
                return Err(Error::bad_param(
                    SWAGMAN,
                    "square",
                    "each row must be a permutation of 1..n (a Latin square), otherwise the \
                     transposition is not invertible",
                ));
            }
        }
        for c in 0..n {
            let mut s: Vec<usize> = (0..n).map(|r| rows[r][c]).collect();
            s.sort_unstable();
            if s != (1..=n).collect::<Vec<usize>>() {
                return Err(Error::bad_param(SWAGMAN, "square", "each column must also be a \
                                                                permutation of 1..n"));
            }
        }
        let t = letters(&input.data);
        if t.is_empty() || t.len() % (n * n) != 0 {
            return Err(Error::node_failed(
                SWAGMAN,
                format!("length must be a non-zero multiple of n^2 = {}", n * n),
            ));
        }
        let enc = dir(SWAGMAN, params)?;
        let mut out = vec![0u8; t.len()];
        for blk in 0..t.len() / (n * n) {
            let base = blk * n * n;
            for r in 0..n {
                for c in 0..n {
                    let dst = (rows[r][c] - 1) * n + c;
                    if enc {
                        out[base + dst] = t[base + r * n + c];
                    } else {
                        out[base + r * n + c] = t[base + dst];
                    }
                }
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

// ---------------------------------------------------------------- CM Bifid

const CMBIFID: &str = "cm_bifid";

/// Conjugated-matrix bifid: bifid whose coordinates are read from one square and
/// written back through a *different* one.
///
/// Two squares means 2 × log2(25!) ≈ 167 bits of key, which exceeds the constraint in
/// any ciphertext under ~52 letters — so this is here to be run, not to be solved.
pub struct CmBifid;

impl Node for CmBifid {
    fn name(&self) -> &'static str { CMBIFID }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/cm_bifid(two-squares)" }
    fn params_schema(&self) -> &'static [ParamSpec] {
        const S: &[ParamSpec] = &[
            ParamSpec::req("key1", ParamType::Str, "square the coordinates are read from"),
            ParamSpec::req("key2", ParamType::Str, "square the result is written through"),
            ParamSpec::opt("period", ParamType::Int, "block length (default 0 = whole text)"),
            ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
        ];
        S
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        const A25: &str = "abcdefghiklmnopqrstuvwxyz";
        let mk = |k: &str| -> Vec<u8> {
            let mut v = Vec::new();
            let mut seen = std::collections::HashSet::new();
            for c in k.bytes().chain(A25.bytes()) {
                let c = c.to_ascii_lowercase();
                let c = if c == b'j' { b'i' } else { c };
                if A25.bytes().any(|m| m == c) && seen.insert(c) { v.push(c); }
            }
            v
        };
        let s1 = mk(params.req_str(CMBIFID, "key1")?);
        let s2 = mk(params.req_str(CMBIFID, "key2")?);
        let t: Vec<u8> = input.data.iter().map(|c| c.to_ascii_lowercase())
            .map(|c| if c == b'j' { b'i' } else { c })
            .filter(|c| A25.bytes().any(|m| m == *c)).collect();
        if t.is_empty() {
            return Err(Error::node_failed(CMBIFID, "no letters from the square"));
        }
        let period = params.opt_i64("period", 0);
        if period < 0 {
            return Err(Error::bad_param(CMBIFID, "period", "must not be negative"));
        }
        let per = if period == 0 { t.len() } else { period as usize };
        let enc = dir(CMBIFID, params)?;
        let mut out = Vec::with_capacity(t.len());
        for blk in t.chunks(per) {
            let n = blk.len();
            if enc {
                let (mut rows, mut cols) = (Vec::new(), Vec::new());
                for &c in blk {
                    let i = s1.iter().position(|&x| x == c).unwrap();
                    rows.push(i / 5); cols.push(i % 5);
                }
                rows.extend(cols);
                for p in rows.chunks_exact(2) { out.push(s2[p[0] * 5 + p[1]]); }
            } else {
                let mut seq = Vec::with_capacity(2 * n);
                for &c in blk {
                    let i = s2.iter().position(|&x| x == c).ok_or_else(|| {
                        Error::node_failed(CMBIFID, format!("'{}' not in square", c as char))
                    })?;
                    seq.push(i / 5); seq.push(i % 5);
                }
                let (rows, cols) = seq.split_at(n);
                for (r, c) in rows.iter().zip(cols.iter()) { out.push(s1[r * 5 + c]); }
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

// ------------------------------------------------- Numbered key / Grandpré / Syllabary

const NUMBERED: &str = "numbered_key";

/// Numbered key: letters are replaced by their 1-based position in a keyed alphabet.
///
/// Output is decimal, so the [`Display`] is set accordingly rather than left as bytes —
/// downstream numeric nodes need to see it as a number stream.
pub struct NumberedKey;

impl Node for NumberedKey {
    fn name(&self) -> &'static str { NUMBERED }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/numbered_key(position-in-keyed-alphabet)" }
    fn params_schema(&self) -> &'static [ParamSpec] {
        const S: &[ParamSpec] = &[
            ParamSpec::req("key", ParamType::Str, "keyword for the alphabet"),
            ParamSpec::opt("separator", ParamType::Str, "between numbers (default \" \")"),
            ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default: numbers->letters) \
                                                        or \"encrypt\""),
        ];
        S
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let mut alpha = Vec::new();
        let mut seen = std::collections::HashSet::new();
        for c in params.req_str(NUMBERED, "key")?.bytes().chain(A26.bytes()) {
            let c = c.to_ascii_lowercase();
            if c.is_ascii_lowercase() && seen.insert(c) { alpha.push(c); }
        }
        let sep = params.opt_str("separator").unwrap_or(" ");
        if dir(NUMBERED, params)? {
            let nums: Vec<String> = letters(&input.data)
                .iter()
                .map(|&c| (alpha.iter().position(|&x| x == c).unwrap() + 1).to_string())
                .collect();
            if nums.is_empty() {
                return Err(Error::node_failed(NUMBERED, "input has no ASCII letters"));
            }
            Ok(Repr::new(nums.join(sep).into_bytes(), Display::Decimal))
        } else {
            let s = String::from_utf8_lossy(&input.data).to_string();
            let mut out = Vec::new();
            for tok in s.split(|c: char| !c.is_ascii_digit()).filter(|t| !t.is_empty()) {
                let v: usize = tok.parse().map_err(|_| {
                    Error::node_failed(NUMBERED, format!("{tok:?} is not a number"))
                })?;
                if v == 0 || v > alpha.len() {
                    return Err(Error::node_failed(
                        NUMBERED,
                        format!("{v} is outside 1..={}", alpha.len()),
                    ));
                }
                out.push(alpha[v - 1]);
            }
            if out.is_empty() {
                return Err(Error::node_failed(NUMBERED, "input has no numbers"));
            }
            Ok(Repr::new(out, Display::Bytes))
        }
    }
}

const GRANDPRE: &str = "grandpre";

/// Grandpré: an 8×8 grid of words; each plaintext letter becomes the coordinates of
/// any cell holding it.
///
/// Encryption is genuinely one-to-many — a letter appearing in several cells has
/// several valid encodings — so this node encrypts using the *first* matching cell and
/// says so, rather than pretending the map is a bijection.
pub struct Grandpre;

impl Node for Grandpre {
    fn name(&self) -> &'static str { GRANDPRE }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/grandpre(word-grid-coordinates)" }
    fn params_schema(&self) -> &'static [ParamSpec] {
        const S: &[ParamSpec] = &[
            ParamSpec::req("grid", ParamType::Str, "comma-separated equal-length words forming \
                                                    a square grid, e.g. 8 words of 8 letters"),
            ParamSpec::opt("separator", ParamType::Str, "between coordinate pairs (default \" \")"),
            ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
        ];
        S
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let words: Vec<Vec<u8>> = params
            .req_str(GRANDPRE, "grid")?
            .split(',')
            .filter(|s| !s.trim().is_empty())
            .map(|s| s.trim().bytes().filter(|b| b.is_ascii_alphabetic())
                      .map(|b| b.to_ascii_lowercase()).collect())
            .collect();
        let n = words.len();
        if n == 0 || words.iter().any(|w| w.len() != n) {
            return Err(Error::bad_param(GRANDPRE, "grid", "need n words of n letters each"));
        }
        let sep = params.opt_str("separator").unwrap_or(" ");
        if dir(GRANDPRE, params)? {
            let mut out = Vec::new();
            for &c in letters(&input.data).iter() {
                let mut found = None;
                'outer: for (r, w) in words.iter().enumerate() {
                    for (k, &x) in w.iter().enumerate() {
                        if x == c { found = Some((r + 1, k + 1)); break 'outer; }
                    }
                }
                let (r, k) = found.ok_or_else(|| {
                    Error::node_failed(GRANDPRE, format!("'{}' is not in the grid", c as char))
                })?;
                out.push(format!("{r}{k}"));
            }
            if out.is_empty() {
                return Err(Error::node_failed(GRANDPRE, "input has no ASCII letters"));
            }
            Ok(Repr::new(out.join(sep).into_bytes(), Display::Decimal))
        } else {
            let digits: Vec<u8> = input.data.iter().filter(|b| b.is_ascii_digit()).copied().collect();
            if digits.is_empty() || digits.len() % 2 != 0 {
                return Err(Error::node_failed(GRANDPRE, "need an even number of digits"));
            }
            let mut out = Vec::new();
            for p in digits.chunks_exact(2) {
                let (r, c) = ((p[0] - b'0') as usize, (p[1] - b'0') as usize);
                if r == 0 || c == 0 || r > n || c > n {
                    return Err(Error::node_failed(GRANDPRE, format!("coordinate {r}{c} out of range")));
                }
                out.push(words[r - 1][c - 1]);
            }
            Ok(Repr::new(out, Display::Bytes))
        }
    }
}

const SYLLABARY: &str = "syllabary";

/// Syllabary: a numbered table of syllables; text is encoded by table index.
///
/// The table is supplied rather than assumed, because syllabary tables are
/// language- and puzzle-specific and there is no canonical one.
pub struct Syllabary;

impl Node for Syllabary {
    fn name(&self) -> &'static str { SYLLABARY }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/syllabary(indexed-table)" }
    fn params_schema(&self) -> &'static [ParamSpec] {
        const S: &[ParamSpec] = &[
            ParamSpec::req("table", ParamType::Str, "comma-separated syllables, index 0 upward"),
            ParamSpec::opt("separator", ParamType::Str, "between numbers (default \" \")"),
            ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default: numbers->syllables)"),
        ];
        S
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let table: Vec<String> = params
            .req_str(SYLLABARY, "table")?
            .split(',')
            .map(|s| s.trim().to_ascii_lowercase())
            .filter(|s| !s.is_empty())
            .collect();
        if table.is_empty() {
            return Err(Error::bad_param(SYLLABARY, "table", "empty table"));
        }
        let sep = params.opt_str("separator").unwrap_or(" ");
        if dir(SYLLABARY, params)? {
            let s = String::from_utf8_lossy(&input.data).to_ascii_lowercase();
            let mut out = Vec::new();
            let mut i = 0usize;
            while i < s.len() {
                let mut hit = None;
                for (n, syl) in table.iter().enumerate() {
                    if s[i..].starts_with(syl.as_str()) {
                        if hit.map_or(true, |(_, l): (usize, usize)| syl.len() > l) {
                            hit = Some((n, syl.len()));
                        }
                    }
                }
                match hit {
                    Some((n, l)) => { out.push(n.to_string()); i += l; }
                    None => i += 1,
                }
            }
            if out.is_empty() {
                return Err(Error::node_failed(SYLLABARY, "no table syllable matched"));
            }
            Ok(Repr::new(out.join(sep).into_bytes(), Display::Decimal))
        } else {
            let s = String::from_utf8_lossy(&input.data).to_string();
            let mut out = String::new();
            for tok in s.split(|c: char| !c.is_ascii_digit()).filter(|t| !t.is_empty()) {
                let v: usize = tok.parse().map_err(|_| {
                    Error::node_failed(SYLLABARY, format!("{tok:?} is not a number"))
                })?;
                let syl = table.get(v).ok_or_else(|| {
                    Error::node_failed(SYLLABARY, format!("index {v} is outside the table"))
                })?;
                out.push_str(syl);
            }
            if out.is_empty() {
                return Err(Error::node_failed(SYLLABARY, "input has no numbers"));
            }
            Ok(Repr::new(out.into_bytes(), Display::Bytes))
        }
    }
}

register_node!(AMSCO_NODE => || Box::new(Amsco));
register_node!(REDEFENCE_NODE => || Box::new(Redefence));
register_node!(CADENUS_NODE => || Box::new(Cadenus));
register_node!(SWAGMAN_NODE => || Box::new(Swagman));
register_node!(CM_BIFID => || Box::new(CmBifid));
register_node!(NUMBERED_KEY => || Box::new(NumberedKey));
register_node!(GRANDPRE_NODE => || Box::new(Grandpre));
register_node!(SYLLABARY_NODE => || Box::new(Syllabary));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn n(name: &str) -> &'static dyn Node { registry().get(name).unwrap() }

    #[test]
    fn all_are_xf() {
        for name in [AMSCO, REDEFENCE, CADENUS, SWAGMAN, CMBIFID, NUMBERED, GRANDPRE, SYLLABARY] {
            assert_eq!(n(name).family(), Family::Xf);
        }
    }

    /// Every transposition here must preserve the letter multiset — that invariant is
    /// what lets a single chi-squared test exclude the whole family at once.
    #[test]
    fn transpositions_preserve_the_letter_multiset() {
        let msg = b"defendtheeastwallofthecastleatonce".to_vec();
        let mut want = msg.clone();
        want.sort_unstable();
        for (name, p) in [
            (AMSCO, params! {"key" => "NINE", "direction" => "encrypt"}),
            (REDEFENCE, params! {"key" => "NINE", "direction" => "encrypt"}),
        ] {
            let out = n(name).apply(&Repr::bytes(msg.clone()), &p).unwrap();
            let mut got = out.data.clone();
            got.sort_unstable();
            assert_eq!(got, want, "{name} changed the multiset");
        }
    }

    #[test]
    fn amsco_round_trips_both_phases() {
        for start_two in [false, true] {
            let p = params! {"key" => "NINE", "start_two" => start_two};
            let enc = n(AMSCO)
                .apply(&Repr::bytes(b"defendtheeastwall".to_vec()), &p.clone().set("direction", "encrypt"))
                .unwrap();
            let back = n(AMSCO).apply(&enc, &p).unwrap();
            assert_eq!(back.data, b"defendtheeastwall", "start_two={start_two}");
        }
    }

    #[test]
    fn redefence_round_trips() {
        let p = params! {"key" => "CAB"};
        let enc = n(REDEFENCE)
            .apply(&Repr::bytes(b"defendtheeastwall".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(n(REDEFENCE).apply(&enc, &p).unwrap().data, b"defendtheeastwall");
    }

    #[test]
    fn cadenus_round_trips_and_rejects_a_ragged_length() {
        let p = params! {"key" => "NINE", "height" => 3i64};
        let msg = b"abcdefghijkl".to_vec(); // 12 = 4 * 3
        let enc = n(CADENUS)
            .apply(&Repr::bytes(msg.clone()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(n(CADENUS).apply(&enc, &p).unwrap().data, msg);
        assert!(n(CADENUS)
            .apply(&Repr::bytes(b"abcde".to_vec()), &p)
            .is_err());
    }

    #[test]
    fn swagman_round_trips_and_validates_the_square() {
        let p = params! {"square" => "123,231,312"};
        let msg = b"abcdefghi".to_vec();
        let enc = n(SWAGMAN)
            .apply(&Repr::bytes(msg.clone()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(n(SWAGMAN).apply(&enc, &p).unwrap().data, msg);
        assert!(n(SWAGMAN)
            .apply(&Repr::bytes(msg), &params! {"square" => "113,231,312"})
            .is_err());
    }

    #[test]
    fn cm_bifid_round_trips_and_differs_from_plain_bifid() {
        let p = params! {"key1" => "ALPHA", "key2" => "BETA", "period" => 5i64};
        let enc = n(CMBIFID)
            .apply(&Repr::bytes(b"defendtheeast".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(n(CMBIFID).apply(&enc, &p).unwrap().data, b"defendtheeast");

        let same = n(CMBIFID)
            .apply(
                &Repr::bytes(b"defendtheeast".to_vec()),
                &params! {"key1" => "ALPHA", "key2" => "ALPHA", "period" => 5i64,
                          "direction" => "encrypt"},
            )
            .unwrap();
        assert_ne!(enc.data, same.data, "conjugating with a second square must matter");
    }

    #[test]
    fn numbered_key_round_trips_and_marks_output_decimal() {
        let p = params! {"key" => "ZOMBIES"};
        let enc = n(NUMBERED)
            .apply(&Repr::bytes(b"cab".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(enc.display, Display::Decimal);
        assert_eq!(n(NUMBERED).apply(&enc, &p).unwrap().data, b"cab");
    }

    #[test]
    fn grandpre_round_trips_over_a_small_grid() {
        let grid = "abcd,efgh,iklm,nopq";
        let p = params! {"grid" => grid};
        let enc = n(GRANDPRE)
            .apply(&Repr::bytes(b"face".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(enc.display, Display::Decimal);
        assert_eq!(n(GRANDPRE).apply(&enc, &p).unwrap().data, b"face");
    }

    #[test]
    fn syllabary_round_trips() {
        let p = params! {"table" => "the,you,will,not,come"};
        let enc = n(SYLLABARY)
            .apply(&Repr::bytes(b"youwillnotcome".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(n(SYLLABARY).apply(&enc, &p).unwrap().data, b"youwillnotcome");
    }
}
