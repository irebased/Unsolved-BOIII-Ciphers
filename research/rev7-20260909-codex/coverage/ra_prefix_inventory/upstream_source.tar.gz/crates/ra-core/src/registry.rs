use std::collections::BTreeMap;
use std::sync::OnceLock;

use linkme::distributed_slice;

use crate::node::Node;

/// Constructor for a registered node.
pub type NodeCtor = fn() -> Box<dyn Node>;

/// The link-time plugin slice.
///
/// Plugin crates push into this with [`register_node!`](crate::register_node).
/// The set of available nodes is therefore fixed when the binary is linked —
/// which is deliberate: it means the shipped binary's hash covers every
/// primitive it can execute, so a reproducible build maps verifiably back to
/// audited source. A runtime-loadable plugin would break that property, which
/// conformance gating depends on.
#[distributed_slice]
pub static NODES: [NodeCtor];

/// Register a node implementation with the global registry.
///
/// ```ignore
/// ra_core::register_node!(REVERSE_NODE => || Box::new(Reverse));
/// ```
#[macro_export]
macro_rules! register_node {
    ($static_name:ident => $ctor:expr) => {
        #[$crate::linkme::distributed_slice($crate::registry::NODES)]
        #[linkme(crate = $crate::linkme)]
        static $static_name: $crate::registry::NodeCtor = $ctor;
    };
}

pub struct Registry {
    by_name: BTreeMap<&'static str, &'static dyn Node>,
}

impl Registry {
    fn build() -> Self {
        let mut by_name: BTreeMap<&'static str, &'static dyn Node> = BTreeMap::new();
        for ctor in NODES {
            // Nodes live for the whole process; leaking is the cheapest way to get
            // a 'static reference and there is exactly one per registered plugin.
            let node: &'static dyn Node = Box::leak(ctor());
            if let Some(prev) = by_name.insert(node.name(), node) {
                panic!(
                    "duplicate node name '{}': {} and {}",
                    node.name(),
                    prev.node_id(),
                    node.node_id()
                );
            }
        }
        Self { by_name }
    }

    pub fn get(&self, name: &str) -> Option<&'static dyn Node> {
        self.by_name.get(name).copied()
    }

    pub fn contains(&self, name: &str) -> bool {
        self.by_name.contains_key(name)
    }

    pub fn names(&self) -> impl Iterator<Item = &'static str> + '_ {
        self.by_name.keys().copied()
    }

    pub fn iter(&self) -> impl Iterator<Item = &'static dyn Node> + '_ {
        self.by_name.values().copied()
    }

    pub fn len(&self) -> usize {
        self.by_name.len()
    }

    pub fn is_empty(&self) -> bool {
        self.by_name.is_empty()
    }
}

/// The process-wide node registry, built once on first use.
pub fn registry() -> &'static Registry {
    static REG: OnceLock<Registry> = OnceLock::new();
    REG.get_or_init(Registry::build)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn builtin_nodes_are_registered() {
        let r = registry();
        for expected in ["reverse", "hexdecode", "b64encode", "rot"] {
            assert!(r.contains(expected), "missing builtin node '{expected}'");
        }
    }

    #[test]
    fn node_ids_are_unique_and_content_addressed() {
        let r = registry();
        let mut ids = std::collections::HashSet::new();
        for n in r.iter() {
            assert!(ids.insert(n.node_id().to_string()), "duplicate node id");
            assert_eq!(n.impl_hash().len(), 64);
        }
    }
}
