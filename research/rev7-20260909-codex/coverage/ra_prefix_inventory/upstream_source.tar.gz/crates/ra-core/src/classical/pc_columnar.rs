//! Practical Cryptography's Columnar Transposition Cipher tool.
//!
//! Source: the page's own inline JavaScript, fetched directly over HTTP (task
//! scratchpad `pages/pc_columnar.html`, lines ~78-127). `Encrypt`/`Decrypt`
//! are transliterated verbatim below.
//!
//! # Column ordering
//!
//! ```js
//! for(i=0; i < key.length; i++){
//!     while(k<26){
//!         t = key.indexOf(chars.charAt(k));
//!         arrkw = key.split(""); arrkw[t] = "_"; key = arrkw.join("");
//!         if(t >= 0) break; else k++;
//!     }
//!     for(j=0; j < colLength; j++) ciphertext += plaintext.charAt(j*key.length + t);
//! }
//! ```
//!
//! For each of `key.length` columns to emit, this scans the 26-letter
//! alphabet from wherever it last left off (`k` never resets) and takes the
//! **leftmost remaining occurrence** of the first alphabet letter still
//! present in the (mutated-in-place) key, blanking that position with `_` so
//! it isn't found again. That is exactly alphabetical order with ties broken
//! by original left-to-right position — the same stable convention as every
//! other columnar port in this module, just derived by direct index-finding
//! and destructive marking instead of a stable sort.
//!
//! # Padding, not truncation
//!
//! Unlike Crypto Corner's tool (`cc_columnar.rs`), this one always pads the
//! plaintext up to a full rectangle before encrypting
//! (`while(plaintext.length % key.length != 0) plaintext += pc.charAt(0)`,
//! default pad character `x`), and its own docs call this the "regular"
//! columnar transposition. Decrypt therefore assumes an exact rectangle: it
//! slices the ciphertext into `key.length` equal-length column strings
//! (`colLength = ciphertext.length / klen`) with no short-column handling at
//! all — a non-multiple length only produces a JS `alert`, reproduced here as
//! a rejected input.
//!
//! # Case
//!
//! Both directions lower-case and filter to `a-z` up front (same convention
//! as `pc_railfence.rs`); output stays lowercase throughout, matching the
//! site's own case handling.
//!
//! # Stripping is the page's input normalisation, not the cipher
//!
//! A columnar transposition permutes *positions* within a grid — it does not
//! need an alphabet at all, only a length and a key's column ordering (which
//! stays letters, since it is a typed-in keyword, not the medium being
//! transposed). The site's lower-case-and-filter-to-`a-z` of the *message* is
//! a property of this specific web page (it only ever expected letters), not
//! of the transposition itself, so it is reproduced by default (for site
//! fidelity) via [`crate::classical::toolfmt`]'s `strip_non_alphabet` param
//! rather than hardcoded — set `strip_non_alphabet=false` to run the same
//! permutation over any medium (e.g. hex ciphertext from an earlier layer),
//! verified in `pc_columnar_preserves_hex_medium_when_stripping_disabled`
//! below.
//!
//! # Ground truth
//!
//! From the page's own worked example ("Example" section, verbatim): plaintext
//! `"defend the east wall of the castle"` padded to
//! `"defendtheeastwallofthecastlexx"` with keyword `GERMAN` ->
//! `"nalcxehwttdttfseeleedsoaxfeahl"`.
//!
//! # Engine direction
//!
//! Decrypt-direction: [`PcColumnar::apply`] runs [`decrypt`]. [`encrypt`] is
//! reproduced test-only.

use crate::classical::toolfmt::{read_output_fmt, CaseFold, InputNorm, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

const PC_COLUMNAR_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(ParamSpec::req(
    "key",
    ParamType::Str,
    "transposition keyword, at least 2 letters (letters a-z only; non-letter \
     characters are dropped)"
),);

/// `Decrypt`, transliterated from `pages/pc_columnar.html`. `ciphertext` and
/// `key` are expected already lower-cased and filtered to `a-z`.
pub fn decrypt(ciphertext: &[u8], key: &[u8]) -> Result<Vec<u8>> {
    let klen = key.len();
    if klen < 2 {
        return Err(Error::bad_param(
            "pc_columnar",
            "key",
            "keyword should be at least 2 characters long",
        ));
    }
    if ciphertext.len() % klen != 0 {
        return Err(Error::bad_param(
            "pc_columnar",
            "key",
            format!(
                "ciphertext length {} is not a multiple of the {klen}-letter key \
                 (site: \"ciphertext has not been padded\")",
                ciphertext.len()
            ),
        ));
    }
    let col_length = ciphertext.len() / klen;

    let mut cols: Vec<&[u8]> = Vec::with_capacity(klen);
    for i in 0..klen {
        cols.push(&ciphertext[i * col_length..(i + 1) * col_length]);
    }

    // Rebuild the destructive alphabet scan: find, for each alphabet letter
    // in order, the leftmost remaining key position; that gives the
    // plaintext column index each ciphertext-order column belongs at.
    let mut key = key.to_vec();
    let mut new_cols: Vec<Option<&[u8]>> = vec![None; klen];
    let mut j = 0usize;
    let mut i = 0usize;
    while j < klen {
        if let Some(t) = key.iter().position(|&c| c == (b'a' + i as u8)) {
            new_cols[t] = Some(cols[j]);
            key[t] = b'_';
            j += 1;
        } else {
            i += 1;
            if i >= 26 {
                break;
            }
        }
    }

    let mut plaintext = Vec::with_capacity(ciphertext.len());
    for row in 0..col_length {
        for c in new_cols.iter().take(klen).flatten() {
            plaintext.push(c[row]);
        }
    }
    Ok(plaintext)
}

/// `Encrypt`, transliterated the same way (including its own default pad
/// character `x`). Test-only.
#[cfg(test)]
fn encrypt(plaintext: &[u8], key: &[u8], pad: u8) -> Vec<u8> {
    let klen = key.len();
    let mut plaintext = plaintext.to_vec();
    while plaintext.len() % klen != 0 {
        plaintext.push(pad);
    }
    let col_length = plaintext.len() / klen;

    let mut key = key.to_vec();
    let mut ciphertext = Vec::with_capacity(plaintext.len());
    let mut k = 0usize;
    for _ in 0..klen {
        let mut t = None;
        while k < 26 {
            let found = key.iter().position(|&c| c == b'a' + k as u8);
            if let Some(pos) = found {
                key[pos] = b'_';
                t = Some(pos);
                break;
            } else {
                k += 1;
            }
        }
        let t = t.expect("key exhausted before klen columns found");
        for j in 0..col_length {
            ciphertext.push(plaintext[j * klen + t]);
        }
    }
    ciphertext
}

/// Practical Cryptography's Columnar Transposition Cipher tool, decrypting.
pub struct PcColumnar;

impl Node for PcColumnar {
    fn name(&self) -> &'static str {
        "pc_columnar"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        PC_COLUMNAR_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = params.req_str("pc_columnar", "key")?;
        let key: Vec<u8> = key
            .to_lowercase()
            .bytes()
            .filter(|b| b.is_ascii_lowercase())
            .collect();

        let in_norm = crate::classical::toolfmt::read_input_norm(
            "pc_columnar",
            params,
            InputNorm {
                case: CaseFold::Lower,
                strip_outside_alphabet: Some("abcdefghijklmnopqrstuvwxyz".to_string()),
                ..InputNorm::default()
            },
        )?;
        let text = in_norm.apply(&input.data);

        let plain = decrypt(&text, &key)?;

        let out_fmt: OutputFmt = read_output_fmt(
            "pc_columnar",
            params,
            OutputFmt {
                case: CaseFold::Preserve,
                grouping: None,
                trailing: Trailing::None,
            },
        )?;
        let out = out_fmt.apply(&plain);
        Ok(Repr::new(out, input.display))
    }
}

register_node!(PC_COLUMNAR => || Box::new(PcColumnar));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    /// Ground truth, verbatim from the page's own worked example.
    #[test]
    fn pc_columnar_site_worked_example() {
        let pt_padded = b"defendtheeastwallofthecastlexx";
        let ct = encrypt(b"defendtheeastwallofthecastle", b"german", b'x');
        assert_eq!(ct, b"nalcxehwttdttfseeleedsoaxfeahl");
        assert_eq!(ct.len(), pt_padded.len());
        let back = decrypt(&ct, b"german").unwrap();
        assert_eq!(back, pt_padded);
    }

    #[test]
    fn pc_columnar_round_trips_varied_keys_and_padded_lengths() {
        let samples: &[&[u8]] = &[b"ab", b"attackatdawn", b"thequickbrownfoxjumpsoverthelazydog"];
        let keys: &[&[u8]] = &[b"zebra", b"key", b"cipher", b"ab"];
        for pt in samples {
            for key in keys {
                let ct = encrypt(pt, key, b'x');
                let back = decrypt(&ct, key).unwrap();
                assert!(back.starts_with(pt), "pt={pt:?} key={key:?} back={back:?}");
            }
        }
    }

    #[test]
    fn pc_columnar_node_decrypts_via_registry() {
        let ct = encrypt(b"defendtheeastwallofthecastle", b"german", b'x');
        let n = registry().get("pc_columnar").unwrap();
        let p = params! {"key" => "german"};
        let out = n.apply(&Repr::bytes(ct), &p).unwrap();
        assert_eq!(out.data, b"defendtheeastwallofthecastlexx");
    }

    #[test]
    fn pc_columnar_rejects_key_shorter_than_two() {
        let n = registry().get("pc_columnar").unwrap();
        let p = params! {"key" => "a"};
        assert!(n.apply(&Repr::bytes(b"xx".to_vec()), &p).is_err());
    }

    #[test]
    fn pc_columnar_rejects_unpadded_ciphertext_length() {
        let n = registry().get("pc_columnar").unwrap();
        let p = params! {"key" => "german"}; // length 6
        let err = n.apply(&Repr::bytes(b"abcde".to_vec()), &p).unwrap_err(); // len 5, not a multiple of 6
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn pc_columnar_preserves_display() {
        let ct = encrypt(b"defendtheeastwallofthecastle", b"german", b'x');
        let n = registry().get("pc_columnar").unwrap();
        let p = params! {"key" => "german"};
        let out = n.apply(&Repr::new(ct, Display::Hex), &p).unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn pc_columnar_is_xf_family_and_not_layer_forming() {
        let n = registry().get("pc_columnar").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    /// The payoff: with `strip_non_alphabet` explicitly disabled, this
    /// transposition operates on any medium, not just a-z text -- proven here
    /// against a 1092-character hex string, the length of rev7's ciphertext
    /// (1092 = 7 * 156, an exact multiple of the 7-letter key, satisfying
    /// this tool's "regular" no-padding-on-decrypt requirement).
    #[test]
    fn pc_columnar_preserves_hex_medium_when_stripping_disabled() {
        let hex: String = (0..1092).map(|i| "0123456789abcdef".as_bytes()[i % 16] as char).collect();
        let n = registry().get("pc_columnar").unwrap();
        let p = params! {"key" => "zombies", "strip_non_alphabet" => false};
        let out = n.apply(&Repr::bytes(hex.clone().into_bytes()), &p).unwrap();
        assert_eq!(out.data.len(), 1092);
        let mut want: Vec<u8> = hex.into_bytes();
        want.sort();
        let mut got = out.data.clone();
        got.sort();
        assert_eq!(got, want, "must be a pure permutation: same multiset of bytes");
    }
}
