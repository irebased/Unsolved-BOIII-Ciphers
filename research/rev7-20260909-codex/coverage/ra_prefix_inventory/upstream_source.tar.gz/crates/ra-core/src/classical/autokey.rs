//! Classical Vigenère autokey cipher.
//!
//! Decryption: `p_i = (index(c_i) - index(k_i)) mod m`, where the keystream `k`
//! starts as the given `key` and is then extended, one character per recovered
//! plaintext letter, by that same recovered plaintext — the defining property of
//! an *autokey* cipher, as opposed to a plain repeating-key Vigenère.
//!
//! Confirmed against gk12: `autokey:key=TRYTHIS,alphabet=ZOMBIESAREEVERYWHERE`
//! recovers the recorded plaintext **exactly**, byte for byte.
//!
//! # Deduplicating the keyed alphabet
//!
//! gk12's `alphabet` parameter, `ZOMBIESAREEVERYWHERE`, has repeated letters (an
//! `E` five times, an `R` three times, ...), so it cannot be used directly as a
//! 1:1 index -> letter mapping. This node builds the working alphabet the
//! standard classical way a keyword is turned into a mixed alphabet: keep the
//! first occurrence of each letter in the given string, in order, then append
//! whatever letters of the standard `A`..`Z` are still missing, in `A`..`Z`
//! order. For `ZOMBIESAREEVERYWHERE` that yields:
//!
//! ```text
//! Z O M B I E S A R V Y W H | C D F G J K L N P Q T U X
//! `--------- from the key ----------`   `-- appended --`
//! ```
//!
//! a 26-letter permutation of the alphabet. This choice is what reproduces
//! gk12; a different deduplication policy (e.g. dropping repeats without
//! completing the alphabet, which would leave it too short to represent every
//! ciphertext letter) does not.
//!
//! # `strip_non_alphabet`
//!
//! Non-alphabet bytes already pass through the cipher untouched (and don't
//! advance the keystream) with no parameter needed for that -- it's this
//! node's own default behaviour, confirmed by `autokey_passthrough_does_not_
//! advance_key_phase`. What was missing is the standard artifact toggle every
//! other node in this crate exposes: [`crate::classical::toolfmt`]'s
//! `strip_non_alphabet` (default off, matching the description above exactly)
//! lets a caller instead remove non-alphabet bytes from the medium entirely
//! before decryption runs, which matters when the ciphertext is embedded in a
//! wider blob (hex, base64, ...) that a sweep needs to see as pure alphabet
//! text. Since this node's default is passthrough rather than stripping,
//! there is no baked-in fallback alphabet: enabling `strip_non_alphabet`
//! without also giving `input_alphabet` is an error, exactly as documented on
//! `strip_non_alphabet`'s own [`crate::node::ParamSpec`].

use crate::classical::toolfmt::{self, InputNorm, OutputFmt};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

const DEFAULT_ALPHABET: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

const AUTOKEY_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::req(
        "key",
        ParamType::Str,
        "initial key; extended by recovered plaintext as decryption proceeds",
    ),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "keyed alphabet (default: the 26 uppercase letters). Repeated letters \
         are deduplicated, first occurrence kept, and any of A-Z still missing \
         are appended in order, producing a 26-letter keyed alphabet",
    ),
);

/// Build the canonical 26-letter keyed alphabet from a raw alphabet string: keep
/// the first occurrence of each letter (case folded to uppercase), in order,
/// then append whichever of `A`..`Z` are still missing, in `A`..`Z` order.
///
/// Errors if the raw string contains anything other than ASCII letters.
fn build_alphabet(node: &str, raw: &str) -> Result<Vec<u8>> {
    if !raw.bytes().all(|b| b.is_ascii_alphabetic()) {
        return Err(Error::bad_param(
            node,
            "alphabet",
            "must contain only ASCII letters",
        ));
    }
    let mut seen = [false; 26];
    let mut out = Vec::with_capacity(26);
    for b in raw.bytes() {
        let upper = b.to_ascii_uppercase();
        let i = (upper - b'A') as usize;
        if !seen[i] {
            seen[i] = true;
            out.push(upper);
        }
    }
    for (i, &was_seen) in seen.iter().enumerate() {
        if !was_seen {
            out.push(b'A' + i as u8);
        }
    }
    Ok(out)
}

/// Classical Vigenère autokey cipher.
pub struct Autokey;

impl Node for Autokey {
    fn name(&self) -> &'static str {
        "autokey"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        AUTOKEY_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key_raw = params.req_str("autokey", "key")?;
        if key_raw.is_empty() {
            return Err(Error::bad_param("autokey", "key", "must not be empty"));
        }
        let alphabet_raw = params.opt_str("alphabet").unwrap_or(DEFAULT_ALPHABET);
        let alphabet = build_alphabet("autokey", alphabet_raw)?;
        let m = alphabet.len() as i64;

        // No site-verified default here strips non-alphabet input -- a byte
        // outside `alphabet` already passes through unchanged below, so
        // `InputNorm::default()` (no stripping) is a no-op by default. What
        // this adds is the *opt-in* `strip_non_alphabet` toggle every other
        // artifact-backed node exposes: set it (with `input_alphabet`, since
        // there is no baked-in default to fall back to) and non-alphabet
        // bytes are removed from the medium entirely instead of merely
        // being skipped in place.
        let in_norm = toolfmt::read_input_norm("autokey", params, InputNorm::default())?;
        let out_fmt = toolfmt::read_output_fmt("autokey", params, OutputFmt::default())?;
        let data = in_norm.apply(&input.data);

        let pos = |b: u8| -> Option<usize> { alphabet.iter().position(|&a| a == b) };

        let mut keystream: Vec<u8> = Vec::with_capacity(key_raw.len());
        for b in key_raw.bytes() {
            let upper = b.to_ascii_uppercase();
            let idx = pos(upper).ok_or_else(|| {
                Error::bad_param(
                    "autokey",
                    "key",
                    format!("key character {:?} is not in the alphabet", b as char),
                )
            })?;
            keystream.push(alphabet[idx]);
        }

        let mut ki = 0usize;
        let mut out = Vec::with_capacity(data.len());
        for &c in &data {
            let upper = c.to_ascii_uppercase();
            match pos(upper) {
                Some(y) => {
                    let kchar = keystream[ki];
                    ki += 1;
                    let kx = pos(kchar).expect("keystream characters are always alphabet members");
                    let x = (y as i64 - kx as i64).rem_euclid(m) as usize;
                    let p = alphabet[x];
                    let out_c = if c.is_ascii_lowercase() {
                        p.to_ascii_lowercase()
                    } else {
                        p
                    };
                    out.push(out_c);
                    // Autokey: extend the key with the plaintext just recovered.
                    keystream.push(p);
                }
                None => out.push(c),
            }
        }

        Ok(Repr::new(out_fmt.apply(&out), input.display))
    }
}

register_node!(AUTOKEY => || Box::new(Autokey));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    /// Hand-computed over the standard alphabet: key "B" (index 1), plaintext
    /// "AB" would encrypt as: c0 = (0+1)%26=1='B'; key extends with 'A' (the
    /// first recovered/used plaintext char is 'A'), c1 = (1+0)%26=1='B'. So
    /// "AB" encrypts to "BB" under key "B". Decrypting "BB" with key "B" must
    /// recover "AB".
    #[test]
    fn autokey_hand_computed_default_alphabet() {
        let n = registry().get("autokey").unwrap();
        let p = params! {"key" => "B"};
        let out = n.apply(&Repr::bytes(b"BB".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"AB");
    }

    /// The gk12 case: key "TRYTHIS" over the repeated-letter keyed alphabet
    /// "ZOMBIESAREEVERYWHERE" recovers the recorded plaintext exactly, byte for
    /// byte -- no transcription tolerance needed.
    #[test]
    fn autokey_reproduces_gk12_exactly() {
        let n = registry().get("autokey").unwrap();
        let ct = "Rc qipv jhx vld plson fhceuh itp jui gh qhzu dg sq xie dhw. U gbfl lf fluz \
                  pcag wrgkv zw, dinyg zw, qge gnvm L fhx.";
        let expected = "We have won the great battle and now we must be on our way. I fear he \
                         will come after us, after me, for what I did.";
        let p = params! {"key" => "TRYTHIS", "alphabet" => "ZOMBIESAREEVERYWHERE"};
        let out = n.apply(&Repr::bytes(ct.as_bytes().to_vec()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), expected);
    }

    #[test]
    fn autokey_deduplicates_repeated_alphabet_letters() {
        let alphabet = build_alphabet("autokey", "ZOMBIESAREEVERYWHERE").unwrap();
        assert_eq!(alphabet.len(), 26);
        // No duplicates.
        let mut sorted = alphabet.clone();
        sorted.sort_unstable();
        sorted.dedup();
        assert_eq!(sorted.len(), 26);
        // First 13 characters are exactly the deduplicated keyword, in order.
        assert_eq!(&alphabet[..13], b"ZOMBIESARVYWH");
    }

    #[test]
    fn autokey_rejects_empty_key() {
        let n = registry().get("autokey").unwrap();
        let p = params! {"key" => ""};
        assert!(n.apply(&Repr::bytes(b"ABC".to_vec()), &p).is_err());
    }

    #[test]
    fn autokey_rejects_key_character_outside_alphabet() {
        let n = registry().get("autokey").unwrap();
        let p = params! {"key" => "AB9"};
        assert!(n.apply(&Repr::bytes(b"ABC".to_vec()), &p).is_err());
    }

    #[test]
    fn autokey_rejects_non_letter_alphabet() {
        let n = registry().get("autokey").unwrap();
        let p = params! {"key" => "A", "alphabet" => "ABC123"};
        assert!(n.apply(&Repr::bytes(b"ABC".to_vec()), &p).is_err());
    }

    /// Non-alphabet characters pass through unchanged, and do not consume a key
    /// position -- the same convention `beaufort` uses, corpus-verified there
    /// against rev1.
    #[test]
    fn autokey_passthrough_does_not_advance_key_phase() {
        let n = registry().get("autokey").unwrap();
        let p = params! {"key" => "B"};
        let plain = n.apply(&Repr::bytes(b"BB".to_vec()), &p).unwrap();
        assert_eq!(plain.data, b"AB");

        let with_gap = n.apply(&Repr::bytes(b"B9B".to_vec()), &p).unwrap();
        assert_eq!(with_gap.data, b"A9B");
    }

    /// `strip_non_alphabet` is opt-in and off by default: two runs with and
    /// without it, over a plain letters+digits ciphertext, differ only in
    /// that the stripped run has every digit *removed* rather than merely
    /// passed through untouched.
    #[test]
    fn strip_non_alphabet_is_off_by_default_and_removes_digits_when_enabled() {
        let n = registry().get("autokey").unwrap();
        let ct = b"B9B".to_vec();

        let default = n.apply(&Repr::bytes(ct.clone()), &params! {"key" => "B"}).unwrap();
        assert_eq!(default.data, b"A9B", "default behaviour: passthrough, unchanged");

        let stripped = n
            .apply(
                &Repr::bytes(ct),
                &params! {
                    "key" => "B",
                    "strip_non_alphabet" => true,
                    "input_alphabet" => DEFAULT_ALPHABET,
                },
            )
            .unwrap();
        assert_eq!(stripped.data, b"AB", "'9' removed from the medium entirely");
    }

    /// Enabling `strip_non_alphabet` without `input_alphabet` is an error:
    /// this node's site-faithful default is passthrough, so there is no
    /// baked-in alphabet to fall back to (unlike `pc_columnar`, whose site
    /// always strips and therefore has one).
    #[test]
    fn strip_non_alphabet_without_input_alphabet_errors() {
        let n = registry().get("autokey").unwrap();
        let p = params! {"key" => "B", "strip_non_alphabet" => true};
        assert!(n.apply(&Repr::bytes(b"B9B".to_vec()), &p).is_err());
    }

    #[test]
    fn autokey_passthrough_preserves_punctuation_and_spaces() {
        let n = registry().get("autokey").unwrap();
        let p = params! {"key" => "TRYTHIS", "alphabet" => "ZOMBIESAREEVERYWHERE"};
        let out = n
            .apply(&Repr::bytes(b"Rc, qipv! 123.".to_vec()), &p)
            .unwrap();
        for (i, &c) in b"Rc, qipv! 123.".iter().enumerate() {
            if !c.is_ascii_alphabetic() {
                assert_eq!(out.data[i], c, "byte {i} ({c:?}) should pass through");
            }
        }
    }

    /// Round trip: encrypting with the classical autokey formula
    /// (`c = p + k mod m`, key extended by *plaintext*) and then decrypting
    /// with this node (key extended by *recovered* plaintext, which is the
    /// same plaintext once decryption is correct) must recover the original.
    #[test]
    fn autokey_round_trips_against_hand_rolled_encryption() {
        let alphabet = build_alphabet("autokey", DEFAULT_ALPHABET).unwrap();
        let pos = |b: u8| alphabet.iter().position(|&a| a == b).unwrap();
        let key = b"KEY";
        let plain = b"THEQUICKBROWNFOXJUMPSOVERTHELAZYDOG";

        let mut keystream: Vec<u8> = key.to_vec();
        let mut cipher = Vec::with_capacity(plain.len());
        for (i, &p) in plain.iter().enumerate() {
            let kx = pos(keystream[i]) as i64;
            let px = pos(p) as i64;
            let cx = (px + kx).rem_euclid(26) as usize;
            cipher.push(alphabet[cx]);
            keystream.push(p);
        }

        let n = registry().get("autokey").unwrap();
        let params = params! {"key" => "KEY"};
        let recovered = n.apply(&Repr::bytes(cipher), &params).unwrap();
        assert_eq!(recovered.data, plain);
    }

    #[test]
    fn autokey_preserves_display() {
        let n = registry().get("autokey").unwrap();
        let p = params! {"key" => "B"};
        let out = n
            .apply(&Repr::new(b"BB".to_vec(), Display::Hex), &p)
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn autokey_is_xf_family_and_not_layer_forming() {
        let n = registry().get("autokey").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
