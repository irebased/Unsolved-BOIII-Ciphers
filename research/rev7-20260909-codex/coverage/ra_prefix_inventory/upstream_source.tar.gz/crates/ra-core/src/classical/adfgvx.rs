//! ADFGVX: the 6x6 sibling of [`crate::classical::adfgx`] — a Polybius square
//! over 36 alphanumeric symbols, then a keyed columnar transposition.
//!
//! # Two sites, two column-key conventions
//!
//! Both practicalcryptography.com
//! (`http://practicalcryptography.com/ciphers/classical-era/adfgvx/`) and
//! geocachingtoolbox.com (`page=adfgvxCipher`, `javascript` field of
//! `docs/toolsites/geocachingtoolbox.json` index 0) implement the identical
//! *cipher* — same Polybius stage, same row-major-fill/rank-order-read-out
//! columnar transposition (see [`crate::classical::adfgx`] for that half in
//! detail) — but they prepare the transposition **key** differently, and the
//! difference is observable whenever the key has a repeated letter:
//!
//! - **practicalcryptography.com** (`variant = "practicalcryptography"`,
//!   the default): the key is lowercased and every non-`a-z` byte (including
//!   digits) is stripped; **no deduplication** — a repeated letter is kept and
//!   the columnar transposition ranks ties left-to-right, exactly as
//!   `xf:adfgx`'s `key` does.
//! - **geocachingtoolbox.com**: the key is lowercased and filtered against its
//!   own `inCharsadfgx` array — the 25-letter alphabet **excluding `j`** —
//!   which is the ADFGX (not ADFGVX) alphabet, reused verbatim for the 6x6
//!   cipher; this means a `j` or a digit in the key is dropped even though
//!   digits are legal ciphertext-square contents. The kept letters are then
//!   **deduplicated**, keeping first occurrence: `"HELLO"` becomes the
//!   four-column key `"helo"`, not a five-column key with a tied pair of
//!   `l`s. This was confirmed by executing the site's `adfgvxCipher()`
//!   verbatim under Node (stubbing `document`); see the
//!   `geocachingtoolbox_dedups_a_repeated_key_letter` test below, which pins
//!   the resulting ciphertext against that run.
//!
//! Both differences are folded into the `key` byte string before it reaches
//! the shared [`crate::classical::adfgx::ranks`]-style column ranking, so the
//! rest of the pipeline (square lookup, row-major fill, rank-order read-out,
//! ragged-final-row handling) is identical code between the two variants —
//! this is "one node, an explicit `variant` parameter", per the task's own
//! rule, not two nodes, because nothing else differs.
//!
//! # The square
//!
//! Unlike `xf:adfgx`'s square (25 letters, a fixed default), ADFGVX's square
//! has no sensible default on either site — both require the puzzle-maker to
//! fill in all 36 cells (individually, one `<input>` per cell, on
//! geocachingtoolbox; as one 36-character field on practicalcryptography.com)
//! — so `square` is a required parameter here: 36 distinct ASCII alphanumeric
//! characters, row-major.
//!
//! # 2016 vs modern: cross-checked, `practicalcryptography` variant is identical
//!
//! The project owner has since supplied 2016 Wayback sources for the CrypTool
//! Online suite (`docs/toolsites/cryptool2016/js/adfgvx.js`,
//! `CTOAdfgvxAlgorithm`). Running its `encodePartA`/`encodePartB` directly
//! under Node (task scratchpad `jstest/run_adfgx.js`, reused with this file's
//! class name) against key `"HELLO"` (a repeated-letter key, the case where
//! the two site variants above diverge), square
//! `"0123456789abcdefghijklmnopqrstuvwxyz"`, and plaintext `"attackatdawn123"`
//! produces the identical ciphertext (`VDFFFADXGXXDVVDDGFXFVDXAVAVVAG`) as
//! `variant = "practicalcryptography"` (the default) — 2016 CrypTool Online
//! does **not** deduplicate a repeated key letter, the same as
//! practicalcryptography.com and unlike geocachingtoolbox.com. Verdict:
//! **identical** to the existing default variant; no change needed, and no
//! third variant is warranted.
//!
//! # `square` audited: already authoritative, no fix needed
//!
//! Unlike `xf:adfgx`'s square (which hardcoded a letters-only gate despite the
//! grid having no structural reason to exclude digits -- since fixed), `square`
//! here was already correctly generalised: `square_of` and `encode`'s input
//! filter both test `is_ascii_alphanumeric`, and a 6x6 grid has *exactly* 36
//! cells, which is *exactly* the number of distinct case-folded ASCII
//! alphanumeric characters (26 letters + 10 digits). So `square` can only ever
//! be some permutation of the full alphanumeric alphabet -- there is no
//! narrower "declared but not honoured" subset for a caller to lose, the way a
//! digit-only Polybius or Baconian alphabet was previously silently rejected
//! elsewhat in this crate. `square` is already end-to-end authoritative over
//! that one alphabet's arrangement; `matches_a_differently_arranged_square`
//! below is the differential proof, not a fix.
//!
//! `key`'s alphabet restriction (`practicalcryptography`: a-z only, digits
//! stripped even though the square legitimately holds them) is deliberately
//! left alone: it is verified site fidelity (see above), not an unhonoured
//! parameter -- there is no `key`-alphabet parameter to make authoritative,
//! only the fixed, confirmed behaviour of the two real sites' own key
//! preparation code.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`], matching `xf:adfgx`: a keyed re-representation at stated
//! parameters, exhaustive at those parameters, no search.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const NAME: &str = "adfgvx";

/// Side of the Polybius square: 6, giving 36 cells (`0-9` + `a-z`).
const SIDE: usize = 6;

/// The classical ADFGVX cipher alphabet, and this node's default `symbols`.
pub const ADFGVX_SYMBOLS: &str = "ADFGVX";

/// The six coordinate symbols, all of the same byte width. A local copy of
/// `xf:adfgx`'s private `Symbols` type generalised to an arbitrary alphabet
/// size, since that type's fields and constructor are private to its module.
struct Symbols {
    list: Vec<Vec<u8>>,
}

impl Symbols {
    fn parse(node: &str, spec: &str, side: usize) -> Result<Self> {
        let list: Vec<Vec<u8>> = if spec.contains('/') {
            spec.split('/').map(|s| s.as_bytes().to_vec()).collect()
        } else {
            spec.as_bytes().iter().map(|&b| vec![b]).collect()
        };
        if list.len() != side {
            return Err(Error::bad_param(
                node,
                "symbols",
                format!("expected {side} symbols, got {}", list.len()),
            ));
        }
        let width = list[0].len();
        if width == 0 || list.iter().any(|s| s.len() != width) {
            return Err(Error::bad_param(
                node,
                "symbols",
                "every symbol must be non-empty and all must have the same width, so \
                 that the ciphertext can be tokenised unambiguously",
            ));
        }
        for (i, s) in list.iter().enumerate() {
            if list[..i].contains(s) {
                return Err(Error::bad_param(
                    node,
                    "symbols",
                    format!("symbol {:?} appears twice", String::from_utf8_lossy(s)),
                ));
            }
        }
        Ok(Symbols { list })
    }

    fn width(&self) -> usize {
        self.list[0].len()
    }

    fn index_of(&self, tok: &[u8]) -> Option<usize> {
        self.list.iter().position(|s| s.as_slice() == tok)
    }

    fn symbol(&self, i: usize) -> &[u8] {
        &self.list[i]
    }
}

/// Column read-out order: `rank[p]` is the position of column `p` in the
/// read-out. A local copy of `xf:adfgx`'s private `ranks` (same rule: rank is
/// the count of strictly smaller key bytes plus equal ones occurring earlier,
/// compared on ASCII-uppercased bytes).
fn ranks(key: &[u8]) -> Vec<usize> {
    let k: Vec<u8> = key.to_ascii_uppercase();
    k.iter()
        .enumerate()
        .map(|(i, c)| {
            k.iter()
                .enumerate()
                .filter(|&(j, o)| o < c || (o == c && j < i))
                .count()
        })
        .collect()
}

/// geocachingtoolbox's `inCharsadfgx`: the 25-letter alphabet (no `j`) that
/// its key-preparation code uses for *both* ADFGX and ADFGVX, even though the
/// 6x6 square legitimately contains digits. Reproduced verbatim as a finding,
/// not "fixed", since the task is to emulate the site's own quirk.
const GEOCACHINGTOOLBOX_KEY_ALPHABET: &[u8] = b"abcdefghiklmnopqrstuvwxyz";

const SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::req(
        "key",
        ParamType::Str,
        "columnar transposition keyword; preparation before ranking depends on \
         `variant`",
    ),
    ParamSpec::req(
        "square",
        ParamType::Str,
        "36 distinct alphanumeric characters filling the 6x6 square row-wise \
         (both emulated sites require the puzzle-maker to supply every cell; \
         there is no site default)",
    ),
    ParamSpec::opt(
        "symbols",
        ParamType::Str,
        "the six coordinate symbols in row/column order. Either six characters \
         (default \"ADFGVX\") or a '/'-separated list of equal-width symbols, \
         as for xf:adfgx",
    ),
    ParamSpec::opt(
        "variant",
        ParamType::Str,
        "\"practicalcryptography\" (default): key is a-z only, not \
         deduplicated, ties broken left-to-right. \"geocachingtoolbox\": key \
         is filtered to the 25-letter no-'j' ADFGX alphabet, then \
         deduplicated (first occurrence kept) before ranking.",
    ),
    ParamSpec::opt(
        "direction",
        ParamType::Str,
        "\"decode\" (default): ciphertext to plaintext. \"encode\": the inverse.",
    ),
);

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Variant {
    PracticalCryptography,
    Geocachingtoolbox,
}

impl Variant {
    fn parse(p: &Params) -> Result<Self> {
        match p.opt_str("variant").unwrap_or("practicalcryptography") {
            "practicalcryptography" => Ok(Variant::PracticalCryptography),
            "geocachingtoolbox" => Ok(Variant::Geocachingtoolbox),
            other => Err(Error::bad_param(
                NAME,
                "variant",
                format!(
                    "expected \"practicalcryptography\" or \"geocachingtoolbox\", got {other:?}"
                ),
            )),
        }
    }

    /// Prepare the raw `key` bytes into the byte string that is actually
    /// ranked for the columnar transposition, per this variant's site.
    fn prepare_key(self, key: &[u8]) -> Vec<u8> {
        let lower: Vec<u8> = key.to_ascii_lowercase();
        match self {
            Variant::PracticalCryptography => {
                lower.into_iter().filter(u8::is_ascii_lowercase).collect()
            }
            Variant::Geocachingtoolbox => {
                let mut seen = Vec::new();
                for b in lower {
                    if GEOCACHINGTOOLBOX_KEY_ALPHABET.contains(&b) && !seen.contains(&b) {
                        seen.push(b);
                    }
                }
                seen
            }
        }
    }
}

/// Column lengths for a `n`-symbol message in `w` columns: the first `n % w`
/// (physical) columns carry one extra symbol — same convention as
/// `xf:adfgx`'s `column_lengths`, duplicated here so this module has no
/// private-item dependency on that one.
fn column_lengths(n: usize, w: usize) -> Vec<usize> {
    let (full, rem) = (n / w, n % w);
    (0..w).map(|p| full + usize::from(p < rem)).collect()
}

fn untranspose(cipher: &[usize], rank: &[usize]) -> Vec<usize> {
    let w = rank.len();
    let lens = column_lengths(cipher.len(), w);
    let mut order: Vec<usize> = (0..w).collect();
    order.sort_by_key(|&p| rank[p]);

    let mut cols: Vec<&[usize]> = vec![&[]; w];
    let mut at = 0usize;
    for &p in &order {
        cols[p] = &cipher[at..at + lens[p]];
        at += lens[p];
    }

    let mut out = Vec::with_capacity(cipher.len());
    for row in 0..lens.iter().copied().max().unwrap_or(0) {
        for col in &cols {
            if let Some(&v) = col.get(row) {
                out.push(v);
            }
        }
    }
    out
}

fn transpose(plain: &[usize], rank: &[usize]) -> Vec<usize> {
    let w = rank.len();
    let mut cols: Vec<Vec<usize>> = vec![Vec::new(); w];
    for (i, &v) in plain.iter().enumerate() {
        cols[i % w].push(v);
    }
    let mut order: Vec<usize> = (0..w).collect();
    order.sort_by_key(|&p| rank[p]);
    let mut out = Vec::with_capacity(plain.len());
    for &p in &order {
        out.extend_from_slice(&cols[p]);
    }
    out
}

fn square_of(p: &Params) -> Result<Vec<u8>> {
    let sq: Vec<u8> = p.req_str(NAME, "square")?.as_bytes().to_ascii_uppercase();
    if sq.len() != SIDE * SIDE {
        return Err(Error::bad_param(
            NAME,
            "square",
            format!("expected {} characters, got {}", SIDE * SIDE, sq.len()),
        ));
    }
    for (i, &c) in sq.iter().enumerate() {
        if !c.is_ascii_alphanumeric() {
            return Err(Error::bad_param(
                NAME,
                "square",
                format!("{:?} is not an ASCII letter or digit", c as char),
            ));
        }
        if sq[..i].contains(&c) {
            return Err(Error::bad_param(
                NAME,
                "square",
                format!("character {:?} appears twice", c as char),
            ));
        }
    }
    Ok(sq)
}

fn key_ranks(p: &Params, variant: Variant) -> Result<Vec<usize>> {
    let raw = p.req_str(NAME, "key")?;
    let key = variant.prepare_key(raw.as_bytes());
    if key.is_empty() {
        return Err(Error::bad_param(
            NAME,
            "key",
            format!("has no usable letters once prepared for variant {variant:?} (from {raw:?})"),
        ));
    }
    Ok(ranks(&key))
}

pub struct Adfgvx;

impl Adfgvx {
    fn decode(&self, input: &[u8], p: &Params) -> Result<Vec<u8>> {
        let variant = Variant::parse(p)?;
        let syms = Symbols::parse(NAME, p.opt_str("symbols").unwrap_or(ADFGVX_SYMBOLS), SIDE)?;
        let square = square_of(p)?;
        let rank = key_ranks(p, variant)?;

        let raw: Vec<u8> = input
            .iter()
            .copied()
            .filter(|b| !b.is_ascii_whitespace())
            .collect();
        if raw.len() % syms.width() != 0 {
            return Err(Error::node_failed(
                NAME,
                format!(
                    "{} ciphertext bytes is not a whole number of {}-byte symbols",
                    raw.len(),
                    syms.width()
                ),
            ));
        }
        let coords: Vec<usize> = raw
            .chunks(syms.width())
            .map(|tok| {
                syms.index_of(tok).ok_or_else(|| {
                    Error::node_failed(
                        NAME,
                        format!(
                            "{:?} is not one of the coordinate symbols",
                            String::from_utf8_lossy(tok)
                        ),
                    )
                })
            })
            .collect::<Result<_>>()?;

        if coords.len() % 2 != 0 {
            return Err(Error::node_failed(
                NAME,
                format!(
                    "{} coordinate symbols is odd, so they cannot pair into square cells",
                    coords.len()
                ),
            ));
        }
        let flat = untranspose(&coords, &rank);
        Ok(flat
            .chunks(2)
            .map(|rc| square[rc[0] * SIDE + rc[1]])
            .collect())
    }

    fn encode(&self, input: &[u8], p: &Params) -> Result<Vec<u8>> {
        let variant = Variant::parse(p)?;
        let syms = Symbols::parse(NAME, p.opt_str("symbols").unwrap_or(ADFGVX_SYMBOLS), SIDE)?;
        let square = square_of(p)?;
        let rank = key_ranks(p, variant)?;

        let mut coords: Vec<usize> = Vec::with_capacity(input.len() * 2);
        for &b in input {
            if !b.is_ascii_alphanumeric() {
                continue;
            }
            let c = b.to_ascii_uppercase();
            let cell = square.iter().position(|&s| s == c).ok_or_else(|| {
                Error::node_failed(NAME, format!("{:?} has no cell in this square", b as char))
            })?;
            coords.push(cell / SIDE);
            coords.push(cell % SIDE);
        }
        let mixed = transpose(&coords, &rank);
        let mut out = Vec::with_capacity(mixed.len() * syms.width());
        for c in mixed {
            out.extend_from_slice(syms.symbol(c));
        }
        Ok(out)
    }
}

impl Node for Adfgvx {
    fn name(&self) -> &'static str {
        NAME
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/adfgvx(6x6-square,columnar-key,variant-parameterised)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }
    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let out = match params.opt_str("direction").unwrap_or("decode") {
            "decode" => self.decode(&input.data, params)?,
            "encode" => self.encode(&input.data, params)?,
            other => {
                return Err(Error::bad_param(
                    NAME,
                    "direction",
                    format!("expected \"decode\" or \"encode\", got {other:?}"),
                ))
            }
        };
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(ADFGVX => || Box::new(Adfgvx));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn adfgvx() -> &'static dyn Node {
        registry().get(NAME).unwrap()
    }

    const IDENTITY_SQUARE: &str = "0123456789abcdefghijklmnopqrstuvwxyz";

    #[test]
    fn is_xf_family_and_not_layer_forming() {
        let n = adfgvx();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    /// The declared `square` is authoritative over its arrangement (see the
    /// module docs: the *content* of a 36-cell ADFGVX square is fixed --
    /// always all 36 alphanumeric symbols -- but which symbol sits in which
    /// cell is entirely up to the parameter). A square with digits and
    /// letters interleaved, rather than grouped as `IDENTITY_SQUARE` groups
    /// them, produces a genuinely different ciphertext and still round
    /// trips -- a differential result, not merely a passing round trip,
    /// since a silently-ignored `square` would produce the *same*
    /// ciphertext as the identity arrangement regardless of what was
    /// declared.
    #[test]
    fn matches_a_differently_arranged_square() {
        let n = adfgvx();
        // every alphanumeric symbol, but digit/letter-interleaved rather
        // than digits-then-letters like IDENTITY_SQUARE
        let interleaved = "0a1b2c3d4e5f6g7h8i9jklmnopqrstuvwxyz";
        let enc_id = params! {
            "key" => "ZOMBIES", "square" => IDENTITY_SQUARE, "direction" => "encode",
        };
        let enc_alt = params! {
            "key" => "ZOMBIES", "square" => interleaved, "direction" => "encode",
        };
        let plain = Repr::bytes(b"attack123".to_vec());
        let ct_id = n.apply(&plain, &enc_id).unwrap();
        let ct_alt = n.apply(&plain, &enc_alt).unwrap();
        assert_ne!(
            ct_id.data, ct_alt.data,
            "a different declared square must change the ciphertext"
        );

        let dec_alt = params! {"key" => "ZOMBIES", "square" => interleaved};
        let back = n.apply(&ct_alt, &dec_alt).unwrap();
        assert_eq!(back.data, b"ATTACK123");
    }

    /// Ground truth from practicalcryptography.com's own `Encrypt()`/`Decrypt()`
    /// (`http://practicalcryptography.com/ciphers/classical-era/adfgvx/`),
    /// extracted verbatim and executed under Node against keysquare
    /// `"0123456789abcdefghijklmnopqrstuvwxyz"` (identity order) and keyword
    /// `"HELLO"` on plaintext `attackatdawn123`. The site's decrypt output is
    /// lowercase; this node uppercases by construction, so the comparison is
    /// on the uppercased text.
    #[test]
    fn matches_practicalcryptography_com_convention() {
        let n = adfgvx();
        let p = params! {
            "key" => "HELLO",
            "square" => IDENTITY_SQUARE,
            "variant" => "practicalcryptography",
        };
        let out = n
            .apply(&Repr::bytes(b"VDFFFADXGXXDVVDDGFXFVDXAVAVVAG".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"ATTACKATDAWN123");

        let enc = n
            .apply(
                &Repr::bytes(b"attackatdawn123".to_vec()),
                &params! {
                    "key" => "HELLO",
                    "square" => IDENTITY_SQUARE,
                    "variant" => "practicalcryptography",
                    "direction" => "encode",
                },
            )
            .unwrap();
        assert_eq!(enc.data, b"VDFFFADXGXXDVVDDGFXFVDXAVAVVAG");
    }

    /// Cross-check against the **2016** CrypTool Online ADFGVX tool
    /// (`docs/toolsites/cryptool2016/js/adfgvx.js`, `CTOAdfgvxAlgorithm`), run
    /// directly under Node (task scratchpad `jstest/run_adfgx.js`) against the
    /// same repeated-letter key, square, and plaintext as
    /// `matches_practicalcryptography_com_convention` above: it produces the
    /// identical ciphertext, confirming that 2016 CrypTool Online does not
    /// deduplicate a repeated key letter either -- the `practicalcryptography`
    /// variant (the default) is also this node's correct emulation of the
    /// 2016 CrypTool Online tool, with no third variant needed.
    #[test]
    fn matches_2016_cryptool_online_adfgvx_js() {
        let n = adfgvx();
        let p = params! {
            "key" => "HELLO",
            "square" => IDENTITY_SQUARE,
            "variant" => "practicalcryptography",
        };
        let out = n
            .apply(&Repr::bytes(b"VDFFFADXGXXDVVDDGFXFVDXAVAVVAG".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"ATTACKATDAWN123");
    }

    /// Ground truth from geocachingtoolbox.com's `adfgvxCipher()`
    /// (`docs/toolsites/geocachingtoolbox.json` index 0's `javascript` field),
    /// extracted verbatim and executed under Node against the same identity
    /// square and the same keyword `"HELLO"` and plaintext. The *ciphertext
    /// differs from practicalcryptography.com's* for exactly this input,
    /// because geocachingtoolbox deduplicates `"hello"` down to the
    /// four-column key `"helo"` before ranking, while
    /// practicalcryptography.com keeps all five letters of `"hello"` as five
    /// columns and breaks the tied pair of `l`s left-to-right. This is the
    /// pinned divergence between the two sites' ADFGVX tools.
    #[test]
    fn geocachingtoolbox_dedups_a_repeated_key_letter() {
        let n = adfgvx();
        let p = params! {
            "key" => "HELLO",
            "square" => IDENTITY_SQUARE,
            "variant" => "geocachingtoolbox",
        };
        let out = n
            .apply(&Repr::bytes(b"VXAVDFDGDVFDFXAAVDGVDGAXVFXVXF".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"ATTACKATDAWN123");

        let enc = n
            .apply(
                &Repr::bytes(b"attackatdawn123".to_vec()),
                &params! {
                    "key" => "HELLO",
                    "square" => IDENTITY_SQUARE,
                    "variant" => "geocachingtoolbox",
                    "direction" => "encode",
                },
            )
            .unwrap();
        assert_eq!(enc.data, b"VXAVDFDGDVFDFXAAVDGVDGAXVFXVXF");

        // and the two variants really do disagree on this key/message pair
        let pc = params! {
            "key" => "HELLO",
            "square" => IDENTITY_SQUARE,
            "variant" => "practicalcryptography",
            "direction" => "encode",
        };
        let pc_enc = n
            .apply(&Repr::bytes(b"attackatdawn123".to_vec()), &pc)
            .unwrap();
        assert_ne!(enc.data, pc_enc.data);
    }

    /// A key with no repeats has nothing for the two variants to disagree
    /// about: `prepare_key` differs only in dedup and alphabet, and neither
    /// matters when every letter is unique and already in a-z-minus-j.
    #[test]
    fn variants_agree_on_a_key_with_no_repeated_or_excluded_letters() {
        let n = adfgvx();
        let base = params! {
            "key" => "GERMAN",
            "square" => IDENTITY_SQUARE,
            "direction" => "encode",
        };
        let pc = n
            .apply(
                &Repr::bytes(b"attackatdawn".to_vec()),
                &params! {
                    "key" => "GERMAN",
                    "square" => IDENTITY_SQUARE,
                    "variant" => "practicalcryptography",
                    "direction" => "encode",
                },
            )
            .unwrap();
        let gtb = n
            .apply(
                &Repr::bytes(b"attackatdawn".to_vec()),
                &params! {
                    "key" => "GERMAN",
                    "square" => IDENTITY_SQUARE,
                    "variant" => "geocachingtoolbox",
                    "direction" => "encode",
                },
            )
            .unwrap();
        assert_eq!(pc.data, gtb.data);
        // sanity: the shared param set (no explicit variant) is the pc default
        let default = n.apply(&Repr::bytes(b"attackatdawn".to_vec()), &base).unwrap();
        assert_eq!(default.data, pc.data);
    }

    /// A ragged final row, same as `xf:adfgx`.
    #[test]
    fn handles_a_ragged_final_row() {
        let n = adfgvx();
        let enc = params! {"key" => "ZOMBIES", "square" => IDENTITY_SQUARE, "direction" => "encode"};
        let dec = params! {"key" => "ZOMBIES", "square" => IDENTITY_SQUARE};
        let plain = Repr::bytes(b"HELLO123".to_vec());
        let coded = n.apply(&plain, &enc).unwrap();
        assert_eq!(n.apply(&coded, &dec).unwrap().data, b"HELLO123");
    }

    #[test]
    fn rejects_malformed_parameters() {
        let n = adfgvx();
        let d = Repr::bytes(b"AA".to_vec());
        for bad in [
            params! {"key" => "BA", "square" => "TOOSHORT"},
            params! {"key" => "BA", "square" => format!("{}{}", IDENTITY_SQUARE, "0")},
            params! {"key" => "BA", "square" => "00123456789abcdefghijklmnopqrstuvwx"},
            params! {"key" => "", "square" => IDENTITY_SQUARE},
            params! {"key" => "123", "square" => IDENTITY_SQUARE}, // digits stripped, empty key
            params! {"key" => "BA", "square" => IDENTITY_SQUARE, "variant" => "sideways"},
            params! {"key" => "BA", "square" => IDENTITY_SQUARE, "direction" => "sideways"},
            Params::new(),
        ] {
            assert!(n.apply(&d, &bad).is_err(), "should have rejected {bad:?}");
        }
    }

    #[test]
    fn skips_whitespace_in_ciphertext() {
        let n = adfgvx();
        let p = params! {"key" => "BA", "square" => IDENTITY_SQUARE};
        assert_eq!(
            n.apply(&Repr::bytes(b"AD AA\n".to_vec()), &p).unwrap().data,
            n.apply(&Repr::bytes(b"ADAA".to_vec()), &p).unwrap().data
        );
    }
}
