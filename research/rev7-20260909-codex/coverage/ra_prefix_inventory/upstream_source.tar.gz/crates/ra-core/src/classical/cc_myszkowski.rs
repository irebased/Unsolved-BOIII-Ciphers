//! Crypto Corner's Myszkowski Transposition Cipher tool.
//!
//! Source: the page's own JavaScript, fetched directly (task scratchpad
//! `pages/cc_myszkowski_js.txt`). `MyszEncrypt`/`MyszDecrypt`/`keyMyszNumbers`
//! are transliterated verbatim below.
//!
//! # Column ordering: `keyMyszNumbers` (the actual Myszkowski distinction)
//!
//! ```js
//! for (i = 0; i < alphabet.length; i++) {
//!   u = 0;
//!   for (j = 0; j < key.length; j++)
//!     if (key[j] == alphabet[i]) { k[j] = a; u = u + 1; }
//!   if (u != 0) a = a + 1;
//! }
//! ```
//!
//! Unlike `cc_columnar.rs`'s `keyNumbers`, every column whose key letter
//! matches the current alphabet letter gets the **same** rank `a` — the rank
//! only advances once per distinct letter actually present in the key, not
//! once per column. This is Myszkowski's defining property: tied (repeated)
//! key letters form a *group* of columns read together, row by row, rather
//! than being ordered against each other by original position.
//!
//! # Grid fill and read-out
//!
//! `MyszEncrypt` fills the grid row-major exactly like `cc_columnar.rs`, but
//! reads a rank group out **row by row across all its columns**, not
//! column-by-column: `for i in 0..m { for j in cols_with_rank(kc) { push
//! grid[i][j] } }`. `MyszDecrypt` mirrors `cc_columnar.rs`'s `columnDecrypt`
//! exactly, just walking rank groups (possibly containing several columns)
//! instead of single columns, and filling row-major within a group instead of
//! column-major.
//!
//! # Case, nulls, engine direction
//!
//! Same conventions as `cc_columnar.rs`: upper-case internally, lower-case
//! the decrypted result (default `output_case: Lower`); nulls are an
//! encrypt-only convenience not modelled here; decrypt-direction engine with
//! [`encrypt`] reproduced test-only.
//!
//! # Stripping is the page's input normalisation, not the cipher
//!
//! Like `cc_columnar.rs`, this is a permutation of grid positions and needs
//! no alphabet for the message; the site's A-Z filtering is reproduced by
//! default (site fidelity) via [`crate::classical::toolfmt`]'s
//! `strip_non_alphabet` param — set it `false` to run the same permutation
//! over any medium, verified in
//! `cc_myszkowski_preserves_hex_medium_when_stripping_disabled` below.

use crate::classical::toolfmt::{read_output_fmt, CaseFold, InputNorm, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

const CC_MYSZKOWSKI_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(ParamSpec::req(
    "key",
    ParamType::Str,
    "transposition keyword (letters A-Z only; non-letter characters are dropped)"
),);

const ALPHABET: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZ";

/// `keyMyszNumbers`, transliterated: repeated key letters share one rank.
fn key_mysz_numbers(key: &[u8]) -> Vec<usize> {
    let mut ranks = vec![0usize; key.len()];
    let mut a = 1usize;
    for &alpha_c in ALPHABET {
        let mut used = false;
        for (j, &kc) in key.iter().enumerate() {
            if kc == alpha_c {
                ranks[j] = a;
                used = true;
            }
        }
        if used {
            a += 1;
        }
    }
    ranks
}

/// `MyszDecrypt`, transliterated from `pages/cc_myszkowski_js.txt`.
pub fn decrypt(ctext: &[u8], key: &[u8]) -> Result<Vec<u8>> {
    if key.is_empty() {
        return Err(Error::bad_param("cc_myszkowski", "key", "must not be empty"));
    }
    let klen = key.len();
    let m = ctext.len().div_ceil(klen);
    let mut count = ctext.len();
    while count % klen != 0 {
        count += 1;
    }
    let count = count - ctext.len() + 1;

    #[derive(Clone, Copy, PartialEq)]
    enum Cell {
        Empty,
        Blank,
        Char(u8),
    }
    let mut grid = vec![vec![Cell::Empty; klen]; m];

    for j in 0..count {
        if j < klen {
            let idx = klen - j;
            if idx < klen {
                grid[m - 1][idx] = Cell::Blank;
            }
        }
    }

    let keyn = key_mysz_numbers(key);
    let maxv = *keyn.iter().max().unwrap_or(&0);
    let mut q = 0usize;
    for kc in 1..=maxv {
        for row in grid.iter_mut().take(m) {
            for (j, &rank) in keyn.iter().enumerate() {
                if rank == kc && row[j] == Cell::Empty {
                    if q == ctext.len() {
                        continue;
                    }
                    row[j] = Cell::Char(ctext[q]);
                    q += 1;
                }
            }
        }
    }

    for cell in grid[m - 1].iter_mut().take(klen) {
        if *cell == Cell::Blank {
            *cell = Cell::Empty;
        }
    }

    let mut out = Vec::with_capacity(ctext.len());
    for row in &grid {
        for cell in row.iter().take(klen) {
            if let Cell::Char(c) = cell {
                out.push(*c);
            }
        }
    }
    Ok(out)
}

/// `MyszEncrypt`, transliterated the same way. Test-only.
#[cfg(test)]
fn encrypt(ptext: &[u8], key: &[u8]) -> Vec<u8> {
    let klen = key.len();
    let m = ptext.len().div_ceil(klen);
    let mut grid = vec![vec![None::<u8>; klen]; m];
    let mut q = 0usize;
    for row in grid.iter_mut().take(m) {
        for cell in row.iter_mut().take(klen) {
            if q < ptext.len() {
                *cell = Some(ptext[q]);
            }
            q += 1;
        }
    }
    let keyn = key_mysz_numbers(key);
    let maxv = *keyn.iter().max().unwrap_or(&0);
    let mut out = Vec::with_capacity(ptext.len());
    for kc in 1..=maxv {
        for row in grid.iter().take(m) {
            for (j, &rank) in keyn.iter().enumerate() {
                if rank == kc {
                    if let Some(c) = row[j] {
                        out.push(c);
                    }
                }
            }
        }
    }
    out
}

/// Crypto Corner's Myszkowski Transposition Cipher tool, decrypting.
pub struct CcMyszkowski;

impl Node for CcMyszkowski {
    fn name(&self) -> &'static str {
        "cc_myszkowski"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CC_MYSZKOWSKI_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = params.req_str("cc_myszkowski", "key")?;
        let key: Vec<u8> = key
            .to_uppercase()
            .bytes()
            .filter(|b| ALPHABET.contains(b))
            .collect();
        if key.is_empty() {
            return Err(Error::bad_param(
                "cc_myszkowski",
                "key",
                "no letters remain in the key after filtering to A-Z",
            ));
        }

        let in_norm = crate::classical::toolfmt::read_input_norm(
            "cc_myszkowski",
            params,
            InputNorm {
                case: CaseFold::Upper,
                strip_outside_alphabet: Some("ABCDEFGHIJKLMNOPQRSTUVWXYZ".to_string()),
                ..InputNorm::default()
            },
        )?;
        let text = in_norm.apply(&input.data);

        let plain = decrypt(&text, &key)?;

        let out_fmt: OutputFmt = read_output_fmt(
            "cc_myszkowski",
            params,
            OutputFmt {
                case: CaseFold::Lower,
                grouping: None,
                trailing: Trailing::None,
            },
        )?;
        let out = out_fmt.apply(&plain);
        Ok(Repr::new(out, input.display))
    }
}

register_node!(CC_MYSZKOWSKI => || Box::new(CcMyszkowski));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    /// Ground truth: direct Python transliteration of the fetched JS (task
    /// scratchpad `cc_oracle.py`), run and cross-checked here.
    #[test]
    fn cc_myszkowski_oracle_vector() {
        let pt = b"TOMORROWISTHEDAY";
        let key = b"TIN";
        let ct = encrypt(pt, key);
        assert_eq!(ct, b"ORWTDMRIHATOOSEY");
        let back = decrypt(&ct, key).unwrap();
        assert_eq!(back, pt);
    }

    /// The defining behaviour: with a key that has no repeated letters,
    /// Myszkowski degenerates to ordinary columnar ordering (each rank group
    /// has exactly one column), so it should agree with `cc_columnar`'s
    /// oracle vector.
    #[test]
    fn cc_myszkowski_matches_columnar_when_key_has_no_repeats() {
        let pt = b"DEFENDTHEEASTWALLOFTHECASTLE";
        let key = b"GERMAN";
        let ct = encrypt(pt, key);
        assert_eq!(ct, b"NALCEHWTTDTTFSEELEEDSOAFEAHL"); // from cc_columnar.rs
    }

    #[test]
    fn cc_myszkowski_round_trips_varied_keys_and_lengths() {
        let samples: &[&[u8]] = &[
            b"A",
            b"AB",
            b"ATTACKATDAWN",
            b"THEQUICKBROWNFOXJUMPSOVERTHELAZYDOGTWICE",
        ];
        let keys: &[&[u8]] = &[b"TIN", b"TOM", b"AABBC", b"A", b"BAB"];
        for pt in samples {
            for key in keys {
                let ct = encrypt(pt, key);
                let back = decrypt(&ct, key).unwrap();
                assert_eq!(&back, pt, "pt={pt:?} key={key:?}");
            }
        }
    }

    #[test]
    fn cc_myszkowski_node_decrypts_lowercasing_output() {
        let pt = b"TOMORROWISTHEDAY";
        let ct = encrypt(pt, b"TIN");
        let n = registry().get("cc_myszkowski").unwrap();
        let p = params! {"key" => "TIN"};
        let out = n.apply(&Repr::bytes(ct), &p).unwrap();
        assert_eq!(
            String::from_utf8(out.data).unwrap(),
            String::from_utf8(pt.to_ascii_lowercase()).unwrap()
        );
    }

    #[test]
    fn cc_myszkowski_rejects_key_with_no_letters() {
        let n = registry().get("cc_myszkowski").unwrap();
        let p = params! {"key" => "123"};
        assert!(n.apply(&Repr::bytes(b"XYZ".to_vec()), &p).is_err());
    }

    #[test]
    fn cc_myszkowski_preserves_display() {
        let ct = encrypt(b"TOMORROWISTHEDAY", b"TIN");
        let n = registry().get("cc_myszkowski").unwrap();
        let p = params! {"key" => "TIN"};
        let out = n.apply(&Repr::new(ct, Display::Hex), &p).unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    /// The payoff: with `strip_non_alphabet` explicitly disabled, this
    /// transposition operates on any medium, not just A-Z text -- proven here
    /// against a 1092-character hex string, the length of rev7's ciphertext.
    #[test]
    fn cc_myszkowski_preserves_hex_medium_when_stripping_disabled() {
        let hex: String = (0..1092).map(|i| "0123456789ABCDEF".as_bytes()[i % 16] as char).collect();
        let n = registry().get("cc_myszkowski").unwrap();
        let p = params! {
            "key" => "ZOMBIES",
            "strip_non_alphabet" => false,
            "output_case" => "preserve",
        };
        let out = n.apply(&Repr::bytes(hex.clone().into_bytes()), &p).unwrap();
        assert_eq!(out.data.len(), 1092);
        let mut want: Vec<u8> = hex.into_bytes();
        want.sort();
        let mut got = out.data.clone();
        got.sort();
        assert_eq!(got, want, "must be a pure permutation: same multiset of bytes");
    }

    #[test]
    fn cc_myszkowski_is_xf_family_and_not_layer_forming() {
        let n = registry().get("cc_myszkowski").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
