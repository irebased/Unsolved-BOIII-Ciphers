# REV11: the seven-step classical chain, reproduced end to end

**Result: POSITIVE.** All seven recorded steps are settled and rev11 now reproduces
from the raw corpus ciphertext to the recorded plaintext. Two parameters that the
corpus does not record — the Trifid alphabet and its period — were recovered, and
three of the recorded step *descriptions* turn out to be wrong in ways that matter.

Reproduce with:

```bash
ra conformance --prim Playfair/Trifid
ra run --target rev11 --trace "reverse | rot:n=20 | playfair:key=ZOMBIES \
  | remove_character:char=x,positions=31;133;179;215;235;345;383;427;459 \
  | replace_character:from=i,to=j,positions=10;21;63;66;169;177;189;227;250;296;337;340;353;373;386;387;422;433 \
  | insert_characters:char=.,positions=46;83;165;179;201;222;233;241;264;270;352 \
  | trifid:alphabet=adgbehcfijmpknqlorsvytwzux.,period=0"
```

---

## 1. Step-by-step status

| step | recorded | status | how it was settled |
|---|---|---|---|
| 1 | `reverse` | settled, as recorded | direct |
| 2 | `rot`, shift 6 | settled, **as ROT-20** | corpus convention, confirmed below |
| 3 | `playfair`, key `ZOMBIES` | settled, as recorded | reproduces the record's step-4 input |
| 4 | `remove_character` | settled, **description wrong** | positions diffed out of the record's own outputs |
| 5 | `replace character` | settled, description vague but right | as above |
| 6 | `insert_characters` | settled, as recorded | as above |
| 7 | `Trifid` | settled, **both parameters recovered** | constraint solve, §4 |

Nothing resisted. Length arithmetic ties the whole chain together and is worth
stating once, because it is what makes each intermediate checkable:

```
689 ciphertext chars = 460 letters (230 digraphs) + 229 spaces
460 Playfair-decrypted letters
451 after step 4 (9 X removals)
451 after step 5 (18 substitutions, length-preserving)
462 after step 6 (11 periods inserted)
462 after step 7 (Trifid is length-preserving)
```

460 = 451 + 8 doubling pads + 1 tail pad. The 451 is forced by the ciphertext and the
462 by the Playfair output, which is why the *recorded plaintext* (464 normalised
characters) cannot be exactly right — see §5.

## 2. Step 2 follows the corpus convention

The recorded shift is the **encryption** shift, so decryption applies its inverse:
ROT-20, not ROT-6. This is the same convention rev12's documented "shift 6" already
established. It is not a judgement call here — `rot:n=6` decrypts to 460 letters of
noise (`tmgilmefbgngankcfsnfvrqurcantzq...`, which no sequence of character edits
turns into a Trifid ciphertext), and `rot:n=20` produces the record's own step-4 input
character for character.

## 3. Steps 4-6 exist because Playfair is lossy

Playfair encryption destroys three things: every non-alphabetic character, the
distinction between the two merged letters (`J`/`I`), and the spacing of doubled
letters (split by an `X`, plus one appended to an odd-length input). Steps 4, 5 and 6
are the hand repair of exactly those three losses. The positions are not recorded
anywhere; they were recovered by diffing the record's consecutive step outputs against
each other, and all three then reproduce those outputs exactly.

**Step 4's recorded note is wrong in both counts.** It reads "Remove all but one
'probable padding' X between doubles". The Playfair output has ten X's flanked by two
identical letters. Eight are removed. **Two** are kept (offsets 61 and 172), not one.
The record's step-4 output capitalises the first of them — that upper-case `X` is where
"all but one" comes from — and then keeps the second silently.
And the ninth removal, at offset 459, is not between doubles at all — it is the last
character of the 460-letter stream, the odd-length tail pad. So a node that implemented
the note as a *rule* would remove the wrong nine characters, which is the concrete
reason `remove_character` takes explicit positions and treats `between_doubles` as an
optional guard rather than its semantics.

Step 5's "Replace some I with J" is eighteen replacements. Step 6 inserts eleven
periods; they exist because the inner Trifid's alphabet has 27 symbols and the 27th is
`.`, so Playfair swallowed them all.

## 4. Trifid: both parameters are RECOVERED, not documented

The record names the step "Trifid", gives its output, and records neither the alphabet
nor the period. Recovered values:

| parameter | value | note |
|---|---|---|
| alphabet | `adgbehcfijmpknqlorsvytwzux.` | `a`..`z` then `.`, filled **down the columns** of the three 3x3 squares |
| period | whole message as one block (`period=0`, equivalently 462) | unique in `2..=462` |

```text
  a d g     j m p     s v y
  b e h     k n q     t w z
  c f i     l o r     u x .
```

Written flat the alphabet looks arbitrary; it is not. It is the plain 27-symbol
alphabet laid in column-wise instead of row-wise — equivalently, a tool that reads the
row and column coordinates in the opposite order to the textbook. That is a *tool
fingerprint*, and it is consistent with `papers/paper1_historical.js`'s note that
Braingle, the corpus's suspected Trifid tool, implements a "non-standard Trifid
ruleset". The engine's `trifid` node keeps the textbook convention (it is checked
against the published `FELIXMARDSTBCGHJKNOPQUVWYZ+` / period 5 /
`AIDETOILECIELTAIDERA` -> `FMJFVOISSUFTFPUFEQQC` vector) and carries the deviation in
the alphabet parameter, where it is visible.

### How the recovery was done, and why it is not a solver

Not by searching alphabets: 27! is unreachable, and a search would make the node
`Family::Solver` with heuristic coverage. It was solved as a constraint system.

For a candidate period the transform is a **fixed permutation of base-3 digit slots**.
Each ciphertext/plaintext position pair therefore asserts an *equality between one
digit of one alphabet symbol and one digit of another*. Union-find over the 81 digit
slots (27 symbols x 3 digits) collapses those equalities. A correct period leaves
exactly 3 classes of exactly 27 slots each, and the 27 symbols then carry 27 distinct
coordinate triples — which is the alphabet, up to the 3! relabellings of the digit
values, all six of which decrypt identically.

The discriminator is sharp. Validated on synthetic Trifid pairs, the correct period
yields 3 classes and ~760 distinct asserted edges; every wrong period collapses to a
single class with ~1100 edges, and the signature survives up to ~20 injected
substitution errors. On rev11 exactly one period in `2..=462` produced the structure,
and it reproduces the record at **462 of 462 symbols** — exact, not a similarity score.
The inverse direction also regenerates the record's step-6 output exactly, which
exercises the encryption path independently.

### What was ruled out along the way

The first sweep found nothing, and the reason is worth recording so nobody repeats it:
**periods 2..119 were searched before the whole-message case was.** The answer sits at
period = message length, which a period sweep bounded at any "reasonable" value misses
entirely. Explicitly eliminated:

- **Standard Delastelle Trifid at every period 2..119** — no structure, and a
  maximum-satisfied-partition optimisation (Kernighan-Lin style, group sizes fixed at
  27) scores a flat 0.46-0.48 of assertions satisfied for every one of them, against a
  shuffled-plaintext baseline of the same value. That is the noise floor, measured
  rather than assumed.
- **All 36 row-order / digit-order conventions** at every period 2..119, both
  directions (`s6 -> s7` as decryption and as encryption).
- **A digit-stream columnar variant** (concatenate all coordinates, transpose through a
  P-column grid, regroup in threes) at every period 2..299.
- **918 keyed alphabet candidates** attacked from the plaintext side — keys `zombies`,
  `revelations`, `apothicon`, `primis`, `richtofen`, `maxis`, `pablo`, `pablomarinus`,
  `thegiant`, `staves`, `shadowman`, `keeper`, `agarthan`, `giant`, `margwa`, forwards
  and reversed, with `.` at each of the 27 positions, x periods 2..60. Best score 8.4%
  against a ~4% chance baseline: nothing.
- **Bifid** — excluded structurally, since step 6's output uses all 27 symbols and a
  Bifid square holds 25.
- **Periods treated as passthrough separators rather than alphabet symbols** —
  excluded by counting: step 6's output has 11 periods and the plaintext has 10, so
  they cannot be positionally preserved.

## 5. Similarity to the recorded plaintext, and which side is wrong

Normalised (alphanumerics and `.`, lowercased) the reproduction and the recorded
plaintext agree at **0.9935**, differing in exactly three places out of 464:

| recorded plaintext | this chain | size |
|---|---|---|
| "the four called **Primis**" | "prim**u**s" | 1 char |
| "surge of **strenght**" | "streng**th**" | 2 chars transposed |
| "I saw all **of** humanity" | "isawall humanity" | 2 chars absent |

All three are drift in the *record*, not in the chain, and the length arithmetic of §1
settles it: the chain's output length is forced to 462 by the 460-letter Playfair
output, while the recorded plaintext normalises to 464. The record's own step-7 output
field agrees with this chain at all 462 characters — it is the `plaintext` field that
has been tidied toward the presumed in-game wording. This is the same class of defect
as rev6's recorded substitution alphabet and rev8's undocumented corrupted byte, and it
is why the conformance check compares on a normalised substring rather than for
equality.

## 6. Coverage semantics

All five new nodes are `Family::Xf` and none is layer-forming, so `ra run --trace`
correctly reports **0 layer boundaries crossed** for this chain: it is seven
representation-preserving transforms, not a cascade of decryptions. rev11's
conformance vector accordingly carries **no primitive coverage** — `ra conformance`
still reports 11 of 11 primitives and reports the classical vector separately, because
folding a classical reproduction into the primitive count would over-claim exactly the
way conformance gating exists to prevent.

The nodes are worth having beyond rev11: Playfair and Trifid are both plausible
TG4/REV7 components, and the three edit nodes generalise the transcription-repair
dimension that `ra repair` already treats as coverage rather than preprocessing.
