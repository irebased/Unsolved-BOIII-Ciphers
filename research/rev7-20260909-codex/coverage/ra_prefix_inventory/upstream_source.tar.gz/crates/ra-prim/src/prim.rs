//! Primitive abstraction, geometry table, and instantiation.
//!
//! Primitives are reached through this crate's own traits rather than the
//! `cipher` traits, so that hand-written implementations (Rijndael-256, XTEA, RC4)
//! and RustCrypto crates sit behind one interface and the mode engine stays
//! agnostic.

use serde::{Deserialize, Serialize};

use crate::loki97::Loki97;
use crate::rc2::MCRYPT_RC2_EFF_KEY_BITS;
use crate::rc4::Rc4;
use crate::rijndael::Rijndael;
use crate::saferplus::Saferplus;
use crate::salsa20::Salsa20Prim;
use crate::xtea::Xtea;

/// A block cipher: a keyed permutation on a fixed-size block.
///
/// Only `encrypt_block` is needed by the feedback modes; CFB and OFB use the
/// forward permutation in both directions.
pub trait BlockPrim: Send + Sync {
    fn block_size(&self) -> usize;
    fn encrypt_block(&self, block: &mut [u8]);
    fn decrypt_block(&self, block: &mut [u8]);
}

pub trait StreamPrim: Send + Sync {
    fn apply_keystream(&self, data: &mut [u8]);
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum PrimKind {
    Block,
    Stream,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum ImplStatus {
    /// Backed by a real implementation in this build.
    Implemented,
    /// Registered so the registry, coverage vocabulary and conformance gating can
    /// all *see* the primitive, but with no implementation behind it. Executing it
    /// errors, and any coverage claimed over it is void by construction.
    ///
    /// This is preferable to omitting it: a primitive absent from the vocabulary
    /// would silently shrink the universe, making the residual look smaller than it
    /// is. Declared-but-unimplemented keeps the universe honest.
    Declared,
}

// Serialize only: the `&'static [usize]` field cannot be deserialised, and this
// table is compiled-in truth rather than configuration.
#[derive(Clone, Copy, Debug, Serialize)]
pub struct PrimInfo {
    /// Name as written in the corpus and in coverage claims.
    pub display_name: &'static str,
    /// libmcrypt's own algorithm name.
    pub mcrypt_name: &'static str,
    pub block_size: usize,
    /// What libmcrypt's `mcrypt_enc_get_key_size` reports: the *maximum*.
    pub max_key_size: usize,
    /// Discrete supported key sizes. Empty means any length up to the maximum.
    pub supported_key_sizes: &'static [usize],
    pub kind: PrimKind,
    pub status: ImplStatus,
    /// Provenance of the backing implementation, folded into the node's
    /// implementation hash so two independent implementations are distinguishable.
    pub impl_source: &'static str,
    pub version: &'static str,
    /// Citation for a **normative test vector** this implementation is checked
    /// against — the algorithm's own published vector, not a corpus reproduction.
    ///
    /// `None` means no such vector is cited here, whether or not one exists in
    /// principle: this field only carries what has actually been checked. It is the
    /// second, independent proof of *implementation correctness* this workspace
    /// admits (`ra_attest::ProvenClass::VectorProven`), distinct from — and never
    /// substituting for — the question conformance's corpus reproduction answers,
    /// which is "did the puzzle author use this primitive". See ARCHITECTURE.md's
    /// "Two conformance classes" for why the two are kept apart. The vectors
    /// themselves live beside the primitive's tests, e.g.
    /// `rijndael_128_matches_fips197_and_libmcrypt_self_test` below.
    pub vector_proof: Option<&'static str>,
}

/// The eleven primitives confirmed in the solved corpus.
pub static PRIMS: &[PrimInfo] = &[
    PrimInfo {
        display_name: "DES",
        mcrypt_name: "des",
        block_size: 8,
        max_key_size: 8,
        supported_key_sizes: &[8],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        impl_source: "RustCrypto/des",
        version: "0.8.1",
        vector_proof: None,
    },
    PrimInfo {
        display_name: "RC2",
        mcrypt_name: "rc2",
        block_size: 8,
        // libmcrypt's rc2.c: `_mcrypt_get_key_size` returns 128 and
        // `_mcrypt_get_supported_key_sizes` returns NULL/0, so any length 1..=128 is
        // accepted and a 7-byte key is passed through unpadded.
        max_key_size: 128,
        supported_key_sizes: &[],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        // The parameterisation is part of the identity: the same crate at the same
        // version with RFC 2268's default effective key bits is a *different cipher*
        // and does not reproduce rev5. See the `rc2` module.
        impl_source: "RustCrypto/rc2(eff-key-bits=1024)",
        version: "0.8.1+mcrypt-effkeybits",
        vector_proof: None,
    },
    PrimInfo {
        display_name: "RC4",
        mcrypt_name: "arcfour",
        block_size: 1,
        max_key_size: 256,
        supported_key_sizes: &[],
        kind: PrimKind::Stream,
        status: ImplStatus::Implemented,
        impl_source: "ra-prim/rc4",
        version: "1.0.0",
        vector_proof: None,
    },
    PrimInfo {
        display_name: "Blowfish",
        mcrypt_name: "blowfish",
        block_size: 8,
        max_key_size: 56,
        supported_key_sizes: &[],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        impl_source: "RustCrypto/blowfish(BE)",
        version: "0.9.1",
        vector_proof: None,
    },
    PrimInfo {
        display_name: "Blowfish-compat",
        mcrypt_name: "blowfish-compat",
        block_size: 8,
        max_key_size: 56,
        supported_key_sizes: &[],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        // mcrypt's "compat" variant is the little-endian word-order Blowfish.
        impl_source: "RustCrypto/blowfish(LE)",
        version: "0.9.1",
        vector_proof: None,
    },
    PrimInfo {
        display_name: "Twofish",
        mcrypt_name: "twofish",
        block_size: 16,
        max_key_size: 32,
        supported_key_sizes: &[16, 24, 32],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        impl_source: "RustCrypto/twofish",
        version: "0.7.1",
        vector_proof: None,
    },
    PrimInfo {
        display_name: "Serpent",
        mcrypt_name: "serpent",
        block_size: 16,
        max_key_size: 32,
        supported_key_sizes: &[16, 24, 32],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        impl_source: "RustCrypto/serpent",
        version: "0.5.1",
        vector_proof: None,
    },
    PrimInfo {
        display_name: "Rijndael-256",
        mcrypt_name: "rijndael-256",
        block_size: 32,
        max_key_size: 32,
        supported_key_sizes: &[16, 24, 32],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        impl_source: "ra-prim/rijndael(variable-block)",
        version: "1.0.0",
        vector_proof: None,
    },
    // Rijndael-128 is AES: the 128-bit-block configuration of the same variable-block
    // Rijndael engine that backs Rijndael-256. libmcrypt's `rijndael-128.c` reports a
    // *maximum* key size of 32 (its `_mcrypt_get_key_size` always returns 32,
    // regardless of algorithm), with the same {16,24,32} discrete sizes as every
    // other Rijndael/AES key length. See `crate::rijndael`, tested against
    // FIPS-197 Appendix C.1/C.3 and libmcrypt's own compiled-in self-test vector
    // (key 01 00...00, plaintext 00..0f -> `5352e43763eec1a8502433d6d520b1f0`).
    PrimInfo {
        display_name: "AES",
        mcrypt_name: "rijndael-128",
        block_size: 16,
        max_key_size: 32,
        supported_key_sizes: &[16, 24, 32],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        impl_source: "ra-prim/rijndael(variable-block)",
        version: "1.0.0",
        // VECTOR-PROVEN: FIPS-197 Appendix C.1, plus libmcrypt's own compiled-in
        // `rijndael-128.c` self-test. No solved corpus cipher uses AES, so this is
        // the ONLY proof this implementation has ever had — see
        // `rijndael_128_matches_fips197_and_libmcrypt_self_test` below.
        vector_proof: Some(
            "FIPS-197 Appendix C.1; libmcrypt rijndael-128.c compiled-in self-test",
        ),
    },
    PrimInfo {
        display_name: "XTEA",
        mcrypt_name: "xtea",
        block_size: 8,
        max_key_size: 16,
        supported_key_sizes: &[16],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        impl_source: "ra-prim/xtea(textbook)",
        version: "1.0.0",
        vector_proof: None,
    },
    // A direct port of libmcrypt's own loki97.c, checked against libmcrypt's
    // compiled-in self-test vector and against rev5's known plaintext end to end.
    // Note that libmcrypt's key schedule is the 256-bit one for every key size and
    // reads a zeroed 32-byte buffer, so Loki97 cannot discriminate between the two
    // null-padding derivation policies. See the `loki97` module.
    PrimInfo {
        display_name: "Loki97",
        mcrypt_name: "loki97",
        block_size: 16,
        max_key_size: 32,
        supported_key_sizes: &[16, 24, 32],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        impl_source: "ra-prim/loki97(libmcrypt-port)",
        version: "1.0.0",
        vector_proof: None,
    },
    // A direct port of libmcrypt's own saferplus.c, checked against libmcrypt's
    // compiled-in self-test vector and against rev10's known plaintext end to end.
    PrimInfo {
        display_name: "Saferplus",
        mcrypt_name: "saferplus",
        block_size: 16,
        max_key_size: 32,
        supported_key_sizes: &[16, 24, 32],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        impl_source: "ra-prim/saferplus(libmcrypt-port)",
        version: "1.0.0",
        vector_proof: None,
    },
    // Standard DES-EDE3 (three independent 8-byte keys, encrypt-decrypt-encrypt).
    // libmcrypt's tripledes.c reports both `_mcrypt_get_key_size` and its single
    // supported key size as 24 - there is no shorter form, unlike DES itself - so
    // every key-derivation policy converges once the key is at least 24 bytes.
    // Checked against libmcrypt's own compiled-in self-test vector.
    PrimInfo {
        display_name: "3DES",
        mcrypt_name: "tripledes",
        block_size: 8,
        max_key_size: 24,
        supported_key_sizes: &[24],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        impl_source: "RustCrypto/des(TdesEde3)",
        version: "0.8.1",
        // VECTOR-PROVEN: libmcrypt's own compiled-in `tripledes.c` self-test,
        // independently cross-checked against PyCryptodome's `DES3`. No solved
        // corpus cipher uses 3DES, so this is the only proof it has —
        // `tripledes_matches_libmcrypt_self_test` below.
        vector_proof: Some(
            "libmcrypt tripledes.c compiled-in self-test, cross-checked against \
             PyCryptodome DES3",
        ),
    },
    // CAST-128 (RFC 2144). Present in libmcrypt's menu and on the
    // openssl_encrypt()-backed forms our tool inventory records. No solved corpus
    // cipher uses it, so it remains outside CorpusProven — but it is checked against
    // RFC 2144 Appendix B.1's own published test vector (all three key sizes), so it
    // is VECTOR-PROVEN: see `cast128_matches_rfc2144_appendix_b1` below. Conformance
    // gating still withholds CorpusProven coverage for it by design; VectorProven
    // coverage is a distinct, weaker figure and is reported as such.
    PrimInfo {
        display_name: "CAST-128",
        mcrypt_name: "cast-128",
        block_size: 8,
        max_key_size: 16,
        supported_key_sizes: &[16],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        impl_source: "RustCrypto/cast5",
        version: "1.0.0",
        vector_proof: Some("RFC 2144 Appendix B.1 (128/80/40-bit key vectors)"),
    },
    // IDEA (Lai-Massey, 64-bit block, 128-bit key). On the openssl_encrypt()
    // menu our tool inventory records for tools4noobs' successor, and absent
    // here until now, so never tested against either unsolved cipher.
    // UNPROVEN, in BOTH conformance classes: no corpus cipher reproduces it, and no
    // authoritative encrypt/decrypt vector was located for it within this workspace
    // to check the implementation against. IDEA has no RFC of its own the way
    // CAST-128 does; the upstream `idea` crate's own test suite pins only the *key
    // schedule* against the original Lai-Massey description (`src/tests.rs`,
    // `test_sub_key_generation`), not a full block encrypt/decrypt against a
    // published ciphertext, so it does not by itself establish VectorProven either.
    // Left here as an honest gap rather than asserted: see ARCHITECTURE.md's
    // conformance section. If a citable vector turns up later, add it beside a test
    // the way `cast128_matches_rfc2144_appendix_b1` does, and set `vector_proof`.
    //
    // Appended at the END of PRIMS deliberately. `dec_node!` in nodes.rs
    // registers by INDEX into this array, so a mid-array insert silently
    // repoints every later node at the wrong primitive - no error, just wrong
    // output. Append, then regenerate the index list.
    PrimInfo {
        display_name: "IDEA",
        mcrypt_name: "idea",
        block_size: 8,
        max_key_size: 16,
        supported_key_sizes: &[16],
        kind: PrimKind::Block,
        status: ImplStatus::Implemented,
        impl_source: "RustCrypto/idea",
        version: "1.0.0",
        vector_proof: None,
    },
    // Salsa20 (Bernstein): a stream cipher, and NOT in libmcrypt's menu at all --
    // it comes from `https://www.unit-conversion.info/texttools/salsa/`, a
    // cipher-authoring tool the corpus author is now known to have used (see
    // `docs/layering-pattern-analysis.md` §8sexies). Because it is outside the
    // mcrypt menu, no negative result recorded anywhere else in this repository
    // says anything about it. Only the 32-byte-key variant is implemented; see
    // that module's doc for why the 16-byte-key variant is a deliberate gap.
    //
    // VECTOR-PROVEN, and it is the clearest case for why that class has to
    // exist: no corpus cipher uses Salsa20 and none ever can, since the corpus
    // predates our knowledge of the tool it came from. Requiring corpus
    // reproduction would withhold its coverage permanently, which is exactly
    // the circularity the two-class model corrects -- an unsolved cipher may
    // use a primitive the solved ones never did. Bernstein's reference vectors
    // are the normative definition of the algorithm and settle correctness on
    // their own; see `published_vector_*` in the `salsa20` module.
    PrimInfo {
        display_name: "Salsa20",
        mcrypt_name: "salsa20",
        block_size: 1,
        max_key_size: 32,
        supported_key_sizes: &[32],
        kind: PrimKind::Stream,
        status: ImplStatus::Implemented,
        impl_source: "RustCrypto/salsa20",
        version: "0.11.0",
        vector_proof: Some(
            "Bernstein's Salsa20 reference vectors (key1/iv0, key0/iv1, key0/iv-hi, \
             and a four-block long-key/nonce vector), as pinned in RustCrypto salsa20",
        ),
    },
];

/// Look up a primitive by either its mcrypt name or its display name, case-insensitively.
pub fn prim_info(name: &str) -> Option<&'static PrimInfo> {
    PRIMS.iter().find(|p| {
        p.mcrypt_name.eq_ignore_ascii_case(name) || p.display_name.eq_ignore_ascii_case(name)
    })
}

pub fn implemented() -> impl Iterator<Item = &'static PrimInfo> {
    PRIMS.iter().filter(|p| p.status == ImplStatus::Implemented)
}

/// Primitives checked against the algorithm's own normative test vector, i.e.
/// [`PrimInfo::vector_proof`] is populated.
///
/// This is deliberately a different question from `ra-cli`'s corpus-driven
/// conformance: it says nothing about whether any puzzle uses the primitive, only
/// that the implementation matches the algorithm's own published answer. See
/// `ra_attest::ProvenClass::VectorProven`.
pub fn vector_proven() -> impl Iterator<Item = &'static PrimInfo> {
    PRIMS.iter().filter(|p| p.vector_proof.is_some())
}

#[derive(Debug, thiserror::Error)]
pub enum PrimError {
    #[error("unknown primitive '{0}'")]
    Unknown(String),
    #[error(
        "primitive '{0}' is declared but not implemented in this build; it can carry no coverage"
    )]
    NotImplemented(&'static str),
    #[error("primitive '{prim}' rejected a {len}-byte key (supported: {supported})")]
    BadKeyLength {
        prim: &'static str,
        len: usize,
        supported: String,
    },
    #[error("'{0}' is a stream cipher; use instantiate_stream")]
    IsStream(&'static str),
    #[error("'{0}' is a block cipher; use instantiate_block")]
    IsBlock(&'static str),
    #[error("'{prim}' rejected mode '{mode}': {source}")]
    ModeInapplicable {
        prim: &'static str,
        mode: &'static str,
        #[source]
        source: crate::mode::ModeError,
    },
}

// ---------------------------------------------------------------------------
// RustCrypto adapter
// ---------------------------------------------------------------------------
use cipher::generic_array::GenericArray;
use cipher::{BlockDecrypt, BlockEncrypt, BlockSizeUser, KeyInit};

struct Wrap<C>(C);

impl<C> BlockPrim for Wrap<C>
where
    C: BlockEncrypt + BlockDecrypt + BlockSizeUser + Send + Sync + 'static,
{
    fn block_size(&self) -> usize {
        <C as BlockSizeUser>::block_size()
    }
    fn encrypt_block(&self, block: &mut [u8]) {
        BlockEncrypt::encrypt_block(&self.0, GenericArray::from_mut_slice(block));
    }
    fn decrypt_block(&self, block: &mut [u8]) {
        BlockDecrypt::decrypt_block(&self.0, GenericArray::from_mut_slice(block));
    }
}

fn wrap<C>(key: &[u8]) -> Option<Box<dyn BlockPrim>>
where
    C: KeyInit + BlockEncrypt + BlockDecrypt + BlockSizeUser + Send + Sync + 'static,
{
    C::new_from_slice(key)
        .ok()
        .map(|c| Box::new(Wrap(c)) as Box<dyn BlockPrim>)
}

/// Build a block cipher instance. `key` must already have been put through a
/// [`KeyDerivation`](crate::keyderiv::KeyDerivation) policy.
pub fn instantiate_block(name: &str, key: &[u8]) -> Result<Box<dyn BlockPrim>, PrimError> {
    let info = prim_info(name).ok_or_else(|| PrimError::Unknown(name.to_string()))?;
    instantiate_block_info(info, key)
}

/// The body of [`instantiate_block`], split out from the name lookup so the
/// declared-but-unimplemented guard stays *directly* testable.
///
/// Every entry in [`PRIMS`] currently reports [`ImplStatus::Implemented`], which
/// would otherwise make the guard's test vacuous — and a guard nobody exercises is
/// a guard that has quietly stopped working by the time the next primitive is
/// declared. Tests construct a synthetic `Declared` [`PrimInfo`] and call this.
pub(crate) fn instantiate_block_info(
    info: &'static PrimInfo,
    key: &[u8],
) -> Result<Box<dyn BlockPrim>, PrimError> {
    if info.status == ImplStatus::Declared {
        return Err(PrimError::NotImplemented(info.display_name));
    }
    if info.kind == PrimKind::Stream {
        return Err(PrimError::IsStream(info.display_name));
    }
    let built = match info.mcrypt_name {
        "des" => wrap::<des::Des>(key),
        // NOT `wrap::<rc2::Rc2>`: `Rc2::new_from_slice` picks RFC 2268's
        // `T1 = 8 * key_len`, whereas mcrypt has the effective-key-bits reduction
        // stripped and therefore always behaves as `T1 = 1024`. See `crate::rc2`.
        "rc2" => (1..=128).contains(&key.len()).then(|| {
            Box::new(Wrap(rc2::Rc2::new_with_eff_key_len(
                key,
                MCRYPT_RC2_EFF_KEY_BITS,
            ))) as Box<dyn BlockPrim>
        }),
        "blowfish" => wrap::<blowfish::Blowfish>(key),
        "blowfish-compat" => wrap::<blowfish::BlowfishLE>(key),
        "twofish" => wrap::<twofish::Twofish>(key),
        "serpent" => wrap::<serpent::Serpent>(key),
        "xtea" => Xtea::new(key).map(|c| Box::new(c) as Box<dyn BlockPrim>),
        "rijndael-128" => Rijndael::new(16, key).map(|c| Box::new(c) as Box<dyn BlockPrim>),
        "rijndael-256" => Rijndael::new(32, key).map(|c| Box::new(c) as Box<dyn BlockPrim>),
        "saferplus" => Saferplus::new(key).map(|c| Box::new(c) as Box<dyn BlockPrim>),
        "loki97" => Loki97::new(key).map(|c| Box::new(c) as Box<dyn BlockPrim>),
        "tripledes" => wrap::<des::TdesEde3>(key),
        "cast-128" => wrap::<cast5::Cast5>(key),
        "idea" => wrap::<idea::Idea>(key),
        other => return Err(PrimError::Unknown(other.to_string())),
    };
    built.ok_or_else(|| PrimError::BadKeyLength {
        prim: info.display_name,
        len: key.len(),
        supported: if info.supported_key_sizes.is_empty() {
            format!("any length up to {}", info.max_key_size)
        } else {
            format!("{:?}", info.supported_key_sizes)
        },
    })
}

/// `nonce` is only consumed by primitives that need per-invocation keyed
/// state distinct from the key itself (Salsa20's 8-byte nonce); RC4 ignores
/// it entirely, since arcfour has no such concept. Callers reach this with
/// whatever the node's own `iv` parameter already carries -- see the
/// `salsa20` module doc for why that parameter is reused rather than adding
/// a second one.
pub fn instantiate_stream(
    name: &str,
    key: &[u8],
    nonce: &[u8],
) -> Result<Box<dyn StreamPrim>, PrimError> {
    let info = prim_info(name).ok_or_else(|| PrimError::Unknown(name.to_string()))?;
    if info.kind != PrimKind::Stream {
        return Err(PrimError::IsBlock(info.display_name));
    }
    match info.mcrypt_name {
        "arcfour" => Rc4::new(key)
            .map(|c| Box::new(c) as Box<dyn StreamPrim>)
            .ok_or(PrimError::BadKeyLength {
                prim: info.display_name,
                len: key.len(),
                supported: "1..=256".into(),
            }),
        "salsa20" => Salsa20Prim::new(key, nonce)
            .map(|c| Box::new(c) as Box<dyn StreamPrim>)
            .ok_or(PrimError::BadKeyLength {
                prim: info.display_name,
                len: key.len(),
                supported: "32".into(),
            }),
        other => Err(PrimError::Unknown(other.to_string())),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn all_eleven_confirmed_primitives_are_in_the_vocabulary() {
        for name in [
            "DES",
            "RC2",
            "RC4",
            "Blowfish",
            "Blowfish-compat",
            "Twofish",
            "Serpent",
            "Loki97",
            "Saferplus",
            "XTEA",
            "Rijndael-256",
        ] {
            assert!(prim_info(name).is_some(), "missing primitive {name}");
        }
    }

    /// AES is `rijndael-128`: the same variable-block Rijndael engine as
    /// Rijndael-256, configured for a 128-bit block. Absent from the corpus (no
    /// solved cipher used it), so it is expected to be conformance-*unproven*
    /// even though it is a real, tested implementation. See FIPS-197 vectors in
    /// `crate::rijndael`.
    #[test]
    fn aes_is_in_the_vocabulary_as_rijndael_128() {
        let info = prim_info("rijndael-128").expect("rijndael-128 missing");
        assert_eq!(info.display_name, "AES");
        assert_eq!(info.block_size, 16);
        assert_eq!(prim_info("AES").unwrap().mcrypt_name, "rijndael-128");
    }

    /// 3DES/tripledes: real, registered, and conformance-unproven for the same
    /// reason AES is — no corpus cipher uses it.
    #[test]
    fn tripledes_is_in_the_vocabulary() {
        let info = prim_info("tripledes").expect("tripledes missing");
        assert_eq!(info.display_name, "3DES");
        assert_eq!(info.block_size, 8);
        assert_eq!(info.supported_key_sizes, &[24]);
    }

    #[test]
    fn lookup_accepts_both_naming_conventions() {
        assert_eq!(prim_info("arcfour").unwrap().display_name, "RC4");
        assert_eq!(prim_info("RC4").unwrap().mcrypt_name, "arcfour");
        assert_eq!(prim_info("rijndael-256").unwrap().block_size, 32);
    }

    /// A `Declared` primitive that is deliberately *not* in [`PRIMS`]: every real
    /// entry is now `Implemented`, and the guard must still be exercised.
    static DECLARED_ONLY: PrimInfo = PrimInfo {
        display_name: "Nonesuch",
        mcrypt_name: "nonesuch",
        block_size: 16,
        max_key_size: 32,
        supported_key_sizes: &[16, 24, 32],
        kind: PrimKind::Block,
        status: ImplStatus::Declared,
        impl_source: "",
        version: "0.0.0",
        vector_proof: None,
    };

    /// Declared-but-unimplemented primitives must fail loudly, never silently
    /// return a wrong answer. Loki97 was the last such entry until it was ported
    /// from libmcrypt's own `loki97.c`; the guard is checked against a synthetic
    /// entry so it cannot rot into a vacuous pass now that `PRIMS` has none.
    #[test]
    fn declared_primitives_refuse_to_execute() {
        // the real table: currently empty of declared entries, but if one is ever
        // added this loop must hold for it.
        for info in PRIMS.iter().filter(|p| p.status == ImplStatus::Declared) {
            match instantiate_block_info(info, &[0u8; 32]) {
                Err(PrimError::NotImplemented(_)) => {}
                Err(e) => panic!("{}: wrong error {e}", info.display_name),
                Ok(_) => panic!("{}: unexpectedly instantiated", info.display_name),
            }
        }
        // and the guard itself, unconditionally
        match instantiate_block_info(&DECLARED_ONLY, &[0u8; 32]) {
            Err(PrimError::NotImplemented("Nonesuch")) => {}
            Err(e) => panic!("wrong error {e}"),
            Ok(_) => panic!("a declared primitive must never instantiate"),
        }
    }

    /// The counterpart claim: the vocabulary is now fully backed. Loki97 was the
    /// last `Declared` entry, and its absence from this set is what lets rev5's
    /// plaintext be reached at all.
    #[test]
    fn every_primitive_in_the_vocabulary_is_implemented() {
        let declared: Vec<&str> = PRIMS
            .iter()
            .filter(|p| p.status == ImplStatus::Declared)
            .map(|p| p.display_name)
            .collect();
        assert!(declared.is_empty(), "still declared-only: {declared:?}");
        for info in PRIMS {
            assert!(
                !info.impl_source.is_empty(),
                "{} has no impl_source",
                info.display_name
            );
            assert_ne!(info.version, "0.0.0", "{}", info.display_name);
        }
    }

    #[test]
    fn implemented_block_primitives_all_instantiate_and_round_trip() {
        for info in implemented().filter(|p| p.kind == PrimKind::Block) {
            let key = vec![0x11u8; info.supported_key_sizes.last().copied().unwrap_or(16)];
            let p = instantiate_block(info.mcrypt_name, &key)
                .unwrap_or_else(|e| panic!("{}: {e}", info.display_name));
            assert_eq!(p.block_size(), info.block_size, "{}", info.display_name);

            let pt: Vec<u8> = (0..info.block_size as u8).collect();
            let mut b = pt.clone();
            p.encrypt_block(&mut b);
            assert_ne!(b, pt, "{} was a no-op", info.display_name);
            p.decrypt_block(&mut b);
            assert_eq!(b, pt, "{} failed to round trip", info.display_name);
        }
    }

    /// AES via the registered `rijndael-128` primitive, reached the same way a node
    /// would reach it (`instantiate_block`, not `Rijndael::new` directly). FIPS-197
    /// Appendix C.1 (AES-128) plus libmcrypt's own compiled-in `rijndael-128.c`
    /// self-test vector, so the primitive's registration and the algorithm are both
    /// pinned, not just the underlying `Rijndael` struct.
    #[test]
    fn rijndael_128_matches_fips197_and_libmcrypt_self_test() {
        // FIPS-197 Appendix C.1.
        let key = hex::decode("000102030405060708090a0b0c0d0e0f").unwrap();
        let pt = hex::decode("00112233445566778899aabbccddeeff").unwrap();
        let want = hex::decode("69c4e0d86a7b0430d8cdb78070b4c55a").unwrap();
        let p = instantiate_block("rijndael-128", &key).unwrap();
        let mut b = pt.clone();
        p.encrypt_block(&mut b);
        assert_eq!(b, want, "FIPS-197 C.1 mismatch");
        p.decrypt_block(&mut b);
        assert_eq!(b, pt);

        // libmcrypt's own compiled-in self-test in `rijndael-128.c`: key 01 00..00,
        // plaintext 00..0f, `#define CIPHER "5352e43763eec1a8502433d6d520b1f0"`.
        let mut key2 = vec![0u8; 16];
        key2[0] = 1;
        let pt2: Vec<u8> = (0..16u8).collect();
        let want2 = hex::decode("5352e43763eec1a8502433d6d520b1f0").unwrap();
        let p2 = instantiate_block("rijndael-128", &key2).unwrap();
        let mut b2 = pt2.clone();
        p2.encrypt_block(&mut b2);
        assert_eq!(b2, want2, "libmcrypt rijndael-128.c self-test mismatch");
    }

    /// libmcrypt's `tripledes.c` compiled-in self-test: key bytes `j % 256` for
    /// `j` in `0..24`, plaintext bytes `j % 256` for `j` in `0..8`,
    /// `#define CIPHER "58ed248f77f6b19e"`. Independently cross-checked against
    /// pycryptodome's `Crypto.Cipher.DES3` (standard DES-EDE3), which reproduces the
    /// same ciphertext byte for byte.
    #[test]
    fn tripledes_matches_libmcrypt_self_test() {
        let key: Vec<u8> = (0..24u32).map(|j| (j % 256) as u8).collect();
        let pt: Vec<u8> = (0..8u32).map(|j| (j % 256) as u8).collect();
        let want = hex::decode("58ed248f77f6b19e").unwrap();
        let p = instantiate_block("tripledes", &key).unwrap();
        let mut b = pt.clone();
        p.encrypt_block(&mut b);
        assert_eq!(b, want, "libmcrypt tripledes.c self-test mismatch");
        p.decrypt_block(&mut b);
        assert_eq!(b, pt);
    }

    /// RFC 2144 Appendix B.1's own published test vector, all three key sizes.
    /// https://www.rfc-editor.org/rfc/rfc2144 — this is CAST-128's own normative
    /// vector, not a corpus reproduction: no solved cipher in this project's corpus
    /// uses CAST-128, so this is the ONLY proof this implementation has, and it is
    /// what backs `PrimInfo::vector_proof` for it (VectorProven, not CorpusProven).
    ///
    /// The 80- and 40-bit vectors go through `cast5::Cast5` directly rather than
    /// `instantiate_block`, because this engine's own `supported_key_sizes` for
    /// CAST-128 is `&[16]` (the mcrypt menu's only offering); RFC 2144's shorter
    /// keys are here to check the underlying implementation, not this engine's
    /// key-length policy.
    #[test]
    fn cast128_matches_rfc2144_appendix_b1() {
        let pt = hex::decode("0123456789ABCDEF").unwrap();

        let key128 = hex::decode("0123456712345678234567893456789A").unwrap();
        let want128 = hex::decode("238B4FE5847E44B2").unwrap();
        let p = instantiate_block("cast-128", &key128).unwrap();
        let mut b = pt.clone();
        p.encrypt_block(&mut b);
        assert_eq!(b, want128, "RFC 2144 B.1 128-bit-key mismatch");
        p.decrypt_block(&mut b);
        assert_eq!(b, pt);

        let key80 = hex::decode("01234567123456782345").unwrap();
        let want80 = hex::decode("EB6A711A2C02271B").unwrap();
        let c = cast5::Cast5::new_from_slice(&key80).unwrap();
        let mut block = GenericArray::clone_from_slice(&pt);
        c.encrypt_block(&mut block);
        assert_eq!(&block[..], &want80[..], "RFC 2144 B.1 80-bit-key mismatch");
        c.decrypt_block(&mut block);
        assert_eq!(&block[..], &pt[..]);

        let key40 = hex::decode("0123456712").unwrap();
        let want40 = hex::decode("7AC816D16E9B302E").unwrap();
        let c = cast5::Cast5::new_from_slice(&key40).unwrap();
        let mut block = GenericArray::clone_from_slice(&pt);
        c.encrypt_block(&mut block);
        assert_eq!(&block[..], &want40[..], "RFC 2144 B.1 40-bit-key mismatch");
        c.decrypt_block(&mut block);
        assert_eq!(&block[..], &pt[..]);
    }

    /// blowfish and blowfish-compat must be genuinely different ciphers, otherwise
    /// rev5 and rev8 would be interchangeable.
    #[test]
    fn blowfish_and_blowfish_compat_differ() {
        let key = b"Zombies\x00".to_vec();
        let a = instantiate_block("blowfish", &key).unwrap();
        let b = instantiate_block("blowfish-compat", &key).unwrap();
        let mut x = [0u8; 8];
        let mut y = [0u8; 8];
        a.encrypt_block(&mut x);
        b.encrypt_block(&mut y);
        assert_ne!(x, y);
    }

    #[test]
    fn wrong_key_length_is_reported_not_panicked() {
        match instantiate_block("twofish", b"short") {
            Err(PrimError::BadKeyLength { .. }) => {}
            Err(e) => panic!("wrong error {e}"),
            Ok(_) => panic!("a 5-byte Twofish key must be rejected"),
        }
    }

    #[test]
    fn stream_and_block_apis_are_not_confusable() {
        assert!(matches!(
            instantiate_block("arcfour", b"Zombies"),
            Err(PrimError::IsStream(_))
        ));
        assert!(matches!(
            instantiate_stream("des", b"Zombies\x00", &[]),
            Err(PrimError::IsBlock(_))
        ));
    }
}
