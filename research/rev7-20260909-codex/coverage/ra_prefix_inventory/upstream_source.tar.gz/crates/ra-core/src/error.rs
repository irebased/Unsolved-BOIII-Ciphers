use thiserror::Error;

pub type Result<T> = std::result::Result<T, Error>;

#[derive(Debug, Error)]
pub enum Error {
    #[error("unknown node '{0}'")]
    UnknownNode(String),

    #[error("node '{node}' requires parameter '{param}'")]
    MissingParam { node: String, param: String },

    #[error("node '{node}' parameter '{param}': {msg}")]
    BadParam {
        node: String,
        param: String,
        msg: String,
    },

    #[error("terminal node '{node}' must be the last step (found at index {index})")]
    TerminalNotLast { node: String, index: usize },

    #[error("chain is empty")]
    EmptyChain,

    #[error("{node}: {msg}")]
    NodeFailed { node: String, msg: String },

    /// A primitive is registered so that the registry and conformance gating can
    /// see it, but has no implementation yet. Coverage claimed over it is void.
    #[error("primitive '{0}' is declared but not implemented; it can carry no coverage")]
    Unimplemented(&'static str),

    #[error("decode error: {0}")]
    Decode(String),

    #[error(transparent)]
    Json(#[from] serde_json::Error),

    #[error(transparent)]
    Io(#[from] std::io::Error),
}

impl Error {
    pub fn node_failed(node: impl Into<String>, msg: impl std::fmt::Display) -> Self {
        Error::NodeFailed {
            node: node.into(),
            msg: msg.to_string(),
        }
    }

    pub fn bad_param(
        node: impl Into<String>,
        param: impl Into<String>,
        msg: impl std::fmt::Display,
    ) -> Self {
        Error::BadParam {
            node: node.into(),
            param: param.into(),
            msg: msg.to_string(),
        }
    }
}
