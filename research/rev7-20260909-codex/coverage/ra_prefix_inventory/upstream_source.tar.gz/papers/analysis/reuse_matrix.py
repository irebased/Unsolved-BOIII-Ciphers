#!/usr/bin/env python3
"""Recompute the cipher-reuse statistics for Paper 8 directly from data/.

Covers all SIX map files.  Run:  python3 papers/analysis/reuse_matrix.py
No dependencies beyond the stdlib.

NORMALISATION WARNING.  Method names in the corpus are not written
consistently: rev11 records "Trifid" and soe2 records "trifid"; de7 records
"2-1_AMSCO".  Comparing raw strings silently splits shared ciphers into
singletons, which is exactly how the three-map version of this analysis
produced the false claim that no cipher is shared between maps.  This project
has been bitten by the same class of bug twice before (the
Rijndael-256/rijndael-256 vacuous conformance pass, and a key-label mismatch
between two subcommands).  Every comparison here goes through norm().
"""
import json
import os
import re
import collections
import unicodedata

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

MAPS = {
    "shadows_of_evil": "soe.json",
    "the_giant": "the_giant.json",
    "der_eisendrache": "der_eisendrache.json",
    "zetsubou_no_shima": "zetsubou.json",
    "gorod_krovi": "gorod_krovi.json",
    "revelations": "revelations.json",
}
MAP_ORDER = list(MAPS)          # release order

STRUCTURAL_TYPES = {"decode", "encode", "transform"}
CIPHER_TYPES = {"classical", "decrypt", "formula"}

# Pairs that are the same technique under different recorded names.  Kept OUT
# of norm() so the headline figures reflect a plain case/separator
# normalisation, and reported separately as a sensitivity check.
SYNONYMS = [("hex", "hexadecimal")]


def norm(name):
    """Canonical form for comparing method names across records.

    Case-folds, strips accents, collapses separator runs to one underscore, so
    "Trifid" == "trifid" and "2-1_AMSCO" == "2 1 amsco".  Deliberately does
    NOT unify synonyms; see SYNONYMS.
    """
    s = unicodedata.normalize("NFKD", name)
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.casefold().strip()
    s = re.sub(r"[\s\-/().']+", "_", s)
    return re.sub(r"_+", "_", s).strip("_")


def load():
    steps, records, per_map = [], 0, {}
    for m in MAP_ORDER:
        data = json.load(open(os.path.join(ROOT, "data", MAPS[m])))
        per_map[m] = len(data)
        records += len(data)
        for r in data:
            for i, s in enumerate((r.get("solution") or {}).get("steps", [])):
                raw = s.get("method")
                steps.append(dict(map=m, rec=r["id"], idx=i, type=s["type"],
                                  raw=raw, method=norm(raw) if raw else None))
    return records, steps, per_map


def ratio(names):
    d = len(set(names))
    return len(names), d, (len(names) / d if d else float("nan"))


def fmt(t):
    return f"{t[0]}/{t[1]}={t[2]:.2f}" if t[1] else "none"


def main():
    records, steps, per_map = load()
    named = [s for s in steps if s["method"]]
    print(f"map files              : {len(MAPS)}")
    print(f"records                : {records}")
    print(f"solution steps (all)   : {len(steps)}")
    print(f"steps carrying a method: {len(named)}")
    print(f"steps with prose only  : {len(steps) - len(named)}")
    print(f"distinct methods       : {len(set(s['method'] for s in named))}")
    print()

    print("== per-map reuse ratio (steps / distinct methods) ==")
    print(f"{'map':<20}{'rec':>4}{'all':>14}{'cipher':>14}{'structural':>14}")
    for m in MAP_ORDER:
        ss = [s for s in named if s["map"] == m]
        print(f"{m:<20}{per_map[m]:>4}"
              f"{fmt(ratio([s['method'] for s in ss])):>14}"
              f"{fmt(ratio([s['method'] for s in ss if s['type'] in CIPHER_TYPES])):>14}"
              f"{fmt(ratio([s['method'] for s in ss if s['type'] in STRUCTURAL_TYPES])):>14}")
    print(f"{'CORPUS':<20}{records:>4}"
          f"{fmt(ratio([s['method'] for s in named])):>14}"
          f"{fmt(ratio([s['method'] for s in named if s['type'] in CIPHER_TYPES])):>14}"
          f"{fmt(ratio([s['method'] for s in named if s['type'] in STRUCTURAL_TYPES])):>14}")
    print()

    by, where, kind = collections.defaultdict(set), collections.defaultdict(list), {}
    for s in named:
        by[s["method"]].add(s["map"])
        where[s["method"]].append(s["rec"])
        kind[s["method"]] = s["type"]

    print("== methods appearing in more than one MAP ==")
    cross = {k: sorted(v) for k, v in by.items() if len(v) > 1}
    ciphers = {k: v for k, v in cross.items() if kind[k] in CIPHER_TYPES}
    struct = {k: v for k, v in cross.items() if kind[k] in STRUCTURAL_TYPES}
    print(f"  CIPHERS shared across maps ({len(ciphers)}):")
    for k in sorted(ciphers):
        print(f"    {k:<30}{where[k]}")
    print(f"  STRUCTURAL shared across maps ({len(struct)}):")
    for k in sorted(struct):
        print(f"    {k:<30}{where[k]}  ({len(by[k])} maps)")
    print()

    print("== sensitivity: recorded synonyms NOT unified by norm() ==")
    for a_, b_ in SYNONYMS:
        if by.get(a_) and by.get(b_):
            print(f"  '{a_}' in {sorted(by[a_])} {where[a_]}")
            print(f"  '{b_}' in {sorted(by[b_])} {where[b_]}")
            joint = by[a_] | by[b_]
            print(f"  -> same technique, different recorded name. Unifying gives"
                  f" a cross-map method over {len(joint)} maps,")
            print(f"     raising the shared-cipher count and lowering distinct"
                  f" methods by one.")
    print()

    print("== every repeated method, corpus-wide ==")
    for k, v in collections.Counter(s["method"] for s in named).most_common():
        if v > 1:
            print(f"  {v}x  {k:<28} [{kind[k]:<9}] {where[k]}")
    print()

    print("== singleton vs repeated, split by role ==")
    for label, tset in (("cipher", CIPHER_TYPES), ("structural", STRUCTURAL_TYPES)):
        ms = [s["method"] for s in named if s["type"] in tset]
        c2 = collections.Counter(ms)
        sing = sum(1 for v in c2.values() if v == 1)
        print(f"  {label:<11} distinct={len(c2):<3} singletons={sing:<3} "
              f"repeated={len(c2) - sing:<3} singleton share={sing / len(c2):.1%}"
              f"  steps={len(ms)}")
    print()

    print("== modern (mcrypt) decryption steps, by map ==")
    for m in MAP_ORDER:
        mod = [s["rec"] for s in named if s["map"] == m and s["type"] == "decrypt"]
        print(f"  {m:<20} {len(mod):>2} modern steps   {sorted(set(mod))}")
    tot = sum(1 for s in named if s["type"] == "decrypt")
    print(f"  {'TOTAL':<20} {tot:>2}")
    print()

    print("== the full distinct-method inventory ==")
    for i, k in enumerate(sorted(set(s["method"] for s in named)), 1):
        maps = ",".join(sorted({s["map"] for s in named if s["method"] == k}))
        print(f"  {i:>2}. {k:<32} [{kind[k]:<9}] {maps}")
    print()

    print("== ciphertext inventory (records that carry one) ==")
    for m in MAP_ORDER:
        for r in json.load(open(os.path.join(ROOT, "data", MAPS[m]))):
            ct = r.get("ciphertext")
            if ct:
                print(f"  {r['id']:<7} len={len(ct):<6} |alpha|={len(set(ct)):<3} "
                      f"solved={str(bool(r.get('solved'))):<5}")


if __name__ == "__main__":
    main()
