//! `ra serve`: a local HTTP interface to the cipher engine.
//!
//! # Why `tiny_http` and not a hand-rolled `TcpListener`, and not tokio/axum
//!
//! This is a single-user localhost tool wrapping a CPU-bound (rayon-parallel)
//! engine — there is no benefit to an async runtime here, and the workspace root
//! `Cargo.toml` already documents a deliberate policy of staying dependency-light.
//! `tiny_http` is a small, synchronous, dependency-light HTTP/1.1 server (no TLS
//! stack pulled in — its `ssl`/`rustls` features are left off) that still handles
//! the fiddly parts a hand-rolled listener would have to reimplement correctly:
//! request-line/header parsing, keep-alive, chunked request bodies, and `Expect:
//! 100-continue`. Handing that off buys correctness for a fixed, small dependency
//! cost, which is the trade the workspace's existing dependencies (e.g. `clap`
//! over hand-rolled arg parsing) already make elsewhere in this crate.
//!
//! Each accepted connection is handled on its own OS thread (`std::thread::spawn`
//! per request); with one interactive user this is simpler than a worker pool and
//! never becomes a bottleneck. The engine's own parallelism (rayon, inside a run)
//! is unaffected — one run's background thread does the CPU-heavy work while the
//! HTTP threads stay free to serve `/api/runs/*` polling and SSE.
//!
//! # Why `/api/plan` and `/api/runs` are not built on `crate::sweep`
//!
//! See the module doc on [`engine`] for the full argument: `sweep::Plan` enumerates
//! a fixed, TG4-shaped tier vocabulary, not an arbitrary sequence of named
//! registered nodes with per-parameter value sets, which is what the frontend's
//! chain builder needs. `engine::Plan` is a second, small, generic planner built
//! directly on `ra_core::{registry, Chain, Step, Params}` — the same substrate
//! `ra run` uses — so it needs no privileged access into `sweep`'s internals.
//! `crate::sweep` itself is not modified by this module; `ra sweep`'s behaviour on
//! the CLI is unchanged.

mod engine;
mod runs;

use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::time::Duration;

use anyhow::{anyhow, Result};
use serde_json::{json, Value as Json};
use tiny_http::{Header, Method, Response, Server};

use engine::PlanRequest;
use runs::{iso8601_utc, RunStore};

const INDEX_HTML: &str = include_str!("index.html");

struct AppState {
    data: PathBuf,
    store: Arc<RunStore>,
}

pub fn run(data: &Path, port: u16, open: bool) -> Result<()> {
    ra_prim::link();
    let addr = format!("127.0.0.1:{port}");
    // Bind loopback-only, never 0.0.0.0: this exposes an execution engine and must
    // not be reachable off-machine.
    let server = Server::http(&addr).map_err(|e| anyhow!("failed to bind {addr}: {e}"))?;
    println!("ra serve listening on http://{addr}  (127.0.0.1 only)");

    if open {
        try_open_browser(&format!("http://{addr}"));
    }

    let state = Arc::new(AppState {
        data: data.to_path_buf(),
        store: Arc::new(RunStore::default()),
    });

    for request in server.incoming_requests() {
        let state = state.clone();
        std::thread::spawn(move || {
            if let Err(e) = handle(&state, request) {
                eprintln!("ra serve: request error: {e}");
            }
        });
    }
    Ok(())
}

fn try_open_browser(url: &str) {
    let attempt = if cfg!(target_os = "macos") {
        std::process::Command::new("open").arg(url).spawn()
    } else if cfg!(target_os = "windows") {
        std::process::Command::new("cmd")
            .args(["/C", "start", url])
            .spawn()
    } else {
        std::process::Command::new("xdg-open").arg(url).spawn()
    };
    if let Err(e) = attempt {
        eprintln!("ra serve: could not open a browser automatically: {e}");
    }
}

fn json_header() -> Header {
    Header::from_bytes(&b"Content-Type"[..], &b"application/json; charset=utf-8"[..])
        .expect("static header is valid")
}

fn json_response(status: u16, body: &Json) -> Response<std::io::Cursor<Vec<u8>>> {
    let data = serde_json::to_vec(body).unwrap_or_else(|_| b"{}".to_vec());
    Response::from_data(data)
        .with_status_code(status)
        .with_header(json_header())
        // The body length is always known up front for a JSON response, so send
        // it as `Content-Length` rather than `Transfer-Encoding: chunked` (tiny_http's
        // default once a body exceeds 32KB, which the `/api/nodes` payload does).
        .with_chunked_threshold(usize::MAX)
}

fn read_body(request: &mut tiny_http::Request) -> Result<Json> {
    let mut s = String::new();
    request
        .as_reader()
        .read_to_string(&mut s)
        .map_err(|e| anyhow!("reading request body: {e}"))?;
    if s.trim().is_empty() {
        return Ok(json!({}));
    }
    serde_json::from_str(&s).map_err(|e| anyhow!("invalid JSON body: {e}"))
}

fn handle(state: &Arc<AppState>, mut request: tiny_http::Request) -> Result<()> {
    let method = request.method().clone();
    let url = request.url().to_string();
    let path = url.split('?').next().unwrap_or("").to_string();
    let segs: Vec<&str> = path.split('/').filter(|s| !s.is_empty()).collect();

    match (&method, segs.as_slice()) {
        (Method::Get, ["api", "nodes"]) => {
            let body = api_nodes();
            request.respond(json_response(200, &body))?;
        }
        (Method::Get, ["api", "groups"]) => {
            let body = api_groups();
            request.respond(json_response(200, &body))?;
        }
        (Method::Get, ["api", "targets"]) => match api_targets(&state.data) {
            Ok(body) => request.respond(json_response(200, &body))?,
            Err(e) => request.respond(json_response(
                500,
                &json!({"ok": false, "error": e.to_string()}),
            ))?,
        },
        (Method::Post, ["api", "plan"]) => {
            let body = read_body(&mut request);
            match body.and_then(|b| {
                serde_json::from_value::<PlanRequest>(b).map_err(|e| anyhow!("{e}"))
            }) {
                Ok(req) => match engine::build_plan(&req) {
                    Ok(plan) => request.respond(json_response(200, &plan_response(&plan)))?,
                    Err(e) => {
                        request.respond(json_response(400, &json!({"ok": false, "error": e})))?
                    }
                },
                Err(e) => request.respond(json_response(
                    400,
                    &json!({"ok": false, "error": e.to_string()}),
                ))?,
            }
        }
        (Method::Post, ["api", "runs"]) => {
            let body = read_body(&mut request);
            match body.and_then(|b| {
                serde_json::from_value::<PlanRequest>(b).map_err(|e| anyhow!("{e}"))
            }) {
                Ok(req) => match runs::spawn_run(state.data.clone(), req, &state.store) {
                    Ok(rec) => request
                        .respond(json_response(200, &json!({"run_id": rec.run_id})))?,
                    Err(e) => {
                        request.respond(json_response(400, &json!({"ok": false, "error": e})))?
                    }
                },
                Err(e) => request.respond(json_response(
                    400,
                    &json!({"ok": false, "error": e.to_string()}),
                ))?,
            }
        }
        (Method::Get, ["api", "runs"]) => {
            let list: Vec<Json> = state.store.list().iter().map(|r| run_summary(r)).collect();
            request.respond(json_response(200, &json!({"runs": list})))?;
        }
        (Method::Get, ["api", "runs", id]) => match state.store.get(id) {
            Some(rec) => request.respond(json_response(200, &run_full(&rec)))?,
            None => request.respond(json_response(
                404,
                &json!({"ok": false, "error": format!("no such run '{id}'")}),
            ))?,
        },
        (Method::Get, ["api", "runs", id, "events"]) => match state.store.get(id) {
            Some(rec) => stream_events(request, rec)?,
            None => request.respond(json_response(
                404,
                &json!({"ok": false, "error": format!("no such run '{id}'")}),
            ))?,
        },
        (Method::Post, ["api", "runs", id, "stop"]) => match state.store.get(id) {
            Some(rec) => {
                rec.stop.store(true, Ordering::Relaxed);
                request.respond(json_response(200, &json!({"ok": true})))?;
            }
            None => request.respond(json_response(
                404,
                &json!({"ok": false, "error": format!("no such run '{id}'")}),
            ))?,
        },
        (Method::Get, _) => {
            let resp = Response::from_string(INDEX_HTML)
                .with_header(
                    Header::from_bytes(&b"Content-Type"[..], &b"text/html; charset=utf-8"[..])
                        .expect("static header is valid"),
                )
                .with_chunked_threshold(usize::MAX);
            request.respond(resp)?;
        }
        _ => {
            request.respond(json_response(
                405,
                &json!({"ok": false, "error": "method not allowed"}),
            ))?;
        }
    }
    Ok(())
}

fn api_nodes() -> Json {
    let reg = ra_core::registry();
    let mut nodes: Vec<&'static dyn ra_core::Node> = reg.iter().collect();
    nodes.sort_by_key(|n| (n.family().as_str(), n.name()));
    let list: Vec<Json> = nodes
        .into_iter()
        .map(|n| {
            let id = n.node_id();
            let params: Vec<Json> = n
                .params_schema()
                .iter()
                .map(|p| {
                    json!({
                        "name": p.name,
                        "type": match p.ty {
                            ra_core::ParamType::Str => "str",
                            ra_core::ParamType::Int => "int",
                            ra_core::ParamType::Bool => "bool",
                            ra_core::ParamType::Hex => "hex",
                        },
                        "required": p.required,
                        "description": p.doc,
                    })
                })
                .collect();
            json!({
                "name": n.name(),
                "family": n.family().as_str(),
                "version": n.version(),
                "digest": id.hash12,
                "layer_forming": n.layer_forming(),
                "params": params,
            })
        })
        .collect();
    json!({"nodes": list})
}

/// `GET /api/groups`: named presets derived from the live registry's `family`
/// (`dec` / `xf` / `codec`), so the UI can offer "all modern primitives" etc. in
/// one click without a hardcoded node list that drifts from what's actually
/// registered.
fn api_groups() -> Json {
    let reg = ra_core::registry();
    let mut modern: Vec<&'static str> = Vec::new();
    let mut classical: Vec<&'static str> = Vec::new();
    let mut codecs: Vec<&'static str> = Vec::new();
    for n in reg.iter() {
        match n.family() {
            ra_core::Family::Dec => modern.push(n.name()),
            ra_core::Family::Xf => classical.push(n.name()),
            ra_core::Family::Codec => codecs.push(n.name()),
            ra_core::Family::Solver => {}
        }
    }
    modern.sort_unstable();
    classical.sort_unstable();
    codecs.sort_unstable();
    json!({"groups": [
        {"id": "modern", "label": "Modern primitives (mcrypt)", "nodes": modern},
        {"id": "classical", "label": "Classical transforms", "nodes": classical},
        {"id": "codecs", "label": "Codecs", "nodes": codecs},
    ]})
}

fn api_targets(data: &Path) -> Result<Json> {
    let targets = crate::corpus::list_targets(data)?;
    let list: Vec<Json> = targets
        .into_iter()
        .map(|t| {
            json!({
                "id": t.id,
                "map": t.map,
                "solved": t.solved,
                "ciphertext_len": t.ciphertext_len,
            })
        })
        .collect();
    Ok(json!({"targets": list}))
}

/// `total_ops` above which a plan gets a `warn` field: these chains ("every
/// classical on every modern") can reach tens of millions of candidates, and the
/// user is entitled to launch that sweep deliberately — this only makes the size
/// legible before they commit, it never refuses to run it.
const WARN_THRESHOLD: u64 = 10_000_000;
/// Rough steady-state throughput used only to phrase the `warn` estimate, not a
/// promised or measured rate.
const ASSUMED_OPS_PER_SEC: f64 = 1e5;

fn warn_message(total_ops: u64) -> String {
    let scaled = total_ops as f64 / 1e6;
    let minutes = (total_ops as f64 / ASSUMED_OPS_PER_SEC) / 60.0;
    format!(
        "{scaled:.1}e6 operations; at ~1e5 ops/sec this is roughly {minutes:.0} minutes"
    )
}

fn plan_response(plan: &engine::Plan) -> Json {
    let axes: Vec<Json> = plan
        .axes()
        .into_iter()
        .filter(|a| a.values.len() > 1)
        .map(|a| json!({"step": a.step, "param": a.param, "values": a.values.len()}))
        .collect();
    let per_step: Vec<Json> = plan
        .per_step()
        .into_iter()
        .map(|s| {
            let alternatives: Vec<Json> = s
                .alternatives
                .iter()
                .map(|a| json!({"node": a.node, "combinations": a.combinations}))
                .collect();
            json!({
                "step": s.step,
                "optional": s.optional,
                "cardinality": s.cardinality,
                "alternatives": alternatives,
            })
        })
        .collect();
    let total_ops = plan.total_ops();
    let mut body = json!({
        "ok": true,
        "total_ops": total_ops,
        "axes": axes,
        "per_step": per_step,
    });
    if total_ops > WARN_THRESHOLD {
        body["warn"] = json!(warn_message(total_ops));
    }
    body
}

fn run_summary(rec: &runs::RunRecord) -> Json {
    json!({
        "run_id": rec.run_id,
        "state": rec.state_str(),
        "total_ops": rec.total_ops,
        "done_ops": rec.done_ops_now(),
        "hits": rec.hits.lock().unwrap().len(),
        "started": iso8601_utc(rec.started_epoch_secs),
        "label": rec.label,
    })
}

fn run_full(rec: &runs::RunRecord) -> Json {
    let hits: Vec<Json> = rec
        .hits
        .lock()
        .unwrap()
        .iter()
        .map(|h| {
            json!({
                "score": h.score,
                "preview": h.preview,
                "chain": h.chain,
                "params": h.params,
            })
        })
        .collect();
    json!({
        "run_id": rec.run_id,
        "target": rec.target,
        "label": rec.label,
        "state": rec.state_str(),
        "total_ops": rec.total_ops,
        "done_ops": rec.done_ops_now(),
        "best_score": *rec.best_score.lock().unwrap(),
        "started": iso8601_utc(rec.started_epoch_secs),
        "elapsed_ms": rec.elapsed_ms(),
        "hits": hits,
        "error": *rec.error.lock().unwrap(),
    })
}

/// `GET /api/runs/{id}/events`: a `text/event-stream` sampled at ~5/sec from the
/// run's shared atomics, independent of how fast the sweep itself is progressing.
/// Terminates the stream once `state` is no longer `"running"`.
fn stream_events(request: tiny_http::Request, rec: Arc<runs::RunRecord>) -> Result<()> {
    let mut writer = request.into_writer();
    writer.write_all(
        b"HTTP/1.1 200 OK\r\n\
          Content-Type: text/event-stream; charset=utf-8\r\n\
          Cache-Control: no-cache\r\n\
          Connection: close\r\n\r\n",
    )?;
    loop {
        let state = rec.state_str();
        let payload = json!({
            "done_ops": rec.done_ops_now(),
            "total_ops": rec.total_ops,
            "hits": rec.hits.lock().unwrap().len(),
            "best_score": *rec.best_score.lock().unwrap(),
            "elapsed_ms": rec.elapsed_ms(),
            "state": state,
        });
        let line = format!("data: {payload}\n\n");
        if writer.write_all(line.as_bytes()).is_err() || writer.flush().is_err() {
            // client disconnected
            break;
        }
        if state != "running" {
            break;
        }
        std::thread::sleep(Duration::from_millis(200));
    }
    Ok(())
}
