"""
covalg.py  -  Coverage algebra for cipher search-space claims.

A coverage claim answers: "exactly which pipelines were tried?"
It must be closed under union and difference so that

    RESIDUAL = UNIVERSE \\ (claim_1 u claim_2 u ... u claim_n)

is computable. That is the whole point: the community needs to know what is LEFT,
not just what was done.

REPRESENTATION
--------------
A pipeline is an ordered composition of layers, applied left to right:

    V . dcd[hex] . xf[reverse] . dec[prim,mode,key,iv,kd]

The set of all pipelines partitions by SKELETON (the ordered tuple of layer
families, ignoring parameter values). Within one skeleton the space is a plain
Cartesian product of per-slot parameter domains. So:

    Space  =  disjoint-union over skeletons of (product of domains)

A claim is therefore a mapping  skeleton -> union of sub-products (a "cover").
Union-of-products is closed under union (concatenate) and difference (orthogonal
decomposition, below), which makes residual exact rather than approximate.

WHY NOT JUST COUNT
------------------
Counting ("we tried 3.2e8 candidates") is not falsifiable and does not compose.
Two teams reporting 3.2e8 each may have tried the same 3.2e8. Set notation makes
overlap explicit and makes the residual computable.
"""

from __future__ import annotations
import json, hashlib, itertools
from typing import Dict, List, Tuple, Iterable

# --------------------------------------------------------------------------
# Product: one hyperrectangle within a fixed skeleton.
# dims maps "slot.param" -> frozenset(values). Order of dims is canonical (sorted).
# --------------------------------------------------------------------------
class Product:
    __slots__ = ("dims",)

    def __init__(self, dims: Dict[str, Iterable]):
        self.dims = {k: frozenset(v) for k, v in dims.items()}
        if any(len(v) == 0 for v in self.dims.values()):
            self.dims = {k: frozenset() for k in self.dims}   # canonical empty

    def is_empty(self) -> bool:
        return any(len(v) == 0 for v in self.dims.values())

    def size(self) -> int:
        if self.is_empty():
            return 0
        n = 1
        for v in self.dims.values():
            n *= len(v)
        return n

    def keys(self) -> List[str]:
        return sorted(self.dims)

    def intersect(self, other: "Product") -> "Product":
        assert self.keys() == other.keys(), "skeleton/dimension mismatch"
        return Product({k: self.dims[k] & other.dims[k] for k in self.dims})

    def contains_point(self, pt: Dict[str, object]) -> bool:
        return all(pt[k] in self.dims[k] for k in self.dims)

    def difference(self, other: "Product") -> List["Product"]:
        """
        A \\ B as a disjoint union of at most |dims| products.

        A \\ B = U_d [ (A_1^B_1) x..x (A_{d-1}^B_{d-1}) x (A_d \\ B_d) x A_{d+1} x..x A_n ]

        where ^ is intersection. Each term fixes the first d-1 dims to the overlap
        and carves the d-th, so terms are pairwise disjoint.
        """
        if self.is_empty():
            return []
        inter = self.intersect(other)
        if inter.is_empty():
            return [self]                      # no overlap, nothing removed
        out: List[Product] = []
        ks = self.keys()
        for d, kd in enumerate(ks):
            carved = self.dims[kd] - other.dims[kd]
            if not carved:
                continue
            nd = {}
            for i, k in enumerate(ks):
                if i < d:      nd[k] = self.dims[k] & other.dims[k]
                elif i == d:   nd[k] = carved
                else:          nd[k] = self.dims[k]
            pr = Product(nd)
            if not pr.is_empty():
                out.append(pr)
        return out

    def to_json(self):
        return {k: sorted(map(_jkey, v)) for k, v in self.dims.items()}

    def notation(self) -> str:
        parts = []
        for k in self.keys():
            v = sorted(map(str, self.dims[k]))
            if len(v) <= 4:
                inner = "{" + ",".join(v) + "}"
            else:
                inner = "{" + ",".join(v[:3]) + ",...|" + str(len(v)) + "|}"
            parts.append(f"{k}\u2208{inner}")
        return " \u00d7 ".join(parts)


def _jkey(x):
    return x if isinstance(x, (str, int, float, bool)) or x is None else str(x)


# --------------------------------------------------------------------------
# Cover: union of products within ONE skeleton.
# --------------------------------------------------------------------------
class Cover:
    def __init__(self, skeleton: Tuple[str, ...], products: List[Product] = None):
        self.skeleton = tuple(skeleton)
        self.products = [p for p in (products or []) if not p.is_empty()]

    def size_upper(self) -> int:
        """Sum of product sizes. Equals exact size only if products are disjoint."""
        return sum(p.size() for p in self.products)

    def size_exact(self) -> int:
        """Exact via successive disjointification. Cost grows with overlap."""
        disjoint: List[Product] = []
        for p in self.products:
            pieces = [p]
            for d in disjoint:
                nxt = []
                for piece in pieces:
                    nxt.extend(piece.difference(d))
                pieces = nxt
                if not pieces:
                    break
            disjoint.extend(pieces)
        return sum(p.size() for p in disjoint)

    def union(self, other: "Cover") -> "Cover":
        assert self.skeleton == other.skeleton
        return Cover(self.skeleton, self.products + other.products)

    def difference(self, other: "Cover") -> "Cover":
        assert self.skeleton == other.skeleton
        cur = list(self.products)
        for b in other.products:
            nxt = []
            for a in cur:
                nxt.extend(a.difference(b))
            cur = nxt
            if not cur:
                break
        return Cover(self.skeleton, cur)

    def notation(self) -> str:
        sk = " \u2218 ".join(self.skeleton)
        if not self.products:
            return f"\u2205  [skeleton {sk}]"
        body = "\n      \u222a ".join(p.notation() for p in self.products)
        return f"\u27e8{sk}\u27e9 :  {body}"


# --------------------------------------------------------------------------
# CoverageSet: skeleton -> Cover. The full claim object.
# --------------------------------------------------------------------------
class CoverageSet:
    def __init__(self, covers: Dict[Tuple[str, ...], Cover] = None):
        self.covers: Dict[Tuple[str, ...], Cover] = dict(covers or {})

    def add(self, cover: Cover):
        if cover.skeleton in self.covers:
            self.covers[cover.skeleton] = self.covers[cover.skeleton].union(cover)
        else:
            self.covers[cover.skeleton] = cover
        return self

    def size_exact(self) -> int:
        return sum(c.size_exact() for c in self.covers.values())

    def union(self, other: "CoverageSet") -> "CoverageSet":
        out = CoverageSet({k: Cover(k, list(v.products)) for k, v in self.covers.items()})
        for sk, cov in other.covers.items():
            out.add(Cover(sk, list(cov.products)))
        return out

    def difference(self, other: "CoverageSet") -> "CoverageSet":
        out = CoverageSet()
        for sk, cov in self.covers.items():
            if sk in other.covers:
                d = cov.difference(other.covers[sk])
                if d.products:
                    out.covers[sk] = d
            else:
                out.covers[sk] = Cover(sk, list(cov.products))
        return out

    def notation(self) -> str:
        return "\n\n".join(c.notation() for c in self.covers.values())

    def to_json(self):
        return {
            "skeletons": [
                {"skeleton": list(sk),
                 "products": [p.to_json() for p in cov.products],
                 "size_exact": cov.size_exact()}
                for sk, cov in sorted(self.covers.items())
            ],
            "size_exact_total": self.size_exact(),
        }

    def digest(self) -> str:
        """Canonical content hash. Order-independent, so equal coverage -> equal hash."""
        canon = json.dumps(self.to_json(), sort_keys=True, separators=(",", ":"))
        return "sha256:" + hashlib.sha256(canon.encode()).hexdigest()


# --------------------------------------------------------------------------
# Convenience builders
# --------------------------------------------------------------------------
def prod(**dims) -> Product:
    return Product(dims)

def cover(skeleton, *products) -> Cover:
    return Cover(tuple(skeleton), list(products))


if __name__ == "__main__":
    # self-test: difference is exact and disjoint
    A = prod(a={1,2,3}, b={"x","y"})
    B = prod(a={2}, b={"x"})
    diff = A.difference(B)
    tot = sum(p.size() for p in diff)
    assert A.size() == 6 and B.size() == 1 and tot == 5, (A.size(), tot)
    # verify pointwise
    pts = {(i,j) for i in (1,2,3) for j in ("x","y")}
    got = set()
    for p in diff:
        for i in p.dims["a"]:
            for j in p.dims["b"]:
                assert (i,j) not in got, "products overlap"
                got.add((i,j))
    assert got == pts - {(2,"x")}
    print("covalg self-test OK: difference exact and disjoint (6 - 1 = 5)")
