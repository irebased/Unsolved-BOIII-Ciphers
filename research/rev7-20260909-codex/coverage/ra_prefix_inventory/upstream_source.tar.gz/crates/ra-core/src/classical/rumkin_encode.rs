//! rumkin.com's Letter Numbers and Baconian, from the pages' own inline scripts.
//!
//! # Letter Numbers: two independent flags, and a greedy 2-digit decode
//!
//! The site packs its options into a method string whose characters 1 and 3 are the
//! `pad` and `hyphen` flags. This node exposes them as booleans instead.
//!
//! * `pad` zero-pads 1..9 to `01`..`09`.
//! * `hyphen` separates numbers with `-`.
//!
//! Decoding always reads **greedily, up to two digits**, regardless of the flags:
//! `123` becomes `12` then `3`, i.e. `LC`, never `1,2,3`. A value outside 1..26 after
//! that lookahead is simply dropped. So encoding without padding and decoding is
//! *not* a round trip for text whose numbers are ambiguous — see
//! `numbers_decode_is_greedy_so_unpadded_is_lossy`, which pins the trap rather than
//! hiding it.
//!
//! Runs of non-letters collapse to a single space on encode (newlines survive as
//! themselves), so layout is not preserved.
//!
//! # Baconian: MSB-first over a parameterised alphabet
//!
//! `idx & 0x10` down to `idx & 0x01` emits `A`/`B` most-significant bit first. The
//! alphabet is a parameter, which is how the site offers both the 24-letter
//! (I/J and U/V shared) and 26-letter variants. Decoding maps `0`/`1` onto `A`/`B`
//! first, so both notations are accepted.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: transforms at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const NUMBERS: &str = "rumkin_numbers";
const BACONIAN: &str = "rumkin_baconian";
const AZ: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZ";

fn enc_dir(node: &'static str, params: &Params) -> Result<bool> {
    match params.opt_str("direction").unwrap_or("decrypt") {
        "encrypt" => Ok(true),
        "decrypt" => Ok(false),
        o => Err(Error::bad_param(node, "direction", format!("got {o:?}"))),
    }
}

const NUM_SCHEMA: &[ParamSpec] = &[
    ParamSpec::opt("pad", ParamType::Bool, "zero-pad 1..9 to 01..09 (default false)"),
    ParamSpec::opt("hyphen", ParamType::Bool, "separate numbers with '-' (default false)"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// The site's Letter Numbers tool (`numbers.php`).
pub struct RumkinNumbers;

impl Node for RumkinNumbers {
    fn name(&self) -> &'static str { NUMBERS }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_encode(numbers.php)" }
    fn params_schema(&self) -> &'static [ParamSpec] { NUM_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let pad = params.opt_bool("pad", false);
        let hyph = params.opt_bool("hyphen", false);
        let mut out: Vec<u8> = Vec::new();
        if enc_dir(NUMBERS, params)? {
            let mut add_hyphen = false;
            for &c in input.data.iter() {
                let up = c.to_ascii_uppercase();
                match AZ.iter().position(|&x| x == up) {
                    Some(i) => {
                        let j = i + 1;
                        if add_hyphen && hyph { out.push(b'-'); }
                        if j < 10 && pad { out.push(b'0'); }
                        out.extend(j.to_string().into_bytes());
                        add_hyphen = true;
                    }
                    None => {
                        if add_hyphen {
                            if c == b'\n' || c == b'\r' { out.push(c); } else { out.push(b' '); }
                        }
                        add_hyphen = false;
                    }
                }
            }
        } else {
            let d = &input.data;
            let mut i = 0usize;
            let mut was_letter = false;
            while i < d.len() {
                let c = d[i];
                if !c.is_ascii_digit() {
                    if !(was_letter && hyph && c == b'-') { out.push(c); }
                    was_letter = false;
                    i += 1;
                    continue;
                }
                // greedy: take a second digit when one is there
                let mut v = (c - b'0') as usize;
                if i + 1 < d.len() && d[i + 1].is_ascii_digit() {
                    v = v * 10 + (d[i + 1] - b'0') as usize;
                    i += 1;
                }
                if (1..=26).contains(&v) { out.push(AZ[v - 1]); }
                was_letter = true;
                i += 1;
            }
        }
        Ok(Repr::new(out, if enc_dir(NUMBERS, params)? { Display::Decimal } else { Display::Bytes }))
    }
}

const BAC_SCHEMA: &[ParamSpec] = &[
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "alphabet indexed by the 5-bit code (default the 26 letters; pass a 24-letter \
         form for the classical I/J, U/V sharing variant)",
    ),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// The site's Baconian tool (`baconian.php`).
pub struct RumkinBaconian;

impl Node for RumkinBaconian {
    fn name(&self) -> &'static str { BACONIAN }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_encode(baconian.php,MSB-first)" }
    fn params_schema(&self) -> &'static [ParamSpec] { BAC_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let alpha: Vec<u8> = params
            .opt_str("alphabet")
            .unwrap_or("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
            .bytes()
            .map(|b| b.to_ascii_uppercase())
            .collect();
        if alpha.is_empty() {
            return Err(Error::bad_param(BACONIAN, "alphabet", "must not be empty"));
        }
        let mut out: Vec<u8> = Vec::new();
        if enc_dir(BACONIAN, params)? {
            let mut space_added = true;
            for &c in input.data.iter() {
                let up = c.to_ascii_uppercase();
                match alpha.iter().position(|&x| x == up) {
                    Some(idx) => {
                        for bit in [0x10usize, 0x08, 0x04, 0x02, 0x01] {
                            out.push(if idx & bit != 0 { b'B' } else { b'A' });
                        }
                        space_added = false;
                    }
                    None => {
                        if !space_added {
                            out.push(b' ');
                            space_added = true;
                        }
                    }
                }
            }
        } else {
            let mut buf: Vec<u8> = Vec::with_capacity(5);
            for &c in input.data.iter() {
                // Tr(str,'01','AB') then keep only A/B
                let u = match c.to_ascii_uppercase() {
                    b'0' => b'A',
                    b'1' => b'B',
                    x => x,
                };
                if u == b'A' || u == b'B' {
                    buf.push(u);
                    if buf.len() == 5 {
                        let mut idx = 0usize;
                        for (k, &b) in buf.iter().enumerate() {
                            if b == b'B' { idx |= 0x10 >> k; }
                        }
                        if idx < alpha.len() { out.push(alpha[idx]); }
                        buf.clear();
                    }
                }
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(RUMKIN_NUMBERS => || Box::new(RumkinNumbers));
register_node!(RUMKIN_BACONIAN => || Box::new(RumkinBaconian));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn n(name: &str) -> &'static dyn Node { registry().get(name).unwrap() }

    #[test]
    fn both_are_xf() {
        for x in [NUMBERS, BACONIAN] { assert_eq!(n(x).family(), Family::Xf); }
    }

    #[test]
    fn numbers_encodes_with_and_without_flags() {
        let plain = n(NUMBERS)
            .apply(&Repr::bytes(b"ABC".to_vec()), &params! {"direction" => "encrypt"})
            .unwrap();
        assert_eq!(plain.data, b"123");
        let padded = n(NUMBERS)
            .apply(&Repr::bytes(b"ABC".to_vec()), &params! {"pad" => true, "direction" => "encrypt"})
            .unwrap();
        assert_eq!(padded.data, b"010203");
        let hyph = n(NUMBERS)
            .apply(&Repr::bytes(b"ABC".to_vec()), &params! {"hyphen" => true, "direction" => "encrypt"})
            .unwrap();
        assert_eq!(hyph.data, b"1-2-3");
    }

    /// Non-letter runs collapse to one space; newlines survive as themselves.
    #[test]
    fn numbers_collapses_non_letter_runs() {
        let out = n(NUMBERS)
            .apply(&Repr::bytes(b"AB,, CD\nEF".to_vec()), &params! {"direction" => "encrypt"})
            .unwrap();
        assert_eq!(out.data, b"12 34\n56");
    }

    /// Padded or hyphenated numbers round-trip.
    #[test]
    fn numbers_round_trips_when_unambiguous() {
        for p in [params! {"pad" => true}, params! {"hyphen" => true}] {
            let e = n(NUMBERS)
                .apply(&Repr::bytes(b"HELLO".to_vec()), &p.clone().set("direction", "encrypt"))
                .unwrap();
            let d = n(NUMBERS).apply(&e, &p).unwrap();
            assert_eq!(d.data, b"HELLO", "{p:?}");
        }
    }

    /// The trap: decoding is greedy over two digits, so unpadded output is lossy.
    /// "AB" -> "12" -> decodes as 12 -> "L", not "AB".
    #[test]
    fn numbers_decode_is_greedy_so_unpadded_is_lossy() {
        let e = n(NUMBERS)
            .apply(&Repr::bytes(b"AB".to_vec()), &params! {"direction" => "encrypt"})
            .unwrap();
        assert_eq!(e.data, b"12");
        let d = n(NUMBERS).apply(&e, &Params::new()).unwrap();
        assert_eq!(d.data, b"L", "greedy lookahead reads 12, not 1 then 2");
    }

    /// MSB-first: A is 00000, B is 00001, C is 00010.
    #[test]
    fn baconian_is_msb_first() {
        let out = n(BACONIAN)
            .apply(&Repr::bytes(b"ABC".to_vec()), &params! {"direction" => "encrypt"})
            .unwrap();
        assert_eq!(out.data, b"AAAAAAAAABAAABA");
    }

    #[test]
    fn baconian_round_trips_and_accepts_01_notation() {
        let p = Params::new();
        let e = n(BACONIAN)
            .apply(&Repr::bytes(b"HELLO".to_vec()), &params! {"direction" => "encrypt"})
            .unwrap();
        assert_eq!(n(BACONIAN).apply(&e, &p).unwrap().data, b"HELLO");
        // the same code written with 0/1 decodes identically
        let zeros: Vec<u8> = e.data.iter()
            .map(|&c| match c { b'A' => b'0', b'B' => b'1', x => x })
            .collect();
        assert_eq!(n(BACONIAN).apply(&Repr::bytes(zeros), &p).unwrap().data, b"HELLO");
    }

    /// A 24-letter alphabet is the classical variant, and it shifts the codes.
    #[test]
    fn baconian_alphabet_is_a_parameter() {
        let p24 = params! {"alphabet" => "ABCDEFGHIKLMNOPQRSTUWXYZ", "direction" => "encrypt"};
        let a = n(BACONIAN).apply(&Repr::bytes(b"Z".to_vec()), &p24).unwrap();
        let b = n(BACONIAN)
            .apply(&Repr::bytes(b"Z".to_vec()), &params! {"direction" => "encrypt"})
            .unwrap();
        assert_ne!(a.data, b.data, "24- and 26-letter forms must differ");
    }
}
