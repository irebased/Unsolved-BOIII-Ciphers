//! ASCII base conversion, matching geocachingtoolbox.com's `asciiConversion`
//! tool (page `Base conversion of text (ASCII)`).
//!
//! # Ground truth
//!
//! `docs/toolsites/geocachingtoolbox.json`, tool `"Base conversion of text
//! (ASCII)"` (`page_id: "asciiConversion"`). `asciiConversion`/`convertBase`
//! were run verbatim under Node (a DOM shim stands in for
//! `document.getElementById`) to produce every vector below, including the
//! per-format padding behaviour this module exists to pin down.
//!
//! # Scope: `text`/`bin`/`oct`/`dec`/`hex` only
//!
//! The site also offers `b32`, `b64` and `html` as `from`/`to` types. Those
//! three are **not ported** here: `b32`/`b64` use a non-standard, site-specific
//! bit-accumulation scheme (each `=` trims exactly one bit off the end of the
//! run rather than a whole symbol's worth), and `html` round-trips through a
//! literal `<br>` token for newlines that a real browser copy would need
//! HTML-entity decoding to reproduce faithfully. None of the three bears on
//! the zero-padding investigation this tool was ported for (see below), so
//! they were cut rather than risk an unfaithful port under time pressure —
//! flagged here as a deliberate gap, not an oversight.
//!
//! # The zero-padding lead: **not a match, except one field**
//!
//! The wider investigation is hunting an encoder that emits fixed-width,
//! zero-padded *decimal* tokens (observed: exactly 3 digits, e.g. `007`,
//! `065`). Checked directly against the site's `asciiConversion`/`convertBase`
//! (ground truth: `run_ascii.js`, and the `dec->hex(5)`/`dec->oct(5)` probes
//! below):
//!
//! - `dec` output is **never padded** — `72 105 33`, and a single-digit value
//!   stays a single digit (`"5"`, not `"005"`).
//! - `oct` and `hex` are likewise **never padded** (`"5"`, not `"05"` or
//!   `"005"`).
//! - `bin` **is** zero-padded — but to a fixed width of **8 bits**, not 3
//!   decimal digits: `("00000000" + convertBase(...)).slice(-8)` in the
//!   source. Not a match either.
//!
//! So this tool is **not** the source of the 3-digit zero-padded tokens. Per
//! the investigation's instruction to make padding explicit wherever it's
//! plausible, [`AsciiBaseGctb`] exposes `zero_pad_width` (default `0`, i.e.
//! matching the site: no padding for `dec`/`oct`/`hex`) so a sweep can force
//! fixed-width decimal/octal/hex output if some other undiscovered tool turns
//! out to share this one's alphabet, and `bin_width` (default `8`, the site's
//! hard-coded value) for the same reason on the one field the site *does* pad.
//!
//! # Direction
//!
//! The site's tool is a symmetric `from`/`to` converter (there is no
//! privileged "decrypt" direction — `dec -> text` is exactly as much a
//! `Family::Xf` step as `text -> dec`), so unlike the morse/numbers-to-letters
//! nodes in this module, [`AsciiBaseGctb`] does not need a test-only encode
//! helper: both directions are already reachable through `from`/`to`, exactly
//! as they are on the site.
//!
//! # Artifacts
//!
//! `output_method: "innerHTML"`, `copy_artifact_risk: "HIGH"`, and the result
//! is itself rendered into a nested `<textarea>` (`output_format_details`:
//! `textarea_output: true`) — reproduced as a `Trailing::CrLf` default, same
//! reasoning as every other `.innerHTML` tool in this module.

use crate::classical::toolfmt::{read_output_fmt, CaseFold, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const NAME: &str = "ascii_base_conversion";

const SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "from",
        ParamType::Str,
        "source representation: text|bin|oct|dec|hex (default: text, the site's default)",
    ),
    ParamSpec::opt(
        "to",
        ParamType::Str,
        "destination representation: text|bin|oct|dec|hex (default: bin, the site's default)",
    ),
    ParamSpec::opt(
        "no_spaces",
        ParamType::Bool,
        "omit the separating space between tokens in numeric output (default: false, \
         matching the site's asciiCheckNoSpaces unchecked default)",
    ),
    ParamSpec::opt(
        "zero_pad_width",
        ParamType::Int,
        "left-pad each dec/oct/hex token with '0' to this many characters; 0 disables \
         padding (default: 0, matching the site -- the site never pads dec/oct/hex). \
         Exists so a sweep can probe for the unidentified fixed-width zero-padded \
         numeric encoder this tool was checked against and ruled out for.",
    ),
    ParamSpec::opt(
        "bin_width",
        ParamType::Int,
        "zero-pad each bin token to this many bits (default: 8, the site's hard-coded \
         width)",
    ),
);

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Format {
    Text,
    Bin,
    Oct,
    Dec,
    Hex,
}

impl Format {
    fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "text" => Format::Text,
            "bin" => Format::Bin,
            "oct" => Format::Oct,
            "dec" => Format::Dec,
            "hex" => Format::Hex,
            _ => return None,
        })
    }
}

/// `conversion['text']`: byte -> the character the site's `text` table maps it
/// to, transcribed verbatim (dumped from the live array via `node
/// dump_ascii_tables.js`). Only tab (9), LF (10), CR (13), printable ASCII
/// (32..=126), and -- a genuine site quirk, not a transcription error --
/// non-breaking-space (160) and soft-hyphen (173), both of which the site's
/// table maps to a literal `' '`, are present. Everything else is blank
/// (`None`): decoding those byte values to text silently drops them, exactly
/// as `newDiv+=conversion['text'][decResult[i]]` does when the table entry is
/// `""`.
fn text_table_to_char(byte: u8) -> Option<u8> {
    match byte {
        9 | 10 | 13 => Some(byte),
        32..=126 => Some(byte),
        160 | 173 => Some(b' '),
        _ => None,
    }
}

/// Inverse of [`text_table_to_char`] for encoding *from* text: `indexOf`
/// returns the *first* matching index, which is always the primary one below
/// (160/173 both alias to `' '` but 32 sorts first in the site's array, so
/// `indexOf(' ')` is always 32).
fn char_to_text_table(byte: u8) -> Option<u8> {
    match byte {
        9 | 10 | 13 => Some(byte),
        32..=126 => Some(byte),
        _ => None,
    }
}

/// `parseInt(splitChars[i])` for the `dec` fromType: a leading optional sign
/// followed by decimal digits. (The site's plain `parseInt` without a radix
/// has a documented JS quirk of auto-detecting a `0x` prefix as hex; that
/// quirk is not reproduced here since it never arises from this tool's own
/// output and is not plausible to encounter as an actual `dec` ciphertext.)
fn parse_decimal(token: &str) -> Option<i64> {
    let bytes = token.as_bytes();
    let mut i = 0;
    let neg = if i < bytes.len() && (bytes[i] == b'+' || bytes[i] == b'-') {
        let n = bytes[i] == b'-';
        i += 1;
        n
    } else {
        false
    };
    let start = i;
    while i < bytes.len() && bytes[i].is_ascii_digit() {
        i += 1;
    }
    if i == start {
        return None;
    }
    let v: i64 = token[start..i].parse().ok()?;
    Some(if neg { -v } else { v })
}

/// `convertBase(token, alphabet, decAlphabet, false)` for a purely-digit
/// alphabet (bin/oct/hex): parse `token` in the given `radix` and
/// `digit_chars` (case-insensitive, matching the site's `cSense=false` for
/// single-case alphabets), skipping any byte not in `digit_chars` exactly as
/// the site's `digVal>-1` guard does (it does not abort the parse, just
/// contributes nothing for that byte).
fn parse_radix(token: &str, digit_chars: &[u8], radix: u32) -> i64 {
    let mut val: i64 = 0;
    let mut mult: i64 = 1;
    for &b in token.as_bytes().iter().rev() {
        let up = b.to_ascii_uppercase();
        if let Some(pos) = digit_chars.iter().position(|&d| d.to_ascii_uppercase() == up) {
            val += mult * pos as i64;
            mult *= radix as i64;
        }
    }
    val
}

const BIN_DIGITS: &[u8] = b"01";
const OCT_DIGITS: &[u8] = b"01234567";
const HEX_DIGITS: &[u8] = b"0123456789ABCDEF";

/// Preprocessing the site applies before parsing *any* non-`text` fromType:
/// collapse literal line breaks to a single space, then collapse runs of
/// multiple spaces to one. (`chars=chars.replace(/(?:\r\n|\r|\n)/g,'
/// ');chars=chars.replace(/ +(?= )/g,'');`)
fn collapse_separators(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '\r' {
            if chars.peek() == Some(&'\n') {
                chars.next();
            }
            out.push(' ');
        } else if c == '\n' {
            out.push(' ');
        } else {
            out.push(c);
        }
    }
    let mut collapsed = String::with_capacity(out.len());
    let mut prev_space = false;
    for c in out.chars() {
        if c == ' ' {
            if !prev_space {
                collapsed.push(' ');
            }
            prev_space = true;
        } else {
            collapsed.push(c);
            prev_space = false;
        }
    }
    collapsed
}

/// Decode `text` (the tool's `from` representation) into the byte sequence
/// `decResult`, matching `asciiConversion`'s per-`fromType` branch exactly.
fn decode_from(from: Format, text: &str) -> Vec<u8> {
    match from {
        Format::Text => text.bytes().filter_map(char_to_text_table).collect(),
        Format::Bin | Format::Oct | Format::Dec | Format::Hex => {
            let prepped = collapse_separators(text);
            prepped
                .split(' ')
                .filter_map(|tok| {
                    if tok.is_empty() {
                        return None;
                    }
                    let n = match from {
                        Format::Bin => parse_radix(tok, BIN_DIGITS, 2),
                        Format::Oct => parse_radix(tok, OCT_DIGITS, 8),
                        Format::Hex => parse_radix(tok, HEX_DIGITS, 16),
                        Format::Dec => parse_decimal(tok)?,
                        Format::Text => unreachable!(),
                    };
                    if (0..256).contains(&n) {
                        Some(n as u8)
                    } else {
                        None
                    }
                })
                .collect()
        }
    }
}

fn format_radix(mut n: u32, digit_chars: &[u8], radix: u32) -> String {
    if n == 0 {
        return (digit_chars[0] as char).to_string();
    }
    let mut digits = Vec::new();
    while n > 0 {
        digits.push(digit_chars[(n % radix) as usize]);
        n /= radix;
    }
    digits.reverse();
    String::from_utf8(digits).unwrap()
}

/// Left-pad `s` with `'0'` to `width` characters. `width <= s.len()` is a
/// no-op, matching "pad, never truncate" for every numeric field on this
/// site (only `bin`'s width is enforced by the site itself; `zero_pad_width`
/// is this node's own opt-in extension -- see the module doc's zero-padding
/// section).
fn zero_pad(s: String, width: usize) -> String {
    if s.len() >= width {
        return s;
    }
    let mut out = "0".repeat(width - s.len());
    out.push_str(&s);
    out
}

/// Encode `decResult` (bytes) into the tool's `to` representation, matching
/// the corresponding branch of `asciiConversion` exactly, including the
/// site's hard-coded 8-bit zero-padding for `bin` and complete absence of
/// padding for `oct`/`dec`/`hex` (see the module doc's zero-padding section).
fn encode_to(
    to: Format,
    bytes: &[u8],
    no_spaces: bool,
    zero_pad_width: usize,
    bin_width: usize,
) -> Vec<u8> {
    match to {
        Format::Text => bytes.iter().filter_map(|&b| text_table_to_char(b)).collect(),
        Format::Bin | Format::Oct | Format::Dec | Format::Hex => {
            let mut out = String::new();
            for (i, &b) in bytes.iter().enumerate() {
                if i > 0 && !no_spaces {
                    out.push(' ');
                }
                let tok = match to {
                    Format::Bin => zero_pad(format_radix(b as u32, BIN_DIGITS, 2), bin_width),
                    Format::Oct => zero_pad(format_radix(b as u32, OCT_DIGITS, 8), zero_pad_width),
                    Format::Dec => zero_pad(b.to_string(), zero_pad_width),
                    Format::Hex => zero_pad(format_radix(b as u32, HEX_DIGITS, 16), zero_pad_width),
                    Format::Text => unreachable!(),
                };
                out.push_str(&tok);
            }
            out.into_bytes()
        }
    }
}

pub struct AsciiBaseGctb;

impl Node for AsciiBaseGctb {
    fn name(&self) -> &'static str {
        NAME
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/ascii_base_gctb(geocachingtoolbox.com asciiConversion, \
         text/bin/oct/dec/hex only)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let from = match params.opt_str("from") {
            Some(s) => Format::parse(s).ok_or_else(|| {
                Error::bad_param(NAME, "from", format!("expected text|bin|oct|dec|hex, got {s:?}"))
            })?,
            None => Format::Text,
        };
        let to = match params.opt_str("to") {
            Some(s) => Format::parse(s).ok_or_else(|| {
                Error::bad_param(NAME, "to", format!("expected text|bin|oct|dec|hex, got {s:?}"))
            })?,
            None => Format::Bin,
        };
        if from == to {
            // The site's own early exit: same-type conversion never produces a
            // result textarea at all ("Conversion to the same type is not
            // necessary."), so there is nothing to copy.
            return Err(Error::node_failed(
                NAME,
                "from and to are the same representation; the site produces no result \
                 for this combination",
            ));
        }
        let no_spaces = params.opt_bool("no_spaces", false);
        let zero_pad_width = params.opt_i64("zero_pad_width", 0).max(0) as usize;
        let bin_width = params.opt_i64("bin_width", 8).max(0) as usize;

        let text = String::from_utf8_lossy(&input.data).into_owned();
        let bytes = decode_from(from, &text);
        let encoded = encode_to(to, &bytes, no_spaces, zero_pad_width, bin_width);

        let fmt = read_output_fmt(
            NAME,
            params,
            OutputFmt {
                case: CaseFold::Preserve, // hex is already uppercase by construction
                grouping: None,
                trailing: Trailing::CrLf, // .innerHTML select-all copy risk (HIGH)
            },
        )?;
        Ok(Repr::new(fmt.apply(&encoded), Display::Bytes))
    }
}

register_node!(ASCII_BASE_GCTB => || Box::new(AsciiBaseGctb));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn node() -> &'static dyn Node {
        registry().get(NAME).unwrap()
    }

    fn run(from: &str, to: &str, text: &[u8], no_spaces: bool) -> Vec<u8> {
        let mut p = params! {"from" => from, "to" => to, "trailing" => "none"};
        if no_spaces {
            p.0.insert("no_spaces".into(), true.into());
        }
        node().apply(&Repr::bytes(text.to_vec()), &p).unwrap().data
    }

    /// Ground truth: `node run_ascii.js` running `asciiConversion` from the
    /// site's own JS under a DOM shim.
    #[test]
    fn ground_truth_from_site_js() {
        assert_eq!(run("text", "bin", b"Hi!", false), b"01001000 01101001 00100001");
        assert_eq!(run("text", "bin", b"Hi!", true), b"010010000110100100100001");
        assert_eq!(run("text", "oct", b"Hi!", false), b"110 151 41");
        assert_eq!(run("text", "dec", b"Hi!", false), b"72 105 33");
        assert_eq!(run("text", "hex", b"Hi!", false), b"48 69 21");
        assert_eq!(run("bin", "text", b"01001000 01101001 00100001", false), b"Hi!");
        assert_eq!(run("oct", "text", b"110 151 41", false), b"Hi!");
        assert_eq!(run("dec", "text", b"72 105 33", false), b"Hi!");
        assert_eq!(run("hex", "text", b"48 69 21", false), b"Hi!");
        assert_eq!(
            run("text", "dec", b"hello world, test 123!", false),
            b"104 101 108 108 111 32 119 111 114 108 100 44 32 116 101 115 116 32 49 50 51 33"
        );
    }

    /// The zero-padding lead: none of dec/oct/hex pad; bin pads to a fixed 8
    /// bits, not 3 decimal digits. Ground truth: `dec->hex(5)` / `dec->oct(5)`
    /// probes against the site's own JS (see module doc).
    #[test]
    fn zero_padding_lead_ruled_out_except_bin_at_width_8() {
        assert_eq!(run("dec", "hex", b"5", false), b"5", "hex must not pad a single digit");
        assert_eq!(run("dec", "oct", b"5", false), b"5", "oct must not pad a single digit");
        assert_eq!(
            run("dec", "hex", b"5 10 255", false),
            b"5 A FF",
            "hex is never zero-padded, even mixed with 2-digit values"
        );
        assert_eq!(run("dec", "bin", b"5", false), b"00000101", "bin pads, but to width 8");
    }

    /// The escape-hatch params exist for a sweep, not because the site uses
    /// them: with `zero_pad_width` unset (default 0) behaviour is identical
    /// to the site's own unpadded dec/oct/hex.
    #[test]
    fn zero_pad_width_param_is_opt_in_and_off_by_default() {
        assert_eq!(run("dec", "hex", b"5", false), b"5");
        let out = node()
            .apply(
                &Repr::bytes(b"5".to_vec()),
                &params! {"from" => "dec", "to" => "hex", "zero_pad_width" => 3i64, "trailing" => "none"},
            )
            .unwrap();
        assert_eq!(out.data, b"005");
    }

    #[test]
    fn bin_width_param_overrides_site_default_of_8() {
        let out = node()
            .apply(
                &Repr::bytes(b"5".to_vec()),
                &params! {"from" => "dec", "to" => "bin", "bin_width" => 4i64, "trailing" => "none"},
            )
            .unwrap();
        assert_eq!(out.data, b"0101");
    }

    #[test]
    fn round_trip_text_through_every_numeric_format() {
        for fmt in ["bin", "oct", "dec", "hex"] {
            let encoded = run("text", fmt, b"Hello, World! 123", false);
            let back = run(fmt, "text", &encoded, false);
            assert_eq!(back, b"Hello, World! 123", "fmt={fmt}");
        }
    }

    #[test]
    fn same_from_and_to_errors_like_the_site() {
        let err = node()
            .apply(
                &Repr::bytes(b"hi".to_vec()),
                &params! {"from" => "text", "to" => "text"},
            )
            .unwrap_err();
        assert!(matches!(err, Error::NodeFailed { .. }), "{err}");
    }

    #[test]
    fn malformed_from_is_rejected() {
        let err = node()
            .apply(
                &Repr::bytes(b"hi".to_vec()),
                &params! {"from" => "sideways", "to" => "bin"},
            )
            .unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn text_decode_silently_drops_control_bytes_outside_the_sites_table() {
        // byte 5 (ENQ) is blank in the site's text table
        assert_eq!(run("dec", "text", b"72 5 105", false), b"Hi");
    }

    #[test]
    fn is_xf_family_and_not_layer_forming() {
        let n = node();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
