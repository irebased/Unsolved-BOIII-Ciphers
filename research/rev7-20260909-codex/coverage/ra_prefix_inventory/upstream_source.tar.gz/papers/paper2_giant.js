const S = require("./style.js");
const { docx, PAGE, numbering, title, subtitle, h1, h2, h3, p, mono, li, numItem, table, callout, spacer, makeHeaderFooter } = S;
const { Document, Packer, Paragraph, TextRun, AlignmentType, BorderStyle } = docx;
const fs = require("fs");

const TG4 = "kCmlgFi6GUJNgkNI1Q41fbfyLoCFTCvIqkZiI0KIAXAzP1U1uy1BE4UfPBfpKmmLObjYnQNRBaPtKiVWzc5A4v0w3xle8FOhAGJZ7g4in0wndJxMOvO3dc1M82at2T6935roTqyWDgtGD/hwwRF3oHqFM5Vcw1JtINbsgWRm4o4/quEDkZ7x1B275bX3/Fo1";

const children = [];
const A = (...x) => children.push(...x);

A(title("Target Analysis: The Giant 4"));
A(subtitle("Structural Profile, Evidence Tiers, and a Constrained Search Plan"));
A(p([
  { t: "Document 2 of 3 (Target Paper). ", bold: true },
  "This paper analyzes the unsolved cipher The Giant 4 (TG4). It is self-contained but relies on Document 1 for the shared modern-encryption invariants (key, IV, mode, tool set) and the evidence taxonomy. The Giant shipped at launch, twelve months before Revelations. TG4 therefore cannot be assumed to share the mature, consolidated tool practice of the Revelations ciphers, and no forward inference from Revelations to TG4 is treated as more than a working hypothesis in what follows.",
]));
A(callout("Chronological caution.", [
  "TG4 predates the Revelations corpus by roughly one year. Techniques and tool habits observed in Revelations may or may not have been in the author's repertoire at launch. Any Revelations-derived expectation applied to TG4 is a working hypothesis, not a forensic inference.",
]));

// 1. Cipher of record
A(h1("1. The Cipher of Record"));
A(p([
  "TG4 is presented on an in-world paper as a Base64 string of 192 characters, displayed in four rows. The label ",
  { t: "TheGiant", mono: true },
  " appears at the top left of the paper, rendered with the words joined and both the T and the G capitalized. The ciphertext of record, per the documentation project, is:",
]));
A(...mono(TG4.match(/.{1,64}/g).join("\n")));
A(table(
  ["Field", "Value"],
  [
    ["In-world location", "Zombie barrier beneath the clocktower, taped to the back wall, upside down"],
    ["Presented encoding", "Base64"],
    ["Character length", "192"],
    ["Decoded length", "144 bytes"],
    ["Candidate key (top left)", "TheGiant"],
  ],
  [2800, 6440]
));

// 2. Hard facts
A(h1("2. Hard Facts (Directly Measured)"));
A(p("The following are computed directly from the ciphertext of record and are safe to use as search constraints."));
A(table(
  ["Measurement", "Value", "Interpretation"],
  [
    ["Base64 length", "192 chars", "Exactly 144 bytes after decode"],
    ["Decoded byte count", "144", "144 = 16 x 9 and 8 x 18"],
    ["16-byte block aligned", "Yes (144 mod 16 = 0)", "Consistent with AES/Rijndael-128 block"],
    ["8-byte block aligned", "Yes (144 mod 8 = 0)", "Consistent with DES/Blowfish/RC2 block"],
    ["Shannon entropy (Base64 symbols)", "5.80 / 6.00 bits", "High; near the ceiling for a 64-symbol alphabet"],
    ["Byte entropy (decoded)", "6.77 / 8.00 bits", "High but not maximal over 144 bytes"],
    ["Printable ASCII after decode", "42.4%", "Decoded bytes are not text; a further layer is present"],
    ["Index of coincidence (B64)", "0.0146", "Flat, near uniform; no classical periodicity at surface"],
  ],
  [3400, 2300, 3540]
));
A(callout("Hard fact.", [
  "The decoded 144 bytes are block-aligned for both 8-byte and 16-byte block ciphers and are not printable text. The surface Base64 is an encoding, not the final layer. The plausible primitive family is a block cipher; no block-size ambiguity excludes either the DES-class (8-byte) or the AES-class (16-byte) menu.",
]));

// 3. The key candidate
A(h1("3. The Key-Candidate Question"));
A(p([
  "The top-left label is the most consequential ambiguity in the target. Two readings are live, and they lead to different search programs.",
]));
A(h2("3.1 Reading A: TheGiant as a supplied key"));
A(p([
  "The author's general practice is to supply the key in-world, frequently in the top-left corner of the paper. Der Eisendrache provides a precedent in which the key was written plainly in the top-left position. Under this reading, ",
  { t: "TheGiant", mono: true },
  " is the key, and the search fixes the key while enumerating primitive, mode, and layer structure. This is the leading working hypothesis and is consistent with the documentation project's own note.",
]));
A(h2("3.2 Reading B: TheGiant as a red herring or a label"));
A(p([
  "The label is also simply the name of the map and may be decorative. A complication sharpens the ambiguity: the string ",
  { t: "TheGiant", mono: true },
  " is itself a valid Base64 sequence. It decodes to six bytes and could therefore be intended as a Base64-encoded key rather than an ASCII key, or could be meaningless as a key altogether. The search must therefore consider ",
  { t: "TheGiant", mono: true },
  " as an ASCII key, as a Base64-decoded key, and as non-key.",
]));
A(callout("Working hypothesis, not fact.", [
  "The most probable single reading is that TheGiant is a supplied key in ASCII, by analogy to the Der Eisendrache top-left precedent. This is a prior that should order the search, not a constraint that should prune it. The Base64-key and non-key readings must remain in the enumeration.",
]));

// 4. Transcription risk
A(h1("4. Transcription Risk"));
A(p([
  "The in-world text is rendered in an Oswald-derived font whose glyphs do not cleanly distinguish lowercase l from uppercase I, or the letter O from the digit 0. Because Base64 is position-sensitive at the byte level, a single misread character corrupts the decode from that point forward and invalidates any downstream brute force that inherited it. Consultation with a contributor familiar with the Oswald font produced a preferred transcription, which is the ciphertext of record above, but as many as sixteen transcription variants are admissible under the glyph ambiguities.",
]));
A(callout("Hard fact and procedural constraint.", [
  "The transcription is not unique. Up to sixteen glyph-disambiguation variants exist. The preferred transcription is the working default, but any negative brute-force result over the preferred transcription must be re-run across the full variant set before the corresponding hypothesis is considered eliminated.",
]));

// 5. What has been tried
A(h1("5. What Has Been Attempted"));
A(p("The following approaches are recorded as exhausted or substantially exhausted and are documented here so the search does not repeat them without new structure."));
A(li([{ t: "mcrypt decryption on key TheGiant. ", bold: true }, "Brute force across mcrypt primitives and modes keyed with the candidate key has been run without a hit."]));
A(li([{ t: "Direct Base64 decode. ", bold: true }, "Decoding yields non-text bytes with no meaningful structure, as expected for an enciphered payload."]));
A(li([{ t: "Combinatorial mcrypt over transcription variants. ", bold: true }, "Reported as tried to no avail, though the completeness of variant coverage is not independently verified here."]));
A(callout("Interpretation.", [
  "A single mcrypt layer keyed with TheGiant does not solve TG4. Given block alignment and high entropy, the most likely missing elements are one of: a second layer, an initial transform before the modern layer, the key being Zombies rather than TheGiant, or a mode or IV that differs from the Revelations invariant because TG4 predates that consolidated practice.",
]));

// 6. Search plan
A(h1("6. A Constrained Search Plan"));
A(p("The plan is ordered by expected value. It fixes hard facts, applies forensic priors to ordering, and enumerates working hypotheses without letting any single one prune the space."));
A(h2("6.1 Fixed constraints (hard facts)"));
A(li("Input is 144 bytes after Base64 decode; treat the modern layer as operating on these bytes."));
A(li("Primitive family is a block cipher; enumerate both 8-byte and 16-byte block menus."));
A(li("Run every candidate pipeline across all admissible transcription variants before eliminating it."));
A(h2("6.2 Key enumeration (ordered by prior)"));
A(numItem([{ t: "TheGiant", mono: true }, " as ASCII key (leading prior, top-left precedent)."], "steps3"));
A(numItem([{ t: "Zombies", mono: true }, " as ASCII key (corpus-wide modern invariant from Document 1)."], "steps3"));
A(numItem([{ t: "TheGiant", mono: true }, " decoded from Base64 to six bytes, used as key."], "steps3"));
A(numItem([{ t: "ZOMBIES", mono: true }, " and other casings, as low-prior fallbacks."], "steps3"));
A(h2("6.3 Structure enumeration (working hypotheses)"));
A(li([{ t: "Single modern layer. ", bold: true }, "Block cipher over the 144 bytes under each key candidate, both ECB and CFB-8, IV as the ASCII-zero invariant and as a true null IV. Include DES-class and AES-class primitives from the Document 1 menu."]));
A(li([{ t: "Transform then modern. ", bold: true }, "A light pre-transform (reverse, ROT, or a route/columnar transposition on the Base64 or on the decoded bytes) preceding the modern layer, mirroring the Revelations inter-layer motif but not assuming it."]));
A(li([{ t: "Two modern layers. ", bold: true }, "Two stacked block primitives with an intervening re-encode (hex to Base64) or reverse, consistent with the multi-layer Revelations template."]));
A(li([{ t: "Classical over modern. ", bold: true }, "An outer classical transform over a modern core, as in Revelations 1. This is expensive to verify because a wrong outer classical decrypt over modern ciphertext yields pseudorandom output with no analytic signal, so it should be treated as a macro: fix the outer classical transform, then sweep the modern layer, and score only on final printable-text emergence."]));
A(h2("6.4 Tooling forensics to pursue in parallel"));
A(li([{ t: "Launch-era tool set. ", bold: true }, "Establish which tools were demonstrably in the author's practice at launch by fingerprinting the five solved Giant ciphers and the six Shadows of Evil ciphers, rather than importing the Revelations tool set wholesale."]));
A(li([{ t: "Base64 provenance. ", bold: true }, "Identify the specific Base64 encoder behavior (line width, padding, line-ending capture) in the solved launch-era Base64 ciphers, then test whether TG4 shares that fingerprint."]));

A(h1("7. Evidence Summary"));
A(table(
  ["Claim", "Tier"],
  [
    ["192 Base64 chars decode to 144 non-text bytes", "Hard fact"],
    ["Decoded payload is block-aligned (8 and 16 byte)", "Hard fact"],
    ["Up to sixteen admissible transcription variants", "Hard fact"],
    ["Single mcrypt layer on TheGiant does not solve", "Hard fact (negative result)"],
    ["TheGiant is a supplied ASCII key", "Working hypothesis (leading)"],
    ["TG4 uses a modern block cipher", "Working hypothesis (well supported)"],
    ["Key may be Zombies per corpus invariant", "Forensic inference"],
    ["Launch-era tool set differs from Revelations", "Forensic inference"],
  ],
  [6600, 2648]
));

A(spacer(60));
A(new Paragraph({
  border: { top: { style: BorderStyle.SINGLE, size: 4, color: "9A9A9A", space: 6 } },
  spacing: { before: 120 },
  children: [new TextRun({ text: "End of Document 2. See Document 1 for shared invariants and Document 3 for Revelations 7.", italics: true, size: 18, color: "6A6A6A", font: S.FONT })],
}));

const doc = new Document({
  numbering,
  styles: { default: { document: { run: { font: S.FONT, size: 21, color: S.INK } } } },
  sections: [{
    properties: { page: PAGE },
    ...makeHeaderFooter("Target Analysis  -  The Giant 4"),
    children,
  }],
});
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/claude/BO3_Cipher_Dossier/papers/02_Target_The_Giant_4.docx", buf);
  console.log("wrote 02_Target_The_Giant_4.docx", buf.length, "bytes");
});
