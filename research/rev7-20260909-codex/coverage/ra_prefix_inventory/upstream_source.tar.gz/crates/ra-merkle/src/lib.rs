//! Merkle commitment over a sweep, plus the spot-audit arithmetic.
//!
//! # The threat model is inverted from intuition
//!
//! Worry about false positives is misplaced. A positive claim is a *constructive
//! proof*: "pipeline P applied to input X yields plaintext Y". Anyone can re-run
//! that single pipeline in microseconds and confirm or refute it, so fabricating a
//! hit is self-defeating.
//!
//! The dangerous claim is the **negative** one. "I swept this block of 1e8 and found
//! nothing" is unfalsifiable by inspection, and if false it poisons the residual: the
//! community permanently stops searching a region that may contain the answer. A
//! fabricated negative is silent, durable, and directly harmful. So verification
//! effort goes almost entirely on proving that work was actually *done*.
//!
//! # Streaming
//!
//! [`StreamingMerkle`] commits to N leaves in O(log N) memory, which reconciles "do
//! not store results" with auditability. The engine keeps no outputs; it folds each
//! leaf into a running frontier and retains periodic checkpoints, so a challenged
//! leaf can be recomputed from a short deterministic replay rather than a full
//! re-scan.

use sha2::{Digest, Sha256};

pub type Hash = [u8; 32];

pub fn h(data: &[u8]) -> Hash {
    Sha256::digest(data).into()
}

/// Domain-separated leaf hash. The `0x00` prefix prevents a leaf from being
/// reinterpreted as an internal node (second-preimage safety).
pub fn leaf_hash(index: u64, params: &str, output_digest: &str) -> Hash {
    let mut m = Sha256::new();
    m.update([0x00]);
    m.update(format!("{index}|{params}|{output_digest}").as_bytes());
    m.finalize().into()
}

fn node_hash(left: &Hash, right: &Hash) -> Hash {
    let mut m = Sha256::new();
    m.update([0x01]);
    m.update(left);
    m.update(right);
    m.finalize().into()
}

/// Largest power of two strictly less than `n`. Requires `n >= 2`.
fn split_point(n: usize) -> usize {
    debug_assert!(n >= 2);
    1usize << (usize::BITS - 1 - (n - 1).leading_zeros())
}

/// Root over already-hashed leaves, using the RFC 6962 left-heavy split.
///
/// The alternative — duplicating the last leaf to pad each level to an even width —
/// builds a *different tree* for any non-power-of-two leaf count, and would therefore
/// not agree with [`StreamingMerkle`]. It also admits the classic duplicate-leaf
/// ambiguity, where two distinct leaf lists share a root. The left-heavy split is
/// unambiguous for every `n` and is exactly what the streaming frontier fold
/// produces, so the two constructions agree by design rather than by coincidence.
pub fn merkle_root(leaves: &[Hash]) -> Hash {
    match leaves.len() {
        0 => h(&[]),
        1 => leaves[0],
        n => {
            let k = split_point(n);
            node_hash(&merkle_root(&leaves[..k]), &merkle_root(&leaves[k..]))
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Side {
    /// The sibling sits to the left of the running hash.
    Left,
    /// The sibling sits to the right of the running hash.
    Right,
}

/// Inclusion proof: sibling hashes ordered from the leaf upward.
pub fn merkle_path(leaves: &[Hash], index: usize) -> Vec<(Side, Hash)> {
    let n = leaves.len();
    if n <= 1 || index >= n {
        return Vec::new();
    }
    let k = split_point(n);
    if index < k {
        let mut path = merkle_path(&leaves[..k], index);
        path.push((Side::Right, merkle_root(&leaves[k..])));
        path
    } else {
        let mut path = merkle_path(&leaves[k..], index - k);
        path.push((Side::Left, merkle_root(&leaves[..k])));
        path
    }
}

pub fn merkle_verify(leaf: Hash, path: &[(Side, Hash)], root: Hash) -> bool {
    let mut cur = leaf;
    for (side, sib) in path {
        cur = match side {
            Side::Left => node_hash(sib, &cur),
            Side::Right => node_hash(&cur, sib),
        };
    }
    cur == root
}

/// Builds a Merkle root over N leaves in O(log N) memory.
pub struct StreamingMerkle {
    frontier: Vec<Option<Hash>>,
    n: u64,
    checkpoint_every: u64,
    checkpoints: Vec<(u64, Vec<Option<Hash>>)>,
}

impl StreamingMerkle {
    pub fn new(checkpoint_every: u64) -> Self {
        Self {
            frontier: Vec::new(),
            n: 0,
            checkpoint_every: checkpoint_every.max(1),
            checkpoints: Vec::new(),
        }
    }

    pub fn add(&mut self, leaf: Hash) {
        if self.n % self.checkpoint_every == 0 {
            self.checkpoints.push((self.n, self.frontier.clone()));
        }
        let mut cur = leaf;
        let mut lvl = 0usize;
        while lvl < self.frontier.len() && self.frontier[lvl].is_some() {
            let left = self.frontier[lvl].take().unwrap();
            cur = node_hash(&left, &cur);
            lvl += 1;
        }
        if lvl == self.frontier.len() {
            self.frontier.push(Some(cur));
        } else {
            self.frontier[lvl] = Some(cur);
        }
        self.n += 1;
    }

    pub fn len(&self) -> u64 {
        self.n
    }

    pub fn is_empty(&self) -> bool {
        self.n == 0
    }

    pub fn root(&self) -> Hash {
        let mut acc: Option<Hash> = None;
        for node in self.frontier.iter().flatten() {
            acc = Some(match acc {
                None => *node,
                Some(a) => node_hash(node, &a),
            });
        }
        acc.unwrap_or_else(|| h(&[]))
    }

    /// Resident memory, for the storage claim in Document 7.
    pub fn memory_bytes(&self) -> usize {
        32 * (self.frontier.len() + self.checkpoints.iter().map(|(_, f)| f.len()).sum::<usize>())
    }

    /// The nearest checkpoint at or before `index`, from which a challenged leaf can
    /// be regenerated by deterministic replay.
    pub fn checkpoint_before(&self, index: u64) -> Option<u64> {
        self.checkpoints
            .iter()
            .rev()
            .find(|(n, _)| *n <= index)
            .map(|(n, _)| *n)
    }
}

/// Probability of catching a worker who honestly computed only `honest_fraction` of
/// a block, using `k` independent random challenges.
///
/// Verifier cost is `k` evaluations regardless of block size, and repeated audits
/// compound across submissions.
pub fn detection_probability(honest_fraction: f64, k: u32) -> f64 {
    1.0 - honest_fraction.powi(k as i32)
}

/// Probability that at least one canary appears in `n` assigned work units.
///
/// A canary is a unit whose target is synthetic: a known plaintext encrypted through
/// a chain that lies *inside* the assigned block. An honest sweep must report that
/// hit; a fabricated negative cannot. The worker cannot distinguish a canary from a
/// real unit, because both are opaque byte strings from the same domain.
pub fn canary_detection(rate: f64, units: u32) -> f64 {
    1.0 - (1.0 - rate).powi(units as i32)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn leaves(n: usize) -> Vec<Hash> {
        (0..n)
            .map(|i| leaf_hash(i as u64, &format!("key=K{i:06}"), "deadbeef"))
            .collect()
    }

    #[test]
    fn streaming_root_matches_the_batch_root() {
        for n in [1usize, 2, 3, 4, 5, 7, 8, 100, 1000] {
            let ls = leaves(n);
            let mut sm = StreamingMerkle::new(64);
            for l in &ls {
                sm.add(*l);
            }
            assert_eq!(
                sm.root(),
                merkle_root(&ls),
                "streaming and batch roots differ at n={n}"
            );
        }
    }

    #[test]
    fn inclusion_proofs_verify_for_every_leaf() {
        let ls = leaves(37); // deliberately not a power of two
        let root = merkle_root(&ls);
        for (i, leaf) in ls.iter().enumerate() {
            let path = merkle_path(&ls, i);
            assert!(merkle_verify(*leaf, &path, root), "leaf {i} failed");
        }
    }

    #[test]
    fn a_tampered_leaf_fails_its_proof() {
        let ls = leaves(16);
        let root = merkle_root(&ls);
        let path = merkle_path(&ls, 5);
        let forged = leaf_hash(5, "key=K000005", "not-the-real-digest");
        assert!(!merkle_verify(forged, &path, root));
    }

    /// A fabricator who alters even one candidate produces a different root, so the
    /// commitment cannot be reconciled with an independent recomputation.
    #[test]
    fn fabricating_one_candidate_changes_the_root() {
        let honest = leaves(1000);
        let mut cheat = honest.clone();
        cheat[500] = leaf_hash(500, "key=K000500", "fabricated");
        assert_ne!(merkle_root(&honest), merkle_root(&cheat));
    }

    #[test]
    fn memory_is_logarithmic_in_the_scan_size() {
        let mut sm = StreamingMerkle::new(1 << 12);
        for i in 0..200_000u64 {
            sm.add(leaf_hash(i, "p", "d"));
        }
        assert_eq!(sm.len(), 200_000);
        let per_leaf = sm.memory_bytes() as f64 / 200_000.0;
        assert!(
            per_leaf < 1.0,
            "resident cost should be well under a byte per candidate, got {per_leaf:.4}"
        );
    }

    #[test]
    fn checkpoints_allow_locating_a_replay_start() {
        let mut sm = StreamingMerkle::new(100);
        for i in 0..1000u64 {
            sm.add(leaf_hash(i, "p", "d"));
        }
        assert_eq!(sm.checkpoint_before(0), Some(0));
        assert_eq!(sm.checkpoint_before(150), Some(100));
        assert_eq!(sm.checkpoint_before(999), Some(900));
    }

    /// Document 6's table: skipping 5% of a block is caught ~64% of the time at k=20.
    #[test]
    fn detection_probabilities_match_the_documented_table() {
        let p = detection_probability(0.95, 20);
        assert!((p - 0.6415).abs() < 0.001, "got {p:.4}");
        assert!(detection_probability(0.99, 10) > 0.09);
        assert!(detection_probability(0.50, 20) > 0.999);
        // an honest worker is never caught
        assert_eq!(detection_probability(1.0, 80), 0.0);
    }

    /// A 5% canary rate catches a fabricating reporter ~92% of the time in 50 units.
    #[test]
    fn canary_rates_match_the_documented_table() {
        let p = canary_detection(0.05, 50);
        assert!((p - 0.9231).abs() < 0.001, "got {p:.4}");
        assert!(canary_detection(0.02, 10) < 0.20);
    }

    #[test]
    fn empty_commitment_is_well_defined() {
        let sm = StreamingMerkle::new(16);
        assert!(sm.is_empty());
        assert_eq!(sm.root(), merkle_root(&[]));
    }
}
