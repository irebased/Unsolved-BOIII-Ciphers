# BO3 Zombies Cipher Dossier

A portable, agent-consumable evidence package for the two remaining unsolved
Black Ops III Zombies ciphers: **The Giant 4 (TG4)** and **Revelations 7 (REV7)**.

## Contents

```
papers/
  01_Historical_Forensic_Reference.docx   Shared reference: history, modern-encryption
                                           invariants, tool-attribution forensics,
                                           evidence taxonomy.
  02_Target_The_Giant_4.docx               TG4 target analysis + constrained search plan.
  03_Target_Revelations_7.docx             REV7 target analysis + constrained search plan.
  *.js                                     Generators for each paper (docx-js).
  style.js                                 Shared document styling module.
data/
  evidence_base.json                       Machine-readable corpus: per-cipher profile,
                                           kind, and confirmed solution chains, plus the
                                           modern-encryption invariants. Read this first
                                           if you are an agent.
  the_giant.json, revelations.json,        Raw source records (irebased project).
  gorod_krovi.json
```

## For an automated agent

1. Load `data/evidence_base.json`. The `meta.modern_encryption_invariants` block
   fixes key (`Zombies`), IV (`30303030303030303030303030303030`, ASCII '0' x16,
   NOT a null IV), mode (CFB-8 via mcrypt), and library.
2. Treat only **hard facts** as search constraints. Use **forensic inferences**
   to order search. Generate pipelines from **working hypotheses** but never let a
   single hypothesis prune the space.
3. Target-specific pipeline orders are in papers 02 and 03, Section "Constrained
   Search Plan".
4. Log every composite pipeline tried, scoped by its assumptions, so a later
   correction (transcription fix, different outer transform) re-runs only the
   affected composites.

## Key numbering caveat

Cipher IDs follow the **texture-file alphabetical** convention (irebased project),
which differs from common Reddit numbering. Cross-check IDs before transferring any
value to an external tool.

## Regenerating the documents

```bash
export NODE_PATH=$(npm root -g)   # docx-js is installed globally in this environment
cd papers
node paper1_historical.js
node paper2_giant.js
node paper3_rev7.js
```

## Provenance of the analytics

All statistics in the papers (entropy, index of coincidence, nibble chi-square,
block alignment, printable-byte ratios, transcription-variant count) were computed
directly from the ciphertexts of record. The headline correction: REV7's normalized
statistics are a near-exact twin of REV12, a confirmed four-layer modern cipher,
which supersedes the earlier "in-between entropy" characterization.

## Document 4: Search Space and Feasibility

`papers/04_Search_Space_Feasibility.docx` quantifies the search space and what is
computationally reachable. Headline results:

- **Bounded programme (T1-T4) is small**: TG4 = 1.15e9 candidates (12 hr single-core
  Python, 9 min optimised). REV7 = 33.7e6 (43 min / 17 sec). Very likely already spent.
- **False positives are effectively zero** (3.8e-11 expected for TG4 across T1-T4), so a
  hit inside the bounded space would have been recognised. Absence of a solve implies
  the answer is outside the modelled space.
- **Implementation, not compute, is the binding constraint**: only 4 of 11 confirmed
  primitives exist in stock libraries. Rijndael-256 (256-bit *block*) is not AES and
  needs a variable-block Rijndael implementation.
- **Highest leverage**: resolving TG4's transcription (16x) and key question (2-6x) is
  worth 32-96x more effective compute, for zero compute spend.

Reproduce with:
```bash
cd tools
python3 primcheck.py   # primitive availability
python3 bench.py       # measured throughput
python3 space.py       # tiered space + false-positive math
python3 budget.py      # compute budgets
python3 reach.py       # reachability of unknown dimensions
```

## Document 5: Coverage Notation and Attestation

`papers/05_Coverage_Notation_Attestation.docx` defines the normative format for
stating what has been tried and binding it to the software that did it.

**The algebra.** A pipeline is an ordered layer composition. The space partitions by
*skeleton* (the ordered tuple of layer families); within a skeleton it is a Cartesian
product. A claim is a union of products per skeleton. Union-of-products is closed under
difference via orthogonal decomposition, so:

    RESIDUAL = UNIVERSE \ (claim_1 u claim_2 u ... u claim_n)

is exact, not estimated. Coverage sets are content-addressed, so equal coverage yields
an equal digest and duplicate work is detectable across teams without re-running.

**The attestation.** A coverage set says what was tried; the attestation says whether to
believe it. It binds: input transcription + ciphertext hash, the coverage set + digest,
the scoring oracle (part of the claim, since a stricter oracle covers strictly less),
harness name/version/commit/hash, and per-primitive implementation hash + conformance.

**Conformance gating.** Every one of the 11 confirmed primitives is exercised by at least
one solved cipher with known plaintext, so the corpus is a complete conformance suite.
Claimed coverage is automatically intersected with primitives whose status is PASS *and*
whose cited vectors actually exercise them. Unproven primitives contribute zero coverage.

**Worked result.** Three realistic claims against the TG4 universe (1.47e9 candidates,
tiers T1-T3) aggregate to 2,168 candidates = 0.0001%. Even the single-layer tier, widely
believed exhausted, is 97% untried once the claim is made precise.

Run it:
```bash
cd tools
python3 covalg.py      # algebra self-test (difference exact + disjoint)
python3 residual.py    # universe, example claims, residual as executable blocks
python3 attest.py      # attestation validation + conformance gating demo
```

Files: `data/coverage-attestation-v1.schema.json` (normative schema),
`data/conformance_suite.json` (primitive -> validating cipher),
`data/attestation_example.json` (validated example with deliberate defects).

## Document 6: Distributed Verification Architecture

`papers/06_Distributed_Verification.docx` specifies how to admit coverage claims from
untrusted, self-hosted compute nodes into a central ledger.

**Threat model is inverted.** False positives are the easy case: a hit is a constructive
proof, re-runnable in microseconds, so fabricating one is self-defeating. The dangerous
claim is the fabricated *negative*, which silently removes a region from the search
forever. Verification effort therefore goes almost entirely on negative claims.

**Compilation is not an integrity mechanism.** Code on adversary-controlled hardware can
be patched, traced, or bypassed entirely by posting straight at the ledger API. Embedded
signing keys are extractable. Use open source + reproducible builds instead: a binary hash
that maps verifiably back to audited source, which also preserves the independent
auditability that conformance gating depends on.

**Three verification mechanisms, none subsuming another:**

| Mechanism | Catches |
|---|---|
| Merkle commit + spot audit | Fabricated computation (95% honest -> 64% caught at k=20) |
| Planted-solution canaries | Fabricated reporting (5% rate -> 92% caught in 50 units) |
| N-version redundant assignment | Honest workers running defective implementations |

**Per-tool versioning pays off in selective invalidation.** Revoking one Twofish build
voids 215M candidates and *retains* 158M (42% preserved). Platform-level versioning would
void all 373M. This bounds the blast radius of the "one mistake invalidates everything"
problem.

**Identity is accountability, not attestation.** Remote attestation needs a hardware root
of trust, impractical for volunteers and still bypassable by the enclave operator. Use
registered keypairs + graduated trust (probationary / established / revoked), since the
protocol verifies *work* rather than *worker*.

Run it:
```bash
cd tools
python3 toolreg.py   # tool identities, chain identity, selective invalidation
python3 verify.py    # live Merkle audit + detection probability tables
```

## Document 7: Engine Architecture and Layer Semantics

`papers/07_Engine_Architecture.docx`. Three findings here revise earlier documents.

**libmcrypt closes the primitive gap: 4/11 -> 11/11.** `tools/mcrypt_node.py` binds
directly to libmcrypt 2.5.8 via ctypes. This is the *authentic* library the ciphers were
made with, so its quirks are the quirks that produced them. Requires `libmcrypt-dev`.
Two Document 1 invariants are now empirically confirmed rather than asserted:
`cfb` (8-bit feedback) != `ncfb` (full-block), which is why CyberChef failed; and
ASCII-zero IV != true null IV.

**CFB-8 self-synchronises, so the oracle must be block-aware.** A wrong IV corrupts
*exactly* blocksize bytes, then recovers cleanly. On 144-byte TG4 a Rijndael-256 hit
presents as only 77.8% printable, so a fixed 0.80 threshold would silently discard a
correct solution. Fix: skip the first blocksize bytes and score the tail. Exact, not
heuristic. Verified: wrong-IV Twofish scores 0.84 naive, 1.00 block-aware.

**Terminology, made computable.**

| Term | Meaning |
|---|---|
| step/node | Single operation, any granularity. Unit of execution and versioning. |
| layer | Transition between representations via >=1 decryption or non-standard decoding. Semantic. |
| macro | Named composition of steps reported as one layer; steps stay individually versioned. |

Layer detection works because pure re-encoding preserves *canonical bytes*. Validated:

| Case | d entropy | Class | Layer? |
|---|---|---|---|
| base64 -> hex | 0.000 | opaque->opaque | No |
| base64 -> decimal | 0.000 | opaque->opaque | No |
| reverse | 0.000 | opaque->opaque | No |
| Twofish decrypt -> plaintext | -1.804 | opaque->text | Yes |
| Serpent decrypt -> digit run | -1.844 | opaque->decimal | Yes |

**Solver nodes are terminal, and produce a different kind of coverage.** An exhaustive
sweep returning nothing proves the region is empty. A solver returning nothing proves
only that its heuristic missed within budget. Heuristic claims are recorded separately
and **never** subtract from the exhaustive residual.

**Storage.** Streaming Merkle: 0.132 bytes/candidate resident, outputs discarded, only
above-threshold hits written locally. Audit still works because deterministic enumeration
lets any challenged leaf be regenerated from one checkpoint block.

```bash
cd tools
python3 mcrypt_node.py   # 11/11 primitives, CFB-8 + IV verification
python3 engine.py        # taxonomy, macros, layer detection, oracle, Merkle
```
