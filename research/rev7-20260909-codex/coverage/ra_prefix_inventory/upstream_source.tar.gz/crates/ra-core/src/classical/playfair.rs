//! Playfair: a keyed 5×5 digraph substitution with two letters merged.
//!
//! # Why this node exists
//!
//! rev11's recorded chain is `reverse | rot | playfair | remove_character |
//! replace character | insert_characters | Trifid` — seven steps, the longest
//! classical chain in the corpus. Its third step is a Playfair decryption keyed
//! `ZOMBIES`, the same key the corpus uses everywhere else.
//!
//! # Playfair is lossy, and that is why rev11 has seven steps
//!
//! Encryption destroys information on the way in, in three separate ways:
//!
//! 1. **Non-alphabetic characters are dropped.** rev11's Playfair input contains
//!    full stops — it is the *ciphertext* of an inner Trifid whose alphabet has 27
//!    symbols, the 27th being `.` — and Playfair silently discarded all eleven of
//!    them.
//! 2. **Two letters are merged.** Classically `J` folds onto `I`, so a `J` in the
//!    input comes back as an `I`.
//! 3. **Doubled letters are padded.** A digraph of two equal letters cannot be
//!    enciphered by the rectangle rule, so encryption splits it with a padding
//!    letter (classically `X`); an odd-length input also gets one appended.
//!
//! So a Playfair *decryption* does not return the text that was encrypted; it
//! returns the padded, merged, alphabet-only image of it. rev11's steps 4, 5 and 6
//! are the hand repair of exactly those three losses, in reverse order of the
//! damage — see [`crate::classical::edits`]. This node therefore deliberately does
//! **not** attempt to undo them: it reverses the digraph rules and nothing else,
//! so the repair stays separate, parameterised and auditable.
//!
//! # `alphabet` is authoritative
//!
//! A Playfair square *is* a 25-letter alphabet -- there is no separate "strip
//! non-alphabet characters" toggle to add here, unlike the transposition nodes,
//! because dropping non-alphabet input is the cipher itself (see above). What was
//! missing is that the alphabet the square is built from used to be hardcoded to
//! `b'a'..=b'z'` inside `Square::build`'s filler range, with no parameter behind
//! it. `alphabet` (default the 26-letter form) now drives both the square
//! construction and the input filter in `normalise`, so a differently-shaped grid
//! -- e.g. a 4x4 square over 16 hex digits -- is a real, working construction
//! rather than something only the `polybius` family could express. See
//! `hex_alphabet_builds_a_working_4x4_square` below.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`], not `Family::Solver`. This is a transform at stated parameters,
//! exhaustive at those parameters, so it may carry coverage exactly as a `dec` step
//! does. It contains no search: the key, the merge pair and the padding letter are
//! all parameters. An automated Playfair cracker would be a different node, would
//! be `Family::Solver`, and would be terminal.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const NAME: &str = "playfair";

/// The classical merge: `J` is folded onto `I`, leaving 25 letters for the square.
pub const DEFAULT_MERGE: &str = "ji";
/// The classical padding letter, inserted between doubled letters by encryption.
pub const DEFAULT_PAD: &str = "x";
/// The classical base alphabet: 26 letters, which after the default J-onto-I
/// merge gives the textbook 5x5 square. Exposed as a parameter (not baked
/// into `Square::build`'s filler range) so that a differently-shaped grid —
/// e.g. a 4x4 square over `"0123456789ABCDEF"` minus one merged digit — is a
/// real, working construction rather than something only `polybius`-family
/// nodes can express.
pub const DEFAULT_ALPHABET: &str = "abcdefghijklmnopqrstuvwxyz";

const SCHEMA: &[ParamSpec] = &[
    ParamSpec::req(
        "key",
        ParamType::Str,
        "keyword for the square; the unused alphabet symbols follow in the order \
         `alphabet` lists them",
    ),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "base symbol set the square is built from, before the merge folds one away \
         (default the 26-letter alphabet, giving the textbook 5x5 square). The \
         alphabet's length, after the merge, must be a perfect square.",
    ),
    ParamSpec::opt(
        "merge",
        ParamType::Str,
        "two distinct symbols \"ab\": 'a' is folded onto 'b', so only 'b' appears in \
         the square (default \"ji\", the classical J-onto-I merge)",
    ),
    ParamSpec::opt(
        "pad",
        ParamType::Str,
        "single padding symbol that encryption inserts between doubled symbols and \
         appends to an odd-length input (default \"x\")",
    ),
    ParamSpec::opt(
        "direction",
        ParamType::Str,
        "\"decrypt\" (default) or \"encrypt\"",
    ),
];

/// A resolved square: any side length whose square is the (post-merge)
/// alphabet size, not just the classical 5.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Square {
    /// The symbols, row-major.
    cells: Vec<u8>,
    /// `cells` inverted: symbol -> cell index.
    index: std::collections::HashMap<u8, usize>,
    /// The side length; `cells.len() == side * side`.
    side: usize,
}

impl Square {
    /// Build the square from a keyword, a base alphabet, and a merge pair.
    ///
    /// `merge.0` is folded onto `merge.1`, so `merge.1` is in the square and
    /// `merge.0` is not. Symbols outside the declared `alphabet` — whether
    /// from `key` or anywhere else — are ignored, and case is folded, the
    /// same as the classical letters-only convention this generalises.
    pub fn build(key: &str, alphabet: &str, merge: (u8, u8)) -> Result<Self> {
        let (dropped, kept) = merge;
        let members: std::collections::HashSet<u8> =
            alphabet.bytes().map(|b| b.to_ascii_lowercase()).collect();
        let mut cells: Vec<u8> = Vec::with_capacity(members.len());
        let mut seen = std::collections::HashSet::new();

        for c in key.bytes().chain(alphabet.bytes()) {
            let mut c = c.to_ascii_lowercase();
            if !members.contains(&c) {
                continue;
            }
            if c == dropped {
                c = kept;
            }
            if seen.insert(c) {
                cells.push(c);
            }
        }

        let side = (cells.len() as f64).sqrt().round() as usize;
        if side * side != cells.len() {
            return Err(Error::bad_param(
                NAME,
                "alphabet",
                format!(
                    "{} symbols (after the merge) is not a perfect square, so a 1:1 \
                     grid of rows and columns can't hold it",
                    cells.len()
                ),
            ));
        }

        let mut index = std::collections::HashMap::with_capacity(cells.len());
        for (i, &c) in cells.iter().enumerate() {
            index.insert(c, i);
        }
        Ok(Self { cells, index, side })
    }

    /// The square's symbols, row-major.
    pub fn cells(&self) -> &[u8] {
        &self.cells
    }

    fn pos(&self, c: u8) -> Option<(usize, usize)> {
        self.index.get(&c).map(|&i| (i / self.side, i % self.side))
    }

    fn at(&self, row: usize, col: usize) -> u8 {
        self.cells[row * self.side + col]
    }

    /// Apply the digraph rule to one pair. `step` is 1 for encryption and
    /// `side - 1` (that is, `-1` modulo `side`) for decryption.
    fn digraph(&self, a: u8, b: u8, step: usize) -> Result<(u8, u8)> {
        let (ra, ca) = self.pos(a).ok_or_else(|| letter_absent(a))?;
        let (rb, cb) = self.pos(b).ok_or_else(|| letter_absent(b))?;
        let side = self.side;
        Ok(if ra == rb {
            (
                self.at(ra, (ca + step) % side),
                self.at(rb, (cb + step) % side),
            )
        } else if ca == cb {
            (
                self.at((ra + step) % side, ca),
                self.at((rb + step) % side, cb),
            )
        } else {
            (self.at(ra, cb), self.at(rb, ca))
        })
    }
}

fn letter_absent(c: u8) -> Error {
    Error::node_failed(
        NAME,
        format!(
            "letter '{}' is not in the square, so it cannot appear in a Playfair text",
            c as char
        ),
    )
}

/// Normalise a text for Playfair: keep only symbols in the declared
/// `alphabet`, lowercase them, and fold the merged symbol away.
///
/// Discarding everything else is not a convenience — it is what Playfair
/// encryption itself does, and reproducing that faithfully is precisely why rev11
/// needs a separate character-reinsertion step afterwards. Testing membership in
/// `alphabet` rather than `is_ascii_alphabetic` is what lets a non-letter
/// alphabet (e.g. hex digits) actually reach the square instead of being
/// silently dropped here before `Square::digraph` ever sees it.
pub fn normalise(data: &[u8], alphabet_members: &std::collections::HashSet<u8>, merge: (u8, u8)) -> Vec<u8> {
    data.iter()
        .map(|c| c.to_ascii_lowercase())
        .filter(|c| alphabet_members.contains(c))
        .map(|c| if c == merge.0 { merge.1 } else { c })
        .collect()
}

/// Insert `pad` between doubled letters and append it when the length is odd,
/// which is what encryption must do before the digraph rules can apply.
///
/// Exposed because it is the only honest statement of the Playfair round trip:
/// `decrypt(encrypt(t))` equals `prepare(normalise(t))`, never `t`.
pub fn prepare(letters: &[u8], pad: u8) -> Result<Vec<u8>> {
    let mut out = Vec::with_capacity(letters.len() + letters.len() / 2 + 1);
    let mut i = 0;
    while i < letters.len() {
        let a = letters[i];
        let b = if i + 1 < letters.len() {
            letters[i + 1]
        } else {
            pad
        };
        if a == b {
            if a == pad {
                // Splitting "xx" needs a pad between two pads, and then again
                // between the new pad and the next one, forever. Classical
                // Playfair has no answer here; report it rather than loop.
                return Err(Error::bad_param(
                    NAME,
                    "pad",
                    format!(
                        "input has the doubled padding letter '{}' at offset {i}, which \
                         cannot be split by inserting another one",
                        pad as char
                    ),
                ));
            }
            out.push(a);
            out.push(pad);
            i += 1;
        } else {
            out.push(a);
            out.push(b);
            i += 2;
        }
    }
    Ok(out)
}

fn merge_pair(params: &Params) -> Result<(u8, u8)> {
    let s = params.opt_str("merge").unwrap_or(DEFAULT_MERGE);
    let b = s.as_bytes();
    // Not restricted to `is_ascii_alphabetic`: `alphabet` decides what the
    // square is built from, so the merge pair only needs to be two distinct
    // bytes to be meaningful over it.
    if b.len() != 2 {
        return Err(Error::bad_param(
            NAME,
            "merge",
            format!("expected exactly two bytes, got {s:?}"),
        ));
    }
    let (dropped, kept) = (b[0].to_ascii_lowercase(), b[1].to_ascii_lowercase());
    if dropped == kept {
        return Err(Error::bad_param(
            NAME,
            "merge",
            "the two symbols must differ; merging a symbol onto itself would leave \
             the full alphabet, which does not fit a 1:1 grid unless its length was \
             already a perfect square",
        ));
    }
    Ok((dropped, kept))
}

fn pad_letter(params: &Params) -> Result<u8> {
    let s = params.opt_str("pad").unwrap_or(DEFAULT_PAD);
    let b = s.as_bytes();
    if b.len() != 1 {
        return Err(Error::bad_param(
            NAME,
            "pad",
            format!("expected a single byte, got {s:?}"),
        ));
    }
    Ok(b[0].to_ascii_lowercase())
}

pub struct Playfair;

impl Node for Playfair {
    fn name(&self) -> &'static str {
        NAME
    }

    fn version(&self) -> &'static str {
        "1.0.0"
    }

    fn family(&self) -> Family {
        Family::Xf
    }

    fn source_digest(&self) -> &'static str {
        "ra-core/classical/playfair(5x5-keyed-square,merge+pad-parameterised)"
    }

    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let merge = merge_pair(params)?;
        let pad = pad_letter(params)?;
        if pad == merge.0 {
            return Err(Error::bad_param(
                NAME,
                "pad",
                "the padding letter is the merged-away letter, so it can never appear \
                 in the square",
            ));
        }
        let alphabet = params.opt_str("alphabet").unwrap_or(DEFAULT_ALPHABET);
        let alphabet_members: std::collections::HashSet<u8> =
            alphabet.bytes().map(|b| b.to_ascii_lowercase()).collect();
        let square = Square::build(params.req_str(NAME, "key")?, alphabet, merge)?;

        let direction = params.opt_str("direction").unwrap_or("decrypt");
        let step = match direction {
            "decrypt" => square.side - 1, // -1 mod side
            "encrypt" => 1,
            other => {
                return Err(Error::bad_param(
                    NAME,
                    "direction",
                    format!("expected \"decrypt\" or \"encrypt\", got {other:?}"),
                ))
            }
        };

        let letters = normalise(&input.data, &alphabet_members, merge);
        if letters.is_empty() {
            return Err(Error::node_failed(
                NAME,
                "input has no ASCII letters, so there is no digraph text to work on",
            ));
        }
        let text = if direction == "encrypt" {
            prepare(&letters, pad)?
        } else {
            if letters.len() % 2 != 0 {
                return Err(Error::node_failed(
                    NAME,
                    format!(
                        "a Playfair ciphertext must have an even number of letters; got {}",
                        letters.len()
                    ),
                ));
            }
            letters
        };

        let mut out = Vec::with_capacity(text.len());
        for pair in text.chunks_exact(2) {
            let (x, y) = square.digraph(pair[0], pair[1], step)?;
            out.push(x);
            out.push(y);
        }
        // Playfair emits a bare letter stream: that is text, not an encoded
        // display, so the display must not be inherited from a ciphertext that
        // merely looked base64-ish.
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(PLAYFAIR => || Box::new(Playfair));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn node() -> &'static dyn Node {
        registry().get(NAME).unwrap()
    }

    #[test]
    fn is_xf_family_and_not_layer_forming() {
        let n = node();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    /// The square is the keyword followed by the unused letters in order, with the
    /// merged-away letter absent. Written out by hand for the classical textbook
    /// key and for the corpus key.
    #[test]
    fn square_is_hand_computed() {
        let s = Square::build("playfair example", DEFAULT_ALPHABET, (b'j', b'i')).unwrap();
        assert_eq!(s.cells(), b"playfirexmbcdghknoqstuvwz");

        let z = Square::build("ZOMBIES", DEFAULT_ALPHABET, (b'j', b'i')).unwrap();
        assert_eq!(z.cells(), b"zombiesacdfghklnpqrtuvwxy");
    }

    /// The textbook vector: key "playfair example", plaintext "hide the gold in the
    /// tree stump" encrypts to BMODZBXDNABEKUDMUIXMMOUVIF. Worked by hand on the
    /// square above — `hi` is a rectangle giving `bm`, `de` gives `od`, and so on.
    #[test]
    fn textbook_vector_encrypts_and_decrypts() {
        let n = node();
        let ct = n
            .apply(
                &Repr::bytes(b"hide the gold in the tree stump".to_vec()),
                &params! {"key" => "playfair example", "direction" => "encrypt"},
            )
            .unwrap();
        assert_eq!(ct.data, b"bmodzbxdnabekudmuixmmouvif");

        let back = n
            .apply(&ct, &params! {"key" => "playfair example"})
            .unwrap();
        // Decryption returns the *prepared* text: the doubled 'e' of "tree" was
        // split by a pad on the way in and stays split on the way out.
        assert_eq!(back.data, b"hidethegoldinthetrexestump");
    }

    /// A digraph small enough to check by eye on the ZOMBIES square
    ///
    /// ```text
    ///   z o m b i
    ///   e s a c d
    ///   f g h k l
    ///   n p q r t
    ///   u v w x y
    /// ```
    ///
    /// `e` sits at (1,0) and `x` at (4,3) — a rectangle, so `ex` decrypts to the
    /// letters at (1,3) and (4,0), which are `c` and `u`. Encrypting `cu` must
    /// return `ex`.
    #[test]
    fn hand_computed_digraph_on_the_corpus_square() {
        let n = node();
        let dec = n
            .apply(&Repr::bytes(b"ex".to_vec()), &params! {"key" => "ZOMBIES"})
            .unwrap();
        assert_eq!(dec.data, b"cu");

        let enc = n
            .apply(
                &Repr::bytes(b"cu".to_vec()),
                &params! {"key" => "ZOMBIES", "direction" => "encrypt"},
            )
            .unwrap();
        assert_eq!(enc.data, b"ex");
    }

    /// Same-row and same-column pairs wrap round, and the two directions invert
    /// each other on a text that needs no padding.
    #[test]
    fn same_row_and_column_rules_wrap() {
        let n = node();
        let enc = params! {"key" => "ZOMBIES", "direction" => "encrypt"};
        // row 0 is z,o,m,b,i: `zo` shifts right to `om`; `bi` wraps to `iz`
        let row = n.apply(&Repr::bytes(b"zobi".to_vec()), &enc).unwrap();
        assert_eq!(row.data, b"omiz");
        // column 0 is z,e,f,n,u: `ze` shifts down to `ef`; `nu` wraps to `uz`
        let col = n.apply(&Repr::bytes(b"zenu".to_vec()), &enc).unwrap();
        assert_eq!(col.data, b"efuz");

        let back = n.apply(&row, &params! {"key" => "ZOMBIES"}).unwrap();
        assert_eq!(back.data, b"zobi");
    }

    /// The round trip that actually holds. Encryption pads doubled letters, merges
    /// J onto I and drops everything non-alphabetic, so decryption returns the
    /// padded, merged, letters-only form. Asserting it returns the original input
    /// would be asserting something false.
    #[test]
    fn round_trip_returns_the_padded_merged_form_not_the_original() {
        let n = node();
        let original = b"Jolly balloons, at 3pm!".to_vec();
        let enc = n
            .apply(
                &Repr::bytes(original.clone()),
                &params! {"key" => "ZOMBIES", "direction" => "encrypt"},
            )
            .unwrap();
        let back = n.apply(&enc, &params! {"key" => "ZOMBIES"}).unwrap();

        // "Jolly balloons, at 3pm!" -> letters only, lowercased, j folded to i:
        //   "iollyballoonsatpm"   (17 letters, odd)
        // -> doubled letters split by 'x' and the odd tail padded:
        //   io lx ly ba lx lo on sa tp mx
        let expected: &[u8] = b"iolxlybalxloonsatpmx";
        assert_eq!(back.data, expected);
        assert_ne!(back.data, original, "the round trip is lossy, by design");

        // and the loss is exactly the documented preparation, nothing more
        let default_members: std::collections::HashSet<u8> = DEFAULT_ALPHABET.bytes().collect();
        let letters = normalise(&original, &default_members, (b'j', b'i'));
        assert_eq!(letters, b"iollyballoonsatpm");
        assert_eq!(prepare(&letters, b'x').unwrap(), expected);
    }

    /// Neither the merge pair nor the padding letter is baked in.
    #[test]
    fn merge_pair_and_pad_are_parameters() {
        // Merging W onto V leaves no 'w' in the square — and leaves 'j' in it,
        // which the default merge removes.
        let s = Square::build("ZOMBIES", DEFAULT_ALPHABET, (b'w', b'v')).unwrap();
        assert_eq!(s.cells(), b"zombiesacdfghjklnpqrtuvxy");

        let n = node();
        let enc = n
            .apply(
                &Repr::bytes(b"ball".to_vec()),
                &params! {"key" => "ZOMBIES", "pad" => "q", "direction" => "encrypt"},
            )
            .unwrap();
        let back = n
            .apply(&enc, &params! {"key" => "ZOMBIES", "pad" => "q"})
            .unwrap();
        assert_eq!(
            back.data, b"balqlq",
            "pad 'q' splits the doubled l and pads the odd tail"
        );
    }

    #[test]
    fn odd_length_ciphertext_is_rejected_rather_than_silently_padded() {
        let n = node();
        let e = node()
            .apply(&Repr::bytes(b"abc".to_vec()), &params! {"key" => "ZOMBIES"})
            .unwrap_err();
        assert!(format!("{e}").contains("even number of letters"), "{e}");
        // sanity: the even-length neighbour succeeds
        assert!(n
            .apply(&Repr::bytes(b"abcd".to_vec()), &params! {"key" => "ZOMBIES"})
            .is_ok());
    }

    /// The merge is applied by `normalise` before the square is consulted, so a
    /// `J` in a ciphertext is folded rather than rejected. That has to be silent,
    /// because it is silent in real Playfair — and it is why rev11 needs step 5.
    #[test]
    fn a_merged_letter_is_folded_not_rejected() {
        let n = node();
        let with_j = n
            .apply(&Repr::bytes(b"jx".to_vec()), &params! {"key" => "ZOMBIES"})
            .unwrap();
        let with_i = n
            .apply(&Repr::bytes(b"ix".to_vec()), &params! {"key" => "ZOMBIES"})
            .unwrap();
        assert_eq!(with_j.data, with_i.data);
    }

    /// The declared `alphabet` is authoritative, not English letters with an
    /// escape hatch: a 4x4 square over 16 hex digits (merging two digits the
    /// message never uses, so nothing is actually lost) encrypts and
    /// decrypts a hex message exactly like the classical 5x5 does for
    /// letters.
    #[test]
    fn hex_alphabet_builds_a_working_4x4_square() {
        let n = node();
        let p_common = params! {
            "key" => "BEEF",
            // 17 symbols so that folding one away leaves a perfect square (16 = 4x4).
            "alphabet" => "0123456789ABCDEFG",
            "merge" => "GF", // 'g' folds onto 'f'; the message below uses neither
            "pad" => "0",
        };
        let enc = p_common.clone().set("direction", "encrypt");

        let ct = n.apply(&Repr::bytes(b"DEADC0DE".to_vec()), &enc).unwrap();
        assert_eq!(ct.data.len(), 8, "even-length input needs no padding");
        assert!(
            ct.data.iter().all(|b| b"0123456789abcdef".contains(b)),
            "{ct:?}"
        );

        let back = n.apply(&ct, &p_common).unwrap();
        assert_eq!(back.data, b"deadc0de");
    }

    #[test]
    fn malformed_parameters_error_rather_than_defaulting() {
        let n = node();
        let d = Repr::bytes(b"abcd".to_vec());
        for bad in [
            params! {"key" => "ZOMBIES", "merge" => "j"},
            params! {"key" => "ZOMBIES", "merge" => "jj"},
            params! {"key" => "ZOMBIES", "merge" => "j1"},
            params! {"key" => "ZOMBIES", "pad" => "xy"},
            params! {"key" => "ZOMBIES", "pad" => "j"},
            params! {"key" => "ZOMBIES", "direction" => "sideways"},
            Params::new(),
        ] {
            assert!(n.apply(&d, &bad).is_err(), "{bad:?} should be rejected");
        }
    }

    #[test]
    fn a_letterless_input_is_an_error_not_an_empty_success() {
        let n = node();
        assert!(n
            .apply(
                &Repr::bytes(b"12 34 !!".to_vec()),
                &params! {"key" => "ZOMBIES"}
            )
            .is_err());
    }

    #[test]
    fn doubled_padding_letter_is_reported_rather_than_looping() {
        // the doubled pad has to fall on a digraph boundary to be hit at all:
        // "axxb" splits as "ax|xb" and is fine, "xxb" splits as "xx" and is not
        assert!(prepare(b"axxb", b'x').is_ok());
        let e = prepare(b"xxb", b'x').unwrap_err();
        assert!(format!("{e}").contains("doubled padding letter"), "{e}");
    }

    /// rev11's step 3 on real corpus bytes.
    ///
    /// The input is the first twenty digraphs of the recorded ciphertext, reversed
    /// and ROT-20'd. The recorded "shift 6" is the *encryption* shift, so
    /// decryption applies its inverse — the same convention rev12 established.
    /// Space-separated digraphs are dropped by `normalise`, exactly as Playfair
    /// encryption dropped them, so no explicit `stripws` step is needed.
    ///
    /// What pins the expected value is the corpus record itself: its step-4 output
    /// begins `cubeuvridxiledluvebmdixcdtedmxg`, which is character-for-character
    /// the first 31 bytes below. Byte 31 is the `x` that step 4 then removes from
    /// between the doubled `g`s, so the two strings diverge from there — which is
    /// the whole point of steps 4 to 6 existing.
    #[test]
    fn reproduces_rev11_step_three() {
        let reg = registry();
        // the *last* twenty digraphs of rev11's ciphertext, which become the first
        // twenty once reversed
        let ct = "gs ve qd yn bq ch ky er qh jr ho ya el ky zj ei hz cb if dk";
        let rev = reg
            .get("reverse")
            .unwrap()
            .apply(&Repr::bytes(ct.as_bytes().to_vec()), &Params::new())
            .unwrap();
        let rot = reg
            .get("rot")
            .unwrap()
            .apply(&rev, &params! {"n" => 20i64})
            .unwrap();
        let out = node().apply(&rot, &params! {"key" => "ZOMBIES"}).unwrap();
        assert_eq!(out.data.len(), 40, "twenty digraphs in, twenty out");
        assert_eq!(&out.data, b"cubeuvridxiledluvebmdixcdtedmxgxgarcvtwm");
    }
}
