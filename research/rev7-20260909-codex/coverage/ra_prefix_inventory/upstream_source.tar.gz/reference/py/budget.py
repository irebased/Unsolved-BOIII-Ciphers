def fmt(n):
    for u,d in [("e15",1e15),("e12",1e12),("e9",1e9),("e6",1e6),("e3",1e3)]:
        if n>=d: return f"{n/d:,.1f}{u}"
    return f"{n:,.0f}"

RATES = {"1 core Python (25k/s)":25_000, "8 core Python (200k/s)":200_000,
         "8 core native C (2M/s)":2_000_000, "GPU / cluster (100M/s)":100_000_000}
BUDGETS = {"1 hour":3600, "1 day":86400, "1 week":604800, "1 month":2_592_000}

print("="*78); print("COMPUTE BUDGET: total candidate evaluations affordable"); print("="*78)
print(f"{'':<26}" + "".join(f"{b:>13}" for b in BUDGETS))
print("-"*78)
for rname, r in RATES.items():
    print(f"{rname:<26}" + "".join(f"{fmt(r*s):>13}" for s in BUDGETS.values()))

# The bounded programme cost (from prior model)
TG4_BOUNDED = 1.15e9
REV7_BOUNDED = 33.7e6

print("\n" + "="*78)
print("HEADROOM: how big an UNKNOWN dimension can we absorb on top of T1-T4?")
print("="*78)
print("(e.g. an unidentified pre-transform family, an unknown tool quirk with N")
print(" settings, or an unmodelled key-derivation space)")
print()
for target,name in [(TG4_BOUNDED,"TG4"),(REV7_BOUNDED,"REV7")]:
    print(f"{name}  (bounded programme = {fmt(target)} candidates)")
    for rname,r in [("8 core native C (2M/s)",2_000_000),("GPU / cluster (100M/s)",100_000_000)]:
        for bname,s in [("1 day",86400),("1 week",604800),("1 month",2_592_000)]:
            headroom = (r*s)/target
            print(f"    {rname:<24}{bname:<9} -> unknown-dimension budget x{headroom:,.0f}")
    print()

print("="*78); print("WHAT THAT BUYS YOU"); print("="*78)
examples = [
 ("Every ROT shift on an outer layer", 26),
 ("Every affine (a,b) pair", 312),
 ("All 4-row route/read-order permutations", 24),
 ("All columnar keys up to length 7", 5913),
 ("All columnar keys up to length 8", 46233),
 ("All columnar keys up to length 9", 409113),
 ("A 10k-word keyword dictionary for keyed alphabets", 10000),
 ("A 100k-word keyword dictionary", 100000),
 ("All columnar keys up to length 10", 4037913),
 ("Free 26-letter substitution alphabet", 4.03e26),
]
print(f"{'UNKNOWN DIMENSION':<52}{'SIZE':>12}   VERDICT (TG4, 1 mo @2M/s)")
print("-"*78)
CAP = 2_000_000*2_592_000/TG4_BOUNDED
for n,sz in examples:
    v = "feasible" if sz<=CAP else "OUT OF REACH"
    print(f"{n:<52}{fmt(sz):>12}   {v}")
print(f"\n  (TG4 headroom cap at 1 month / 2M per sec = x{CAP:,.0f})")
