//! Binding a coverage claim to the software that produced it.
//!
//! A coverage set says *what* was tried. An attestation says *whether to believe it*.
//!
//! Three things can silently void a claim:
//!
//! 1. **A wrong primitive implementation.** Seven of the eleven confirmed primitives
//!    have no stock implementation, so each harness rolls its own. A subtly wrong
//!    Twofish sweeps a space that is not the real one: the claim looks fine and
//!    covers nothing.
//! 2. **A too-strict scoring oracle.** A sweep that only accepts fully printable
//!    output discards a correct CFB-8 decryption whose first block is corrupt. Same
//!    pipelines, less coverage. The oracle is therefore part of the claim.
//! 3. **A different input.** TG4 admits up to sixteen transcriptions. A claim over
//!    the wrong bytes covers nothing relevant.
//!
//! # Conformance gating
//!
//! A primitive may carry coverage only once it is **proven**, and there are two
//! independent ways to prove one — kept visibly apart because they answer two
//! different questions:
//!
//! - [`ProvenClass::CorpusProven`]: the implementation reproduces a *solved* corpus
//!   cipher end to end with known plaintext. This answers "did the puzzle author use
//!   this primitive", which is a fact about the corpus, not about the code.
//! - [`ProvenClass::VectorProven`]: the implementation matches the algorithm's own
//!   published or normative test vector (FIPS-197, an RFC, a compiled-in self-test).
//!   This answers "is this implementation correct", which is a fact about the code
//!   and needs no corpus cipher to use the primitive at all.
//!
//! Using only the first as a proxy for the second is circular for the two unsolved
//! targets this workspace exists to attack: "proven" would then mean "already seen
//! in a solved cipher", which can never certify a primitive the puzzle author used
//! but this project has not yet solved anything with — precisely the case a genuine
//! search has to allow for. `ra conformance` previously reported such a primitive as
//! contributing *zero* coverage forever, regardless of how much correctly-targeted
//! compute was spent on it, which silently prevented crediting a search of genuinely
//! new space. VectorProven closes that gap without weakening what CorpusProven
//! already means: it is a second, differently-labelled, independently-checkable
//! proof of implementation correctness, not a relaxation of the corpus requirement.
//!
//! Either class admits coverage; an [`Unproven`](ProvenClass) primitive still
//! contributes zero, unconditionally. The two are never merged into one number —
//! [`GatedCoverage`] and [`ProvenPrimitives`] track which class proved each admitted
//! primitive, and callers report the two counts side by side, the same way this
//! workspace already keeps `Solver` (heuristic) coverage visibly apart from
//! exhaustive coverage rather than summing them.
//!
//! [`gate_coverage`] is the **only** implementation of that intersection in this
//! workspace. [`Attestation::effective_coverage`] is a thin call into it, and so is
//! `ra residual`'s fold of sweep-emitted claims: a second implementation would be a
//! second thing to keep honest. [`gate_coverage_by_class`] does not reimplement the
//! intersection — it calls [`gate_coverage`] twice more, once per class, purely so a
//! caller can report the two contributions separately; the coverage that actually
//! enters a residual is still the single `effective` set the one gate produces.

use std::collections::{BTreeMap, BTreeSet};

use ra_covalg::{Cover, CoverageSet, Product};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

/// The dimension-key suffix that names a primitive, e.g. `1.prim`.
///
/// A coverage set is keyed `"<slot>.<param>"`, and this is the only suffix the gate
/// can bite on. If it ever changes, every gate in the workspace changes with it —
/// which is the point of naming it once.
pub const PRIM_DIM_SUFFIX: &str = ".prim";

/// Which of the two admissible proofs established a primitive.
///
/// Both classes admit coverage; neither is a relaxation of the other, and a caller
/// must never sum them into one number without saying which is which. See this
/// module's top-level documentation for why the two are kept apart.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum ProvenClass {
    /// Reproduces a solved corpus cipher end to end with known plaintext.
    CorpusProven,
    /// Matches the algorithm's own published or normative test vector (a
    /// standards-body RFC/FIPS vector, or a reference implementation's own
    /// compiled-in self-test) — proof of implementation correctness with no
    /// dependence on any corpus cipher having used the primitive.
    ///
    /// A future primitive (for example a `salsa20` implementation, proven against
    /// its eSTREAM test vectors) lands here the same way AES and 3DES do: nothing
    /// about this class is specific to the primitives proven under it today.
    VectorProven,
}

impl ProvenClass {
    pub fn as_str(self) -> &'static str {
        match self {
            ProvenClass::CorpusProven => "CorpusProven",
            ProvenClass::VectorProven => "VectorProven",
        }
    }
}

/// The set of primitives a conformance run actually proved, and which class proved
/// each one.
///
/// Matching is **case-insensitive**, because the workspace spells the same primitive
/// two ways: `Rijndael-256` in a claim's `*.prim` dimension, `rijndael-256` in
/// `conformance_suite.json`. A case-sensitive lookup between those two spellings once
/// made a conformance check pass *vacuously* (ARCHITECTURE.md, deviation 3), and the
/// same mismatch here would silently void a proven primitive's coverage instead.
///
/// Case-insensitive is not name-blind. Only names actually present are admitted; an
/// unrecognised primitive is voided whatever its case, so the gate can never admit
/// coverage it was not given evidence for.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct ProvenPrimitives {
    /// lowercased key -> (the spelling the conformance run used, the class that
    /// proved it)
    names: BTreeMap<String, (String, ProvenClass)>,
}

impl ProvenPrimitives {
    pub fn new() -> Self {
        Self::default()
    }

    /// Build from names a conformance run reported as reproduced.
    ///
    /// Defaults every name to [`ProvenClass::CorpusProven`] — this is the
    /// constructor every call site predating the two-class model still uses, and
    /// corpus reproduction is what "proven" meant before VectorProven existed. Use
    /// [`Self::insert_with_class`] to record the other class.
    pub fn from_names<I, S>(names: I) -> Self
    where
        I: IntoIterator<Item = S>,
        S: AsRef<str>,
    {
        let mut out = Self::default();
        for n in names {
            out.insert(n.as_ref());
        }
        out
    }

    /// Build from `(name, class)` pairs, e.g. corpus names plus vector-proven names.
    pub fn from_classified<I, S>(entries: I) -> Self
    where
        I: IntoIterator<Item = (S, ProvenClass)>,
        S: AsRef<str>,
    {
        let mut out = Self::default();
        for (n, class) in entries {
            out.insert_with_class(n.as_ref(), class);
        }
        out
    }

    /// Insert as [`ProvenClass::CorpusProven`]. Kept for callers that predate the
    /// two-class model; equivalent to `insert_with_class(name, CorpusProven)`.
    pub fn insert(&mut self, name: &str) -> &mut Self {
        self.insert_with_class(name, ProvenClass::CorpusProven)
    }

    /// Insert with an explicit proof class. A name already present with a *stronger*
    /// or equal claim is not downgraded by a later, weaker insert for the same name
    /// — in practice this only matters if a primitive is both corpus- and
    /// vector-proven, in which case CorpusProven (the harder-won proof) is what is
    /// recorded, since it is a superset of what VectorProven establishes.
    pub fn insert_with_class(&mut self, name: &str, class: ProvenClass) -> &mut Self {
        let key = name.to_ascii_lowercase();
        match self.names.get(&key) {
            Some((_, ProvenClass::CorpusProven)) => {}
            _ => {
                self.names.insert(key, (name.to_string(), class));
            }
        }
        self
    }

    pub fn contains(&self, name: &str) -> bool {
        self.names.contains_key(&name.to_ascii_lowercase())
    }

    /// Which class proved this primitive, if any.
    pub fn class_of(&self, name: &str) -> Option<ProvenClass> {
        self.names.get(&name.to_ascii_lowercase()).map(|(_, c)| *c)
    }

    pub fn is_empty(&self) -> bool {
        self.names.is_empty()
    }

    pub fn len(&self) -> usize {
        self.names.len()
    }

    /// The proven names, as the conformance run spelled them.
    pub fn iter(&self) -> impl Iterator<Item = &str> {
        self.names.values().map(|(name, _)| name.as_str())
    }

    /// Only the names proven under `class`, as a fresh, filtered set.
    ///
    /// A reporting convenience, not a second gate: passing the result into
    /// [`gate_coverage`] answers "what would this claim cover if only this class of
    /// proof existed", which is exactly what [`gate_coverage_by_class`] does.
    pub fn only(&self, class: ProvenClass) -> ProvenPrimitives {
        let mut out = ProvenPrimitives::new();
        for (name, c) in self.names.values() {
            if *c == class {
                out.insert_with_class(name, *c);
            }
        }
        out
    }
}

/// What gating one coverage set did to it.
#[derive(Clone, Debug)]
pub struct GatedCoverage {
    /// Claimed coverage intersected with the proven set. The only coverage that may
    /// enter a residual calculation.
    pub effective: CoverageSet,
    /// Primitives named by the claim that survived the intersection.
    pub admitted: BTreeSet<String>,
    /// Primitives named by the claim that contribute zero coverage.
    pub voided: BTreeSet<String>,
    /// Products dropped whole, because every primitive they named was voided.
    pub products_dropped: usize,
    /// Which class admitted each surviving primitive in [`Self::admitted`]. Every
    /// key in `admitted` has an entry here; the two are never allowed to drift apart
    /// because both are populated in the same loop in [`gate_coverage`].
    pub admitted_class: BTreeMap<String, ProvenClass>,
    /// How many `*.prim` dimensions the gate actually examined.
    ///
    /// Zero means the gate had nothing to bite on and *passed vacuously* — a claim
    /// spelling its primitive dimension `1.primitive`, or omitting it, would sail
    /// through untouched with no primitive ever checked. That is not a pass; callers
    /// must treat [`GatedCoverage::is_vacuous`] as a failure to gate, not as a
    /// clean gate.
    pub prim_dimensions_seen: usize,
}

impl GatedCoverage {
    /// True when no primitive dimension was found, so nothing was actually checked.
    pub fn is_vacuous(&self) -> bool {
        self.prim_dimensions_seen == 0
    }

    /// True when gating changed nothing — every named primitive is proven.
    pub fn is_identity(&self) -> bool {
        self.voided.is_empty() && self.products_dropped == 0
    }

    /// Admitted primitives proven under `class`, e.g. to report VectorProven
    /// admissions separately from CorpusProven ones.
    pub fn admitted_under(&self, class: ProvenClass) -> BTreeSet<String> {
        self.admitted_class
            .iter()
            .filter(|(_, c)| **c == class)
            .map(|(name, _)| name.clone())
            .collect()
    }

    /// True when at least one admitted primitive rests on the weaker (but still
    /// valid) VectorProven evidence rather than a corpus reproduction. A reader
    /// auditing a negative result needs this visible at a glance, not buried in a
    /// primitive-by-primitive list.
    pub fn rests_on_vector_proof(&self) -> bool {
        self.admitted_class
            .values()
            .any(|c| *c == ProvenClass::VectorProven)
    }
}

/// Primitives named anywhere in a coverage set, read off its `*.prim` dimensions.
pub fn claimed_primitives(coverage: &CoverageSet) -> BTreeSet<String> {
    let mut out = BTreeSet::new();
    for cover in coverage.covers.values() {
        for p in &cover.products {
            for (k, v) in &p.dims {
                if k.ends_with(PRIM_DIM_SUFFIX) {
                    out.extend(v.iter().cloned());
                }
            }
        }
    }
    out
}

/// Intersect a coverage set with the primitives that actually reproduce.
///
/// **The one conformance gate in this workspace.** Every `*.prim` dimension is
/// intersected with `proven`; a product whose primitive set becomes empty covers
/// nothing and is dropped entirely rather than shrunk to zero, so the result stays a
/// canonical union of non-empty products.
///
/// The reported [`GatedCoverage::prim_dimensions_seen`] is what makes a vacuous pass
/// visible: gating a set that names no primitive at all is a no-op, and a no-op that
/// looks like a clean pass is exactly the failure this apparatus exists to prevent.
pub fn gate_coverage(coverage: &CoverageSet, proven: &ProvenPrimitives) -> GatedCoverage {
    let mut effective = CoverageSet::new();
    let mut admitted = BTreeSet::new();
    let mut admitted_class = BTreeMap::new();
    let mut voided = BTreeSet::new();
    let mut products_dropped = 0usize;
    let mut prim_dimensions_seen = 0usize;

    for (sk, cover) in &coverage.covers {
        let mut keep = Vec::new();
        for p in &cover.products {
            let mut dims: Vec<(String, Vec<String>)> = Vec::new();
            let mut all_voided = false;
            for (k, v) in &p.dims {
                if k.ends_with(PRIM_DIM_SUFFIX) {
                    prim_dimensions_seen += 1;
                    let mut kept = Vec::new();
                    for x in v {
                        if let Some(class) = proven.class_of(x) {
                            admitted.insert(x.clone());
                            admitted_class.insert(x.clone(), class);
                            kept.push(x.clone());
                        } else {
                            voided.insert(x.clone());
                        }
                    }
                    // Deliberately no early exit: a T3 product carries two `*.prim`
                    // dimensions, and stopping at the first empty one would leave the
                    // second's primitives unreported and uncounted, understating both
                    // the void reasons and the dimensions actually examined.
                    all_voided |= kept.is_empty();
                    dims.push((k.clone(), kept));
                } else {
                    dims.push((k.clone(), v.iter().cloned().collect()));
                }
            }
            if all_voided {
                products_dropped += 1;
            } else {
                keep.push(Product::new(dims));
            }
        }
        if !keep.is_empty() {
            effective.add(Cover::new(sk.clone(), keep));
        }
    }

    GatedCoverage {
        effective,
        admitted,
        voided,
        products_dropped,
        admitted_class,
        prim_dimensions_seen,
    }
}

/// [`gate_coverage`], reported by class.
///
/// This is a reporting convenience, not a second gate: the coverage that may
/// actually enter a residual is `full.effective`, exactly as before. `corpus` and
/// `vector` restrict admission to one class at a time so a caller can print the two
/// contributions side by side, per ARCHITECTURE.md's conformance section — never
/// summed into one figure without saying which class backs it.
pub struct ClassGatedCoverage {
    /// Gated against every proven primitive, of either class. What actually enters
    /// the residual.
    pub full: GatedCoverage,
    /// Gated as if only CorpusProven primitives existed.
    pub corpus: GatedCoverage,
    /// Gated as if only VectorProven primitives existed.
    pub vector: GatedCoverage,
}

pub fn gate_coverage_by_class(coverage: &CoverageSet, proven: &ProvenPrimitives) -> ClassGatedCoverage {
    ClassGatedCoverage {
        full: gate_coverage(coverage, proven),
        corpus: gate_coverage(coverage, &proven.only(ProvenClass::CorpusProven)),
        vector: gate_coverage(coverage, &proven.only(ProvenClass::VectorProven)),
    }
}

pub fn sha256_str(s: &str) -> String {
    format!("sha256:{}", hex::encode(Sha256::digest(s.as_bytes())))
}

#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub struct Harness {
    pub name: String,
    pub version: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub git_commit: Option<String>,
    pub sha256: String,
}

#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub struct ConformanceRecord {
    pub status: ra_toolreg::Conformance,
    #[serde(default)]
    pub vectors: Vec<String>,
}

#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub struct PrimitiveRecord {
    pub impl_name: String,
    pub version: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub sha256: Option<String>,
    pub conformance: ConformanceRecord,
}

#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub struct Execution {
    pub started: String,
    pub finished: String,
    pub candidates_evaluated: u128,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ValidationReport {
    pub errors: Vec<String>,
    pub warnings: Vec<String>,
    /// Every primitive that admits coverage, of either class — CorpusProven and
    /// VectorProven together. Kept for backward compatibility with every reader
    /// that predates the two-class split; use [`Self::proven_vector`] to see which
    /// of these rest on the weaker proof.
    pub proven: Vec<String>,
    pub unproven: Vec<String>,
    /// The subset of `proven` admitted specifically under VectorProven — matches the
    /// algorithm's own normative test vector, with no corpus cipher backing it.
    /// Reported separately per ARCHITECTURE.md's conformance section: never merge
    /// this into a single count with the CorpusProven share.
    #[serde(default)]
    pub proven_vector: Vec<String>,
}

impl ValidationReport {
    pub fn is_valid(&self) -> bool {
        self.errors.is_empty()
    }
}

pub struct Attestation {
    pub claim_id: String,
    pub target: String,
    pub coverage: CoverageSet,
    pub ciphertext: String,
    pub variant_id: String,
    pub harness: Harness,
    pub primitives: BTreeMap<String, PrimitiveRecord>,
    pub oracle_id: String,
    pub execution: Execution,
    pub hits: Vec<serde_json::Value>,
    pub notes: String,
    /// primitive -> corpus ciphers that actually exercise it.
    pub conformance_vectors: BTreeMap<String, Vec<String>>,
    /// Primitives this build's own implementation is checked against an algorithm's
    /// published/normative test vector, independent of any corpus cipher —
    /// [`ProvenClass::VectorProven`]. Supplied by the caller (`ra-cli` wires this
    /// from `ra_prim::vector_proven()`) so this crate stays agnostic of any
    /// particular primitive implementation. Defaults empty, so an attestation built
    /// before this field existed is unaffected: it simply admits no VectorProven
    /// primitive, exactly as today.
    pub vector_proven_primitives: BTreeSet<String>,
}

impl Attestation {
    /// Primitives named anywhere in the claim, read off the `*.prim` dimensions.
    pub fn claimed_primitives(&self) -> BTreeSet<String> {
        claimed_primitives(&self.coverage)
    }

    /// The primitives this attestation's own evidence proves, as a gate input —
    /// carrying which class proved each one.
    pub fn proven_primitives(&self) -> ProvenPrimitives {
        let report = self.validate();
        let mut out = ProvenPrimitives::new();
        // `report.proven` and `report.proven_vector` are already disjoint (`validate`
        // only promotes a primitive into `proven_vector` when the corpus check did
        // not already prove it), so insertion order does not matter here.
        for p in &report.proven {
            out.insert_with_class(p, ProvenClass::CorpusProven);
        }
        for p in &report.proven_vector {
            out.insert_with_class(p, ProvenClass::VectorProven);
        }
        out
    }

    pub fn validate(&self) -> ValidationReport {
        let mut errors = Vec::new();
        let mut warnings = Vec::new();
        let mut proven = BTreeSet::new();
        let mut unproven = BTreeSet::new();

        match ra_oracle::oracle(&self.oracle_id) {
            None => errors.push(format!("unknown oracle '{}'", self.oracle_id)),
            Some(spec) => {
                if !spec.block_aware {
                    warnings.push(format!(
                        "oracle '{}' is not block-aware; a CFB-8 hit with a corrupt first \
                         block would be rejected, so effective coverage is reduced below \
                         what is claimed",
                        self.oracle_id
                    ));
                }
            }
        }

        if self.harness.name.is_empty() {
            errors.push("harness missing required field 'name'".into());
        }
        if self.harness.version.is_empty() {
            errors.push("harness missing required field 'version'".into());
        }
        if self.harness.sha256.is_empty() {
            errors.push("harness missing required field 'sha256'".into());
        }

        for prim in self.claimed_primitives() {
            let Some(rec) = self.primitives.get(&prim) else {
                unproven.insert(prim.clone());
                errors.push(format!("primitive '{prim}' claimed but not declared"));
                continue;
            };
            if rec.sha256.as_deref().unwrap_or("").is_empty() {
                errors.push(format!(
                    "primitive '{prim}' declared without an implementation hash"
                ));
            }
            if rec.conformance.status != ra_toolreg::Conformance::Pass {
                unproven.insert(prim.clone());
                warnings.push(format!(
                    "primitive '{prim}' conformance={:?}; its coverage is void",
                    rec.conformance.status
                ));
                continue;
            }
            // Case-insensitive lookup: a case mismatch must not vacuously pass.
            let expected = self
                .conformance_vectors
                .iter()
                .find(|(k, _)| k.eq_ignore_ascii_case(&prim))
                .map(|(_, v)| v.clone())
                .unwrap_or_default();
            if rec.conformance.vectors.is_empty() {
                errors.push(format!("primitive '{prim}' claims PASS with no vectors cited"));
                unproven.insert(prim);
            } else if expected.is_empty() {
                errors.push(format!(
                    "primitive '{prim}' claims PASS but no conformance vectors are defined \
                     for it, so the claim cannot be checked"
                ));
                unproven.insert(prim);
            } else if !rec
                .conformance
                .vectors
                .iter()
                .any(|v| expected.iter().any(|e| e.eq_ignore_ascii_case(v)))
            {
                errors.push(format!(
                    "primitive '{prim}' cites vectors {:?} which do not validate it; \
                     expected one of {:?}",
                    rec.conformance.vectors, expected
                ));
                unproven.insert(prim);
            } else {
                proven.insert(prim);
            }
        }

        // A second, independent proof: a primitive the corpus check above left
        // unproven may still be VectorProven — the harness declared *some*
        // implementation of it (a record exists, so `rec` was found above) and that
        // implementation is checked against the algorithm's own normative test
        // vector rather than a corpus cipher. This never overrides a CorpusProven
        // result (the two sets stay disjoint), and it never promotes a primitive
        // with no declared record at all — VectorProven still requires knowing
        // *which* implementation is being vouched for.
        let mut proven_vector = BTreeSet::new();
        for prim in unproven.iter().cloned().collect::<Vec<_>>() {
            if self.primitives.contains_key(&prim)
                && self
                    .vector_proven_primitives
                    .iter()
                    .any(|v| v.eq_ignore_ascii_case(&prim))
            {
                unproven.remove(&prim);
                proven_vector.insert(prim);
            }
        }

        ValidationReport {
            errors,
            warnings,
            proven: proven.into_iter().collect(),
            unproven: unproven.into_iter().collect(),
            proven_vector: proven_vector.into_iter().collect(),
        }
    }

    /// Claimed coverage intersected with the conformance-proven primitives.
    ///
    /// This is the number that may enter the residual calculation. Everything else
    /// is an assertion.
    ///
    /// The intersection itself lives in [`gate_coverage`], which `ra residual` calls
    /// on the sweep path. One gate, two callers.
    pub fn effective_coverage(&self) -> CoverageSet {
        self.gated().effective
    }

    /// [`effective_coverage`](Self::effective_coverage) plus what gating did and why.
    pub fn gated(&self) -> GatedCoverage {
        gate_coverage(&self.coverage, &self.proven_primitives())
    }

    /// [`gated`](Self::gated), split so the CorpusProven and VectorProven
    /// contributions can be reported side by side rather than merged into one
    /// number. `gated().effective` remains what actually enters the residual.
    pub fn gated_by_class(&self) -> ClassGatedCoverage {
        gate_coverage_by_class(&self.coverage, &self.proven_primitives())
    }

    /// Serialise in the `bo3-coverage-attestation/v1` shape.
    pub fn to_json(&self) -> serde_json::Value {
        let by_class = self.gated_by_class();
        let effective = &by_class.full.effective;
        let report = self.validate();
        serde_json::json!({
            "schema": "bo3-coverage-attestation/v1",
            "claim_id": self.claim_id,
            "target": self.target,
            "input": {
                "variant_id": self.variant_id,
                "ciphertext_sha256": sha256_str(&self.ciphertext),
                "ciphertext_len": self.ciphertext.len(),
            },
            "coverage_claimed": self.coverage.to_json(),
            "coverage_claimed_digest": self.coverage.digest(),
            "coverage_effective_digest": effective.digest(),
            "coverage_claimed_size": self.coverage.size_exact().to_string(),
            "coverage_effective_size": effective.size_exact().to_string(),
            // The two proof classes, broken out. Never merge these into one figure:
            // a reader auditing a negative needs to see at a glance how much of it
            // rests on the weaker (but still valid) VectorProven evidence.
            "coverage_effective_corpus_proven_size": by_class.corpus.effective.size_exact().to_string(),
            "coverage_effective_vector_proven_size": by_class.vector.effective.size_exact().to_string(),
            "rests_on_vector_proof": by_class.full.rests_on_vector_proof(),
            "oracle": ra_oracle::oracle(&self.oracle_id),
            "toolchain": { "harness": self.harness, "primitives": self.primitives },
            "execution": self.execution,
            "hits": self.hits,
            "validation": report,
            "notes": self.notes,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ra_covalg::product;
    use ra_toolreg::Conformance;

    const TG4: &str = "kCmlgFi6GUJNgkNI1Q41fbfyLoCFTCvIqkZiI0KIAXAzP1U1uy1BE4UfPBfpKmmLObjYnQNRBaPtKiVWzc5A\
                       4v0w3xle8FOhAGJZ7g4in0wndJxMOvO3dc1M82at2T6935roTqyWDgtGD/hwwRF3oHqFM5Vcw1JtINbsgWRm\
                       4o4/quEDkZ7x1B275bX3/Fo1";

    fn vectors() -> BTreeMap<String, Vec<String>> {
        [
            ("DES", vec!["rev2", "rev9"]),
            ("RC2", vec!["rev1", "rev5"]),
            ("RC4", vec!["rev10"]),
            ("Blowfish", vec!["rev5"]),
            ("Twofish", vec!["rev9"]),
            ("Serpent", vec!["rev6"]),
            ("XTEA", vec!["rev12"]),
            ("rijndael-256", vec!["rev1"]),
        ]
        .into_iter()
        .map(|(k, v)| (k.to_string(), v.into_iter().map(String::from).collect()))
        .collect()
    }

    fn rec(impl_name: &str, status: Conformance, vecs: &[&str]) -> PrimitiveRecord {
        PrimitiveRecord {
            impl_name: impl_name.into(),
            version: "1.0.0".into(),
            sha256: Some(format!("sha256:{}", "a".repeat(64))),
            conformance: ConformanceRecord {
                status,
                vectors: vecs.iter().map(|s| s.to_string()).collect(),
            },
        }
    }

    /// The worked example from Document 5: a claim reported informally as "we brute
    /// forced every mcrypt combination", with three primitives that quietly void
    /// themselves.
    fn worked_example() -> Attestation {
        let mut coverage = CoverageSet::new();
        coverage.add(Cover::new(
            vec!["b64d", "dec"],
            vec![product! {
                "0.variant" => ["v00"],
                "1.key"     => ["TheGiant"],
                "1.kd"      => ["nullpad"],
                "1.prim"    => ["DES","RC2","RC4","Blowfish","Twofish","Serpent","XTEA"],
                "1.mode"    => ["cfb","ecb"],
                "1.iv"      => ["ascii0"],
            }],
        ));

        let primitives = [
            ("DES", rec("pycryptodome", Conformance::Pass, &["rev2", "rev9"])),
            ("RC2", rec("pycryptodome", Conformance::Pass, &["rev1"])),
            ("RC4", rec("pycryptodome", Conformance::Pass, &["rev10"])),
            ("Blowfish", rec("pycryptodome", Conformance::Pass, &["rev5"])),
            // the three that void themselves
            ("Twofish", rec("custom/twofish", Conformance::Untested, &[])),
            ("Serpent", rec("custom/serpent", Conformance::Fail, &["rev6"])),
            ("XTEA", rec("custom/xtea", Conformance::Pass, &["rev2"])), // wrong vector
        ]
        .into_iter()
        .map(|(k, v)| (k.to_string(), v))
        .collect();

        Attestation {
            claim_id: "tg4-sweep-2026-07-12-run17".into(),
            target: "tg4".into(),
            coverage,
            ciphertext: TG4.into(),
            variant_id: "oswald-preferred/v00".into(),
            harness: Harness {
                name: "pallas".into(),
                version: "0.4.2".into(),
                git_commit: Some("9f3c1a7e".into()),
                sha256: format!("sha256:{}", "a".repeat(64)),
            },
            primitives,
            oracle_id: "printable-1.00".into(),
            execution: Execution {
                started: "2026-07-12T09:00:00Z".into(),
                finished: "2026-07-12T09:04:11Z".into(),
                candidates_evaluated: 28,
            },
            hits: vec![],
            notes: "Reported informally as 'brute forced every mcrypt combination'.".into(),
            conformance_vectors: vectors(),
            vector_proven_primitives: BTreeSet::new(),
        }
    }

    #[test]
    fn gating_voids_unproven_primitives_and_keeps_the_rest() {
        let att = worked_example();
        let r = att.validate();

        assert_eq!(r.proven, vec!["Blowfish", "DES", "RC2", "RC4"]);
        assert_eq!(r.unproven, vec!["Serpent", "Twofish", "XTEA"]);

        // 7 prims x 2 modes = 14 claimed; only 4 prims are proven => 8 effective
        assert_eq!(att.coverage.size_exact(), 14);
        assert_eq!(att.effective_coverage().size_exact(), 8);
    }

    /// A primitive with no corpus vector at all — exactly AES's and 3DES's
    /// situation — still admits coverage once it is VectorProven, and the two
    /// classes are reported separately rather than merged into `proven`.
    #[test]
    fn a_vector_proven_primitive_contributes_nonzero_coverage_and_is_reported_separately() {
        let mut att = worked_example();
        // Twofish is declared `Untested` in the worked example: no corpus proof.
        // Mark it VectorProven the way AES/3DES are — matches a normative test
        // vector, no solved cipher needed.
        att.vector_proven_primitives = BTreeSet::from(["Twofish".to_string()]);

        let r = att.validate();
        assert_eq!(r.proven, vec!["Blowfish", "DES", "RC2", "RC4"], "unchanged: corpus-only");
        assert_eq!(r.proven_vector, vec!["Twofish"], "reported as its own class");
        assert_eq!(r.unproven, vec!["Serpent", "XTEA"], "Twofish left unproven");

        // 7 prims x 2 modes = 14 claimed; now 5 prims (4 corpus + 1 vector) proven
        assert_eq!(att.effective_coverage().size_exact(), 10);

        let by_class = att.gated_by_class();
        assert_eq!(by_class.corpus.effective.size_exact(), 8, "unchanged corpus share");
        assert_eq!(by_class.vector.effective.size_exact(), 2, "Twofish's own share");
        assert!(by_class.full.rests_on_vector_proof());
        assert_eq!(
            att.proven_primitives().class_of("Twofish"),
            Some(ProvenClass::VectorProven)
        );
    }

    /// VectorProven status is not name-blind either: a primitive absent from the
    /// claim's own declared toolchain is not promoted just because its name happens
    /// to be in the global vector-proven list — [`Attestation::validate`] still
    /// requires "claimed but not declared" to be an error for it.
    #[test]
    fn vector_proven_does_not_rescue_an_undeclared_primitive() {
        let mut att = worked_example();
        att.primitives.remove("DES");
        att.vector_proven_primitives = BTreeSet::from(["DES".to_string()]);
        let r = att.validate();
        assert!(r.unproven.contains(&"DES".to_string()));
        assert!(!r.proven_vector.contains(&"DES".to_string()));
    }

    #[test]
    fn each_void_reason_is_reported_distinctly() {
        let r = worked_example().validate();
        let joined = r.errors.join(" | ") + " || " + &r.warnings.join(" | ");
        assert!(joined.contains("Twofish") && joined.contains("Untested"));
        assert!(joined.contains("Serpent") && joined.contains("Fail"));
        assert!(
            joined.contains("XTEA") && joined.contains("do not validate it"),
            "XTEA cites rev2, a DES vector: {joined}"
        );
    }

    /// A non-block-aware oracle must be flagged, because it silently under-covers.
    #[test]
    fn strict_oracle_produces_a_warning() {
        let r = worked_example().validate();
        assert!(r.warnings.iter().any(|w| w.contains("not block-aware")));
    }

    #[test]
    fn claimed_and_effective_digests_differ_when_coverage_is_gated() {
        let att = worked_example();
        assert_ne!(att.coverage.digest(), att.effective_coverage().digest());
    }

    /// A fully proven claim passes through gating untouched.
    #[test]
    fn fully_proven_claim_is_not_reduced() {
        let mut att = worked_example();
        att.oracle_id = "printable-0.75".into();
        att.primitives = [
            ("DES", rec("ra-prim", Conformance::Pass, &["rev9"])),
            ("Twofish", rec("ra-prim", Conformance::Pass, &["rev9"])),
        ]
        .into_iter()
        .map(|(k, v)| (k.to_string(), v))
        .collect();
        let mut coverage = CoverageSet::new();
        coverage.add(Cover::new(
            vec!["b64d", "dec"],
            vec![product! {"1.prim" => ["DES","Twofish"], "1.mode" => ["cfb"]}],
        ));
        att.coverage = coverage;

        let r = att.validate();
        assert!(r.is_valid(), "unexpected errors: {:?}", r.errors);
        assert!(r.warnings.is_empty(), "unexpected warnings: {:?}", r.warnings);
        assert_eq!(att.coverage.size_exact(), 2);
        assert_eq!(att.effective_coverage().size_exact(), 2);
        assert_eq!(att.coverage.digest(), att.effective_coverage().digest());
    }

    #[test]
    fn undeclared_primitive_is_an_error_not_a_silent_pass() {
        let mut att = worked_example();
        att.primitives.remove("DES");
        let r = att.validate();
        assert!(r.errors.iter().any(|e| e.contains("claimed but not declared")));
        assert!(r.unproven.contains(&"DES".to_string()));
    }

    #[test]
    fn missing_implementation_hash_is_an_error() {
        let mut att = worked_example();
        att.primitives.get_mut("DES").unwrap().sha256 = None;
        let r = att.validate();
        assert!(r
            .errors
            .iter()
            .any(|e| e.contains("without an implementation hash")));
    }

    #[test]
    fn unknown_oracle_is_an_error() {
        let mut att = worked_example();
        att.oracle_id = "vibes-based".into();
        assert!(att
            .validate()
            .errors
            .iter()
            .any(|e| e.contains("unknown oracle")));
    }

    /// Regression: a case-mismatched primitive name must not vacuously pass.
    #[test]
    fn rijndael_case_mismatch_still_requires_a_real_vector() {
        let mut att = worked_example();
        let mut coverage = CoverageSet::new();
        coverage.add(Cover::new(
            vec!["b64d", "dec"],
            vec![product! {"1.prim" => ["Rijndael-256"], "1.mode" => ["ecb"]}],
        ));
        att.coverage = coverage;

        att.primitives = BTreeMap::from([(
            "Rijndael-256".to_string(),
            rec("ra-prim", Conformance::Pass, &["rev1"]),
        )]);
        assert_eq!(
            att.effective_coverage().size_exact(),
            1,
            "a correct vector should be admitted despite the suite's lowercase key"
        );

        att.primitives = BTreeMap::from([(
            "Rijndael-256".to_string(),
            rec("ra-prim", Conformance::Pass, &["rev9"]),
        )]);
        assert_eq!(
            att.effective_coverage().size_exact(),
            0,
            "an irrelevant vector must void the coverage"
        );
    }

    // -----------------------------------------------------------------------
    // The gate as a standalone function. `Attestation::effective_coverage` is one
    // caller; `ra residual` is the other. These pin the shared contract, including
    // the part `Attestation` never exercises: what happens when nothing is gated.
    // -----------------------------------------------------------------------

    fn t1(prims: &[&str]) -> CoverageSet {
        let mut set = CoverageSet::new();
        set.add(Cover::new(
            vec!["b64d", "dec"],
            vec![product! {"1.prim" => prims, "1.mode" => ["cfb","ecb"]}],
        ));
        set
    }

    #[test]
    fn the_gate_drops_products_whose_primitives_are_all_unproven() {
        let proven = ProvenPrimitives::from_names(["DES"]);
        let g = gate_coverage(&t1(&["Twofish"]), &proven);
        assert_eq!(g.effective.size_exact(), 0);
        assert!(g.effective.covers.is_empty(), "an empty cover is not emitted");
        assert_eq!(g.products_dropped, 1);
        assert_eq!(g.voided, BTreeSet::from(["Twofish".to_string()]));
        assert!(g.admitted.is_empty());
        assert!(!g.is_vacuous(), "a prim dimension was examined");
        assert!(!g.is_identity());
    }

    #[test]
    fn the_gate_keeps_the_proven_share_of_a_mixed_dimension() {
        let proven = ProvenPrimitives::from_names(["DES", "RC2"]);
        let g = gate_coverage(&t1(&["DES", "RC2", "Twofish"]), &proven);
        assert_eq!(g.effective.size_exact(), 4, "2 proven prims x 2 modes");
        assert_eq!(g.admitted, BTreeSet::from(["DES".into(), "RC2".into()]));
        assert_eq!(g.voided, BTreeSet::from(["Twofish".to_string()]));
    }

    /// The prior art, generalised. A gate that finds no `*.prim` dimension has
    /// checked nothing, and reporting that as a clean pass is exactly how a
    /// conformance check once passed vacuously.
    #[test]
    fn a_coverage_set_with_no_prim_dimension_gates_vacuously_and_says_so() {
        let mut set = CoverageSet::new();
        set.add(Cover::new(
            vec!["b64d", "dec"],
            vec![product! {"1.primitive" => ["Twofish"], "1.mode" => ["cfb"]}],
        ));
        let g = gate_coverage(&set, &ProvenPrimitives::new());
        assert_eq!(
            g.effective.size_exact(),
            1,
            "nothing was intersected, so nothing was removed"
        );
        assert!(
            g.is_vacuous(),
            "and that must be reported as a failure to gate, not as a pass"
        );
        assert_eq!(g.prim_dimensions_seen, 0);
    }

    /// Case-insensitive across the two spellings this workspace uses, and not
    /// name-blind: an unknown primitive is voided whatever its case.
    #[test]
    fn the_gate_folds_case_but_admits_only_names_it_was_given() {
        let proven = ProvenPrimitives::from_names(["rijndael-256"]);
        assert_eq!(
            gate_coverage(&t1(&["Rijndael-256"]), &proven)
                .effective
                .size_exact(),
            2
        );
        assert_eq!(
            gate_coverage(&t1(&["Rijndael-192"]), &proven)
                .effective
                .size_exact(),
            0
        );
        assert!(proven.contains("RIJNDAEL-256"));
        assert!(!proven.contains("rijndael-192"));
    }

    /// Both `*.prim` dimensions of a two-layer skeleton are examined. Stopping at the
    /// first empty one would leave the second's primitives unreported.
    #[test]
    fn every_prim_dimension_is_examined_not_just_the_first() {
        let mut set = CoverageSet::new();
        set.add(Cover::new(
            vec!["b64d", "dec", "xf", "codec", "dec"],
            vec![product! {"1.prim" => ["Twofish"], "4.prim" => ["Serpent"]}],
        ));
        let g = gate_coverage(&set, &ProvenPrimitives::from_names(["DES"]));
        assert_eq!(g.prim_dimensions_seen, 2);
        assert_eq!(
            g.voided,
            BTreeSet::from(["Serpent".to_string(), "Twofish".to_string()])
        );
        assert_eq!(g.effective.size_exact(), 0);
    }

    /// `Attestation::effective_coverage` must be the shared gate, not a copy of it.
    #[test]
    fn the_attestation_gate_and_the_free_function_agree() {
        let att = worked_example();
        let direct = gate_coverage(&att.coverage, &att.proven_primitives());
        assert_eq!(direct.effective.digest(), att.effective_coverage().digest());
        assert_eq!(
            att.gated().voided,
            BTreeSet::from(["Serpent".to_string(), "Twofish".into(), "XTEA".into()])
        );
    }

    #[test]
    fn claimed_primitives_reads_every_prim_dimension() {
        let mut set = CoverageSet::new();
        set.add(Cover::new(
            vec!["b64d", "dec", "xf", "codec", "dec"],
            vec![product! {"1.prim" => ["DES"], "4.prim" => ["RC2"], "2.xf" => ["identity"]}],
        ));
        assert_eq!(
            claimed_primitives(&set),
            BTreeSet::from(["DES".to_string(), "RC2".to_string()])
        );
    }

    #[test]
    fn serialises_with_the_v1_schema_marker_and_both_digests() {
        let j = worked_example().to_json();
        assert_eq!(j["schema"], "bo3-coverage-attestation/v1");
        assert_eq!(j["target"], "tg4");
        assert_eq!(j["coverage_claimed_size"], "14");
        assert_eq!(j["coverage_effective_size"], "8");
        assert!(j["input"]["ciphertext_sha256"]
            .as_str()
            .unwrap()
            .starts_with("sha256:"));
        assert_eq!(j["input"]["ciphertext_len"], 192);
        assert_ne!(j["coverage_claimed_digest"], j["coverage_effective_digest"]);
    }
}
