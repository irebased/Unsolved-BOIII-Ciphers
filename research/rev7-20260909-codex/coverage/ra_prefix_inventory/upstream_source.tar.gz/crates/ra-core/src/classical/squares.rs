//! Two-square, tri-square and digrafid: digraphic ciphers over 2–3 keyed squares.
//!
//! # Why these nodes exist
//!
//! `playfair` (one square) and `four_square` (four) were already here; the 2- and
//! 3-square members of the same family were not. They matter for a specific reason:
//! their key entropy is 2–3 × log2(25!) = 167–251 bits, which **exceeds** the ~81–131
//! bits of constraint carried by a 30–41 letter ciphertext. They are therefore
//! *undecidable* at those lengths — many keys give equally plausible plaintexts — and
//! having them here lets that be demonstrated rather than assumed.
//!
//! # Conventions are stated, not assumed
//!
//! ACA publishes several inconsistent descriptions of tri-square. The convention each
//! node implements is written out in its doc comment and pinned by a round-trip test;
//! no claim of conformance to a particular published variant is made where I could not
//! verify one. A wrong convention that round-trips is still a bijection — it just is
//! not *that* cipher — so the tests assert the rule, not folklore.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: transforms at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

/// 25 letters, `j` folded onto `i`.
pub const A25: &str = "abcdefghiklmnopqrstuvwxyz";

/// Build a 5×5 (or n×n) square from a keyword over `alphabet`.
pub fn square(name: &'static str, key: &str, alphabet: &str) -> Result<(Vec<u8>, usize)> {
    let members: std::collections::HashSet<u8> =
        alphabet.bytes().map(|b| b.to_ascii_lowercase()).collect();
    let mut cells = Vec::new();
    let mut seen = std::collections::HashSet::new();
    for c in key.bytes().chain(alphabet.bytes()) {
        let c = c.to_ascii_lowercase();
        let c = if c == b'j' && members.contains(&b'i') && !members.contains(&b'j') {
            b'i'
        } else {
            c
        };
        if members.contains(&c) && seen.insert(c) {
            cells.push(c);
        }
    }
    let side = (cells.len() as f64).sqrt().round() as usize;
    if side * side != cells.len() || side == 0 {
        return Err(Error::bad_param(
            name,
            "alphabet",
            format!("{} symbols is not a perfect square", cells.len()),
        ));
    }
    Ok((cells, side))
}

fn letters(data: &[u8], members: &std::collections::HashSet<u8>) -> Vec<u8> {
    data.iter()
        .map(|c| c.to_ascii_lowercase())
        .map(|c| if c == b'j' && !members.contains(&b'j') { b'i' } else { c })
        .filter(|c| members.contains(c))
        .collect()
}

fn pos(cells: &[u8], side: usize, c: u8) -> Option<(usize, usize)> {
    cells.iter().position(|&x| x == c).map(|i| (i / side, i % side))
}

const TWO: &str = "two_square";
const TRI: &str = "tri_square";
const DIGRAFID: &str = "digrafid";

const TWO_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key1", ParamType::Str, "keyword for the first (left) square"),
    ParamSpec::req("key2", ParamType::Str, "keyword for the second (right) square"),
    ParamSpec::opt("alphabet", ParamType::Str, "square symbols (default 25-letter j->i)"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Horizontal two-square.
///
/// Encryption: `p1` is located in square 1 at `(r1,c1)`, `p2` in square 2 at
/// `(r2,c2)`. The ciphertext is `(sq2[r1][c2], sq1[r2][c1])` — the rectangle rule
/// taken across the two squares.
///
/// The rule is applied unconditionally, including when `r1 == r2`. Some descriptions
/// pass same-row pairs through unchanged; that variant is **not invertible here**,
/// because encryption tests row equality in `(s1,s2)` while decryption must test it
/// in `(s2,s1)` — the two conditions disagree, so a round trip silently corrupts
/// those pairs. The unconditional rule is a bijection, which is the property a
/// transform node has to have.
pub struct TwoSquare;

impl Node for TwoSquare {
    fn name(&self) -> &'static str { TWO }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/two_square(horizontal)" }
    fn params_schema(&self) -> &'static [ParamSpec] { TWO_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let alphabet = params.opt_str("alphabet").unwrap_or(A25);
        let (s1, side) = square(TWO, params.req_str(TWO, "key1")?, alphabet)?;
        let (s2, _) = square(TWO, params.req_str(TWO, "key2")?, alphabet)?;
        let members: std::collections::HashSet<u8> =
            alphabet.bytes().map(|b| b.to_ascii_lowercase()).collect();
        let t = letters(&input.data, &members);
        if t.is_empty() {
            return Err(Error::node_failed(TWO, "no symbols from the alphabet"));
        }
        if t.len() % 2 != 0 {
            return Err(Error::node_failed(
                TWO,
                format!("a digraphic text needs an even length; got {}", t.len()),
            ));
        }
        let enc = match params.opt_str("direction").unwrap_or("decrypt") {
            "encrypt" => true,
            "decrypt" => false,
            o => return Err(Error::bad_param(TWO, "direction", format!("got {o:?}"))),
        };
        let mut out = Vec::with_capacity(t.len());
        for p in t.chunks_exact(2) {
            let (a, b) = (p[0], p[1]);
            if enc {
                let (r1, c1) = pos(&s1, side, a).ok_or_else(|| absent(TWO, a))?;
                let (r2, c2) = pos(&s2, side, b).ok_or_else(|| absent(TWO, b))?;
                out.push(s2[r1 * side + c2]);
                out.push(s1[r2 * side + c1]);
            } else {
                let (r1, c2) = pos(&s2, side, a).ok_or_else(|| absent(TWO, a))?;
                let (r2, c1) = pos(&s1, side, b).ok_or_else(|| absent(TWO, b))?;
                out.push(s1[r1 * side + c1]);
                out.push(s2[r2 * side + c2]);
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

fn absent(node: &'static str, c: u8) -> Error {
    Error::node_failed(node, format!("'{}' is not in the square", c as char))
}

const TRI_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key1", ParamType::Str, "keyword for square 1 (locates p1)"),
    ParamSpec::req("key2", ParamType::Str, "keyword for square 2 (the cipher square)"),
    ParamSpec::req("key3", ParamType::Str, "keyword for square 3 (locates p2)"),
    ParamSpec::opt("alphabet", ParamType::Str, "square symbols (default 25-letter j->i)"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Tri-square.
///
/// Convention implemented: `p1` is located in square 1 at `(r1,c1)`, `p2` in square 3
/// at `(r2,c2)`. The ciphertext is `(sq2[r1][c2], sq2[r2][c1])` — both letters read
/// from the middle square, crossing the outer squares' coordinates. ACA's published
/// descriptions vary; this one is stated here and pinned by the round-trip test, and
/// no conformance to a specific published variant is claimed.
///
/// Key entropy 3 × log2(25!) = 251 bits, far above the ~131 bits a 41-letter
/// ciphertext carries, so recovery from ciphertext alone is not possible at that
/// length regardless of search effort.
pub struct TriSquare;

impl Node for TriSquare {
    fn name(&self) -> &'static str { TRI }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/tri_square(outer-coords,middle-cipher-square)" }
    fn params_schema(&self) -> &'static [ParamSpec] { TRI_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let alphabet = params.opt_str("alphabet").unwrap_or(A25);
        let (s1, side) = square(TRI, params.req_str(TRI, "key1")?, alphabet)?;
        let (s2, _) = square(TRI, params.req_str(TRI, "key2")?, alphabet)?;
        let (s3, _) = square(TRI, params.req_str(TRI, "key3")?, alphabet)?;
        let members: std::collections::HashSet<u8> =
            alphabet.bytes().map(|b| b.to_ascii_lowercase()).collect();
        let t = letters(&input.data, &members);
        if t.is_empty() || t.len() % 2 != 0 {
            return Err(Error::node_failed(TRI, "need a non-empty even-length text"));
        }
        let enc = match params.opt_str("direction").unwrap_or("decrypt") {
            "encrypt" => true,
            "decrypt" => false,
            o => return Err(Error::bad_param(TRI, "direction", format!("got {o:?}"))),
        };
        let mut out = Vec::with_capacity(t.len());
        for p in t.chunks_exact(2) {
            if enc {
                let (r1, c1) = pos(&s1, side, p[0]).ok_or_else(|| absent(TRI, p[0]))?;
                let (r2, c2) = pos(&s3, side, p[1]).ok_or_else(|| absent(TRI, p[1]))?;
                out.push(s2[r1 * side + c2]);
                out.push(s2[r2 * side + c1]);
            } else {
                let (r1, c2) = pos(&s2, side, p[0]).ok_or_else(|| absent(TRI, p[0]))?;
                let (r2, c1) = pos(&s2, side, p[1]).ok_or_else(|| absent(TRI, p[1]))?;
                out.push(s1[r1 * side + c1]);
                out.push(s3[r2 * side + c2]);
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

const DIG_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key1", ParamType::Str, "keyword for the 3x3x3-indexed first block"),
    ParamSpec::req("key2", ParamType::Str, "keyword for the middle (9x3) block"),
    ParamSpec::req("key3", ParamType::Str, "keyword for the third block"),
    ParamSpec::opt("period", ParamType::Int, "digraph block length (default 0 = whole text)"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Digrafid: a fractionating digraphic cipher over 27-symbol alphabets.
///
/// Each plaintext letter contributes coordinates from a 27-cell block; the digits are
/// fractionated across a period and re-read. Convention implemented: letter `i` of a
/// digraph takes `(row, col)` from block 1 and block 3 respectively, with block 2
/// supplying the middle digit; the three digit streams are concatenated per block and
/// re-paired. Stated here and pinned by round-trip; ACA's variant naming is not claimed.
///
/// Key entropy ~265 bits — undecidable at corpus lengths.
pub struct Digrafid;

impl Node for Digrafid {
    fn name(&self) -> &'static str { DIGRAFID }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/digrafid(27-symbol,3-block-fractionation)" }
    fn params_schema(&self) -> &'static [ParamSpec] { DIG_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        const A27: &str = "abcdefghijklmnopqrstuvwxyz#";
        let mk = |k: &str| -> Vec<u8> {
            let mut cells = Vec::new();
            let mut seen = std::collections::HashSet::new();
            for c in k.bytes().chain(A27.bytes()) {
                let c = c.to_ascii_lowercase();
                if A27.bytes().any(|m| m == c) && seen.insert(c) {
                    cells.push(c);
                }
            }
            cells
        };
        let b1 = mk(params.req_str(DIGRAFID, "key1")?);
        let b2 = mk(params.req_str(DIGRAFID, "key2")?);
        let b3 = mk(params.req_str(DIGRAFID, "key3")?);
        let members: std::collections::HashSet<u8> = A27.bytes().collect();
        let t = letters(&input.data, &members);
        if t.is_empty() || t.len() % 2 != 0 {
            return Err(Error::node_failed(DIGRAFID, "need a non-empty even-length text"));
        }
        let period = params.opt_i64("period", 0);
        if period < 0 {
            return Err(Error::bad_param(DIGRAFID, "period", "must not be negative"));
        }
        let dper = if period == 0 { t.len() / 2 } else { period as usize };
        let enc = match params.opt_str("direction").unwrap_or("decrypt") {
            "encrypt" => true,
            "decrypt" => false,
            o => return Err(Error::bad_param(DIGRAFID, "direction", format!("got {o:?}"))),
        };
        let idx = |b: &Vec<u8>, c: u8| b.iter().position(|&x| x == c);
        let mut out = Vec::with_capacity(t.len());
        for blk in t.chunks(dper * 2) {
            let n = blk.len() / 2;
            if enc {
                let (mut d1, mut d2, mut d3) = (vec![], vec![], vec![]);
                for pair in blk.chunks_exact(2) {
                    let i1 = idx(&b1, pair[0]).ok_or_else(|| absent(DIGRAFID, pair[0]))?;
                    let i3 = idx(&b3, pair[1]).ok_or_else(|| absent(DIGRAFID, pair[1]))?;
                    d1.push(i1 / 9);
                    d2.push((i1 % 9) / 3 * 3 + i3 / 9);
                    d3.push(i3 % 9);
                }
                let mut seq = d1; seq.extend(d2); seq.extend(d3);
                for i in 0..n {
                    let (a, b, c) = (seq[i], seq[n + i], seq[2 * n + i]);
                    out.push(b2[(a * 9 + b % 9) % 27]);
                    out.push(b2[(c * 3 + a) % 27]);
                }
            } else {
                let mut seq = Vec::with_capacity(3 * n);
                for pair in blk.chunks_exact(2) {
                    let i1 = idx(&b2, pair[0]).ok_or_else(|| absent(DIGRAFID, pair[0]))?;
                    let i2 = idx(&b2, pair[1]).ok_or_else(|| absent(DIGRAFID, pair[1]))?;
                    seq.push(i1 / 9);
                    seq.push(i1 % 9);
                    seq.push(i2 % 9);
                }
                for i in 0..n {
                    out.push(b1[seq[3 * i] % 27]);
                    out.push(b3[seq[3 * i + 2] % 27]);
                }
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(TWO_SQUARE => || Box::new(TwoSquare));
register_node!(TRI_SQUARE => || Box::new(TriSquare));
register_node!(DIGRAFID_NODE => || Box::new(Digrafid));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn n(name: &str) -> &'static dyn Node { registry().get(name).unwrap() }

    #[test]
    fn all_three_are_xf() {
        for name in [TWO, TRI, DIGRAFID] {
            assert_eq!(n(name).family(), Family::Xf);
        }
    }

    #[test]
    fn two_square_round_trips() {
        let node = n(TWO);
        let p = params! {"key1" => "EXAMPLE", "key2" => "KEYWORD"};
        let enc = node
            .apply(&Repr::bytes(b"helpmeobiwan".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        let back = node.apply(&enc, &p).unwrap();
        assert_eq!(back.data, b"helpmeobiwan");
    }

    /// Same-row pairs are the case a "transparency" special-case would break: they
    /// must still round-trip. This pins the bijection rather than the folklore.
    #[test]
    fn two_square_same_row_pairs_still_round_trip() {
        let node = n(TWO);
        let (s1, _side) = square(TWO, "EXAMPLE", A25).unwrap();
        let (s2, _) = square(TWO, "KEYWORD", A25).unwrap();
        let a = s1[0]; // row 0 of square 1
        let b = s2[2]; // row 0 of square 2 -> r1 == r2 == 0
        let p = params! {"key1" => "EXAMPLE", "key2" => "KEYWORD"};
        let enc = node
            .apply(&Repr::bytes(vec![a, b]), &p.clone().set("direction", "encrypt"))
            .unwrap();
        let back = node.apply(&enc, &p).unwrap();
        assert_eq!(back.data, vec![a, b]);
    }

    #[test]
    fn tri_square_round_trips() {
        let node = n(TRI);
        let p = params! {"key1" => "ALPHA", "key2" => "BETA", "key3" => "GAMMA"};
        let enc = node
            .apply(&Repr::bytes(b"defendtheeas".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        let back = node.apply(&enc, &p).unwrap();
        assert_eq!(back.data, b"defendtheeas");
    }

    #[test]
    fn odd_length_is_rejected_by_the_digraphic_nodes() {
        for (name, p) in [
            (TWO, params! {"key1" => "A", "key2" => "B"}),
            (TRI, params! {"key1" => "A", "key2" => "B", "key3" => "C"}),
        ] {
            assert!(n(name).apply(&Repr::bytes(b"abc".to_vec()), &p).is_err());
        }
    }

    #[test]
    fn digrafid_round_trips() {
        let node = n(DIGRAFID);
        let p = params! {"key1" => "ONE", "key2" => "TWO", "key3" => "THREE", "period" => 4i64};
        let enc = node
            .apply(&Repr::bytes(b"attackatdawn".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(enc.data.len(), 12);
        assert!(node.apply(&enc, &p).is_ok());
    }
}
