"""
verify.py  -  Making distributed coverage claims trustworthy WITHOUT trusting the client.

THE THREAT MODEL IS INVERTED FROM INTUITION
-------------------------------------------
Worry about false positives is misplaced. A positive claim is a CONSTRUCTIVE PROOF:
"pipeline P applied to input X yields plaintext Y". Anyone can re-run that single
pipeline in microseconds and confirm or refute it. Fabricating a hit is therefore
self-defeating; it is caught by the first verifier who looks.

The dangerous claim is the NEGATIVE one. "I swept this block of 10^8 and found
nothing" is unfalsifiable by inspection, and if false it poisons the residual: the
community permanently stops searching a region that may contain the answer. A
fabricated negative is silent, durable, and directly harmful.

So the protocol spends its effort on verifying that work was actually DONE.

WHY COMPILING THE ENGINE DOES NOT HELP
--------------------------------------
Code running on hardware the adversary controls is not a security boundary.
A compiled binary can be patched, traced, or simply bypassed by posting crafted
payloads straight at the ledger API. Any signing key shipped inside the binary is
extractable. Compilation buys obfuscation, not integrity, and it costs the one
thing this project needs most: independent auditability of the implementations.

What replaces it: reproducible builds (so a binary hash maps verifiably back to
audited source), plus the two mechanisms below.
"""
from __future__ import annotations
import hashlib, os, json, random
from typing import List, Tuple

# --------------------------------------------------------------------------
# Merkle commitment over a scan
# --------------------------------------------------------------------------
def H(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()

def leaf_hash(idx: int, params: str, out_digest: str) -> bytes:
    return H(b"\x00" + f"{idx}|{params}|{out_digest}".encode())

def merkle_root(leaves: List[bytes]) -> bytes:
    if not leaves:
        return H(b"")
    lvl = list(leaves)
    while len(lvl) > 1:
        if len(lvl) % 2:
            lvl.append(lvl[-1])
        lvl = [H(b"\x01" + lvl[i] + lvl[i+1]) for i in range(0, len(lvl), 2)]
    return lvl[0]

def merkle_path(leaves: List[bytes], idx: int) -> List[Tuple[str, bytes]]:
    path, lvl, i = [], list(leaves), idx
    while len(lvl) > 1:
        if len(lvl) % 2:
            lvl.append(lvl[-1])
        sib = i ^ 1
        path.append(("L" if sib < i else "R", lvl[sib]))
        lvl = [H(b"\x01" + lvl[j] + lvl[j+1]) for j in range(0, len(lvl), 2)]
        i //= 2
    return path

def merkle_verify(leaf: bytes, path, root: bytes) -> bool:
    cur = leaf
    for side, sib in path:
        cur = H(b"\x01" + (sib + cur if side == "L" else cur + sib))
    return cur == root


# --------------------------------------------------------------------------
# A toy but real deterministic scan, so the audit is genuine
# --------------------------------------------------------------------------
from Crypto.Cipher import DES

def evaluate(input_bytes: bytes, key: bytes, iv: bytes) -> str:
    """One deterministic candidate evaluation -> output digest."""
    c = DES.new(key.ljust(8, b"\x00")[:8], DES.MODE_CFB, iv=iv[:8], segment_size=8)
    return hashlib.sha256(c.decrypt(input_bytes)).hexdigest()

def enumerate_block(input_bytes: bytes, n: int):
    """Deterministic candidate enumeration for a work unit."""
    for i in range(n):
        key = f"K{i:06d}".encode()
        iv = b"0" * 8
        yield i, f"key=K{i:06d}", evaluate(input_bytes, key, iv)


def honest_scan(input_bytes: bytes, n: int):
    leaves, recs = [], []
    for i, params, dig in enumerate_block(input_bytes, n):
        leaves.append(leaf_hash(i, params, dig))
        recs.append((i, params, dig))
    return leaves, recs

def fabricated_scan(input_bytes: bytes, n: int, honest_fraction: float):
    """Cheater computes only a fraction, fills the rest with plausible garbage."""
    leaves, recs = [], []
    k = int(n * honest_fraction)
    for i in range(n):
        if i < k:
            _, params, dig = next(iter(enumerate_block(input_bytes, 1))) if False else (None, f"key=K{i:06d}", evaluate(input_bytes, f"K{i:06d}".encode(), b"0"*8))
        else:
            params, dig = f"key=K{i:06d}", hashlib.sha256(os.urandom(16)).hexdigest()
        leaves.append(leaf_hash(i, params, dig))
        recs.append((i, params, dig))
    return leaves, recs


def audit(input_bytes: bytes, n: int, leaves, recs, root: bytes, k_challenges: int, rng):
    """Ledger issues random challenges AFTER the root is committed."""
    challenged = rng.sample(range(n), min(k_challenges, n))
    for idx in challenged:
        i, params, claimed_dig = recs[idx]
        # ledger independently recomputes this candidate from scratch
        true_dig = evaluate(input_bytes, f"K{idx:06d}".encode(), b"0"*8)
        if claimed_dig != true_dig:
            return False, idx, "recomputation mismatch"
        if not merkle_verify(leaves[idx], merkle_path(leaves, idx), root):
            return False, idx, "merkle path invalid"
    return True, None, "all challenges passed"


# --------------------------------------------------------------------------
def detection_table():
    print("=" * 78)
    print("MECHANISM 1: MERKLE COMMIT + SPOT AUDIT")
    print("=" * 78)
    print("Worker commits a Merkle root over ALL leaves BEFORE challenges are issued.")
    print("Building a consistent root requires evaluating every candidate. The ledger")
    print("then recomputes k random leaves independently and checks them against both")
    print("the revealed value and the committed root.\n")
    print(f"{'honest fraction':>16}{'k=10':>10}{'k=20':>10}{'k=40':>10}{'k=80':>10}")
    print("-" * 78)
    for f in (0.99, 0.95, 0.90, 0.75, 0.50, 0.10):
        row = "".join(f"{1-f**k:>10.4%}" for k in (10, 20, 40, 80))
        print(f"{f:>16.0%}{row}")
    print("\nVerifier cost is k evaluations regardless of block size N.")
    print("A worker skipping even 5 percent of a block is caught ~64% of the time at k=20,")
    print("and repeated audits compound across submissions.")

    print("\n" + "=" * 78)
    print("MECHANISM 2: PLANTED-SOLUTION CANARIES")
    print("=" * 78)
    print("The ledger occasionally issues a work unit whose 'target' is synthetic:")
    print("a known plaintext encrypted through a chain that lies INSIDE the assigned")
    print("block. An honest sweep must report that hit. A fabricated negative cannot.")
    print("The worker cannot distinguish a canary from a real unit, because both are")
    print("just opaque byte strings drawn from the same domain.\n")
    print(f"{'canary rate':>14}{'10 units':>12}{'25 units':>12}{'50 units':>12}{'100 units':>12}")
    print("-" * 78)
    for p in (0.02, 0.05, 0.10, 0.20):
        row = "".join(f"{1-(1-p)**n:>12.2%}" for n in (10, 25, 50, 100))
        print(f"{p:>14.0%}{row}")
    print("\nThis catches the fabricator who returns 'no hit' without computing.")
    print("Cost to the ledger is only the wasted compute on canary units.")

    print("\n" + "=" * 78)
    print("MECHANISM 3: N-VERSION REDUNDANT ASSIGNMENT")
    print("=" * 78)
    print("Assign each block to 2+ workers using DIFFERENT tool implementations")
    print("(distinct tool_ids per toolreg.py). Agreement on the committed root is")
    print("evidence both implementations are correct. Disagreement localises a bug")
    print("to a specific tool version, which is exactly the silent-void failure mode.")
    print("\nThis is the only mechanism that catches an HONEST worker running a")
    print("DEFECTIVE implementation. Audits and canaries do not, because such a")
    print("worker computes faithfully; it is the primitive that is wrong.")


if __name__ == "__main__":
    rng = random.Random(1234)
    N = 4000
    inp = os.urandom(64)

    print("=" * 78); print("LIVE AUDIT DEMONSTRATION"); print("=" * 78)

    lv, rc = honest_scan(inp, N)
    root = merkle_root(lv)
    ok, idx, msg = audit(inp, N, lv, rc, root, 20, rng)
    print(f"  honest worker      root={root.hex()[:16]}...  audit -> {'PASS' if ok else 'FAIL'} ({msg})")

    for frac in (0.95, 0.50):
        lv2, rc2 = fabricated_scan(inp, N, frac)
        root2 = merkle_root(lv2)
        ok2, idx2, msg2 = audit(inp, N, lv2, rc2, root2, 20, rng)
        label = f"fabricator ({frac:.0%} real)"
        detail = f"caught at candidate #{idx2}" if not ok2 else "survived this audit"
        print(f"  {label:<19}root={root2.hex()[:16]}...  audit -> {'PASS' if ok2 else 'FAIL'} ({detail})")

    print()
    detection_table()
