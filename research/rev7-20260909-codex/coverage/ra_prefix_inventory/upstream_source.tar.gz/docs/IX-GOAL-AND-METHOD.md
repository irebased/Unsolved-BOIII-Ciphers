---
name: ix-cipher-goal-and-method
description: "The IX cipher goal (ix3/ix7/ix9) plus the operator's standing process rules for how cryptanalysis work must be conducted"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 6db1adb0-f04a-4a21-a1de-aa59a8537035
  modified: 2026-08-01T04:04:29.358Z
---

# GOAL
Solve the three unsolved BO4 "IX" ciphers (2018 release, same puzzle master):
- CT1 = ix7 (n=38): UWDRZSHWZSUSAUUWNAOUSWVDHTDOHLPZAPUXDI
- CT2 = ix9 (n=30): DFGOHQGEPSYADLFATNGKYVKEWLAMLI   (site flags "solved" - that is a DATA ERROR)
- CT3 = ix3 (n=41): WPKITUAVZZFKLZTDMKXAQULNROVEYUMKCANTKULFL
Source: irebased.github.io/Unsolved-BOIII-Ciphers, data at
lavender/src/data/ciphers/ix.json in that GitHub repo.

# STANDING PROCESS RULES (operator-given, all still in force)

1. **Reply format**: short precise statements with statistics or facts. Scenario,
   problem/outcome, next action. No long narrative unless asked. Include the
   minimum required evidence from tool output.
2. **Never treat a new method as concrete.** Always stay skeptical; assume better
   routes exist and keep looking. A working method is a hypothesis, not an answer.
3. **Do research** where knowledge is missing (fetch tool lists, cipher taxonomies,
   corpora) rather than guessing.
4. **Express mathematical limits** - quantify key-space bits vs constraint bits, and
   extreme-value limits of any scorer - to stay grounded about what is even decidable.
5. **Explore new classical techniques**, including ones absent from the toolchain.
6. **Run proper scientific experiments**: null distributions, controls, power tests.
7. **Never report a negative from an unvalidated harness.** Plant a known case and
   confirm recovery first. Never report a hit without a random-control comparison.
8. **Do not get stuck in a local minimum** - vary chains, orders, and combinations.

**Why:** several hours were lost to negatives produced by harnesses that could not
have found the answer (thresholds above what real English scores, searches that
excluded the very key class the author uses).

**How to apply:** before any sweep, state key-space bits vs available constraint;
validate the harness on a planted case; calibrate the acceptance threshold against
the AUTHOR's own plaintexts, not intuition; and control every claimed hit.
See [[short-ciphertext-undecidability]] and [[ix-author-repertoire]].
