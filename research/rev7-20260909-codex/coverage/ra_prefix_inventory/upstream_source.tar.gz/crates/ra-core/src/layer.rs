//! Layer detection: making the semantic definition of a "layer" computable.
//!
//! The governing insight is that pure re-encoding preserves *canonical bytes*, so
//! byte entropy is invariant across it. `base64 -> decimal` moves the display but
//! not the content and registers a delta of zero. A decryption rewrites the byte
//! sequence and typically drops entropy toward structure.

use serde::{Deserialize, Serialize};

use crate::node::{Family, Node};
use crate::repr::Repr;

/// Shannon entropy in bits per byte.
pub fn shannon(b: &[u8]) -> f64 {
    if b.is_empty() {
        return 0.0;
    }
    let mut counts = [0usize; 256];
    for &x in b {
        counts[x as usize] += 1;
    }
    let n = b.len() as f64;
    -counts
        .iter()
        .filter(|&&c| c > 0)
        .map(|&c| {
            let p = c as f64 / n;
            p * p.log2()
        })
        .sum::<f64>()
}

/// Index of coincidence over the byte alphabet.
pub fn index_of_coincidence(b: &[u8]) -> f64 {
    if b.len() < 2 {
        return 0.0;
    }
    let mut counts = [0usize; 256];
    for &x in b {
        counts[x as usize] += 1;
    }
    let n = b.len() as f64;
    counts
        .iter()
        .map(|&c| {
            let c = c as f64;
            c * (c - 1.0)
        })
        .sum::<f64>()
        / (n * (n - 1.0))
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ReprClass {
    Empty,
    Text,
    Octal,
    Decimal,
    Hex,
    Base64ish,
    Printable,
    Opaque,
}

impl ReprClass {
    pub fn as_str(self) -> &'static str {
        match self {
            ReprClass::Empty => "empty",
            ReprClass::Text => "text",
            ReprClass::Octal => "octal",
            ReprClass::Decimal => "decimal",
            ReprClass::Hex => "hex",
            ReprClass::Base64ish => "base64ish",
            ReprClass::Printable => "printable",
            ReprClass::Opaque => "opaque",
        }
    }

    /// Classes that indicate a genuine breakthrough when arrived at.
    pub fn is_structured(self) -> bool {
        matches!(
            self,
            ReprClass::Text | ReprClass::Printable | ReprClass::Decimal | ReprClass::Octal
        )
    }
}

/// Classify a byte string into a representation class.
///
/// Order matters. Text-likeness is checked *first*, because uppercase prose also
/// matches the base64 character class and would otherwise be mislabelled. Then
/// the numeric classes run most-specific first, since octal is a subset of
/// decimal and decimal a subset of hex.
pub fn classify(b: &[u8]) -> ReprClass {
    if b.is_empty() {
        return ReprClass::Empty;
    }
    let n = b.len() as f64;
    let printable = b.iter().filter(|&&x| (32..127).contains(&x)).count() as f64;
    let printable_ratio = printable / n;

    if printable_ratio > 0.95 {
        let letters = b
            .iter()
            .filter(|&&x| (65..=90).contains(&(x & 0xDF)))
            .count() as f64;
        let spaces = b.iter().filter(|&&x| x == b' ').count() as f64;
        if letters / n > 0.55 && spaces / n > 0.05 {
            return ReprClass::Text;
        }
    }

    let all = |f: fn(u8) -> bool| b.iter().all(|&x| f(x) || x.is_ascii_whitespace());
    if all(|x| (b'0'..=b'7').contains(&x)) {
        return ReprClass::Octal;
    }
    if all(|x| x.is_ascii_digit()) {
        return ReprClass::Decimal;
    }
    if all(|x| x.is_ascii_hexdigit()) {
        return ReprClass::Hex;
    }
    if all(|x| x.is_ascii_alphanumeric() || x == b'+' || x == b'/' || x == b'=') {
        return ReprClass::Base64ish;
    }
    if printable_ratio > 0.95 {
        return ReprClass::Printable;
    }
    ReprClass::Opaque
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct LayerDelta {
    pub entropy_before: f64,
    pub entropy_after: f64,
    pub entropy_delta: f64,
    pub class_before: ReprClass,
    pub class_after: ReprClass,
    pub class_changed: bool,
    pub bytes_changed: bool,
    pub keyed: bool,
    /// A layer boundary requires a layer-forming node that actually rewrote bytes.
    pub is_layer_boundary: bool,
    /// Worth a human's attention: bytes moved *and* either entropy shifted
    /// materially or the class became structured.
    pub notable: bool,
}

/// Quantify whether a step achieved a genuine representation change.
pub fn layer_delta(before: &Repr, after: &Repr, node: &dyn Node) -> LayerDelta {
    let cb_bytes = before.canonical_bytes();
    let ca_bytes = after.canonical_bytes();
    let eb = shannon(&cb_bytes);
    let ea = shannon(&ca_bytes);
    let cb = classify(&cb_bytes);
    let ca = classify(&ca_bytes);
    let bytes_changed = cb_bytes != ca_bytes;
    let class_changed = cb != ca;

    LayerDelta {
        entropy_before: round4(eb),
        entropy_after: round4(ea),
        entropy_delta: round4(ea - eb),
        class_before: cb,
        class_after: ca,
        class_changed,
        bytes_changed,
        keyed: node.family() == Family::Dec,
        is_layer_boundary: node.layer_forming() && bytes_changed,
        notable: bytes_changed && ((ea - eb).abs() > 0.25 || (class_changed && ca.is_structured())),
    }
}

fn round4(v: f64) -> f64 {
    (v * 10_000.0).round() / 10_000.0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn classify_orders_most_specific_first() {
        assert_eq!(classify(b"0123 4567"), ReprClass::Octal);
        assert_eq!(classify(b"0123 4589"), ReprClass::Decimal);
        assert_eq!(classify(b"0123 45ef"), ReprClass::Hex);
        assert_eq!(classify(b"abc+/ZZ=="), ReprClass::Base64ish);
        assert_eq!(classify(b""), ReprClass::Empty);
    }

    /// Whitespace-robustness audit (see fix/whitespace-robustness): all four of
    /// `classify`'s alphabet-membership branches (`Octal`, `Decimal`, `Hex`,
    /// `Base64ish`) go through the shared `all` closure, which already treats
    /// any ASCII whitespace byte as a free pass alongside the branch's own
    /// alphabet. A web tool's trailing newline, leading space, or interior
    /// line-wrap must not demote a pure intermediate to a false negative.
    #[test]
    fn classify_tolerates_leading_trailing_and_interior_whitespace() {
        assert_eq!(classify(b"0123456789abcdef0123\n"), ReprClass::Hex);
        assert_eq!(classify(b" 0123456789abcdef0123"), ReprClass::Hex);
        assert_eq!(classify(b"0123 4567\n"), ReprClass::Octal);
        assert_eq!(classify(b" 0123 4589"), ReprClass::Decimal);
        assert_eq!(classify(b"abc+/ZZ==\n"), ReprClass::Base64ish);
        assert_eq!(classify(b"abc+/\nZZ=="), ReprClass::Base64ish);
    }

    /// Uppercase prose is inside the base64 character class; text must win.
    #[test]
    fn uppercase_prose_is_text_not_base64() {
        let s = b"THE BODY OF THE GIANT LIES BENEATH AND THE KEEPER GUARDS THE WAY";
        assert_eq!(classify(s), ReprClass::Text);
    }

    #[test]
    fn entropy_of_uniform_bytes_is_eight_bits() {
        let all: Vec<u8> = (0..=255u8).collect();
        assert!((shannon(&all) - 8.0).abs() < 1e-9);
        assert!(shannon(b"aaaaaaaa").abs() < 1e-9);
    }

    #[test]
    fn ioc_matches_hand_computed_value() {
        // "aabb": pairs = 2*1 + 2*1 = 4; n(n-1) = 12
        assert!((index_of_coincidence(b"aabb") - 4.0 / 12.0).abs() < 1e-12);
    }
}
