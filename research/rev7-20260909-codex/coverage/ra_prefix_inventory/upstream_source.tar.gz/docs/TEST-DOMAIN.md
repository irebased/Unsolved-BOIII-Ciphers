# Test domain: what the TG4 variant run actually covers

The precise specification of the search this run performs, and — more importantly — of
what it does **not** perform. A coverage claim is only worth what its boundary
statement is worth, so the exclusions below are the substance of this document, not an
appendix to it.

Companion to the emitted claims in `claims/`. Every number here is reproducible with
`ra sweep --dry-run`.

---

## 1. Input domain: the transcription variant axis

TG4's ciphertext is 192 base64 characters (144 bytes). Two glyph pairs are hard to
disambiguate in the source, and both members of each pair are valid base64.

| pair | positions | count | status |
|---|---|---|---|
| `0` vs `O` | 37, 64, 86, 94, 105, 112, 114 | 7 | **RESOLVED** — fixed as recorded |
| `I` vs `l` | 3, 15, 31, 36, 39, 90, 160 | 7 | **AMBIGUOUS** — enumerated |

`0`/`O` is resolved by the project team's direct review of the transcript against the
font used in the source. That is external ground truth about the artefact and is not
derivable from the corpus; it is attributed, not inferred.

An independent corpus measurement corroborates it. Across the three solved base64
ciphers this engine reproduces (rev1, rev5, rev9), there are 177 `I`/`l` and `0`/`O`
glyph calls. Flipping any single one breaks the reproduction — 128/128 on rev5, 45/45
on rev9 — because one wrong base64 character corrupts about nine bytes under CFB-8,
which is enough to destroy the class check. So each call is independently
load-bearing, and all 177 are correct. Of those, 89 were `0`/`O` calls and 88 were
`I`/`l`. The rule of three puts the 95% upper bound on the per-call error rate at
3/177 = 1.69%.

Two consequences. First, the team's `0`/`O` finding is consistent with the corpus
rather than merely asserted over it. Second, the recorded `I`/`l` reading (variant
index 0) is the single most likely one — but it is **not** assumed: all 2⁷ = 128
readings are enumerated exhaustively, so the claim needs no probability argument to
stand up.

**Variant domain size: 128, exhaustive.**

`reference/py/space.py` sets `N_TRANS_TG = 16`. The true admissible count is 128 — an
8× understatement.

REV7 is unaffected throughout: hex excludes `O`, `I` and `l`, so a transcribed `0`
there can only be a zero. The dossier's "REV7 is unambiguous" claim is confirmed.

---

## 2. Parameter domain: one modern layer

Every `dec` slot draws from the same product.

| axis | values | domain |
|---|---|---|
| `prim` | 11 | DES, RC2, RC4, Blowfish, Blowfish-compat, Twofish, Serpent, Rijndael-256, XTEA, Loki97, Saferplus |
| `mode` | 7 | `cfb` (**= CFB-8**), `ecb`, `cbc`, `ncfb`, `ofb` (= OFB-8), `nofb`, `stream` |
| `key` | 6 | `Zombies`, `TheGiant`, `ZOMBIES`, `thegiant`, `zombies`, `TheGiant_b64` |
| `kd` | 4 | natural, null-pad-max, null-pad-next-supported, repeat-pad-max |
| `iv` | 2 | `ascii0` (0x30 × 16), `null` (0x00 × 16) |

**11 × 7 × 6 × 4 × 2 = 3,696 parameterisations per modern layer.**

Notes on the domain values:

- All 11 primitives are conformance-validated: each reproduces a solved cipher end to
  end (`ra conformance` = 11/11). Under conformance gating an unproven primitive
  contributes zero coverage, so this axis carries real coverage rather than assertions.
  The gate runs on the path these claims actually travel: `ra residual --claims`
  executes the suite and intersects every `*.prim` dimension with what reproduces
  before folding anything, and each claim records the conformance state it was emitted
  under. While all 11 pass, gating is the identity — which is exactly why it has to be
  executable rather than assumed, and why an integration test drives the real binary
  with a claim naming an unproven primitive and requires it to contribute zero.
- `TheGiant_b64` denotes base64(`TheGiant`) = `VGhlR2lhbnQ=`, the bytes, not the twelve
  literal characters. One subcommand got this wrong and was corrected; a shared
  resolver and a regression test now hold it.
- Key derivation stays a 4-value axis even though null-pad-next-supported is
  corpus-confirmed via rev9's Twofish layer, because "confirmed for Twofish" is not
  "confirmed for every primitive". Note that rev5's Loki97 layer **cannot**
  discriminate the null-padding policies — libmcrypt's Loki97 key schedule is the
  256-bit one for every key size and reads a zeroed buffer.
- `stream` is only meaningful for RC4; for block primitives it is a pass-through. Those
  combinations are evaluated and claimed rather than silently skipped, so the claim
  size matches the work.

---

## 3. Skeleton domain: chain shapes and lengths

The coverage algebra partitions by **skeleton** — the ordered tuple of layer families.
Each is swept and committed to separately.

| tier | skeleton | steps | modern layers | candidates (× 128 variants) |
|---|---|---|---|---|
| T1 | `b64d ∘ dec` | 2 | 1 | 3,696 → **473,088** |
| T2 | `b64d ∘ xf ∘ dec` | 3 | 1 | 7,392 → **946,176** |
| T3 | `b64d ∘ dec ∘ xf ∘ codec ∘ dec` | 5 | 2 | 163,924,992 → **20,982,398,976** |

**Total: 20,983,818,240 candidates.** At the measured throughput (~1.1M/s for TG4 on 18
cores) that is roughly 5.3 hours, dominated entirely by T3.

Inter-layer axes:

| axis | values | domain |
|---|---|---|
| `xf` | 2 | identity, reverse |
| `codec` | 6 | identity, `b64decode`, `hexdecode`, `hex_to_base64\|b64decode`, `decimaldecode`, `octaldecode` |

The `codec` slot exists because of a structural finding: **every recorded corpus chain
omits an implicit `b64decode`.** The tools4noobs decrypt box base64-decodes its input at
each hop. rev9 does not reproduce without it and rev1 needs two. Anyone modelling
multi-layer pipelines from the recorded chains was enumerating the wrong skeleton —
`dec ∘ xf ∘ dec` where the truth is `dec ∘ xf ∘ codec ∘ dec`. For the record,
`reference/py/residual.py`'s `SK_T3 = ("b64d","dec","xf","dec")` is exactly that error:
that universe does not contain the pipelines which actually solved the corpus.

The codec vocabulary is *derived*, not asserted: a test reads the `codec`-family nodes
appearing between consecutive layer-forming steps in the reproduced conformance chains
and requires set equality with the sweep's vocabulary. Inventing a value or dropping an
observed one fails the build.

---

## 4. How comprehensive is this? Measured against the solved corpus

The honest yardstick is not the dossier's tier model but the shapes the 11 reproduced
corpus chains actually needed.

| reproduced chain | steps | modern layers | skeleton | in domain? |
|---|---|---|---|---|
| rev9 / DES | 2 | 1 | `codec ∘ dec` | ✅ T1 |
| rev10 / RC4 | 2 | 1 | `codec ∘ dec` | ✅ T1 |
| rev5 / RC2 | 2 | 1 | `codec ∘ dec` | ✅ T1 |
| rev10 / Saferplus | 5 | 2 | `codec ∘ dec ∘ codec ∘ codec ∘ dec` | ✅ T3, identity `xf` |
| rev5 / Blowfish | 6 | 2 | `codec ∘ dec ∘ xf ∘ codec ∘ codec ∘ dec` | ✅ T3, composite codec |
| rev6 / Serpent | 4 | 1 | `codec ∘ xf ∘ codec ∘ dec` | ❌ second codec before `dec` |
| rev12 / XTEA | 4 | 1 | `codec ∘ dec ∘ xf ∘ xf` | ❌ two trailing transforms |
| rev9 / Twofish | 6 | 2 | `codec ∘ dec ∘ codec ∘ xf ∘ codec ∘ dec` | ❌ `codec` *precedes* `xf` |
| rev1 / Rijndael-256 | 6 | 2 | `xf ∘ codec ∘ dec ∘ xf ∘ codec ∘ dec` | ❌ opens with `xf` |
| rev8 / Blowfish-compat | 7 | 1 | `xf ∘ codec ∘ xf ∘ codec ∘ codec ∘ dec ∘ codec` | ❌ opens with `xf` |
| rev5 / Loki97 | 8 | **3** | three modern layers | ❌ third layer |

**5 of 11 reproduced shapes are inside the domain. 6 are outside.** The longest chain
the corpus required is 8 steps with 3 modern layers; the deepest this run reaches is 5
steps with 2.

So this run is exhaustive **within its skeletons** and should not be described as
comprehensive over TG4. It is a complete, content-addressed negative over a precisely
bounded region — which is exactly the unit the coverage algebra is built to accumulate.

### The four uncovered classes, ranked by corpus support

1. **A step before the first decryption.** 2 of 11 chains (rev1 Beaufort, rev8 insert).
   The engine has the nodes — `beaufort`, `insert`, `rot`, `substitute`, `group` — but
   the sweep does not enumerate a leading `xf` slot. This is the largest gap and the
   cheapest to close.
2. **A third modern layer.** 1 of 11 (rev5). Cost scales by ×3,696 per layer, so a full
   three-layer tier is ~7.8e13 × 128 variants and is not reachable by brute force. It
   needs the leading-`xf` and inter-layer-shape gaps closed first so that the
   two-layer prefix can be pruned.
3. **Richer inter-layer arrangements.** 2 of 11 (rev6, rev9/Twofish) place a `codec`
   before the `xf`, or use `codec ∘ xf ∘ codec`. These are distinct skeletons, cheap to
   add, and their absence is currently legible rather than silent.
4. **Trailing transforms after the final decryption.** 1 of 11 (rev12: `xf ∘ xf`).
   Cheap; matters because the recorded `rot` shift is an *encryption* shift, so
   decryption applies its inverse.

### Also outside the domain, by design

- **8 of the 19 mcrypt primitives.** Only the 11 confirmed by the corpus are modelled
  (CAST-128, CAST-256, TripleDES, Enigma, Gost, Rijndael-128, Rijndael-192, Wake are
  absent). They would contribute zero coverage anyway under conformance gating.
- **A third IV class.** The dossier models `other`; only `ascii0` and `null` are swept.
- **The wider transform set.** The dossier's `N_XFORM_SMALL = 100` (rot-*n* over the
  alphabet, row and route permutations of the 4-row layout) against 2 values here.
- **Classical layers over modern** — the dossier's T4, bounded at 10,000.
- **Solver nodes.** None are enumerated. Deliberate: a solver's coverage is
  *heuristic*, and an exhaustive sweep returning nothing proves its region empty while
  a solver returning nothing proves only that its heuristic missed within budget.
  Heuristic claims must never subtract from the exhaustive residual.

---

## 5. Oracle: part of the claim, not an implementation detail

Default `printable-0.75`, block-aware. A stricter oracle covers strictly less, so the
oracle id is recorded in every claim and attestation.

Block-awareness is exact, not heuristic: under CFB-8 a wrong IV corrupts exactly
`block_size` bytes and the stream then self-synchronises — verified byte for byte
against rev9. On a 144-byte candidate a correct Rijndael-256 hit therefore presents as
only 112/144 = 77.8% printable, so a fixed 0.80 threshold would silently discard the
answer. The oracle skips the corrupt prefix and scores the tail.

Hits are judged against chance expectation, never by raw count. A pass count at or
below the expected-by-chance figure with short scored regions is an artifact and is
reported as one; a real decryption presents over the full region. Retention ranks by
scored length before score, so a genuine full-length hit cannot be crowded out by
short-window artifacts — a first-N policy had that bug and would have found the answer
and thrown it away.

---

## 6. Integrity properties this run guarantees

- **Deterministic enumeration.** Candidate *i* is a pure function of *i* and the axis
  list (mixed radix), tested as a bijection per tier, so a challenged candidate is
  regenerable without replaying the sweep. That is what makes a spot audit cheap.
- **Outputs discarded.** Every candidate folds into a streaming Merkle commitment and
  is dropped; only above-threshold hits are retained. Resident cost measured at 0.0129
  bytes per candidate.
- **Claim size equals work done.** `size_exact() == candidates evaluated` is asserted
  at runtime, not merely tested. Any shortfall against the plan is printed as an
  explicit `BOUND LOGGED` line with the exact prefix decomposition of what was covered.
  A claim that overstates its own size is the precise failure this project exists to
  prevent.
- **Content-addressed and reproducible.** Equal coverage yields an equal digest. TG4's
  T3 claim digest reproduced exactly across two independent runs on different
  worktrees.
