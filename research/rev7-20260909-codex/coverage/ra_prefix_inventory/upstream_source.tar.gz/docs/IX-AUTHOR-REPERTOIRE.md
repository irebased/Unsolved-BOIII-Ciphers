---
name: ix-author-repertoire
description: The IX puzzle author's validated cipher repertoire and the key quirks proven from solved ciphers
metadata:
  type: project
---

Derived from the 8 solved classical ix ciphers (ix1,2,4,5,6,8,10,11). The author
uses a DIFFERENT classical cipher per puzzle, and keys them with a word:

- ix1 substitution | ix2 caesar_shift | ix5 affine | ix6 caesar
- ix4 beaufort key "Nine" | ix10 porta key "Nine" | ix11 columnar key "Nine"
- ix8 **hill key "2 15 18 22"**

**Two facts proven by reproducing the in-game images:**
1. Hill: column-vector convention, A=0, key (2 15 18 22) reproduces ix8's
   ciphertext EXACTLY (46/46 chars, image read off `ix_8.webp`).
2. That key has **det = 8 mod 26, gcd(8,26)=2 - it is SINGULAR**. The author
   encrypts with non-invertible matrices, so a standard "invert and decrypt"
   brute force silently skips the entire key class in use. Decryption requires
   enumerating the 2 preimages per digraph.
3. Porta validated against ix10's image (opening AYXATC..., reciprocal).

**Register:** 8 of 9 known plaintexts contain YOU/YOUR; 6 of 9 contain WILL.
Taunts aimed at the player ("The solace you seek will not come without sacrifice").
This prior is what makes a word-segmentation scorer work - see [[ix-cipher-goal-and-method]].

**DECISIVE (found 2026-07-31 from the FULL BO4 corpus, not just IX):** across all
Black Ops 4 maps the author's method counts are playfair 6, ADFGX 5, ADFVGX 5,
affine 2, then one each of Ubchi, Vigenere, double_columnar, hill, porta,
substitution, caesar, caesar_shift, columnar. **PLAYFAIR IS THEIR MOST-USED
METHOD.** And the recorded keys include six EXPLICIT RANDOM 25-letter squares:
GEDZXYFLWPAINVTMSQORCBUHK, OVDAXSRWIPKNUTCLMZBGFQHYE, OUZXHMTKDCPLFIAESWRNQGYVB,
BXMNIPYOSDRKWTFQALZUHCVEG, HRMPLQWCTVYUZXINAOKFSGEDB, CLASIFEDBGHJKNOPQRTUVWXYZ.

**This author does NOT derive squares from keywords.** Every keyword-square sweep
(millions of keywords over playfair/four-square/bifid) was therefore searching the
wrong space. All six known squares were tested directly against ix3/ix7/ix9 -
no match.

**Consequence:** a random 25-letter square is 83.7 bits. ix7 (n=38) and ix9 (n=30)
carry ~103 and ~81 bits. So if either is Playfair - the author's favourite - it is
information-theoretically UNSOLVABLE from ciphertext alone, which is very likely
why these are the unsolved ones. ix3 (n=41, odd) cannot be Playfair at all, and
every other method in the author's observed repertoire is separately excluded for
it, so ix3 uses something outside their demonstrated toolkit.

**Ciphertexts verified against source images** (ix3 and ix7 character-exact), so
transcription error is ruled out. CT3's odd length 41 is genuine, which excludes
Playfair/Hill/all digraphic ciphers for ix3 without any search.
