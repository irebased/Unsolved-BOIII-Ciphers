# REV7: a rigorous negative over the transcription-repair space

**Result: NULL.** No single-layer mcrypt decrypt of a repaired REV7 produces a
recognisable first layer, over any value of the missing characters. This is the first
exhaustive negative over REV7's repair space, and it is stated below precisely enough
to be entered in the residual and differenced against.

Reproduce with `ra repair`; every figure here is command output, not prose.

---

## 1. The transcription hypothesis, and whether it survives

REV7 (`data/revelations.json`, record `rev7`) is transcribed on a rigid grid. `ra
repair --target rev7 --grid` computes the census:

```
lines            : 16
groups           : 219
display chars    : 1092
group length     : {2: 1, 5: 218}
groups per line  : {10: 1, 13: 1, 14: 14}
```

Two lines break the 14x5 grid, and nothing else does:

| where | what | short by |
|---|---|---|
| line 0, slot 0 (char offset 0) | a 2-character group where every other group is 5 | 3 characters |
| line 11 (char offset 767) | 13 groups where every interior line has 14 | one whole 5-character group |

Line 15 holding only 10 groups is the stream ending, not a defect.

### The hypothesis is confirmed, two independent ways

**Parity.** A hex stream needs an even character count. The recorded 1092 is even, but
each single repair breaks parity and only the joint repair restores it:

```
repair none (as recorded)      1092 chars =  546.0 units  CONSISTENT
repair line0                   1095 chars =  547.5 units  IMPOSSIBLE
repair line11                  1097 chars =  548.5 units  IMPOSSIBLE
repair line0+line11            1100 chars =  550.0 units  CONSISTENT
```

`1100 = 220 x 5 = 15 x 14 + 10` groups `= 550 bytes`, not 546.

**The final line's width — which counts no characters at all.** This is a second,
independent confirmation, and it is the one that kills the serious alternative.

The serious alternative is that the leading `83` is *legitimate*: a stream chunked into
fives **from the right** leaves the first group short and every other group full, which
is exactly what REV7 shows, with nothing missing. `1092 = 218*5 + 2`, so on character
counts alone that reading is self-consistent and cannot be waved away.

It dies on the layout. Right-aligned chunking is a *re-chunk* of the surviving text, so
laying its 219 groups out fourteen to a row ends with a row of **nine**. A row-faithful
transcription of a 220-slot grid that dropped one group from row 11 ends with a row of
**ten**, and leaves every other row untouched. REV7's last line holds **ten**, and rows
0–10 and 12–14 all hold exactly 14. The recorded shape is the second one, line for
line.

So the grid reconstruction stands: **REV7's ciphertext is 8 hex characters short, in
the two places named, and the true stream is 550 bytes.** Pinned by
`repair::tests::rev7_grid_arithmetic_is_what_the_hypothesis_needs` and
`repair::tests::the_right_aligned_alternative_is_refuted_two_independent_ways`.

Base rate supports it: of four hex-transcribed Revelations ciphers, rev2 needs a
character removed, and rev8 needs one inserted *plus* carries a second, undocumented
corrupted byte.

---

## 2. Why the search is cheap: sequence, not product

The naive joint space is `16^5 x (14 x 16^5) = 1.54e13` transcription variants. It does
not have to be paid, for two reasons.

**Sequencing.** Lines 0–10 hold 767 recorded characters. Repairing gap 1 (+3) makes
that 770 = **exactly 385 whole bytes**, and gap 2 begins at character 770. So repairing
gap 1 alone byte-aligns bytes `[0, 385)` *regardless of gap 2*. Scoring only that
prefix makes the window **completely independent of the entire gap-2 space**.

384 rather than 385 bytes are scored, because 384 is a whole number of blocks for every
block size in the vocabulary (1, 8, 16, 32) — so ECB and CBC candidates are not
penalised by a trailing partial block that `mdecrypt_generic` leaves undecrypted.

**The bounded-prefix theorem.** Whatever REV7's first 5-character group turns out to be,
it is followed by `B57B2...`, so only the first **three bytes** of the stream can differ
across all `16^5` values of that group. Every mcrypt mode confines the resulting
plaintext damage to a bounded prefix: ECB to block 0, CBC and nCFB to blocks 0–1, CFB-8
to `3 + block_size` bytes, and the output-feedback modes to the three altered bytes,
since their keystream does not depend on the ciphertext at all. Measured on real REV7
bytes across 5 primitives x 7 modes, the worst case is **64 of 384 bytes**
(`repair::tests::a_wrong_gap1_value_perturbs_only_a_bounded_prefix_in_every_mode`).

Two consequences, and they point in opposite directions — both are reported:

- **The negative is much broader than the space enumerated.** A first layer scoring `s`
  under the *true* repair scores at least `s - 64/384 = s - 0.167` under **any** of the
  `16^5` values. So the negative covers every gap-1 value for any layer whose true-value
  score would be >= `0.75 + 0.167 = 0.917`. rev12's genuine layer scores **0.985**, so a
  real layer of that quality is covered at every gap-1 value.
- **The enumeration buys little discriminating power.** The 45.4e6 candidates are
  ~3696 effectively-independent trials with a bounded perturbation, not 45.4e6
  independent draws. That is why no false-positive inflation appears at this window
  size, and it is stated so the space figure is not read as a trial count.

---

## 3. Positive control: the method works, on corpus bytes

Before believing any negative, the search has to be shown capable of finding a layer
that is there. rev12 is the corpus's only cipher whose first layer is a bare mcrypt
decrypt, which makes it the one usable vector.

| condition | best score | hits |
|---|---|---|
| rev12 intact, full axes | **0.9852** (class `text`, `xtea/cfb key=Zombies`) | 4 |
| rev12 with its first 3 hex characters deleted | 0.4641 | **0** |
| the same, with 3 unknowns re-enumerated at the deletion site | 0.9852 | **4096** |

Read the middle row: deleting three hex characters nibble-shifts the stream from byte
zero and the layer becomes **invisible**. That is precisely the premise of the REV7
hypothesis, demonstrated rather than assumed.

Read the last row: **all 4096** repair values recover the layer, not only the true one —
the bounded-prefix theorem in action. The true value (`452`) is uniquely maximal, so the
search still pins the gap once the layer is found.

Pinned by `repair::tests::a_deleted_gap_is_recoverable_and_the_layer_survives_a_wrong_gap_value`.

The separation is what matters: a real hit sits at **0.98** against a noise ceiling of
**0.47**. There is no ambiguous middle ground to argue over.

---

## 4. Step 1: the search, and its result

```bash
ra repair --target rev7 --site char:0,char:1,char:2 --unknowns 3 --bytes 0..384 \
  --modes ecb,cbc,cfb,ncfb,ofb,nofb,stream \
  --keys Zombies,ZOMBIES,zombies,TheGiant,thegiant,TheGiant_b64 \
  --kd natural,null-pad-max,null-pad-next-supported,repeat-pad-max \
  --ivs ascii0,null --xf identity --oracle printable-0.75,encoding-valid
```

The three sites are the three ways three contiguous characters can be lost from a
5-character group holding `83`: `???83`, `8???3`, `83???`.

```
candidates : 45,416,448
merkle root: 9eb19b5c20c8168573d21ea5c3a16e80ce774cf37d87ed50746045ee91c6dd5f
inapplicable: 6,709,248   (a key length the primitive rejects; still committed to)

hits (passed an oracle): 0
best score = 0.4740   (random-byte baseline 0.3711)
```

### Score distribution

```
[0.00, 0.02)       6709248   14.773%     <- inapplicable combinations
[0.28, 0.30)         11462    0.025%
[0.30, 0.32)        920262    2.026%
[0.32, 0.34)       2329000    5.128%
[0.34, 0.36)      12847851   28.289%
[0.36, 0.38)      10010896   22.042%     <- the 0.3711 baseline sits here
[0.38, 0.40)       7956888   17.520%
[0.40, 0.42)       3345758    7.367%
[0.42, 0.44)       1171130    2.579%
[0.44, 0.46)         68323    0.150%
[0.46, 0.48)         45630    0.100%
best = 0.4740
```

The distribution is centred on the random-byte expectation of 0.3711 and dies out just
past 0.47. **This is a null result, not a marginal lead.** A real layer would sit at
0.98 (section 3), roughly eleven bucket-widths beyond anything observed. The threshold
was not approached: `P(a random 384-byte window >= 0.75 printable) = 1.67e-51`, giving
`7.6e-44` expected false positives over the whole run, so the oracle had no opportunity
to be satisfied by chance.

The top candidates are all `blowfish-compat/ecb key=TheGiant`, all scoring exactly
0.4740, and their previews are **byte-identical after the first block** — the
bounded-prefix theorem showing up in the output. The 0.474 ceiling is a property of the
3696 cipher settings, not of any repair value.

Because step 1 produced no hit, **step 2 was not run.** Enumerating gap 2 without a
layer to test it against would search nothing.

---

## 5. Controls

| control | space | best score | hits |
|---|---|---|---|
| **null** — no repair, whole recorded 546-byte stream, `xf=identity,reverse` | 7,392 | 0.4505 | **0** |
| **null** — no repair, same 384-byte window | 3,696 | 0.4402 | **0** |
| **wrong-gap** — 3 unknowns at `char:7` and `char:547` | 30,277,632 | **0.4740** | **0** |
| **parity** — 3 unknowns at `char:760,762,764`, window kept in *recorded* parity | 45,416,448 | 0.4538 | **0** |
| **step 1** — the hypothesis | 45,416,448 | **0.4740** | **0** |

Every control and the hypothesis itself land in the band **0.440–0.474**. The
hypothesised site beats the matched-size parity control by **0.020**, against a
**0.51** gap to what a real layer looks like. There is nothing here.

**The null control found nothing.** Had it found something, the repair hypothesis would
have been unnecessary and that would have been the headline; it did not.

**The wrong-gap control reaches exactly the same ceiling, 0.4740, as the hypothesis.**
The hypothesised site is statistically indistinguishable from a wrong one. This is the
control doing its job: 0.4740 is the noise ceiling of a 3696-setting cipher sweep at
this window length, and attaching any significance to it would be reading noise.

A caveat on the wrong-gap control, found while running it and worth recording because it
constrains what such a control *can* show: inserting three characters anywhere inside
line 0 yields the **same** byte stream from byte 5 onward, since both readings shift the
tail by the same three nibbles. So `char:7` is not "wrong" in a way that changes the
tail's alignment. The control that does vary alignment is the parity control, which
holds the window in the recorded (even) parity at matched space size — and the null
controls, which are the recorded parity at small space size.

---

## 6. What is eliminated, exactly

**Eliminated.** For the skeleton `<hexdecode o dec>` — one mcrypt decryption applied
directly to the hex-decoded bytes — over

- transcription: **all** `16^5 = 1,048,576` values of REV7's missing first group, and
  **all** `14 x 16^5 = 14,680,064` positions-and-values of the missing line-11 group,
- primitive: all 11 corpus-confirmed primitives,
- mode: all 7 mcrypt modes (`ecb, cbc, cfb, ncfb, ofb, nofb, stream`),
- key: `Zombies, ZOMBIES, zombies, TheGiant, thegiant, TheGiant_b64`,
- key derivation: all 4 policies,
- IV: `ascii0, null`,

**no combination yields >= 75% printable output or a clean intermediate encoding over
bytes `[0, 384)`.** That is `1.54e13` transcription variants x 3696 cipher settings =
**5.69e16** points.

The three parts of that claim rest on different footings, and the difference matters:

1. **Exhaustive enumeration** — 45,416,448 candidates actually executed and committed to
   (Merkle root `9eb19b5c…`). This covers 12,288 of the gap-1 values at threshold 0.75
   unconditionally.
2. **Gap 2, exactly and unconditionally** — the window `[0, 384)` lies entirely before
   gap 2, so it is independent of that space by construction. No assumption.
3. **The remaining 1,036,288 gap-1 values** — covered by the bounded-prefix theorem, and
   therefore **conditional on the threshold margin**: eliminated for any layer whose
   score under its true repair value would be >= **0.917**. A hypothetical layer scoring
   between 0.75 and 0.917 at its true value is *not* eliminated at those values. rev12's
   real layer scores 0.985, so this is a wide margin in practice, but it is a condition
   and is recorded as one.

**Not eliminated.** Stated so it is not mistaken for coverage:

- **Any skeleton with a step before the first decryption.** rev1 opens with a Beaufort
  layer; rev8 opens with `insert | hexdecode | reverse | hex_to_base64`. Nothing here
  touches those. This is the largest uncovered region and the obvious next direction.
- **`xf=reverse`, specifically and unavoidably.** Reversing the full stream puts its
  tail at the front, and under the sequential decomposition the tail is exactly what is
  still unknown. The prefix trick cannot cover the reverse skeleton — covering it needs
  the joint `16^5 x 14 x 16^5` enumeration, which the sequencing argument was there to
  avoid. `ra repair --xf reverse` over a partial window reverses the *window*, a
  different hypothesis, and the command prints a warning saying so.
- **Repairs of shapes other than "3 contiguous characters lost from the first group".**
  Non-contiguous loss within the group (`8X3YZ`) is not enumerated, though by the
  bounded-prefix theorem it falls under the conditional coverage in point 3 above.
- **Multi-layer pipelines.** Only the first layer was searched, which is the whole point
  of the prefix trick.
- **Keys outside the six-key dossier domain.**

**The standing caveat.** As with every negative in this workspace, it is worth exactly
as much as the conformance of the primitives that produced it. `ra conformance` reports
11 of 11 reproduced end to end, which is what licenses reading this as "the answer is
not in that space" rather than "our software did not find it".

---

## 7. Files

| | |
|---|---|
| `crates/ra-cli/src/repair.rs` | the `ra repair` command and its 18 tests |
| `notes/rev7-step1.log` | step 1, full output |
| `notes/rev7-step1-claim.json` | step 1 as a coverage set with a content digest |
| `notes/rev7-controls.log` | null controls |
| `notes/rev7-wronggap.log` | wrong-gap control |
| `notes/rev7-parity-control.log` | parity control |

## 8. What would change the conclusion

- A first layer that is **not** a bare mcrypt decrypt. Extend the search to skeletons
  with a leading transform — the `Xf` nodes already registered (`beaufort`, `rot`,
  `reverse`, `route4`) are the candidates, and only the byte-level ones are compatible
  with prefix scoring.
- A different reading of the grid. The two anomalies are computed and the alternative
  reading is refuted twice over, but a look at `revelations_7.png` itself would settle
  what the transcription only implies. That evidence is outside this repository.
- A repair of a different *size*. Every claim here is conditioned on the two deficits
  being 3 and 5 characters. The parity argument fixes their **sum** as even; it does not
  by itself fix each one.

---

## 9. The widened re-run (2026-07-31): same null, and the ceiling did not move

The step-1 search above was run with **11 primitives and 4 raw-byte key
derivations**. Both axes have since grown substantially — 16 primitives (adding AES,
3DES, CAST-128, IDEA and Salsa20) and 15 key derivations (adding the md5/sha1/sha256
raw-digest, lower/upper hex-string, and `EVP_BytesToKey` families). The search was
re-run over the widened space.

```
candidates  : 247,726,080          (5.5x the original 45,416,448)
cipher space: 16 prim x 7 mode x 6 key x 15 kd x 2 iv x 1 xf
merkle root : 44a357fabbe960a680fabf27755cc41760b7453a56fef0badce48d537f48f02d
inapplicable: 40,402,944  (a key length the primitive rejects; still committed to)
hits        : 0
best score  : 0.4740   (+0.1029 vs the 0.3711 random-byte baseline)
```

Score distribution over the 384-byte window:

```
[0.00, 0.02)  40402944  16.310%   <- inapplicable combinations
[0.26, 0.28)     29026   0.012%
[0.28, 0.30)    631562   0.255%
[0.30, 0.32)   4465866   1.803%
[0.32, 0.34)  18813414   7.594%
[0.34, 0.36)  48406748  19.540%
[0.36, 0.38)  60690140  24.499%   <- the 0.3711 baseline sits here
[0.38, 0.40)  49753382  20.084%
[0.40, 0.42)  18750606   7.569%
[0.42, 0.44)   5092695   2.056%
[0.44, 0.46)    594829   0.240%
[0.46, 0.48)     94868   0.038%
best = 0.4740
```

### The result worth having is that the ceiling is *identical*

The original 45.4M search topped out at **0.4740**, on `blowfish-compat/ecb
key=TheGiant`. So does this one — same score, same primitive, same mode, same key,
and the previews are again byte-identical after the first block. Multiplying the
cipher space by 5.5, across five new primitives and eleven new key-derivation
policies, moved the best score **not at all**.

That converts an observation into a measurement. **0.4740 is the noise ceiling of a
printable-ratio oracle over a 384-byte window for this ciphertext**, and it is a
property of the scoring, not of any cipher setting, repair value, or key derivation.
It was already suspected — the wrong-gap control reached exactly 0.4740 too — and the
widened re-run confirms it from a third independent direction. Attaching significance
to a 0.47 would be reading noise, whichever axis produced it.

For contrast, a genuine first layer scores **0.985** (rev12, §3). The gap between the
observed ceiling and a real layer is **0.51**, roughly eleven bucket-widths. There is
no ambiguous middle ground here and there never was.

### What this adds to §6's elimination

Everything in §6 still stands, with the primitive axis extended from 11 to 16 and the
key-derivation axis from 4 to 15. Under conformance's two-class model the five added
primitives carry coverage as follows: AES, 3DES, CAST-128 and Salsa20 are
**VectorProven** (validated against FIPS-197 C.1, libmcrypt's own self-tests, RFC 2144
Appendix B.1, and Bernstein's reference vectors respectively); **IDEA remains unproven
under either class and therefore contributes zero**, so its share of this space is
enumerated and committed to but not claimed.

What is still **not** eliminated is unchanged and worth restating: any skeleton with a
step *before* the first decryption, `xf=reverse` specifically (the sequential prefix
decomposition cannot cover it), non-contiguous loss within the first group,
multi-layer pipelines, and keys outside the dossier domain.
