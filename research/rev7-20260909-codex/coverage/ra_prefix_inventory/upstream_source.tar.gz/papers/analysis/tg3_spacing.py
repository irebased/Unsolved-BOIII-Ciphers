#!/usr/bin/env python3
"""TG3: can the recorded 'K-wheel = 9, S-wheel = 4' be wheel LENGTHS after all?

Under the letters-only alignment the keystream period is 28, and lcm(9,4)=36,
so (9,4) cannot be lengths of two wheels that both advance once per output
symbol.  But a teleprinter cipher encodes spaces too (ITA2 '9'), and if the
tool consumed the spaced message while the published ciphertext shows only the
48 letter positions, the wheels would have advanced 57 times, not 48 -- and the
period-28 observation would be an artefact of the sampling.

This script tests every such alignment hypothesis.  Stdlib only.
"""
import itertools

ITA2 = "/T3O9HNM4LRGIPCVEZDBSYFXAWJ+UQK-"
CODE = {c: i for i, c in enumerate(ITA2)}

CT = "NMFU3DNILVAXTPPH9AYHRXUM3PDBVMHN/CANVGPYS+3HGQKH"
RAW = "When finished we will return to the house and the infinite"


def fits(idx, vals, m, n):
    """Does val[k] = K[idx[k] mod m] ^ S[idx[k] mod n] have a solution?"""
    K = [None] * m
    S = [None] * n
    obs = {}
    for j, v in zip(idx, vals):
        key = (j % m, j % n)
        if key in obs and obs[key] != v:
            return None          # direct contradiction
        obs[key] = v
    while True:
        seeds = [(a, b) for (a, b) in obs if K[a] is None and S[b] is None]
        if seeds:
            a, b = seeds[0]
            S[b], K[a] = 0, obs[(a, b)]
        ch = True
        while ch:
            ch = False
            for (a, b), v in obs.items():
                if K[a] is None and S[b] is not None:
                    K[a], ch = v ^ S[b], True
                elif S[b] is None and K[a] is not None:
                    S[b], ch = v ^ K[a], True
        if not seeds:
            break
    K = [0 if x is None else x for x in K]
    S = [0 if x is None else x for x in S]
    if all(v == K[j % m] ^ S[j % n] for j, v in zip(idx, vals)):
        return K, S
    return None


def alignment(spaced, offset):
    """Indices of the letter positions in `spaced`, shifted by `offset`."""
    return [i + offset for i, c in enumerate(spaced) if c != "9"]


def main():
    letters = "".join(c for c in RAW.upper() if c.isalpha())
    spaced = RAW.upper().replace(" ", "9")
    print(f"letters only     : {len(letters)} symbols")
    print(f"spaces as ITA2 '9': {len(spaced)} symbols "
          f"({spaced.count('9')} spaces)")
    print()

    cases = {
        "letters only (wheels advance 48 times)":
            (list(range(len(letters))), letters),
        "spaced message (wheels advance 57 times, spaces not published)":
            (alignment(spaced, 0), letters),
    }
    # also allow a leading offset, in case the tool prefixed a shift character
    for off in range(1, 4):
        cases[f"spaced message, {off}-symbol lead-in"] = \
            (alignment(spaced, off), letters)
        cases[f"letters only, {off}-symbol lead-in"] = \
            ([i + off for i in range(len(letters))], letters)

    for label, (idx, pt) in cases.items():
        vals = [CODE[c] ^ CODE[p] for c, p in zip(CT, pt)]
        print(f"--- {label}")
        hits = []
        for m, n in itertools.product(range(2, 21), repeat=2):
            if m >= n:
                continue
            r = fits(idx, vals, m, n)
            if r:
                hits.append((m, n))
        # report only factorisations where BOTH wheels are shorter than the
        # span of the message, i.e. genuinely constraining
        real = [(m, n) for m, n in hits if m * n >= max(idx) + 1 or True]
        print(f"    (9,4) as wheel lengths : "
              f"{'FITS' if fits(idx, vals, 4, 9) else 'does NOT fit'}")
        print(f"    all fitting (m<n<=20)  : {hits[:12]}"
              f"{' ...' if len(hits) > 12 else ''}")
        print()


if __name__ == "__main__":
    main()
