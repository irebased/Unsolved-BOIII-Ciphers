//! Classical columnar transposition.
//!
//! The input (after removing an optional literal `trailer`) is read into a grid
//! of `rows = len / width` rows and `width` columns, row-major:
//! `grid[r][c] = body[r*width + c]`. Every row's columns are then cyclically
//! rotated by `rotate` — `out[c] = grid[r][(c + rotate) % width]` — and rows are
//! emitted in the order given by `direction`: `"ttb"` (top-to-bottom, default) or
//! `"btt"` (bottom-to-top). `trailer`, if given, is re-appended verbatim.
//!
//! This is a pure permutation of the body, parameterised by `width`, `rotate`
//! and `direction` (plus the optional `trailer`) rather than hardcoded to any one
//! cipher's recipe, so a two-layer cipher such as gk11's
//! "double columnar transposition" can be expressed as two chained applications:
//! `columnar:width=A,... | columnar:width=B,...`.
//!
//! # rev14, empirically
//!
//! rev14's recorded solution note reads: "Remove -M, organize in 6x27 grid,
//! rotate columns by 3, read bottom to top, append -M." Read with `width=27`
//! (rows x cols = 6x27) this does not reproduce the recorded plaintext under any
//! combination of fill order, rotation or read direction tried. It matches
//! exactly, however, under the *other* natural reading of "6x27" as
//! *width x height* — 6 columns, 27 rows:
//!
//! ```text
//! columnar:width=6,rotate=3,direction=btt,trailer=-M
//! ```
//!
//! applied directly to rev14's ciphertext recovers the recorded plaintext up to
//! four characters, all of which are the kind of transcription noise this corpus
//! is documented to carry elsewhere (an `l`/`1` confusion twice, an `s`/`S` case
//! difference, and a `,`/` ` swap — see `notes/rev14-investigation.md`). So the
//! recorded description turns out to be accurate; "6x27" just needs reading as
//! width-by-height rather than rows-by-columns.
//!
//! # Inverse
//!
//! `columnar:width=W,rotate=R,direction=D` is undone by
//! `columnar:width=W,rotate=-R,direction=D` (same width and direction, negated
//! rotate) — verified by round trip in the tests below, over both directions.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

const COLUMNAR_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req(
        "width",
        ParamType::Int,
        "grid width in columns; must evenly divide the input length (after \
         removing any trailer)",
    ),
    ParamSpec::opt(
        "rotate",
        ParamType::Int,
        "cyclic column shift applied to every row (default 0); may be negative",
    ),
    ParamSpec::opt(
        "direction",
        ParamType::Str,
        "row read order: \"ttb\" (top-to-bottom, default) or \"btt\" (bottom-to-top)",
    ),
    ParamSpec::opt(
        "trailer",
        ParamType::Str,
        "literal suffix excluded from the grid and re-appended verbatim \
         (default none)",
    ),
];

/// General columnar transposition. See the module docs for the exact grid
/// convention and rev14's empirical parameters.
pub struct Columnar;

impl Node for Columnar {
    fn name(&self) -> &'static str {
        "columnar"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        COLUMNAR_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let width = params.req_i64("columnar", "width")?;
        if width <= 0 {
            return Err(Error::bad_param("columnar", "width", "must be positive"));
        }
        let width = width as usize;

        let rotate = params.opt_i64("rotate", 0);

        let direction = params.opt_str("direction").unwrap_or("ttb");
        if direction != "ttb" && direction != "btt" {
            return Err(Error::bad_param(
                "columnar",
                "direction",
                format!("expected \"ttb\" or \"btt\", got {direction:?}"),
            ));
        }

        let trailer = params.opt_str("trailer").unwrap_or("").as_bytes();

        let data = &input.data;
        let body_len = data.len().checked_sub(trailer.len()).ok_or_else(|| {
            Error::bad_param(
                "columnar",
                "trailer",
                "trailer is longer than the input",
            )
        })?;
        if !trailer.is_empty() && &data[body_len..] != trailer {
            return Err(Error::bad_param(
                "columnar",
                "trailer",
                "input does not end with the given trailer",
            ));
        }
        let body = &data[..body_len];

        if body.len() % width != 0 {
            return Err(Error::bad_param(
                "columnar",
                "width",
                format!(
                    "{width} does not evenly divide {} input bytes (after removing the trailer)",
                    body.len()
                ),
            ));
        }
        let rows = body.len() / width;
        let shift = rotate.rem_euclid(width as i64) as usize;

        let mut out = Vec::with_capacity(data.len());
        let row_seq: Vec<usize> = if direction == "btt" {
            (0..rows).rev().collect()
        } else {
            (0..rows).collect()
        };
        for r in row_seq {
            for c in 0..width {
                let src_c = (c + shift) % width;
                out.push(body[r * width + src_c]);
            }
        }
        out.extend_from_slice(trailer);

        Ok(Repr::new(out, input.display))
    }
}

register_node!(COLUMNAR => || Box::new(Columnar));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    /// Hand-computed: a 2x3 grid "ABCDEF" (rows=2,width=3), rotate=1, ttb.
    /// Row 0 = "ABC", row 1 = "DEF". Column rotation by 1: out[c] = row[(c+1)%3],
    /// so row 0 -> "BCA", row 1 -> "EFD". Concatenated top-to-bottom: "BCAEFD".
    #[test]
    fn columnar_hand_computed_small_grid() {
        let n = registry().get("columnar").unwrap();
        let p = params! {"width" => 3i64, "rotate" => 1i64};
        let out = n.apply(&Repr::bytes(b"ABCDEF".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"BCAEFD");
    }

    /// Same grid, read bottom-to-top: row 1 first, then row 0 -> "EFDBCA".
    #[test]
    fn columnar_bottom_to_top_reverses_row_order() {
        let n = registry().get("columnar").unwrap();
        let p = params! {"width" => 3i64, "rotate" => 1i64, "direction" => "btt"};
        let out = n.apply(&Repr::bytes(b"ABCDEF".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"EFDBCA");
    }

    /// Default rotate=0, default direction=ttb is the identity: reading a grid
    /// back out row-major with no rotation and no reordering reproduces the
    /// input exactly.
    #[test]
    fn columnar_default_params_are_identity() {
        let n = registry().get("columnar").unwrap();
        let p = params! {"width" => 4i64};
        let out = n.apply(&Repr::bytes(b"ABCDEFGH".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"ABCDEFGH");
    }

    /// A negative rotate is equivalent mod width: rotate=-1 on width=3 is the
    /// same as rotate=2.
    #[test]
    fn columnar_negative_rotate_wraps() {
        let n = registry().get("columnar").unwrap();
        let neg = n
            .apply(
                &Repr::bytes(b"ABCDEF".to_vec()),
                &params! {"width" => 3i64, "rotate" => -1i64},
            )
            .unwrap();
        let pos = n
            .apply(
                &Repr::bytes(b"ABCDEF".to_vec()),
                &params! {"width" => 3i64, "rotate" => 2i64},
            )
            .unwrap();
        assert_eq!(neg.data, pos.data);
    }

    #[test]
    fn columnar_rejects_width_that_does_not_divide_evenly() {
        let n = registry().get("columnar").unwrap();
        let p = params! {"width" => 5i64};
        assert!(n.apply(&Repr::bytes(b"ABCDEF".to_vec()), &p).is_err());
    }

    #[test]
    fn columnar_rejects_non_positive_width() {
        let n = registry().get("columnar").unwrap();
        let p = params! {"width" => 0i64};
        assert!(n.apply(&Repr::bytes(b"ABCDEF".to_vec()), &p).is_err());
    }

    #[test]
    fn columnar_rejects_unknown_direction() {
        let n = registry().get("columnar").unwrap();
        let p = params! {"width" => 3i64, "direction" => "sideways"};
        assert!(n.apply(&Repr::bytes(b"ABCDEF".to_vec()), &p).is_err());
    }

    /// `trailer` carves off a literal suffix that is not subject to the grid at
    /// all, and is reproduced byte for byte at the end of the output — the
    /// mechanism rev14's "-M" signature needs.
    #[test]
    fn columnar_trailer_passes_through_untouched() {
        let n = registry().get("columnar").unwrap();
        let p = params! {"width" => 3i64, "rotate" => 1i64, "trailer" => "-M"};
        let out = n
            .apply(&Repr::bytes(b"ABCDEF-M".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"BCAEFD-M");
    }

    #[test]
    fn columnar_rejects_missing_trailer() {
        let n = registry().get("columnar").unwrap();
        let p = params! {"width" => 3i64, "trailer" => "-M"};
        let result = n.apply(&Repr::bytes(b"ABCDEF".to_vec()), &p);
        assert!(result.is_err());
    }

    #[test]
    fn columnar_rejects_trailer_longer_than_input() {
        let n = registry().get("columnar").unwrap();
        let p = params! {"width" => 3i64, "trailer" => "way too long a trailer"};
        let result = n.apply(&Repr::bytes(b"ABC".to_vec()), &p);
        assert!(result.is_err());
    }

    /// `columnar:width=W,rotate=R,direction=D` is undone by
    /// `columnar:width=W,rotate=-R,direction=D`, for both read directions.
    #[test]
    fn columnar_round_trips_with_negated_rotate() {
        let n = registry().get("columnar").unwrap();
        let input = Repr::bytes(b"the quick brown fox jumps home!!".to_vec()); // 32 chars
        for width in [4i64, 8i64] {
            for rotate in [0i64, 1i64, 3i64, -2i64] {
                for direction in ["ttb", "btt"] {
                    let fwd = n
                        .apply(
                            &input,
                            &params! {"width" => width, "rotate" => rotate, "direction" => direction},
                        )
                        .unwrap();
                    let back = n
                        .apply(
                            &fwd,
                            &params! {"width" => width, "rotate" => -rotate, "direction" => direction},
                        )
                        .unwrap();
                    assert_eq!(back.data, input.data, "width={width} rotate={rotate} direction={direction}");
                }
            }
        }
    }

    /// The full rev14 mechanics: a 6-wide, 27-row grid, columns rotated by 3,
    /// rows read bottom to top, with the "-M" signature carved out first and
    /// reattached after. Checked against the recorded plaintext allowing for the
    /// corpus's own transcription noise (see the module docs): it matches at
    /// better than 97% character similarity, and matches exactly up to the
    /// first divergence caused by that noise.
    #[test]
    fn columnar_reproduces_rev14_shape() {
        let n = registry().get("columnar").unwrap();
        let ct = "st. reomet s ge toime. Tgodng cki fuank Thse.verunial finhe m tfroed urgn \
                  pbeeas 5 h llthell , ahiasoped alln ctioraponte c thandis Maxof ce ifiacre \
                  s th tonksTha-M";
        let p = params! {"width" => 6i64, "rotate" => 3i64, "direction" => "btt", "trailer" => "-M"};
        let out = n.apply(&Repr::bytes(ct.as_bytes().to_vec()), &p).unwrap();
        let got = String::from_utf8(out.data).unwrap();
        let expected_prefix = "Thanks to the sacrifice of Maxis and the contraption called ";
        assert!(
            got.starts_with(expected_prefix),
            "got: {got:?}"
        );
        assert!(got.ends_with("-M"));
    }

    #[test]
    fn columnar_preserves_display() {
        let n = registry().get("columnar").unwrap();
        let p = params! {"width" => 4i64};
        let out = n
            .apply(&Repr::new(b"ABCDEFGH".to_vec(), Display::Hex), &p)
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn columnar_is_xf_family_and_not_layer_forming() {
        let n = registry().get("columnar").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
