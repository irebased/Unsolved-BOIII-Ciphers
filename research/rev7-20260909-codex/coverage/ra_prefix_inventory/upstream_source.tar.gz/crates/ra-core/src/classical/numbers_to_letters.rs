//! Numbers-to-letters, matching geocachingtoolbox.com's `numbersToLetters`
//! tool exactly.
//!
//! # Ground truth
//!
//! `docs/toolsites/geocachingtoolbox.json`, tool `"Numbers to letters"`
//! (`page_id: "numbersToLetters"`). The site's `setCharValues`/
//! `calculateNumbersToLetters` were run verbatim under Node (a DOM shim stands
//! in for `document.getElementById`) to produce every vector in the test
//! module below.
//!
//! # The eight `method`s
//!
//! The site offers 8 numbering conventions, selected by the `numbersToLettersMethod`
//! dropdown (default `a=1`): four map onto the 26-letter table (`validCharsN`)
//! at different offsets/directions, and four onto 30-letter tables that add
//! German (`validCharsG`: ä ö ü ß) or Swedish (`validCharsSw`: å ä ö) letters
//! after `z`. All eight are exposed as [`Method`] and are exhaustively
//! ground-truthed, not just the default.
//!
//! | method  | table | index -> letter          |
//! |---------|-------|---------------------------|
//! | `a=1`   | N     | `charValues[i+1] = table[i]` (1-indexed)     |
//! | `a=0`   | N     | `charValues[i]   = table[i]` (0-indexed)     |
//! | `a=26`  | N     | `charValues[26-i] = table[i]` (reverse, 1..26) |
//! | `a=25`  | N     | `charValues[25-i] = table[i]` (reverse, 0..25) |
//! | `a=1G`  | G     | `charValues[i+1] = table[i]` (1-indexed, 30 letters) |
//! | `a=0G`  | G     | `charValues[i]   = table[i]` (0-indexed, 30 letters) |
//! | `a=1Sw` | Sw    | `charValues[i+1] = table[i]` (1-indexed, 30 letters) |
//! | `a=0Sw` | Sw    | `charValues[i]   = table[i]` (0-indexed, 30 letters) |
//!
//! # Zero-padding lead
//!
//! **Not a match.** This tool's numbers are plain, unpadded decimal (`"8 5 12
//! 12 15"`), never zero-padded, in either direction — confirmed by running the
//! site's own JS (see `run_n2l.js` ground truth below): no `padStart`,
//! `slice(-N)`, or manual zero-prepend appears anywhere in
//! `calculateNumbersToLetters`. It is not the source of the 3-digit
//! zero-padded tokens the wider investigation is hunting for.
//!
//! # Direction
//!
//! This crate is decrypt-direction: [`NumbersToLetters`] decodes numbers to
//! letters only (the site's default direction, and the only one that is a
//! plausible "ciphertext -> plaintext" step; going letters-to-numbers is not
//! offered by the site at all, so there is nothing to reproduce for the other
//! direction).
//!
//! # Artifacts
//!
//! Writes into `numbersToLettersDiv` via `.innerHTML` (`copy_artifact_risk:
//! "HIGH"`), with one `<br>` per input line — reproduced here as
//! `Trailing::CrLf` default and, for multi-line input, plain `\n` joining
//! decoded lines (this crate's [`crate::classical::toolfmt::Trailing`] models
//! only a single trailing terminator, not interior per-line CRLF, matching
//! every other node in this module — see `toolfmt.rs`). Input is
//! whole-string-trimmed before splitting into lines, matching
//! `input_normalization: ["input_trimmed"]`.

use crate::classical::toolfmt::{
    read_input_norm, read_output_fmt, CaseFold, InputNorm, OutputFmt, Trailing,
};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const NAME: &str = "numbers_to_letters";

const SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "method",
        ParamType::Str,
        "numbering convention: a=1|a=0|a=26|a=25|a=1G|a=0G|a=1Sw|a=0Sw (default a=1, \
         the site's default)",
    ),
    ParamSpec::opt(
        "replace",
        ParamType::Str,
        "how an out-of-range or non-numeric token is rendered: \" \" (a literal \
         space, the site default), \"?\", or \"num\" (pass the token through \
         unchanged)",
    ),
);

const TABLE_N: &[&str] = &[
    "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s",
    "t", "u", "v", "w", "x", "y", "z",
];
/// German table: the 26 base letters plus ä, ö, ü, ß.
const TABLE_G: &[&str] = &[
    "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s",
    "t", "u", "v", "w", "x", "y", "z", "\u{e4}", "\u{f6}", "\u{fc}", "\u{df}",
];
/// Swedish table: the 26 base letters plus å, ä, ö.
const TABLE_SW: &[&str] = &[
    "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s",
    "t", "u", "v", "w", "x", "y", "z", "\u{e5}", "\u{e4}", "\u{f6}",
];

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Method {
    A1,
    A0,
    A26,
    A25,
    A1G,
    A0G,
    A1Sw,
    A0Sw,
}

impl Method {
    fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "a=1" => Method::A1,
            "a=0" => Method::A0,
            "a=26" => Method::A26,
            "a=25" => Method::A25,
            "a=1G" => Method::A1G,
            "a=0G" => Method::A0G,
            "a=1Sw" => Method::A1Sw,
            "a=0Sw" => Method::A0Sw,
            _ => return None,
        })
    }

    /// The `charValues` array the site builds for this method: `charValues[n]`
    /// is the letter for input number `n`, or `None` if `n` is out of range.
    fn value_for(self, n: i64) -> Option<&'static str> {
        let (table, index): (&[&str], i64) = match self {
            Method::A1 => (TABLE_N, n - 1),
            Method::A0 => (TABLE_N, n),
            Method::A26 => (TABLE_N, 26 - n),
            Method::A25 => (TABLE_N, 25 - n),
            Method::A1G => (TABLE_G, n - 1),
            Method::A0G => (TABLE_G, n),
            Method::A1Sw => (TABLE_SW, n - 1),
            Method::A0Sw => (TABLE_SW, n),
        };
        if index < 0 {
            return None;
        }
        table.get(index as usize).copied()
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Replace {
    Space,
    Question,
    Num,
}

impl Replace {
    fn parse(s: &str) -> Option<Self> {
        Some(match s {
            " " => Replace::Space,
            "?" => Replace::Question,
            "num" => Replace::Num,
            _ => return None,
        })
    }
}

/// Decode one line of whitespace-separated number tokens to letters, matching
/// `calculateNumbersToLetters`'s inner loop exactly: each token is
/// `parseInt`'d (non-numeric tokens parse to nothing usable, i.e. behave as
/// out-of-range), looked up in the method's table, and replaced per `replace`
/// when absent.
fn decode_line(line: &[u8], method: Method, replace: Replace) -> Vec<u8> {
    let mut out = Vec::new();
    for token in line.split(|&b| b == b' ') {
        let text = String::from_utf8_lossy(token);
        let n: Option<i64> = js_parse_int(&text);
        let letter = n.and_then(|n| method.value_for(n));
        match letter {
            Some(l) => out.extend_from_slice(l.as_bytes()),
            None => match replace {
                Replace::Space => out.push(b' '),
                Replace::Question => out.push(b'?'),
                Replace::Num => out.extend_from_slice(token),
            },
        }
    }
    out
}

/// `parseInt` on a leading run of ASCII digits (optionally signed), matching
/// JS's `parseInt` closely enough for this tool's inputs: it reads as many
/// leading digits as it can and ignores trailing garbage, returning `None`
/// when there is no valid leading integer at all (JS: `NaN`).
fn js_parse_int(s: &str) -> Option<i64> {
    let s = s.trim_start();
    let bytes = s.as_bytes();
    let mut i = 0;
    let neg = if i < bytes.len() && (bytes[i] == b'+' || bytes[i] == b'-') {
        let n = bytes[i] == b'-';
        i += 1;
        n
    } else {
        false
    };
    let start = i;
    while i < bytes.len() && bytes[i].is_ascii_digit() {
        i += 1;
    }
    if i == start {
        return None;
    }
    let digits: i64 = s[start..i].parse().ok()?;
    Some(if neg { -digits } else { digits })
}

pub struct NumbersToLetters;

impl Node for NumbersToLetters {
    fn name(&self) -> &'static str {
        NAME
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/numbers_to_letters(geocachingtoolbox.com numbersToLetters, decode)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let method = match params.opt_str("method") {
            Some(s) => Method::parse(s).ok_or_else(|| {
                Error::bad_param(
                    NAME,
                    "method",
                    format!(
                        "expected a=1|a=0|a=26|a=25|a=1G|a=0G|a=1Sw|a=0Sw, got {s:?}"
                    ),
                )
            })?,
            None => Method::A1,
        };
        let replace = match params.opt_str("replace") {
            Some(s) => Replace::parse(s).ok_or_else(|| {
                Error::bad_param(NAME, "replace", format!("expected \" \"|\"?\"|\"num\", got {s:?}"))
            })?,
            None => Replace::Space,
        };

        let norm = read_input_norm(
            NAME,
            params,
            InputNorm {
                trim: true, // input_normalization: ["input_trimmed"]
                ..InputNorm::default()
            },
        )?;
        let data = norm.apply(&input.data);

        let mut decoded = Vec::new();
        for (i, line) in data.split(|&b| b == b'\n').enumerate() {
            if i > 0 {
                decoded.push(b'\n');
            }
            decoded.extend(decode_line(line, method, replace));
        }

        let fmt = read_output_fmt(
            NAME,
            params,
            OutputFmt {
                case: CaseFold::Preserve, // table entries are already fixed-case
                grouping: None,
                trailing: Trailing::CrLf, // .innerHTML select-all copy risk (HIGH)
            },
        )?;
        Ok(Repr::new(fmt.apply(&decoded), Display::Bytes))
    }
}

register_node!(NUMBERS_TO_LETTERS => || Box::new(NumbersToLetters));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn node() -> &'static dyn Node {
        registry().get(NAME).unwrap()
    }

    /// Ground truth: `node run_n2l.js` running `setCharValues` /
    /// `calculateNumbersToLetters` from the site's own JS under a DOM shim.
    #[test]
    fn ground_truth_from_site_js() {
        // {"method":"a=1","replace":" ","text":"8 5 12 12 15","out":"hello"}
        assert_eq!(
            decode_line(b"8 5 12 12 15", Method::A1, Replace::Space),
            b"hello"
        );
        // {"method":"a=1","replace":" ","text":"19 15 19","out":"sos"}
        assert_eq!(decode_line(b"19 15 19", Method::A1, Replace::Space), b"sos");
        // {"method":"a=0","replace":" ","text":"7 4 11 11 14","out":"hello"}
        assert_eq!(
            decode_line(b"7 4 11 11 14", Method::A0, Replace::Space),
            b"hello"
        );
        // {"method":"a=26","replace":" ","text":"19 22 15 15 12","out":"hello"}
        assert_eq!(
            decode_line(b"19 22 15 15 12", Method::A26, Replace::Space),
            b"hello"
        );
        // {"method":"a=25","replace":" ","text":"7 4 12 12 15","out":"svnnk"}
        assert_eq!(
            decode_line(b"7 4 12 12 15", Method::A25, Replace::Space),
            b"svnnk"
        );
        // {"method":"a=1","replace":"?","text":"8 5 99 12 15","out":"he?lo"}
        assert_eq!(
            decode_line(b"8 5 99 12 15", Method::A1, Replace::Question),
            b"he?lo"
        );
        // {"method":"a=1","replace":"num","text":"8 5 99 12 15","out":"he99lo"}
        assert_eq!(
            decode_line(b"8 5 99 12 15", Method::A1, Replace::Num),
            b"he99lo"
        );
        // {"method":"a=1G","replace":" ","text":"27 28 29 30","out":"äöüß"}
        assert_eq!(
            decode_line(b"27 28 29 30", Method::A1G, Replace::Space),
            "\u{e4}\u{f6}\u{fc}\u{df}".as_bytes()
        );
        // {"method":"a=1Sw","replace":" ","text":"27 28 29","out":"åäö"}
        assert_eq!(
            decode_line(b"27 28 29", Method::A1Sw, Replace::Space),
            "\u{e5}\u{e4}\u{f6}".as_bytes()
        );
    }

    /// The lead: this tool's decimal-number output/input is never zero-padded
    /// in any direction or method (checked against the site's source: no
    /// `padStart`/`slice(-N)`/leading-zero construction appears anywhere in
    /// `calculateNumbersToLetters`). Recorded here as a standing regression
    /// guard as much as documentation.
    #[test]
    fn zero_padding_lead_does_not_apply_here() {
        // "8" and "08" must decode identically: no fixed-width parsing.
        assert_eq!(
            decode_line(b"8", Method::A1, Replace::Space),
            decode_line(b"08", Method::A1, Replace::Space),
        );
    }

    #[test]
    fn multi_line_input_joins_with_lf() {
        // {"method":"a=1","replace":" ","text":"1 2 3\n4 5 6","out":"abc<br>def"}
        let out = node()
            .apply(
                &Repr::bytes(b"1 2 3\n4 5 6".to_vec()),
                &params! {"trailing" => "none"},
            )
            .unwrap();
        assert_eq!(out.data, b"abc\ndef");
    }

    #[test]
    fn node_decodes_with_default_artifacts() {
        let out = node()
            .apply(&Repr::bytes(b"8 5 12 12 15".to_vec()), &params! {})
            .unwrap();
        assert_eq!(out.data, b"hello\r\n");
    }

    #[test]
    fn malformed_method_is_rejected() {
        let err = node()
            .apply(
                &Repr::bytes(b"1 2 3".to_vec()),
                &params! {"method" => "a=sideways"},
            )
            .unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn out_of_range_number_uses_replace_default_space() {
        let out = decode_line(b"0 1", Method::A1, Replace::Space); // a=1 has no 0
        assert_eq!(out, b" a");
    }

    #[test]
    fn is_xf_family_and_not_layer_forming() {
        let n = node();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
