"""
engine.py  -  Node taxonomy, macros, solver nodes, and layer semantics.

TERMINOLOGY (normative, per the project convention)
---------------------------------------------------
STEP / NODE   A single operation of any granularity: reverse, tolower, base64
              decode, AES decrypt. Steps are the unit of execution and the unit
              of versioning.

LAYER         A transition from one REPRESENTATION to another, achieved by any
              series of steps including at least one decryption or non-standard
              decoding. A layer is a semantic notion, not a syntactic one: it is
              about what the ciphertext has BECOME, combined with the work done
              to get there.

The distinction matters operationally because base64 -> decimal is a step
sequence that achieves nothing (the underlying bytes are unchanged, only their
display), whereas base64 -> a run of digits that carries structure is a
breakthrough. Section "layer detection" below makes that computable rather than
a matter of judgement.
"""
from __future__ import annotations
import base64, binascii, hashlib, math, re, json
from collections import Counter
from typing import List, Dict, Optional, Callable, Iterator

from mcrypt_node import mcrypt_decrypt, CONFIRMED_MAP

# ==========================================================================
# REPRESENTATION
# ==========================================================================
class Repr:
    """A value plus how it is currently being displayed.

    canonical_bytes is the byte sequence the representation DENOTES, recovered by
    normalising the display away. Pure re-encoding (bytes -> hex -> base64)
    changes `data` but leaves canonical_bytes identical, which is exactly why
    such a move is not a layer. This is the mechanism that makes the semantic
    definition of a layer computable.
    """
    def __init__(self, data: bytes, display: str = "bytes"):
        self.data = data
        self.display = display

    @property
    def canonical_bytes(self) -> bytes:
        """Undo the display encoding to recover the denoted bytes."""
        try:
            if self.display == "hex":
                s = re.sub(rb"[^0-9A-Fa-f]", b"", self.data)
                if len(s) % 2: s = s[:-1]
                return binascii.unhexlify(s)
            if self.display == "base64":
                s = re.sub(rb"[^A-Za-z0-9+/=]", b"", self.data)
                s += b"=" * (-len(s) % 4)
                return base64.b64decode(s)
            if self.display == "decimal":
                return bytes(int(t) for t in self.data.split() if t.isdigit())
            if self.display == "octal":
                return bytes(int(t, 8) for t in self.data.split() if t)
        except Exception:
            return self.data
        return self.data

    def __len__(self):
        return len(self.data)

    def __repr__(self):
        return f"Repr({self.display}, {len(self.data)}B, {self.data[:16]!r}...)"


# ==========================================================================
# NODE TAXONOMY
# ==========================================================================
FAMILY_XF = "xf"          # representation-preserving transform
FAMILY_CODEC = "codec"    # encode/decode between displays
FAMILY_DEC = "dec"        # keyed decryption
FAMILY_SOLVER = "solver"  # automated classical solver, TERMINAL ONLY


class Node:
    """One versioned step."""
    family: str = FAMILY_XF
    terminal: bool = False

    def __init__(self, name, version, fn: Callable[[Repr, Dict], Repr],
                 layer_forming=False, params_schema=None):
        self.name = name
        self.version = version
        self.fn = fn
        self.layer_forming = layer_forming
        self.params_schema = params_schema or {}

    @property
    def impl_hash(self) -> str:
        src = f"{self.family}|{self.name}|{self.version}"
        return hashlib.sha256(src.encode()).hexdigest()

    @property
    def node_id(self) -> str:
        return f"{self.family}:{self.name}@{self.version}#{self.impl_hash[:12]}"

    def apply(self, r: Repr, params: Dict) -> Repr:
        return self.fn(r, params)


class XfNode(Node):
    family = FAMILY_XF

class CodecNode(Node):
    family = FAMILY_CODEC

class DecNode(Node):
    """Keyed decryption. Always layer-forming."""
    family = FAMILY_DEC
    def __init__(self, name, version, fn, params_schema=None, block_size=None):
        super().__init__(name, version, fn, layer_forming=True, params_schema=params_schema)
        self.block_size = block_size

class SolverNode(Node):
    """Automated solver for a classical cipher.

    TERMINAL ONLY: a solver emits plaintext, so nothing may follow it.

    IMPORTANT COVERAGE SEMANTIC: a solver searches an implicit space using a
    heuristic (hill climbing, simulated annealing, dictionary). A solver that
    returns nothing does NOT prove the space is empty. Its coverage is
    HEURISTIC, not EXHAUSTIVE, and must be recorded separately in the ledger.
    Mixing the two corrupts the residual, because subtracting a heuristic
    failure from the universe removes ground that was never actually cleared.
    """
    family = FAMILY_SOLVER
    terminal = True
    def __init__(self, name, version, fn, budget_schema=None):
        super().__init__(name, version, fn, layer_forming=True)
        self.budget_schema = budget_schema or {"iterations": int, "restarts": int, "seed": int}


# ==========================================================================
# CONCRETE NODES
# ==========================================================================
def _rev(r, p):        return Repr(r.data[::-1], r.display)
def _lower(r, p):      return Repr(r.data.lower(), r.display)
def _upper(r, p):      return Repr(r.data.upper(), r.display)
def _strip_ws(r, p):   return Repr(re.sub(rb"\s+", b"", r.data), r.display)

def _b64d(r, p):
    s = re.sub(rb"[^A-Za-z0-9+/=]", b"", r.data)
    s += b"=" * (-len(s) % 4)
    return Repr(base64.b64decode(s), "bytes")

def _b64e(r, p):       return Repr(base64.b64encode(r.data), "base64")

def _hexd(r, p):
    s = re.sub(rb"[^0-9A-Fa-f]", b"", r.data)
    if len(s) % 2: s = s[:-1]
    return Repr(binascii.unhexlify(s), "bytes")

def _hexe(r, p):
    up = p.get("uppercase", True)
    h = binascii.hexlify(r.data)
    return Repr(h.upper() if up else h, "hex")

def _grp(r, p):
    n = p.get("n", 5)
    s = re.sub(rb"\s+", b"", r.data)
    return Repr(b" ".join(s[i:i+n] for i in range(0, len(s), n)), r.display)

def _mcrypt_dec(r, p):
    alg = CONFIRMED_MAP.get(p["prim"], p["prim"])
    out = mcrypt_decrypt(r.data, alg, p.get("mode", "cfb"),
                         p["key"].encode() if isinstance(p["key"], str) else p["key"],
                         p.get("iv", b"0" * 32), p.get("keyderiv", "nullpad"))
    return Repr(out, "bytes")

def _rot(r, p):
    n = p.get("n", 13)
    out = bytearray()
    for c in r.data:
        if 65 <= c <= 90:   out.append((c - 65 + n) % 26 + 65)
        elif 97 <= c <= 122: out.append((c - 97 + n) % 26 + 97)
        else: out.append(c)
    return Repr(bytes(out), r.display)


NODES = {
    "reverse":   XfNode("reverse", "1.0.0", _rev),
    "tolower":   XfNode("tolower", "1.0.0", _lower),
    "toupper":   XfNode("toupper", "1.0.0", _upper),
    "stripws":   XfNode("stripws", "1.0.0", _strip_ws),
    "group":     XfNode("group", "1.0.0", _grp),
    "rot":       XfNode("rot", "1.0.0", _rot),
    "b64decode": CodecNode("b64decode", "1.0.0", _b64d),
    "b64encode": CodecNode("b64encode", "1.0.0", _b64e),
    "hexdecode": CodecNode("hexdecode", "1.0.0", _hexd),
    "hexencode": CodecNode("hexencode", "1.0.0", _hexe),
    "mcrypt":    DecNode("mcrypt", "2.5.8", _mcrypt_dec,
                         params_schema={"prim": str, "mode": str, "key": str,
                                        "iv": bytes, "keyderiv": str}),
}


# ==========================================================================
# MACROS: several steps presented as one layer
# ==========================================================================
class Macro:
    """A named, versioned composition of steps that reads as a single layer.

    Macros exist because the semantic unit a human reasons about ("peel the
    mcrypt layer") is usually several steps ("strip whitespace, hex decode,
    mcrypt decrypt, base64 encode"). The macro is the unit of REPORTING; the
    steps remain the unit of VERSIONING, so a defect in any constituent step
    still invalidates surgically per Document 6.
    """
    def __init__(self, name, version, steps: List[tuple]):
        self.name = name
        self.version = version
        self.steps = steps            # [(node_key, params_or_binding), ...]

    @property
    def macro_id(self) -> str:
        inner = "|".join(NODES[k].node_id for k, _ in self.steps)
        return f"macro:{self.name}@{self.version}#{hashlib.sha256(inner.encode()).hexdigest()[:12]}"

    def expand(self) -> List[tuple]:
        return list(self.steps)


MACROS = {
    "mcrypt_layer": Macro("mcrypt_layer", "1.0.0", [
        ("stripws", {}), ("hexdecode", {}), ("mcrypt", "@inject"), ("b64encode", {}),
    ]),
    "rev7_outer": Macro("rev7_outer", "1.0.0", [
        ("stripws", {}), ("reverse", {}), ("hexdecode", {}),
    ]),
}


# ==========================================================================
# LAYER DETECTION: making the semantic definition computable
# ==========================================================================
def shannon(b: bytes) -> float:
    if not b: return 0.0
    c = Counter(b); n = len(b)
    return -sum(v/n * math.log2(v/n) for v in c.values())

def classify_repr(b: bytes) -> str:
    if not b: return "empty"
    s = bytes(b)
    printable = sum(1 for x in s if 32 <= x < 127)
    # text-likeness is checked FIRST, because uppercase prose also matches the
    # base64 character class and would otherwise be mislabelled
    if printable / len(s) > 0.95:
        letters = sum(1 for x in s if 65 <= (x & 0xDF) <= 90)
        spaces = s.count(b" "[0])
        if letters / len(s) > 0.55 and spaces / len(s) > 0.05:
            return "text"
    # most specific class first: octal is a subset of decimal, decimal of hex
    if re.fullmatch(rb"[0-7\s]+", s): return "octal"
    if re.fullmatch(rb"[0-9\s]+", s): return "decimal"
    if re.fullmatch(rb"[0-9A-Fa-f\s]+", s): return "hex"
    if re.fullmatch(rb"[A-Za-z0-9+/=\s]+", s): return "base64ish"
    if printable / len(s) > 0.95: return "printable"
    return "opaque"


def layer_delta(before: Repr, after: Repr, node: Node) -> Dict:
    """Quantify whether a step achieved a genuine representation change.

    The governing insight: pure re-encoding preserves canonical bytes, so byte
    entropy is invariant. base64 -> decimal moves display but not content, and
    registers delta 0. A decryption rewrites the byte sequence and typically
    drops entropy toward structure.
    """
    eb, ea = shannon(before.canonical_bytes), shannon(after.canonical_bytes)
    cb, ca = classify_repr(before.canonical_bytes), classify_repr(after.canonical_bytes)
    bytes_changed = before.canonical_bytes != after.canonical_bytes
    return {
        "entropy_before": round(eb, 4),
        "entropy_after": round(ea, 4),
        "entropy_delta": round(ea - eb, 4),
        "class_before": cb,
        "class_after": ca,
        "class_changed": cb != ca,
        "bytes_changed": bytes_changed,
        "keyed": node.family == FAMILY_DEC,
        "is_layer_boundary": bool(node.layer_forming and bytes_changed),
        "notable": bool(bytes_changed and (abs(ea - eb) > 0.25 or (cb != ca and ca in
                        ("text", "printable", "decimal", "octal")))),
    }


# ==========================================================================
# CHAIN EXECUTION
# ==========================================================================
class Chain:
    def __init__(self, steps: List[tuple]):
        """steps = [(node_key, params), ...]; a SolverNode may appear only last."""
        self.steps = steps
        for i, (k, _) in enumerate(steps):
            if NODES.get(k) and NODES[k].terminal and i != len(steps) - 1:
                raise ValueError(f"terminal node '{k}' must be last")

    @property
    def chain_id(self) -> str:
        canon = json.dumps([[k, _jsonable(p)] for k, p in self.steps],
                           sort_keys=True, separators=(",", ":"))
        ids = "|".join(NODES[k].node_id for k, _ in self.steps if k in NODES)
        return "chain:" + hashlib.sha256((ids + canon).encode()).hexdigest()[:24]

    def run(self, r: Repr, trace=False):
        layers, cur = [], r
        for k, params in self.steps:
            node = NODES[k]
            before = cur
            cur = node.apply(cur, params)
            if trace:
                layers.append((k, layer_delta(before, cur, node)))
        return cur, layers


def _jsonable(p):
    if isinstance(p, dict):
        return {k: (v.hex() if isinstance(v, bytes) else v) for k, v in p.items()}
    return str(p)


# ==========================================================================
# ORACLE: block-aware, exploiting CFB-8 self-synchronisation
# ==========================================================================
def oracle_score(out: bytes, block_size: Optional[int] = None) -> Dict:
    """Score the decryption, skipping the deterministically corrupt prefix.

    Empirically verified with libmcrypt: under CFB-8 a wrong IV corrupts exactly
    `block_size` bytes and the stream then self-synchronises. Skipping that
    prefix eliminates IV-mismatch false negatives AND lowers the false positive
    rate, because the scored region is pure signal.
    """
    skip = block_size or 0
    tail = out[skip:] if len(out) > skip else out
    if not tail:
        return {"score": 0.0, "class": "empty", "skipped": skip}
    printable = sum(1 for x in tail if 32 <= x < 127)
    return {"score": printable / len(tail), "class": classify_repr(tail),
            "skipped": skip, "scored_len": len(tail)}


# ==========================================================================
# STREAMING MERKLE: commit to a scan without storing it
# ==========================================================================
class StreamingMerkle:
    """Build a Merkle root over N leaves in O(log N) memory.

    This reconciles 'do not store results' with the Document 6 audit. The engine
    keeps no outputs; it folds each leaf into a running frontier and retains
    periodic subtree checkpoints so a challenged leaf can be recomputed from a
    small deterministic replay rather than a full re-scan.
    """
    def __init__(self, checkpoint_every=1 << 16):
        self.frontier: List[Optional[bytes]] = []
        self.n = 0
        self.checkpoint_every = checkpoint_every
        self.checkpoints: List[tuple] = []

    @staticmethod
    def _h(b): return hashlib.sha256(b).digest()

    def add(self, leaf: bytes):
        if self.n % self.checkpoint_every == 0:
            self.checkpoints.append((self.n, list(self.frontier)))
        cur, lvl = leaf, 0
        while lvl < len(self.frontier) and self.frontier[lvl] is not None:
            cur = self._h(b"\x01" + self.frontier[lvl] + cur)
            self.frontier[lvl] = None
            lvl += 1
        if lvl == len(self.frontier):
            self.frontier.append(cur)
        else:
            self.frontier[lvl] = cur
        self.n += 1

    def root(self) -> bytes:
        acc = None
        for node in self.frontier:
            if node is None: continue
            acc = node if acc is None else self._h(b"\x01" + node + acc)
        return acc or self._h(b"")

    def memory_bytes(self) -> int:
        return 32 * (len(self.frontier) + sum(len(f) for _, f in self.checkpoints))


if __name__ == "__main__":
    print("=" * 76); print("NODE TAXONOMY"); print("=" * 76)
    for k, n in NODES.items():
        flag = " TERMINAL" if n.terminal else (" layer-forming" if n.layer_forming else "")
        print(f"  {k:<12}{n.node_id}{flag}")

    print("\n" + "=" * 76); print("MACROS (steps versioned individually, reported as one layer)"); print("=" * 76)
    for k, m in MACROS.items():
        print(f"  {m.macro_id}")
        for sk, sp in m.expand():
            print(f"      {NODES[sk].node_id}  params={sp}")

    print("\n" + "=" * 76); print("LAYER DETECTION"); print("=" * 76)
    from mcrypt_node import mcrypt_encrypt
    pt = b"THE BODY OF THE GIANT LIES BENEATH AND THE KEEPER GUARDS THE WAY HOME"
    ct = mcrypt_encrypt(pt, "twofish", "cfb", b"Zombies", b"0" * 16)
    r0 = Repr(base64.b64encode(ct), "base64")

    print("\n  Case 1: pure re-encoding (base64 -> hex). Expect NOT notable.")
    a = NODES["b64decode"].apply(r0, {})
    b = NODES["hexencode"].apply(a, {})
    d = layer_delta(a, b, NODES["hexencode"])
    print(f"     entropy {d['entropy_before']} -> {d['entropy_after']}  delta={d['entropy_delta']}")
    print(f"     class {d['class_before']} -> {d['class_after']}   bytes_changed={d['bytes_changed']}")
    print(f"     is_layer_boundary={d['is_layer_boundary']}   notable={d['notable']}")

    print("\n  Case 2: actual decryption (twofish cfb-8). Expect notable.")
    c = NODES["mcrypt"].apply(a, {"prim": "Twofish", "mode": "cfb", "key": "Zombies",
                                  "iv": b"0" * 16})
    d2 = layer_delta(a, c, NODES["mcrypt"])
    print(f"     entropy {d2['entropy_before']} -> {d2['entropy_after']}  delta={d2['entropy_delta']}")
    print(f"     class {d2['class_before']} -> {d2['class_after']}   bytes_changed={d2['bytes_changed']}")
    print(f"     is_layer_boundary={d2['is_layer_boundary']}   notable={d2['notable']}")
    print(f"     recovered: {c.data[:40]!r}")

    print("\n" + "=" * 76); print("BLOCK-AWARE ORACLE"); print("=" * 76)
    wrong = NODES["mcrypt"].apply(a, {"prim": "Twofish", "mode": "cfb", "key": "Zombies",
                                      "iv": b"\x00" * 16})
    naive = oracle_score(wrong.data, block_size=0)
    aware = oracle_score(wrong.data, block_size=16)
    print(f"  correct IV, naive score      : {oracle_score(c.data,0)['score']:.4f}")
    print(f"  WRONG IV, naive score        : {naive['score']:.4f}  class={naive['class']}")
    print(f"  WRONG IV, block-aware (skip16): {aware['score']:.4f}  class={aware['class']}")
    print("  -> a wrong-IV hit is still recognised, because the tail self-synchronises.")
    print("     A naive fixed threshold would have discarded it.")

    print("\n" + "=" * 76); print("STREAMING MERKLE (no results retained)"); print("=" * 76)
    sm = StreamingMerkle(checkpoint_every=1 << 12)
    N = 200_000
    for i in range(N):
        sm.add(hashlib.sha256(f"cand{i}".encode()).digest())
    print(f"  leaves committed : {sm.n:,}")
    print(f"  root             : {sm.root().hex()[:32]}...")
    print(f"  resident memory  : {sm.memory_bytes():,} bytes for a {N:,}-candidate scan")
    print(f"  per-leaf storage : {sm.memory_bytes()/N:.4f} bytes")
    print("  -> outputs are discarded; only hits above threshold are written to local disk.")
