//! XTEA (32 rounds, 64-bit block, 128-bit key), big-endian word order.
//!
//! # Conformance status: PASS, against rev12
//!
//! Textbook XTEA, and it reproduces rev12 end to end. The full chain
//!
//! ```text
//! hexdecode -> xtea/cfb (key "Zombies", IV ASCII '0' x16, null-pad-max) -> reverse -> rot
//! ```
//!
//! recovers rev12's recorded plaintext exactly ("Now that the many worlds are
//! one, ..."). See `tests/corpus.rs`. Because this is a *known-plaintext* vector
//! rather than a shape heuristic, it simultaneously pins four separate things:
//!
//! - the round function and big-endian word order used here,
//! - CFB-8 as the meaning of mcrypt's `cfb`,
//! - the ASCII-zero IV, and
//! - [`KeyDerivation::NullPadMax`](crate::keyderiv::KeyDerivation::NullPadMax) as
//!   the key-derivation policy (a 7-byte passphrase null-padded to XTEA's 16-byte
//!   key size). Repeat-padding is ruled out.
//!
//! Two notes on the corpus record, both of which cost real time to rediscover:
//!
//! - The recorded `rot` shift is the **encryption** shift. Decryption applies its
//!   inverse, so rev12's documented "shift 6" is a ROT-20 on the way out.
//! - rev12's recorded plaintext is *not* byte-exact: it is 207 UTF-8 bytes against
//!   a 211-byte ciphertext, because the transcription dropped three leading
//!   newlines and rendered a byte as a multi-byte en-dash. Any conformance check
//!   that demands exact equality against stored plaintexts will produce false
//!   failures across the corpus; compare on a normalised substring instead.

use crate::prim::BlockPrim;

const DELTA: u32 = 0x9E37_79B9;
const ROUNDS: u32 = 32;

pub struct Xtea {
    k: [u32; 4],
}

impl Xtea {
    /// `key` must be exactly 16 bytes.
    pub fn new(key: &[u8]) -> Option<Self> {
        if key.len() != 16 {
            return None;
        }
        let mut k = [0u32; 4];
        for (i, w) in k.iter_mut().enumerate() {
            *w = u32::from_be_bytes([key[4 * i], key[4 * i + 1], key[4 * i + 2], key[4 * i + 3]]);
        }
        Some(Self { k })
    }
}

impl BlockPrim for Xtea {
    fn block_size(&self) -> usize {
        8
    }

    fn encrypt_block(&self, block: &mut [u8]) {
        let mut v0 = u32::from_be_bytes([block[0], block[1], block[2], block[3]]);
        let mut v1 = u32::from_be_bytes([block[4], block[5], block[6], block[7]]);
        let mut sum = 0u32;
        for _ in 0..ROUNDS {
            v0 = v0.wrapping_add(
                (((v1 << 4) ^ (v1 >> 5)).wrapping_add(v1))
                    ^ sum.wrapping_add(self.k[(sum & 3) as usize]),
            );
            sum = sum.wrapping_add(DELTA);
            v1 = v1.wrapping_add(
                (((v0 << 4) ^ (v0 >> 5)).wrapping_add(v0))
                    ^ sum.wrapping_add(self.k[((sum >> 11) & 3) as usize]),
            );
        }
        block[..4].copy_from_slice(&v0.to_be_bytes());
        block[4..].copy_from_slice(&v1.to_be_bytes());
    }

    fn decrypt_block(&self, block: &mut [u8]) {
        let mut v0 = u32::from_be_bytes([block[0], block[1], block[2], block[3]]);
        let mut v1 = u32::from_be_bytes([block[4], block[5], block[6], block[7]]);
        let mut sum = DELTA.wrapping_mul(ROUNDS);
        for _ in 0..ROUNDS {
            v1 = v1.wrapping_sub(
                (((v0 << 4) ^ (v0 >> 5)).wrapping_add(v0))
                    ^ sum.wrapping_add(self.k[((sum >> 11) & 3) as usize]),
            );
            sum = sum.wrapping_sub(DELTA);
            v0 = v0.wrapping_sub(
                (((v1 << 4) ^ (v1 >> 5)).wrapping_add(v1))
                    ^ sum.wrapping_add(self.k[(sum & 3) as usize]),
            );
        }
        block[..4].copy_from_slice(&v0.to_be_bytes());
        block[4..].copy_from_slice(&v1.to_be_bytes());
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn round_trips() {
        let x = Xtea::new(&[0u8; 16]).unwrap();
        let pt = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08];
        let mut b = pt;
        x.encrypt_block(&mut b);
        assert_ne!(b, pt);
        x.decrypt_block(&mut b);
        assert_eq!(b, pt);
    }

    /// All-zero key and block is the one XTEA vector that is unambiguous across
    /// references, and it pins the round function and word order.
    #[test]
    fn all_zero_vector() {
        let x = Xtea::new(&[0u8; 16]).unwrap();
        let mut b = [0u8; 8];
        x.encrypt_block(&mut b);
        assert_eq!(hex::encode(b), "dee9d4d8f7131ed9");
    }

    #[test]
    fn rejects_wrong_key_length() {
        assert!(Xtea::new(b"Zombies").is_none());
        assert!(Xtea::new(&[0u8; 16]).is_some());
    }
}
