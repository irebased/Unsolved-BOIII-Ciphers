import math
from math import comb, factorial

def fmt(n):
    if n < 1e4: return f"{n:,.0f}"
    for u,d in [("e24",1e24),("e21",1e21),("e18",1e18),("e15",1e15),("e12",1e12),("e9",1e9),("e6",1e6),("e3",1e3)]:
        if n >= d: return f"{n/d:,.1f}{u}"
    return f"{n:,.0f}"

def wall(n, rate):
    s = n/rate
    if s < 60: return f"{s:.1f} sec"
    if s < 3600: return f"{s/60:.1f} min"
    if s < 86400: return f"{s/3600:.1f} hr"
    if s < 86400*365: return f"{s/86400:.1f} days"
    return f"{s/(86400*365):,.1f} YEARS"

# ---- Dimension definitions ----
# Keys: TheGiant(ascii), Zombies, ZOMBIES, thegiant, TheGiant(b64->6 bytes), zombies
N_KEY_TG   = 6
N_KEY_REV  = 3          # corpus invariant much tighter for Revelations
N_KEYDERIV = 2          # null-pad vs repeat-pad (tools4noobs behaviour uncertainty)

N_PRIM_OBS = 11         # primitives confirmed in solved corpus
N_PRIM_ALL = 19         # full mcrypt menu
N_MODE_OBS = 2          # cfb8, ecb
N_MODE_ALL = 7          # ecb cbc cfb ofb nofb ncfb stream
N_IV       = 3          # ascii-zero, true-null, other

N_TRANS_TG  = 16        # glyph-ambiguity transcription variants
N_TRANS_REV = 1         # hex, unambiguous

# Pre/inter-layer transforms (bounded set)
N_XFORM_SMALL = 100     # identity, reverse, rot-n over alphabet, row/route perms of the 4-row layout
N_XFORM_BETWEEN = 10    # reverse / re-encode between two modern layers

# Classical outer layer, BOUNDED (keyed by Zombies-family, tool-constrained)
N_CLASSICAL_BOUNDED = 10_000
# Classical outer layer, FREE substitution alphabet
N_CLASSICAL_FREE = factorial(26)
# Columnar transposition, free key of length n
def colperm(n): return factorial(n)

RATE_PY   = 25_000        # single-core python, CFB-8, 144B
RATE_OPT  = 2_000_000     # optimised native, 8-core (conservative 80x)

print("="*74)
print("SEARCH SPACE MODEL")
print("="*74)

def unit(n_prim, n_mode):
    return n_prim * n_mode * N_IV     # one modern-layer parameterisation

U_OBS = unit(N_PRIM_OBS, N_MODE_OBS)
U_ALL = unit(N_PRIM_ALL, N_MODE_ALL)
print(f"\nOne modern-layer unit  (observed menu): {U_OBS:,}  = 11 prim x 2 mode x 3 iv")
print(f"One modern-layer unit  (full mcrypt)  : {U_ALL:,}  = 19 prim x 7 mode x 3 iv")

for label, NT, NK in [("THE GIANT 4", N_TRANS_TG, N_KEY_TG), ("REVELATIONS 7", N_TRANS_REV, N_KEY_REV)]:
    print("\n" + "="*74)
    print(f"{label}   (transcription variants={NT}, key candidates={NK})")
    print("="*74)
    base = NT * NK * N_KEYDERIV
    rate = RATE_PY if NT==16 else 13_000
    rows = []
    t1_o = base * U_OBS
    t1_a = base * U_ALL
    rows.append(("T1  single modern layer (observed menu)", t1_o))
    rows.append(("T1' single modern layer (full mcrypt)", t1_a))
    t2 = base * U_ALL * N_XFORM_SMALL
    rows.append(("T2  transform + modern", t2))
    t3 = base * U_ALL * U_ALL * N_XFORM_BETWEEN
    rows.append(("T3  two modern layers", t3))
    t4b = base * U_ALL * N_CLASSICAL_BOUNDED
    rows.append(("T4  bounded classical OVER modern", t4b))
    t5 = base * U_ALL * U_ALL * U_ALL * N_XFORM_BETWEEN**2
    rows.append(("T5  three modern layers", t5))
    t6 = base * U_ALL * N_CLASSICAL_FREE
    rows.append(("T6  FREE substitution over modern", t6))
    t7 = base * U_ALL * colperm(10)
    rows.append(("T7  free columnar (key len 10) over modern", t7))
    print(f"\n{'TIER':<44}{'CANDIDATES':>14}{'@25k/s py':>16}")
    print("-"*74)
    for n,v in rows:
        print(f"{n:<44}{fmt(v):>14}{wall(v,rate):>16}")
    print("-"*74)
    cum = t1_a + t2 + t3 + t4b
    print(f"{'CUMULATIVE T1-T4 (bounded programme)':<44}{fmt(cum):>14}{wall(cum,rate):>16}")
    print(f"{'  same, optimised native 8-core':<44}{'':>14}{wall(cum,RATE_OPT):>16}")

print("\n" + "="*74)
print("VERIFICATION / FALSE-POSITIVE MATH")
print("="*74)
P_PRINT = 95/256
for nbytes,label in [(144,"TG4 (144 B)"),(546,"REV7 (546 B)")]:
    p_all = P_PRINT**nbytes
    # >=75% printable
    k = math.ceil(0.75*nbytes)
    p75 = sum(comb(nbytes,i)*(P_PRINT**i)*((1-P_PRINT)**(nbytes-i)) for i in range(k,nbytes+1))
    print(f"\n{label}")
    print(f"  P(100% printable by chance)  = {p_all:.3e}")
    print(f"  P(>=75% printable by chance) = {p75:.3e}")
    for tier,N in [("T1-T4 bounded", 1.5e9), ("T6 free-subst", 1e30)]:
        print(f"    expected false positives over {tier:<14} ({fmt(N)}): 100%={p_all*N:.2e}   75%={p75*N:.2e}")
