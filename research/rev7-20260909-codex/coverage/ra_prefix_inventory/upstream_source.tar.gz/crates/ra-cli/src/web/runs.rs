//! Background run execution and the in-memory run store for `ra serve`.
//!
//! A run walks `0..plan.total_ops()` exactly once, via [`super::engine::Plan`] —
//! the same planner `/api/plan` counts against — so `done_ops` can never overrun
//! `total_ops`, and the terminal state's `done_ops == total_ops` by construction
//! (short of an early stop).
//!
//! # Progress without slowing the hot loop
//!
//! `done_ops` is an `Arc<AtomicU64>` bumped **once per chunk**, after a batch of
//! chunks finishes evaluating in parallel under rayon — never once per candidate.
//! The per-candidate work (build a `Chain`, run it, score it) touches no shared
//! state at all except a `Relaxed` load of the stop flag; hits are collected into a
//! thread-local `Vec` and merged into the shared hit list only at chunk boundaries.
//! `/api/runs/{id}/events` (SSE) samples the atomics on its own timer rather than
//! being pushed to, so the sampling rate is decoupled from the sweep's rate.

use std::collections::BTreeMap;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Instant, SystemTime, UNIX_EPOCH};

use rayon::prelude::*;
use serde::Serialize;

use ra_core::{Repr, Value};
use ra_oracle::OracleSpec;

use super::engine::{build_plan, Plan, PlanRequest};

const DEFAULT_ORACLE: &str = "printable-0.75";
/// Hits kept per run. Bounded so a flood of chance passes on a short scored region
/// cannot exhaust memory; keeps the most significant (highest score) hits.
const HIT_CAP: usize = 200;
/// Completed/errored runs kept in the store before the oldest is evicted.
const RUN_CAP: usize = 200;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum RunState {
    Running,
    Done,
    Stopped,
    Error,
}

impl RunState {
    pub fn as_str(self) -> &'static str {
        match self {
            RunState::Running => "running",
            RunState::Done => "done",
            RunState::Stopped => "stopped",
            RunState::Error => "error",
        }
    }
}

#[derive(Clone, Serialize)]
pub struct HitRecord {
    pub score: f64,
    pub preview: String,
    pub chain: String,
    /// Flattened `"<step index>.<param name>"` -> value, matching the labelling
    /// `ra-cli`'s own sweep/residual reporting already uses for axis names.
    pub params: BTreeMap<String, String>,
}

fn significance(h: &HitRecord) -> (usize, f64) {
    (h.preview.len(), h.score)
}

fn push_hit(hits: &mut Vec<HitRecord>, hit: HitRecord, cap: usize) {
    if hits.len() < cap {
        hits.push(hit);
        return;
    }
    if let Some((worst_i, worst)) = hits
        .iter()
        .enumerate()
        .map(|(i, h)| (i, significance(h)))
        .min_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal))
    {
        if significance(&hit) > worst {
            hits[worst_i] = hit;
        }
    }
}

pub struct RunRecord {
    pub run_id: String,
    pub target: String,
    pub label: String,
    pub total_ops: u64,
    pub done_ops: Arc<AtomicU64>,
    pub hits: Arc<Mutex<Vec<HitRecord>>>,
    pub state: Arc<Mutex<RunState>>,
    pub error: Arc<Mutex<Option<String>>>,
    pub stop: Arc<AtomicBool>,
    pub best_score: Arc<Mutex<f64>>,
    pub started_epoch_secs: i64,
    pub start_instant: Instant,
}

impl RunRecord {
    pub fn elapsed_ms(&self) -> u64 {
        self.start_instant.elapsed().as_millis() as u64
    }

    pub fn state_str(&self) -> &'static str {
        (*self.state.lock().unwrap_or_else(|e| e.into_inner())).as_str()
    }

    pub fn done_ops_now(&self) -> u64 {
        self.done_ops.load(Ordering::Relaxed)
    }
}

/// The process-wide run store. Bounded: oldest non-running run is evicted once
/// the cap is exceeded, so a long-lived server does not grow without limit.
#[derive(Default)]
pub struct RunStore {
    order: Mutex<Vec<String>>,
    by_id: Mutex<BTreeMap<String, Arc<RunRecord>>>,
}

impl RunStore {
    pub fn insert(&self, rec: Arc<RunRecord>) {
        let id = rec.run_id.clone();
        self.by_id.lock().unwrap().insert(id.clone(), rec);
        let mut order = self.order.lock().unwrap();
        order.push(id);
        while order.len() > RUN_CAP {
            let evict = order.remove(0);
            // Never evict a run that is still running; push it back to the front
            // and stop trying rather than lose live progress.
            let still_running = self
                .by_id
                .lock()
                .unwrap()
                .get(&evict)
                .map(|r| r.state_str() == "running")
                .unwrap_or(false);
            if still_running {
                order.insert(0, evict);
                break;
            }
            self.by_id.lock().unwrap().remove(&evict);
        }
    }

    pub fn get(&self, id: &str) -> Option<Arc<RunRecord>> {
        self.by_id.lock().unwrap().get(id).cloned()
    }

    pub fn list(&self) -> Vec<Arc<RunRecord>> {
        let order = self.order.lock().unwrap();
        let by_id = self.by_id.lock().unwrap();
        order.iter().filter_map(|id| by_id.get(id).cloned()).collect()
    }
}

fn new_run_id() -> String {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos();
    static COUNTER: AtomicU64 = AtomicU64::new(0);
    let n = COUNTER.fetch_add(1, Ordering::Relaxed);
    let mix = (nanos as u64) ^ n.wrapping_mul(0x9E3779B97F4A7C15);
    format!("r_{:012x}", mix & 0xFFFF_FFFF_FFFF)
}

/// Days-since-epoch civil calendar conversion (Howard Hinnant's algorithm),
/// avoided pulling in a date/time crate for one field: `started`.
pub fn iso8601_utc(secs_since_epoch: i64) -> String {
    let days = secs_since_epoch.div_euclid(86400);
    let rem = secs_since_epoch.rem_euclid(86400);
    let z = days + 719468;
    let era = z.div_euclid(146097);
    let doe = z - era * 146097; // [0, 146096]
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365; // [0, 399]
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100); // [0, 365]
    let mp = (5 * doy + 2) / 153; // [0, 11]
    let d = doy - (153 * mp + 2) / 5 + 1; // [1, 31]
    let m = if mp < 10 { mp + 3 } else { mp - 9 }; // [1, 12]
    let y = if m <= 2 { y + 1 } else { y };
    let hh = rem / 3600;
    let mm = (rem % 3600) / 60;
    let ss = rem % 60;
    format!("{y:04}-{m:02}-{d:02}T{hh:02}:{mm:02}:{ss:02}Z")
}

fn value_to_string(v: &Value) -> String {
    match v {
        Value::Str(s) => s.clone(),
        Value::Int(i) => i.to_string(),
        Value::Bool(b) => b.to_string(),
    }
}

fn params_map(steps: &[ra_core::Step]) -> BTreeMap<String, String> {
    let mut m = BTreeMap::new();
    for (i, s) in steps.iter().enumerate() {
        for (k, v) in s.params.0.iter() {
            m.insert(format!("{i}.{k}"), value_to_string(v));
        }
    }
    m
}

struct ChunkOut {
    evaluated: u64,
    best_score: f64,
    hits: Vec<HitRecord>,
}

fn run_range(
    plan: &Plan,
    input: &Repr,
    oracle: &OracleSpec,
    start: u64,
    end: u64,
    stop: &AtomicBool,
) -> ChunkOut {
    let mut best_score = 0.0f64;
    let mut hits = Vec::new();
    let mut evaluated = 0u64;
    for idx in start..end {
        if stop.load(Ordering::Relaxed) {
            break;
        }
        evaluated += 1;
        let steps = plan.candidate(idx);
        let Ok(chain) = ra_core::Chain::new(steps.clone()) else {
            continue;
        };
        let Ok(out) = chain.run(input) else {
            continue;
        };
        let score = oracle.score(&out.data, chain.terminal_block_size());
        if score.score > best_score {
            best_score = score.score;
        }
        if score.passed {
            let preview: String = String::from_utf8_lossy(&out.data)
                .chars()
                .take(240)
                .collect();
            push_hit(
                &mut hits,
                HitRecord {
                    score: score.score,
                    preview,
                    chain: crate::spec::render_chain(&chain),
                    params: params_map(&steps),
                },
                HIT_CAP,
            );
        }
    }
    ChunkOut {
        evaluated,
        best_score,
        hits,
    }
}

fn execute(rec: &RunRecord, plan: &Plan, input: &Repr, oracle: &OracleSpec) {
    let bound = rec.total_ops;
    if bound == 0 {
        return;
    }
    let threads = rayon::current_num_threads().max(1) as u64;
    let chunk = (bound / (threads * 32)).clamp(1, 4096);
    let batch = chunk * threads * 4;
    let mut at = 0u64;
    while at < bound {
        if rec.stop.load(Ordering::Relaxed) {
            break;
        }
        let batch_end = (at + batch).min(bound);
        let ranges: Vec<(u64, u64)> = (at..batch_end)
            .step_by(chunk as usize)
            .map(|s| (s, (s + chunk).min(batch_end)))
            .collect();
        let outs: Vec<ChunkOut> = ranges
            .par_iter()
            .map(|&(s, e)| run_range(plan, input, oracle, s, e, &rec.stop))
            .collect();
        let mut hit_batch = Vec::new();
        for out in outs {
            // The atomic is bumped once per finished chunk, not once per candidate.
            rec.done_ops.fetch_add(out.evaluated, Ordering::Relaxed);
            if out.best_score > 0.0 {
                let mut b = rec.best_score.lock().unwrap();
                if out.best_score > *b {
                    *b = out.best_score;
                }
            }
            hit_batch.extend(out.hits);
        }
        if !hit_batch.is_empty() {
            let mut hits = rec.hits.lock().unwrap();
            for h in hit_batch {
                push_hit(&mut hits, h, HIT_CAP);
            }
        }
        at = batch_end;
    }
}

/// Build a plan, resolve its target and oracle, and start the run in a background
/// thread. Returns immediately with the run handle; the server stays responsive.
pub fn spawn_run(
    data: PathBuf,
    req: PlanRequest,
    store: &Arc<RunStore>,
) -> Result<Arc<RunRecord>, String> {
    let plan = build_plan(&req)?;
    let target = crate::corpus::load_target(&data, &req.target).map_err(|e| e.to_string())?;
    let oracle_id = req.oracle.clone().unwrap_or_else(|| DEFAULT_ORACLE.to_string());
    let oracle = ra_oracle::oracle(&oracle_id)
        .ok_or_else(|| format!("unknown oracle '{oracle_id}'"))?
        .clone();

    let rec = Arc::new(RunRecord {
        run_id: new_run_id(),
        target: req.target.clone(),
        label: plan.label(),
        total_ops: plan.total_ops(),
        done_ops: Arc::new(AtomicU64::new(0)),
        hits: Arc::new(Mutex::new(Vec::new())),
        state: Arc::new(Mutex::new(RunState::Running)),
        error: Arc::new(Mutex::new(None)),
        stop: Arc::new(AtomicBool::new(false)),
        best_score: Arc::new(Mutex::new(0.0)),
        started_epoch_secs: SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_secs() as i64)
            .unwrap_or(0),
        start_instant: Instant::now(),
    });
    store.insert(rec.clone());

    let bg = rec.clone();
    std::thread::spawn(move || {
        let input = Repr::new(target.raw.clone().into_bytes(), target.display);
        // A panic inside the sweep (a node implementation bug, say) must not vanish
        // silently: catch it, surface it on the run record, and mark the run
        // errored rather than leaving it "running" forever.
        let outcome =
            std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                execute(&bg, &plan, &input, &oracle);
            }));
        let final_state = match outcome {
            Ok(()) if bg.stop.load(Ordering::Relaxed) => RunState::Stopped,
            Ok(()) => RunState::Done,
            Err(payload) => {
                let msg = payload
                    .downcast_ref::<&str>()
                    .map(|s| s.to_string())
                    .or_else(|| payload.downcast_ref::<String>().cloned())
                    .unwrap_or_else(|| "run panicked".to_string());
                *bg.error.lock().unwrap() = Some(msg);
                RunState::Error
            }
        };
        *bg.state.lock().unwrap() = final_state;
    });

    Ok(rec)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn iso8601_matches_known_instants() {
        assert_eq!(iso8601_utc(0), "1970-01-01T00:00:00Z");
        assert_eq!(iso8601_utc(1_700_000_000), "2023-11-14T22:13:20Z");
    }
}
