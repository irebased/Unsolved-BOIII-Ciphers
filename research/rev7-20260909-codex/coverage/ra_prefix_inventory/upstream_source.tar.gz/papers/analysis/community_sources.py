#!/usr/bin/env python3
"""Reconcile the community "Zombies Sources" sheet against this project's corpus.

Run: python3 papers/analysis/community_sources.py     (stdlib only)

WHAT THE SHEET IS
-----------------
data/zombies_sources.csv, 83 rows across WaW/BO1/BO2/BO3, columns
Game, Map, Cipher, Type, Encoding Source, Confidence, Explanation.  It records,
per cipher, WHICH WEBSITE OR TOOL the community believes was used, with a
confidence percentage and a prose explanation.  It is direct human attribution
by people who worked the problem, and where it conflicts with this project's
menu-coverage INFERENCE it is the stronger evidence.  It is not ground truth:
many rows are "Unknown", confidences run from 25% to 100%, and its author
records being "pretty knackered" with a second draft intended.

THE NUMBERING DOES NOT MATCH, AND THAT IS THE MAIN HAZARD
---------------------------------------------------------
The sheet uses Reddit numbering; this corpus uses irebased texture-file
ALPHABETICAL numbering.  Reading an attribution straight across by number is
wrong for every Revelations cipher for which a mapping is known.  So the
mapping is DERIVED here rather than transcribed:

  phase 1  match the sheet's `Type` against the recorded solution chain, and
           accept only where the match is unique within the map;
  phase 2  ask, per map, whether every phase-1 pair happens to satisfy
           sheet number == corpus number.  Where it does, the sheet's
           numbering for that map is identity and may be extended to rows
           whose Type is "Unknown".  Where it does not -- Revelations -- it
           may not, and those rows stay UNMAPPED;
  phase 3  pair any residue that is forced by elimination, labelled as such.

The four Revelations pairs the phase-1 matcher recovers are then asserted
against the independently verified list, so a regression in the matcher is a
test failure rather than a silently wrong document.

The sheet spells the map "Revalations" and cases "Zetsubou no Shima"
differently from this corpus; both are handled by name normalisation.
"""
import csv
import itertools
import json
import os
import random
import re
import sys
import collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reuse_matrix import ROOT, MAPS, MAP_ORDER, norm, CIPHER_TYPES  # noqa: E402

SHEET = os.path.join(ROOT, "data", "zombies_sources.csv")

# Sheet map name -> corpus map key.  The sheet's spelling is preserved verbatim.
SHEET_MAP = {
    "shadows of evil": "shadows_of_evil",
    "the giant": "the_giant",
    "der eisendrache": "der_eisendrache",
    "zetsubou no shima": "zetsubou_no_shima",
    "gorod krovi": "gorod_krovi",
    "revalations": "revelations",          # sic
}

# Sheet `Type` -> tokens to look for.  "m:" is a recorded method name, matched
# after norm(); "p:" is a word to look for in a prose puzzle description.
# Types that carry no information ("Unknown", "Unsolved") map to no tokens and
# are therefore unmatchable by type, which is the correct outcome.
TYPE_TOKENS = {
    "porta": ["m:porta"],
    "trifid": ["m:trifid"],
    "four_square": ["m:four_square"],
    "tupper_s_formula": ["m:tupper_s_self_referential_formula"],
    "straddling_checkerboard": ["m:straddling_checkerboard"],
    "code_128": ["p:barcode"],
    "periodic_table": ["p:periodic"],
    "simplified_lorenz": ["m:simplified_lorenz"],
    "enigma": ["m:enigma_m3"],
    "flag_semaphore": ["m:flag_semaphore"],
    "base64": ["m:base64"],
    "playfair": ["m:playfair"],
    "bifid": ["m:bifid"],
    "navajo_code": ["m:navajo_code_talker"],
    "homophonic": ["m:homophonic_substitution"],
    "amsco_2_1": ["m:2_1_amsco"],
    "formulas": ["m:math_formulas_to_obfuscate_information"],
    "trithemius": ["m:trithemius"],
    "ubchi": ["m:ubchi"],
    "purple": ["m:purple"],
    "t9": ["m:t_9"],
    "vigenere": ["m:vigenere"],
    "letter_numbers": ["m:numbers_to_letters"],
    "hexadecimal": ["m:hexadecimal"],
    "keyed_caesar": ["m:keyed_caesar"],
    "skip": ["m:skip"],
    "modified_binary": ["m:modified_binary_dna_sequence"],
    "crossword": ["p:crossowrd"],          # the corpus's own typo
    "rail_fence": ["m:rail_fence"],
    "keyed_vigenere": ["m:keyed_vigenere_quagmire_iii"],
    "leetspeak": ["m:leet_speak"],
    "octal": ["m:octal"],
    "pigpen": ["m:pigpen"],
    "zulu": ["p:zulu"],
    "book": ["m:book"],
    "rotate": ["m:rotate"],
    "baudot": ["m:baudot_code"],
    "decimal_roman_numerals": ["p:roman"],
    "atbash": ["m:atbash"],
    "double_columnar": ["m:double_columnar_transposition"],
    "assembly": ["p:assembly"],
    # Revelations. Each is a whole chain, so several tokens must all be present.
    "reverse_affine": ["m:reverse", "m:affine"],
    "polybius_adfgx": ["m:adfgx"],
    "reverse_columnar_transposition": ["m:columnar_transposition"],
    "reverse_ascii_octal_straddling_checkerboard": ["m:straddling_checkerboard"],
}

# Independently verified before this script was written; asserted, not used.
VERIFIED_REV = {1: "rev13", 2: "rev4", 3: "rev14", 4: "rev3"}

# --------------------------------------------------------------------------
# Practical Cryptography's straddling checkerboard default, for section 5.
# practicalcryptography.com itself still refuses connections from this
# environment.  The default below is taken from two secondary sources that
# each name Practical Cryptography as their origin, and they agree.
PC_DEFAULT_KEY = "FKMCPDYEHBIGQROSAZLUTJNWVX"
PC_DEFAULT_SPARES = (3, 7)
PC_SOURCE = ("a.tools Tool.php?Id=281, which reproduces the PC form's "
             "pre-filled default, and the Call of Duty wiki, which quotes the "
             "same key and the same spare positions")

REV3_LAYOUT = "C.D..YFE.W/NXM.T...U./.SOGIAR.BH"   # ra-core straddling.rs
REV3_STRADDLE = "13"


# --------------------------------------------------------------------------
def load_sheet():
    with open(SHEET, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def load_corpus():
    recs = {}
    for m in MAP_ORDER:
        for r in json.load(open(os.path.join(ROOT, "data", MAPS[m]))):
            steps = (r.get("solution") or {}).get("steps", [])
            recs[r["id"]] = dict(
                id=r["id"], map=m, number=r["number"],
                methods={norm(s["method"]) for s in steps if s.get("method")},
                ciphers={norm(s["method"]) for s in steps
                         if s.get("method") and s["type"] in CIPHER_TYPES},
                prose=" ".join((s.get("description") or "") for s in steps).lower(),
                nsteps=len(steps),
            )
    return recs


def tnorm(s):
    """norm(), after folding the sheet's typographic characters. The sheet uses
    a curly apostrophe in "Tupper's Formula" and an "approximately equal" sign
    in "ASCII = Octal"; neither is a combining mark, so norm() alone leaves them
    in and the lookup silently misses."""
    return norm(s.replace("’", "'").replace("‘", "'")
                 .replace("≈", " ").replace("–", "-"))


def sheet_number(cipher):
    """The cipher's number in the sheet's own numbering, or None.

    "GK Scrap #1" is deliberately NOT number 1: the scrap rows are a separate
    sequence, and reading their "#1" as a cipher number silently destroys the
    numbering-identity test for Gorod Krovi."""
    if "scrap" in cipher.lower():
        return None
    m = re.search(r"#\s*(\d+)", cipher)
    return int(m.group(1)) if m else None


def matches(rec, tokens):
    for t in tokens:
        kind, val = t.split(":", 1)
        if kind == "m" and val not in rec["methods"]:
            return False
        if kind == "p" and val not in rec["prose"]:
            return False
    return True


def build_mapping(rows, recs):
    """Returns rowidx -> (record id, basis) and a list of unmapped rowidx."""
    mapping, basis = {}, {}
    by_map = collections.defaultdict(list)
    for i, r in enumerate(rows):
        key = SHEET_MAP.get(norm(r["Map"]).replace("_", " "))
        if key:
            by_map[key].append(i)

    for mkey, idxs in by_map.items():
        recs_here = [v for v in recs.values() if v["map"] == mkey]
        # ---- phase 1: unique match on Type
        for i in idxs:
            toks = TYPE_TOKENS.get(tnorm(rows[i]["Type"]))
            if not toks:
                continue
            hits = [r for r in recs_here if matches(r, toks)]
            if len(hits) == 1:
                mapping[i] = hits[0]["id"]
                basis[i] = "type"
        # ---- phase 1b: k rows sharing a Type against exactly k matching
        # records. The records are then indistinguishable from each other by
        # anything the corpus holds, so the pairing is by order and is labelled
        # as the arbitrary choice it is.
        groups = collections.defaultdict(list)
        for i in idxs:
            if i not in mapping and TYPE_TOKENS.get(tnorm(rows[i]["Type"])):
                groups[tnorm(rows[i]["Type"])].append(i)
        for toks_key, gidx in groups.items():
            hits = [r for r in recs_here
                    if matches(r, TYPE_TOKENS[toks_key])
                    and r["id"] not in set(mapping.values())]
            if len(hits) == len(gidx) and len(gidx) > 1:
                for i, r in zip(gidx, sorted(hits, key=lambda x: x["number"])):
                    mapping[i] = r["id"]
                    basis[i] = "type, tie broken by order (records identical)"
        # ---- phase 2: does this map's numbering agree with ours?
        pairs = [(sheet_number(rows[i]["Cipher"]), recs[mapping[i]]["number"])
                 for i in idxs if i in mapping and sheet_number(rows[i]["Cipher"])]
        identity = bool(pairs) and all(a == b for a, b in pairs)
        if identity:
            taken = set(mapping.values())
            for i in idxs:
                if i in mapping:
                    continue
                n = sheet_number(rows[i]["Cipher"])
                hit = [r for r in recs_here
                       if r["number"] == n and r["id"] not in taken]
                if n and len(hit) == 1:
                    mapping[i] = hit[0]["id"]
                    basis[i] = "numbering (identity for this map)"
                    taken.add(hit[0]["id"])
        # ---- phase 3: elimination, ONLY when it is genuinely forced, that is
        # when one row and one record remain. Anything looser would invent a
        # mapping: Revelations ends here with ten "Unknown" rows against ten
        # records, and ten factorial orderings are equally consistent with the
        # sheet. Those rows stay unmapped, which is the whole point.
        left_rows = [i for i in idxs if i not in mapping]
        left_recs = [r for r in recs_here if r["id"] not in set(mapping.values())]
        if len(left_rows) == 1 and len(left_recs) == 1:
            mapping[left_rows[0]] = left_recs[0]["id"]
            basis[left_rows[0]] = "elimination (uniquely forced)"
        mapping.setdefault("_identity_" + mkey, identity)
    return mapping, basis, by_map


# --------------------------------------------------------------------------
def parse_layout():
    rows = REV3_LAYOUT.split("/")
    board = {}
    for d, ch in enumerate(rows[0]):
        if ch != ".":
            board[(d,)] = ch
    for r, s in enumerate(REV3_STRADDLE):
        for d, ch in enumerate(rows[r + 1]):
            if ch != ".":
                board[(int(s), d)] = ch
    return board


def pc_board(alpha, s1, s2, swap=False, gaps=()):
    order = [(d,) for d in range(10) if d not in (s1, s2)]
    for s in ([s2, s1] if swap else [s1, s2]):
        order += [(s, d) for d in range(10)]
    it, out = iter(alpha), {}
    for i, c in enumerate(order):
        if i in gaps:
            continue
        try:
            out[c] = next(it)
        except StopIteration:
            break               # 26 letters into 28 cells; the rest stay empty
    return out


def forced_sigma(ours, board):
    """Digit relabellings are not searched, they are FORCED: board letters are
    unique, so an attested letter at our code c must sit at their code
    sigma(c), which reads sigma off digit by digit."""
    where = {v: k for k, v in board.items()}
    sig = {}
    for code, letter in ours.items():
        t = where.get(letter)
        if t is None or len(t) != len(code):
            return None
        for a, b in zip(code, t):
            if a in sig and sig[a] != b:
                return None
            sig[a] = b
    return sig if len(set(sig.values())) == len(sig) else None


def block_of_ours(ours):
    return {L: (0 if len(c) == 1 else (1 if c[0] == 1 else 2))
            for c, L in ours.items()}


def block_of_alpha(alpha):
    return {ch: (0 if i < 8 else (1 if i < 18 else 2))
            for i, ch in enumerate(alpha)}


def block_agreement(ourb, alphab):
    return max(sum(1 for L, b in ourb.items() if alphab[L] == p[b])
               for p in itertools.permutations(range(3)))


# --------------------------------------------------------------------------
def main():
    rows, recs = load_sheet(), load_corpus()
    print("=" * 76)
    print("THE SHEET")
    print("=" * 76)
    print(f"  rows                       : {len(rows)}")
    for k, v in collections.Counter(r["Game"] for r in rows).most_common():
        print(f"    {k:<24} : {v}")
    print()

    mapping, basis, by_map = build_mapping(rows, recs)
    mapped = {i: v for i, v in mapping.items() if isinstance(i, int)}

    print("=" * 76)
    print("SHEET ROW -> CORPUS RECORD, DERIVED")
    print("=" * 76)
    for mkey in MAP_ORDER:
        idxs = by_map.get(mkey, [])
        if not idxs:
            continue
        ident = mapping.get("_identity_" + mkey)
        print(f"  {mkey}   (numbering identity holds: {ident})")
        for i in idxs:
            tgt = mapped.get(i, "UNMAPPED")
            print(f"    {rows[i]['Cipher']:<14} {rows[i]['Type'][:44]:<46}"
                  f"-> {tgt:<8} [{basis.get(i, 'none')}]")
        print()

    unmapped = [i for i in range(len(rows)) if i not in mapped]
    off = [i for i in unmapped
           if norm(rows[i]["Map"]).replace("_", " ") not in SHEET_MAP]
    print(f"  mapped   : {len(mapped)} of {len(rows)}")
    print(f"  unmapped : {len(unmapped)}  "
          f"({len(off)} on maps outside this corpus, "
          f"{len(unmapped) - len(off)} inside it)")
    for i in unmapped:
        if i not in off:
            print(f"      {rows[i]['Map']} {rows[i]['Cipher']}: "
                  f"Type is {rows[i]['Type']!r}, nothing to match on")
    print()

    # ---- the assertion the brief demands ---------------------------------
    for n, rid in VERIFIED_REV.items():
        got = [mapped[i] for i in by_map["revelations"]
               if sheet_number(rows[i]["Cipher"]) == n and i in mapped]
        assert got == [rid], f"Rev #{n} derived as {got}, expected {rid}"
    assert mapping["_identity_revelations"] is False, \
        "Revelations numbering must NOT come out as identity"
    for mkey in ("shadows_of_evil", "the_giant", "der_eisendrache",
                 "zetsubou_no_shima", "gorod_krovi"):
        assert mapping["_identity_" + mkey] is True, mkey
    print("  ASSERTED: Rev #1->rev13, #2->rev4, #3->rev14, #4->rev3, derived "
          "by type match")
    print("  ASSERTED: numbering is identity on the other five maps and is NOT "
          "on Revelations")
    print()

    # ---- tools ------------------------------------------------------------
    print("=" * 76)
    print("WHAT THE SHEET ATTRIBUTES")
    print("=" * 76)
    def srcs(row):
        s = row["Encoding Source"].strip()
        parts = re.split(r"\s*/\s*", s)
        if s.lower().startswith("font"):        # "Font / UTF-16 Encoding"
            parts = [s]
        return [p.strip() for p in parts]

    allrows = collections.Counter()
    ours = collections.Counter()
    mine = {i for i in mapped}
    for i, r in enumerate(rows):
        for t in srcs(r):
            allrows[t.casefold()] += 1
            if i in mine:
                ours[t.casefold()] += 1
    disp = {t.casefold(): t for r in rows for t in srcs(r)}
    print(f"    {'source':<28}{'all 83 rows':>13}{'the 52 mapped':>15}")
    for t, n in allrows.most_common():
        print(f"    {disp[t]:<28}{n:>13}{ours.get(t, 0):>15}")
    print()
    named = [t for t in allrows
             if t not in ("unknown", "manually encoded", "manually scripted",
                          "custom tool", "custom font", "font / utf-16 encoding")]
    top = max(named, key=lambda t: allrows[t])
    print(f"  most-attributed IDENTIFIED tool: {disp[top]}, "
          f"{allrows[top]} of {len(rows)} rows.")
    print("  Our menu analysis revived rumkin on the independent ground that "
          "Skip and flag")
    print("  semaphore are covered by it and by nothing else. Two routes, same "
          "answer.")
    print()

    print("  Candidates this project argued about, probed across all 83 rows:")
    for probe, label in (("dcode", "dcode.fr"),
                         ("boxentriq", "Boxentriq"),
                         ("cachesleuth", "CacheSleuth"),
                         ("geocaching", "geocachingtoolbox.com")):
        cited = [t for t in allrows if probe in t]
        prose = [r["Cipher"].strip() for r in rows
                 if probe in r["Explanation"].lower()]
        print(f"    {label}")
        print(f"      named as an Encoding Source : "
              f"{cited if cited else 'NEVER, in any of the 83 rows'}")
        print(f"      discussed in an Explanation : "
              f"{', '.join(prose) if prose else 'never'}")
    print()
    print("  dcode's absence is not mere silence. The sheet REACHED FOR IT "
          "FOUR TIMES AND")
    print("  PUT IT DOWN EACH TIME, twice on a reproduction failure:")
    print("    ZnS #1  'dCode is normally cited as the source of this cipher, "
          "but the")
    print("            outputs do not match when I try to encipher the known "
          "plaintext.'")
    print("    GK #4   'Only other contemporary online encoder I could find "
          "was dCode,")
    print("            which handles the numbers in a way. Cryptii handles the "
          "numbers")
    print("            exactly how they need to be handled.'")
    print("    SoE #1  the Porta table exists on both, but 'on dCode it is "
          "labelled a")
    print("            variant' where Practical Cryptography has it as the "
          "default.")
    print("  That is an active elimination by people who tried it, and it "
          "independently")
    print("  supports the owner's exclusion far more strongly than absence "
          "would.")
    print()
    print("  geocachingtoolbox.com, which the owner's hypotheses repeatedly "
          "name as the")
    print("  'geo toolbox', appears in NO Encoding Source cell but is the "
          "runner-up in two")
    print("  Explanations (SoE #3, Mob #5). The community considered it and "
          "preferred")
    print("  another tool on grounds of page formatting and later reuse, not "
          "on menu.")
    print()

    # ---- attribution against menu, row by row -----------------------------
    print("=" * 76)
    print("EVERY ATTRIBUTION, CHECKED AGAINST THE MENU WE HOLD FOR THAT TOOL")
    print("=" * 76)
    print("  A community attribution and a menu inference are different kinds")
    print("  of evidence. This is where they can be made to talk: for every")
    print("  mapped row whose named tool is in toolkit_coverage.py, does that")
    print("  tool's menu actually carry the cipher the sheet gives it?")
    print()
    from toolkit_coverage import TOOLKITS   # noqa: E402
    alias = {
        "rumkin": "rumkin.com", "cryptool online": "Cryptool Online",
        "cryptii v2": "cryptii v2", "practical cryptography":
        "Practical Cryptography", "braingle": "Braingle", "cimt":
        "CIMT / MEP Codes and Ciphers", "limfinity": "Limfinity",
        "brian neal purple": "Brian Neal PURPLE", "pmacg": "PMacg",
        "woodmann": "Woodmann", "google translate": "Google Translate",
    }
    print("  A row may name several tools, one per layer, so the test is "
          "whether the UNION")
    print("  of the named tools' menus carries each CIPHER-role method of the "
          "record.")
    print()
    agree, conflict = [], []
    for i, rid in sorted(mapped.items(), key=lambda kv: kv[1]):
        rec = recs[rid]
        if not rec["ciphers"]:
            continue
        names = [alias.get(t.casefold(), "") for t in srcs(rows[i])]
        tks = [TOOLKITS[n] for n in names if n in TOOLKITS]
        if not tks:
            continue
        union = set().union(*(t["covers"] for t in tks))
        got = sorted(m for m in rec["ciphers"] if m in union)
        gap = sorted(m for m in rec["ciphers"] if m not in union)
        label = " + ".join(t.strip() for t in srcs(rows[i]))
        (conflict if gap else agree).append((rid, label, got, gap))
    print(f"  attribution and menu AGREE      : {len(agree)}")
    for rid, t, c, _ in agree:
        print(f"      {rid:<7} {t:<38} {','.join(c)}")
    print(f"  attribution and menu DISAGREE   : {len(conflict)}")
    for rid, t, c, m in conflict:
        print(f"      {rid:<7} {t:<38} not on the menu: {','.join(m)}")
    print()
    print("  Five of the six disagreements are Der Eisendrache attributed to "
          "Cryptool")
    print("  Online. This project's 2026 enumeration of that site found "
          "neither Bifid nor")
    print("  Navajo nor AMSCO nor Trithemius nor Playfair, and the sheet gives "
          "it all five,")
    print("  at 90, 75, 80, 75 and 85 per cent. That is a DISAGREEMENT, not a "
          "refutation:")
    print("  the menu is not complete, so 'not found' means 'not known to be "
          "covered', and")
    print("  section 0's blocker is exactly what stops it being decided. It is "
          "recorded and")
    print("  left standing. The sheet's reasoning for de4 is checkable if the "
          "2016 site is")
    print("  ever reachable: it says the site's Bifid had a setting "
          "substituting W as VV,")
    print("  which is what de4's ciphertext shows.")
    print("  The sixth is rev4's ADFGX, and the sheet agrees it is unexplained:")
    print("  'I was not able to identify an ADFGX tool that output in groups "
          "of 45.'")
    print()
    print("  Two rows the previous revision would have called conflicts are "
          "instead a")
    print("  correction to this project's METHOD. zns7 (keyed Caesar, 95%) "
          "and zns12")
    print("  (Quagmire III, 99%) are attributed to rumkin's 'keymaker', a "
          "SETTING on pages")
    print("  the coverage table had recorded only as 'Caesar' and 'Vigenere'. "
          "A menu")
    print("  enumeration counts PAGES, NOT CAPABILITIES, so every "
          "complete=True flag in")
    print("  that table means complete-at-page-level and undercounts. Both "
          "methods are")
    print("  now in rumkin's covers set on the sheet's testimony, and "
          "Quagmire III -- the")
    print("  last real cipher in the corpus without an identified source -- "
          "leaves the")
    print("  uncovered list because of it.")
    print()

    # ---- confirmations ----------------------------------------------------
    print("=" * 76)
    print("THREE INDEPENDENTLY DERIVED FINDINGS, CHECKED AGAINST THE SHEET")
    print("=" * 76)
    tg3 = [r for r in rows if r["Cipher"].strip() == "TG #3"][0]
    print(f"  1. TG3 = CIMT. sheet source {tg3['Encoding Source']!r} at "
          f"{tg3['Confidence']}.")
    assert tg3["Encoding Source"].strip() == "CIMT" and tg3["Confidence"].startswith("100")
    print("     We recovered wheel lengths 14 and 4 (period 28 = lcm) from the "
          "ciphertext")
    print("     BEFORE any tool was consulted, then reproduced 48/48. AGREE, "
          "independently.")

    rev2 = [r for r in rows if r["Cipher"].strip() == "Rev #2"][0]
    assert "the key actually is Zombies" in rev2["Explanation"]
    assert "incorrect" in rev2["Explanation"]
    print("  2. Rev #2 = our rev4 (ADFGX). Sheet: the key 'actually is "
          "Zombies' and the")
    print("     30957298 explanation was 'poor (and quite frankly incorrect)'. "
          "Our adfgx.rs")
    print("     records that ZOMBIES ranks to 7541326, that the seven-column "
          "transposition")
    print("     under that ranking reproduces the plaintext, and that "
          "30957298 'corresponds")
    print("     to nothing in the reproduction'. AGREE, independently.")

    rev3 = [r for r in rows if r["Cipher"].strip() == "Rev #3"][0]
    assert "probably still unknown" in rev3["Explanation"]
    assert rev3["Encoding Source"].strip() == "Unknown"
    print("  3. Rev #3 = our rev14 (columnar). Sheet: the true scheme is "
          "'probably still")
    print("     unknown, as my testing with columnar encoders online have not "
          "output the way")
    print("     I need them to'. We tested every width dividing 162 and, via "
          "the within-block")
    print("     step invariant, every column key order: none fits. AGREE, "
          "independently, on")
    print("     a NEGATIVE, which is the harder kind to agree on.")
    print()

    # ---- rev13 behavioural fingerprint ------------------------------------
    print("=" * 76)
    print("REV #1 = our rev13: the sheet's BEHAVIOURAL fingerprint, tested")
    print("=" * 76)
    r13 = json.load(open(os.path.join(ROOT, "data", "revelations.json")))
    r13 = {r["id"]: r for r in r13}
    ct = r13["rev13"]["ciphertext"][::-1]
    pt = r13["rev13"]["plaintext"]
    same_nonalpha = all((not a.isalpha()) == (not b.isalpha())
                        and (a == b if not a.isalpha() else True)
                        for a, b in zip(ct, pt))
    same_case = all(a.isupper() == b.isupper()
                    for a, b in zip(ct, pt) if a.isalpha() and b.isalpha())
    print(f"  sheet claims Rumkin at 85% on a 'casing preserving / punctuation "
          f"preserving /")
    print(f"  spacing preserving trio'. Against rev13's own ciphertext and "
          f"plaintext:")
    print(f"    lengths equal, {len(ct)} = {len(pt)}          : "
          f"{len(ct) == len(pt)}")
    print(f"    every non-letter identical, in place        : {same_nonalpha}")
    print(f"    every letter's case identical               : {same_case}")
    n_sp = sum(1 for c in pt if c.isspace())
    n_pu = sum(1 for c in pt if not c.isalnum() and not c.isspace())
    n_up = sum(1 for c in pt if c.isupper())
    print(f"    carried through: {n_sp} spaces, {n_pu} punctuation marks, "
          f"{n_up} capitals")
    assert same_nonalpha and same_case
    print("  >>> The trio is CONFIRMED from our data. This is a behavioural "
          "fingerprint,")
    print("      not a menu one, and it is a better class of evidence than "
          "menu coverage.")
    print()

    # ---- and the inference it does NOT license ----------------------------
    A52 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    ct1, key = r13["rev1"]["ciphertext"], "ZOMBIES"

    def bf(s, k, alpha=None):
        out, ki = [], 0
        for c in s:
            if alpha and c in alpha:
                out.append(alpha[(alpha.index(k[ki % len(k)]) - alpha.index(c))
                                 % len(alpha)])
                ki += 1
            elif not alpha and c.isalpha():
                base = ord("A") if c.isupper() else ord("a")
                kk = ord(k[ki % len(k)].upper()) - ord("A")
                out.append(chr(base + (kk - (ord(c) - base)) % 26))
                ki += 1
            else:
                out.append(c)
        return "".join(out)

    a, b = bf(ct1, key, A52), bf(ct1, key)
    agree = sum(1 for x, y in zip(a, b) if x == y)
    print("  Does that bear on rev1's RECORDED 52-character mixed-case "
          "Beaufort alphabet?")
    print("  A case-preserving tool is often described as 'effectively "
          "operating on 52")
    print("  characters'. Tested on rev1's own ciphertext, that is FALSE:")
    print(f"    52-char alphabet output : {a[:44]}")
    print(f"    case-preserving 26      : {b[:44]}")
    print(f"    identical               : {a == b}   "
          f"(agreement {agree}/{len(a)})")
    assert a != b
    print("  >>> A 52-symbol cyclic group is NOT case preservation. rev1 and "
          "rev13 are")
    print("      different ciphers and the rev13 fingerprint does not transfer "
          "to rev1.")
    print()

    # ---- Practical Cryptography's straddling default ----------------------
    print("=" * 76)
    print("REV #4 = our rev3: the sheet's 100% Practical Cryptography claim")
    print("=" * 76)
    print("  Sheet: 'we are 100% sure Practical Cryptography was used for the")
    print("  Straddling Checkerboard layer due to its use of the site's "
          "default key.'")
    print(f"  PC default key    : {PC_DEFAULT_KEY}")
    print(f"  PC default spares : {PC_DEFAULT_SPARES[0]} and "
          f"{PC_DEFAULT_SPARES[1]}")
    print(f"  obtained from     : {PC_SOURCE}")
    print("                      practicalcryptography.com still refuses the "
          "connection.")
    print()
    print("  Corroboration that does not go through rev3 at all: soe5's "
          "recorded")
    soe5 = [r for r in json.load(open(os.path.join(ROOT, "data", "soe.json")))
            if r["id"] == "soe5"][0]
    cfg = soe5["solution"]["steps"][0].get("configuration")
    print(f"  configuration is {cfg!r}, and the sheet's SoE #5 row says the "
          f"spare")
    print("  cells 'are also defaults of the site'. Two independent records, "
          "same value.")
    assert "3 and 7" in cfg
    print()

    ours = parse_layout()
    print(f"  our rev3 layout   : {REV3_LAYOUT}  straddle {{1,3}}")
    print(f"                      {len(ours)} of 28 cells attested by a "
          f"61-character plaintext")
    print()
    print("  Two freedoms make a naive string comparison meaningless:")
    print("    (a) rev3's chain begins with base10, which assigns digits BY "
          "ORDER OF")
    print("        APPEARANCE, so the digit LABELS -- and hence the straddle "
          "digits {1,3}")
    print("        -- are our convention, not the author's;")
    print("    (b) the recorded `substitution` step is not separately "
          "identifiable from")
    print("        the board, so the letters are the COMPOSITE's.")
    print("  What survives (a) is the partition of letters by CODE LENGTH and "
          "row, which")
    print("  no relabelling can change. That is the test run below.")
    print()

    exact = 0
    for s1, s2 in itertools.combinations(range(10), 2):
        for swap in (0, 1):
            for gaps in itertools.combinations(range(28), 2):
                if forced_sigma(ours, pc_board(PC_DEFAULT_KEY, s1, s2, swap, gaps)):
                    exact += 1
    print(f"  exact isomorphism, over all 45 spare pairs x 2 row orders x 378")
    print(f"  placements of the two empty cells                   : {exact} "
          f"found")

    ourb = block_of_ours(ours)
    obs = block_agreement(ourb, block_of_alpha(PC_DEFAULT_KEY))
    pcb = block_of_alpha(PC_DEFAULT_KEY)
    bad = sorted(L for L, b in ourb.items() if pcb[L] != [0, 2, 1][b])
    print(f"  block agreement, our board vs the PC default        : "
          f"{obs}/{len(ourb)}")
    print(f"  the letters that disagree                           : {bad}")

    random.seed(0)
    alpha, N, ge, tot = list(PC_DEFAULT_KEY), 100000, 0, 0
    for _ in range(N):
        random.shuffle(alpha)
        a2 = block_agreement(ourb, block_of_alpha(alpha))
        tot += a2
        ge += a2 >= obs
    print(f"  null: random alphabets in the same 8/10/8 shape, n={N}")
    print(f"    E[agreement] = {tot / N:.2f}/{len(ourb)}     "
          f"P(>= {obs}) = {ge / N:.5f}")
    assert obs == 17 and ge / N < 0.001

    sig = {0: 4, 1: 7, 2: 6, 3: 3, 4: 2, 5: 8, 6: 5, 7: 9, 8: 1, 9: 0}
    board = pc_board(PC_DEFAULT_KEY, *PC_DEFAULT_SPARES)
    hit = sum(1 for c, L in ours.items()
              if board.get(tuple(sig[d] for d in c)) == L)
    print(f"  under the relabelling the agreeing cells FORCE, "
          f"sigma = {list(sig.values())},")
    print(f"  cells reproducing the PC default letter for letter   : "
          f"{hit}/{len(ours)}")
    assert hit == 16
    print()
    print("  VERDICT. Not an exact match, and 'due to its use of the site's "
          "default key'")
    print("  is not reproduced literally. But 17 of 19 attested letters sit in "
          "the block")
    print("  the PC default puts them in, and 16 of 19 reproduce it cell for "
          "cell under a")
    print("  single digit relabelling, against a null expectation near 9 and "
          "p < 1e-4.")
    print("  The community's attribution is CORROBORATED, at a strength the "
          "sheet did not")
    print("  claim and by a route it did not use, and its 100% is too strong: "
          "three cells")
    print(f"  ({', '.join(sorted(set(bad) | {'F'}))}) do not fit any placement "
          f"of the default key.")
    print("  The sheet's own SoE #5 row anticipates exactly this, calling "
          "soe5's alphabet")
    print("  'weirdly similar (but not outright identical) to the default'.")
    print()

    # ---- the owner's "missing zero-pad encoding tool" ---------------------
    print("=" * 76)
    print("THE OWNER'S 'MISSING ZERO-PAD ENCODING TOOL'")
    print("=" * 76)
    print("  The hypotheses name, for rev6, rev9 and rev10, a tool that "
          "renders bytes as")
    print("  FIXED-WIDTH ZERO-PADDED DECIMAL. rev6's ciphertext is that "
          "format in the raw,")
    print("  so the tell can be measured rather than assumed:")
    toks = r13["rev6"]["ciphertext"].split()
    widths = collections.Counter(len(t) for t in toks)
    padded = [t for t in toks if t[0] == "0"]
    print(f"    tokens                                   : {len(toks)}")
    print(f"    token widths                             : {dict(widths)}")
    print(f"    tokens a non-padding encoder would shorten: {len(padded)} "
          f"({len(padded) / len(toks):.0%})")
    print(f"    e.g. {' '.join(toks[:6])}")
    assert set(widths) == {3}
    print("  Every token is exactly three digits and none is ever two, so this "
          "is padding,")
    print("  not coincidence. rev9's chain places `decode:decimal` "
          "IMMEDIATELY AFTER its")
    print("  DES layer, so the same renderer produced rev9's intermediate; "
          "rev10 places an")
    print("  `octal` step in the same position.")
    print("  Searched and NOT FOUND. Of the toolkits enumerated in "
          "toolkit_coverage.py,")
    print("  none is known to emit fixed-width zero-padded decimal: "
          "geocachingtoolbox's")
    print("  ASCII conversion does not, and cryptii v2's Decimal format does "
          "not pad.")
    print("  This stays OPEN, and it is the most concrete searchable "
          "behaviour the")
    print("  hypotheses supply, because it is a rendering choice rather than "
          "a cipher.")
    print()

    print("=" * 76)
    print("WHAT THE SHEET SAYS ABOUT THE TWO UNSOLVED CIPHERS")
    print("=" * 76)
    tg4 = [r for r in rows if r["Cipher"].strip() == "TG #4"][0]
    print(f"  TG4 is mapped by the numbering identity that holds on The Giant. "
          f"Its row is")
    print(f"    Type {tg4['Type']!r}, Source {tg4['Encoding Source']!r}, "
          f"Confidence {tg4['Confidence']!r}")
    print(f"    {tg4['Explanation']!r}")
    assert tg4["Type"].strip() == "Unknown"
    assert tg4["Encoding Source"].strip() == "Unknown"
    print("  The community has no attribution either. That bounds what "
          "fingerprinting can")
    print("  offer for this project's actual target: there is no tool menu to "
          "narrow.")
    print()
    revknown = {mapped[i] for i in by_map["revelations"] if i in mapped}
    print(f"  REV7 is UNMAPPED. Only {len(revknown)} of the sheet's 14 "
          f"Revelations rows carry a")
    print(f"  Type at all ({', '.join(sorted(revknown))}); the other ten are "
          f"'Unknown / Unknown /")
    print("  N/A'. So whichever of those ten rows is our rev7, it attributes "
          "nothing. The")
    print("  conclusion does not depend on recovering the mapping, which is "
          "why it can be")
    print("  stated at all.")
    left = sorted((r for r in recs.values()
                   if r["map"] == "revelations" and r["id"] not in revknown),
                  key=lambda r: r["number"])
    print(f"  The same holds for all ten unmapped records: "
          f"{', '.join(r['id'] for r in left)}.")
    assert "rev7" in {r["id"] for r in left}


if __name__ == "__main__":
    main()
