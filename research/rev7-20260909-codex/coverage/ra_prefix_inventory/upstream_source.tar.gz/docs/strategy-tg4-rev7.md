# Strategy: the last two ciphers (TG4, REV7)

Written 2026-07-31, from a full read of the repo's docs, claims, and notes, plus
external validation that the artefacts are what the corpus says they are (BO3
Zombies; one unsolved cipher each on The Giant and Revelations; the 2025-26
mcrypt/tools4noobs breakthroughs are publicly documented).

## 1. Diagnosis: why ten years of math hasn't mathed

Three causes, all now visible in this repo's own record:

1. **Counts never composed.** Paper 5's worked result — the "widely believed
   exhausted" single-layer tier was 97% untried once claims were made precise —
   is the whole decade in one number. Community negatives were counts, not
   coverage sets; overlapping, unverifiable, and quietly smaller than believed.
   This repo has fixed that for its own work; the fix is the strategy's
   foundation, not its conclusion.
2. **Every real breakthrough was a tool-model discovery, not an enumeration
   win.** CFB-8 vs nCFB, null-pad-to-*smallest*, RC2 `T1=1024`, the implicit
   per-hop `b64decode`, the ASCII-`'0'` IV. Each one made a previously "covered"
   space retroactively uncovered. Enumeration only ever *confirms* a correct
   tool model; it cannot repair a wrong one.
3. **The negatives are now strong enough to invert the question.** Stop asking
   "which parameters next" and ask "which standing assumption is weakest". The
   two targets give opposite answers, and that asymmetry should drive
   everything:

| | tool model | key |
|---|---|---|
| **REV7** | 12/12 sibling confirmations (every solved Revelations modern step is tools4noobs/mcrypt) | 12/13 `Zombies` |
| **TG4** | none — the only Giant cipher with Unknown attribution; tools4noobs is a Revelations-only fingerprint | physical (the sheet label `TheGiant`) |

**So: for REV7, trust the tool and attack the workflow and the key. For TG4,
trust the key and attack the tool.**

What the accumulated REV7 negatives jointly say: under the six swept keys, a
bare listed decrypt of `stripws → reverse → hexdecode` is *not* layer 1 — the
layer-1 structural saturation (15 prims × 15 KDs × 6 modes × 6 keys × 2 IVs,
plus 3.1M classical→modern) covers every depth whose intermediates are text,
via the canary-validated charset-purity argument. What survives is exactly:
an unmodelled author workflow quirk, an unlisted primitive, a key outside the
six, or binary (identity-codec) intermediates.

## 2. REV7 plan, ordered by (prior × cheapness)

**R1. Author-workflow quirks — small, specific, and apparently unswept.**
The corpus precedent is that REV7's blocker is a copy-paste quirk of the same
kind as rev8's `insert` and rev1's double implicit decode.

- *Feed granularity.* The decrypt box base64-decodes its input, and every hex
  character is a valid base64 symbol — so the **display text itself** (stripped;
  reversed or not) is an admissible input to any hop. Skeleton:
  `text-as-b64 → b64decode → dec`. No claim covers it.
- *Reverse granularity.* Char-level reverse of a hex stream and pair-level
  (byte) reverse are **different byte streams** — char-reverse additionally
  swaps the nibbles of every byte. Verify both granularities are in the swept
  prefix domain; if only one is, there is a factor-2 dark region under every
  existing REV7 negative. Precedent: `insert` already needed `unit=hexpair`
  for exactly this class of ambiguity.
- *Direction.* If the author ever authored with the *decrypt* box, solving
  requires mcrypt **encrypt**; under CFB-8 the two differ. One flag, doubles a
  tiny sweep.

Total cost: ~10⁵ candidates. An afternoon.

**R2. Complete the mcrypt menu at layer 1.** `cast-256`, `gost`, `wake`,
`enigma`, `rijndael-192` are still absent from the 15-primitive vocabulary.
Layer-1 structural sweep per primitive is thousands of candidates.