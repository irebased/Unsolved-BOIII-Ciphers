//! ADFGX: a 5x5 Polybius square, then a columnar transposition.
//!
//! # What the corpus documented, and what had to be recovered
//!
//! rev4's whole recorded solution is one step: *"adfgx — Polybius square conversion
//! with transpose key 30957298 -> ZOMBIES"*. Three separate questions hide in that
//! sentence, and the answers are not what the note's shape suggests.
//!
//! ## 1. The transposition key **is** `ZOMBIES`; the number `30957298` is not its
//! ranking
//!
//! The `30957298 -> ZOMBIES` notation reads as *"the numeric key derived from the
//! letters `ZOMBIES`"*. That reading is **wrong**, and was checked rather than
//! assumed. `ZOMBIES` has seven letters, and ranking them alphabetically (`B`=1,
//! `E`=2, `I`=3, `M`=4, `O`=5, `S`=6, `Z`=7) gives the seven-digit column order
//! `7541326`, not the eight digits `30957298`. What *is* confirmed against the
//! plaintext is the seven-column transposition under exactly that alphabetical
//! ranking of `ZOMBIES`. `30957298` corresponds to nothing in the reproduction; it is
//! recorded here as unexplained rather than quietly reinterpreted.
//!
//! ## 2. The five coordinate symbols are **two-digit** Polybius codes, not digits
//!
//! rev4's ciphertext charset is `12345`, so the obvious reading is that the letters
//! `A D F G X` were transcribed as the digits `1..5`. That reading is also wrong. The
//! digit frequencies are nowhere near uniform (`1`:273, `2`:240, `3`:47, `4`:53,
//! `5`:47 over 660 characters), which five coordinates of a real ADFGX cannot be; and
//! 660 characters against a 165-letter plaintext is four characters per letter, not
//! two.
//!
//! Chunking the ciphertext into four-character groups settles it: there are exactly
//! **25** distinct groups, and every one is a pair drawn from the five two-character
//! tokens `{11, 14, 21, 22, 53}`. Those five tokens are precisely where `A`, `D`,
//! `F`, `G` and `X` sit in the standard I/J-merged 5x5 square:
//!
//! ```text
//!      1 2 3 4 5
//!   1  A B C D E     A = row 1 col 1 = 11
//!   2  F G H I K     D = row 1 col 4 = 14
//!   3  L M N O P     F = row 2 col 1 = 21
//!   4  Q R S T U     G = row 2 col 2 = 22
//!   5  V W X Y Z     X = row 5 col 3 = 53
//! ```
//!
//! So rev4's ciphertext is the ADFGX ciphertext with each of its five *letters* itself
//! Polybius-encoded — which is what the record's own phrase *"Polybius square
//! conversion"* denotes, applied to the cipher alphabet rather than to the plaintext.
//! The `symbols` parameter therefore takes a list of symbols of arbitrary equal width,
//! not five characters, and rev4 states `11/14/21/22/53`. Their order matters and is
//! itself a finding: ascending numeric order maps to square rows/columns 1..5.
//!
//! ## 3. The square is **unkeyed**
//!
//! ADFGX is normally keyed by a keyword. rev4's is not: the recovered square is the
//! plain alphabet with `I`/`J` merged, `ABCDEFGHIKLMNOPQRSTUVWXYZ`, which is this
//! node's default. `Q` is the one cell the reproduction cannot observe — it does not
//! occur in rev4's plaintext — so its position is inferred from the other 24 being in
//! strict alphabetical order rather than attested directly.
//!
//! ## How 1–3 were recovered
//!
//! Not by heuristic search. Enumerating every column permutation for widths 2..=9 and
//! keeping only those whose un-transposed digram stream maps to the recorded plaintext
//! **consistently and injectively** leaves **exactly one** survivor: width 7 with the
//! column order `6 4 3 0 2 1 5`, which is the alphabetical ranking of `ZOMBIES`. The
//! square then falls out of that same alignment with no further freedom. A unique
//! survivor over an exhaustively enumerated space is a derivation, not a guess.
//!
//! # 2016 vs modern: cross-checked, identical
//!
//! The project owner has since supplied 2016 Wayback sources for the CrypTool Online
//! suite (`docs/toolsites/cryptool2016/js/adfgx.js`, `CTOAdfgxAlgorithm`). Running its
//! `encodePartA`/`encodePartB` directly under Node (task scratchpad
//! `jstest/run_adfgx.js`) against the same key/square/plaintext used in
//! `matches_practicalcryptography_com_convention` below produces the *exact same*
//! ciphertext (`XGFFGGGGDDDDDGDGDDXDXGXX`) as both practicalcryptography.com's tool and
//! this node -- the same "Polybius substitution, then a stable-alphabet-rank columnar
//! transposition with left-to-right tie-breaking and the first `n % w` columns padded"
//! convention all three share. Verdict: **identical**; no change needed.

// ===========================================================================
// `square` is authoritative
// ===========================================================================
//
// `square` was already a declared parameter, but `square_of` and `encode`'s input
// filter both hardcoded `is_ascii_alphabetic`, so a square legitimately built from
// digits (or a letter/digit mix) was rejected outright even though the 25-cell
// grid itself has no structural reason to be letters-only -- `xf:adfgvx`'s 36-cell
// square already allows alphanumerics for exactly this reason. Both are now
// `is_ascii_alphanumeric`, matching `xf:adfgvx`'s convention; see
// `alphanumeric_square_is_a_working_alphabet` below for a 25-symbol square mixing
// digits and letters. The classical I/J merge fallback in `encode` is unaffected:
// it is a fixed quirk of the *letter* convention (`Q` has 25 cells, `A`-`Z` has 26),
// not something `square` generalises away, and it simply never fires for a square
// that has no letters in it.
//
// ===========================================================================
// Coverage semantics
// ===========================================================================
//
// [`Family::Xf`]: a keyed re-representation at stated parameters, exhaustive at those
// parameters. It is not a solver, it does not search, and nothing here recovers a key
// from ciphertext alone.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

/// Side of the Polybius square.
const SIDE: usize = 5;

/// The classical ADFGX cipher alphabet, and this node's default `symbols`.
pub const ADFGX_SYMBOLS: &str = "ADFGX";

/// The unkeyed I/J-merged 5x5 square, and this node's default. rev4 uses exactly
/// this: see the module docs — the absence of a keyword is a finding, since ADFGX is
/// normally keyed.
pub const SQUARE_IJ: &str = "ABCDEFGHIKLMNOPQRSTUVWXYZ";

/// rev4's recovered `symbols` value. **Reconstructed**, not recorded: the five ADFGX
/// letters appear in the ciphertext as their own Polybius coordinates.
pub const REV4_SYMBOLS: &str = "11/14/21/22/53";

const ADFGX_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req(
        "key",
        ParamType::Str,
        "columnar transposition key; column read-out order is the alphabetical rank \
         of each character, ties left to right, compared case-insensitively",
    ),
    ParamSpec::opt(
        "square",
        ParamType::Str,
        "25 distinct ASCII letters and/or digits filling the 5x5 square row-wise \
         (default \"ABCDEFGHIKLMNOPQRSTUVWXYZ\", the unkeyed I/J-merged square \
         rev4 uses); the declared square is the cipher's alphabet, so it need not \
         be all letters",
    ),
    ParamSpec::opt(
        "symbols",
        ParamType::Str,
        "the five coordinate symbols in row/column order. Either five characters \
         (default \"ADFGX\") or, for a transcription that spells them out, a \
         '/'-separated list of equal-width symbols (rev4: \"11/14/21/22/53\")",
    ),
    ParamSpec::opt(
        "direction",
        ParamType::Str,
        "\"decode\" (default): ciphertext to plaintext. \"encode\": the inverse.",
    ),
];

/// The five coordinate symbols, all of the same byte width.
struct Symbols {
    list: Vec<Vec<u8>>,
    width: usize,
}

impl Symbols {
    fn parse(spec: &str) -> Result<Self> {
        let list: Vec<Vec<u8>> = if spec.contains('/') {
            spec.split('/').map(|s| s.as_bytes().to_vec()).collect()
        } else {
            spec.as_bytes().iter().map(|&b| vec![b]).collect()
        };
        if list.len() != SIDE {
            return Err(Error::bad_param(
                "adfgx",
                "symbols",
                format!("expected {SIDE} symbols, got {}", list.len()),
            ));
        }
        let width = list[0].len();
        if width == 0 || list.iter().any(|s| s.len() != width) {
            return Err(Error::bad_param(
                "adfgx",
                "symbols",
                "every symbol must be non-empty and all must have the same width, so \
                 that the ciphertext can be tokenised unambiguously",
            ));
        }
        for (i, s) in list.iter().enumerate() {
            if list[..i].contains(s) {
                return Err(Error::bad_param(
                    "adfgx",
                    "symbols",
                    format!("symbol {:?} appears twice", String::from_utf8_lossy(s)),
                ));
            }
        }
        Ok(Symbols { list, width })
    }

    fn index_of(&self, tok: &[u8]) -> Option<usize> {
        self.list.iter().position(|s| s.as_slice() == tok)
    }
}

/// Column read-out order: `rank[p]` is the position of column `p` in the read-out.
///
/// The rank of a key character is the number of strictly smaller characters in the
/// key, plus the number of equal ones before it — the textbook rule, which is what
/// makes a key with a repeated letter well defined. Comparison is on ASCII-uppercased
/// bytes so `Zombies` and `ZOMBIES` describe the same transposition; the corpus mixes
/// both spellings of its keys and the difference is not meant to be significant.
fn ranks(key: &[u8]) -> Vec<usize> {
    let k: Vec<u8> = key.to_ascii_uppercase();
    k.iter()
        .enumerate()
        .map(|(i, c)| {
            k.iter()
                .enumerate()
                .filter(|&(j, o)| o < c || (o == c && j < i))
                .count()
        })
        .collect()
}

/// Column lengths for a `n`-symbol message in `w` columns: the first `n % w` columns
/// carry one extra symbol.
fn column_lengths(n: usize, w: usize) -> Vec<usize> {
    let (full, rem) = (n / w, n % w);
    (0..w).map(|p| full + usize::from(p < rem)).collect()
}

/// Undo the columnar transposition: slice the ciphertext into columns in read-out
/// order, then read the grid back row-wise.
fn untranspose(cipher: &[usize], rank: &[usize]) -> Vec<usize> {
    let w = rank.len();
    let lens = column_lengths(cipher.len(), w);
    let mut order: Vec<usize> = (0..w).collect();
    order.sort_by_key(|&p| rank[p]);

    let mut cols: Vec<&[usize]> = vec![&[]; w];
    let mut at = 0usize;
    for &p in &order {
        cols[p] = &cipher[at..at + lens[p]];
        at += lens[p];
    }

    let mut out = Vec::with_capacity(cipher.len());
    for row in 0..lens.iter().copied().max().unwrap_or(0) {
        for col in &cols {
            if let Some(&v) = col.get(row) {
                out.push(v);
            }
        }
    }
    out
}

/// Apply the columnar transposition: fill the grid row-wise, read columns out in rank
/// order.
fn transpose(plain: &[usize], rank: &[usize]) -> Vec<usize> {
    let w = rank.len();
    let mut cols: Vec<Vec<usize>> = vec![Vec::new(); w];
    for (i, &v) in plain.iter().enumerate() {
        cols[i % w].push(v);
    }
    let mut order: Vec<usize> = (0..w).collect();
    order.sort_by_key(|&p| rank[p]);
    let mut out = Vec::with_capacity(plain.len());
    for &p in &order {
        out.extend_from_slice(&cols[p]);
    }
    out
}

fn square_of(p: &Params) -> Result<Vec<u8>> {
    let sq: Vec<u8> = p
        .opt_str("square")
        .unwrap_or(SQUARE_IJ)
        .as_bytes()
        .to_ascii_uppercase();
    if sq.len() != SIDE * SIDE {
        return Err(Error::bad_param(
            "adfgx",
            "square",
            format!("expected {} letters, got {}", SIDE * SIDE, sq.len()),
        ));
    }
    for (i, &c) in sq.iter().enumerate() {
        // Alphanumeric, not letters-only: the square is the declared alphabet
        // (see `ADFGX_SCHEMA`'s `square` docs), and restricting it to letters
        // would silently forbid a legitimate 25-symbol alphabet mixing digits
        // in, the same generalisation `xf:adfgvx`'s square already makes.
        if !c.is_ascii_alphanumeric() {
            return Err(Error::bad_param(
                "adfgx",
                "square",
                format!("{:?} is not an ASCII letter or digit", c as char),
            ));
        }
        if sq[..i].contains(&c) {
            return Err(Error::bad_param(
                "adfgx",
                "square",
                format!("letter {:?} appears twice", c as char),
            ));
        }
    }
    Ok(sq)
}

fn key_ranks(p: &Params) -> Result<Vec<usize>> {
    let key = p.req_str("adfgx", "key")?.as_bytes();
    if key.is_empty() {
        return Err(Error::bad_param("adfgx", "key", "must not be empty"));
    }
    Ok(ranks(key))
}

/// ADFGX in both directions.
pub struct Adfgx;

impl Adfgx {
    fn decode(&self, input: &[u8], p: &Params) -> Result<Vec<u8>> {
        let syms = Symbols::parse(p.opt_str("symbols").unwrap_or(ADFGX_SYMBOLS))?;
        let square = square_of(p)?;
        let rank = key_ranks(p)?;

        let raw: Vec<u8> = input
            .iter()
            .copied()
            .filter(|b| !b.is_ascii_whitespace())
            .collect();
        if raw.len() % syms.width != 0 {
            return Err(Error::node_failed(
                "adfgx",
                format!(
                    "{} ciphertext bytes is not a whole number of {}-byte symbols",
                    raw.len(),
                    syms.width
                ),
            ));
        }
        let coords: Vec<usize> = raw
            .chunks(syms.width)
            .map(|tok| {
                syms.index_of(tok).ok_or_else(|| {
                    Error::node_failed(
                        "adfgx",
                        format!(
                            "{:?} is not one of the coordinate symbols",
                            String::from_utf8_lossy(tok)
                        ),
                    )
                })
            })
            .collect::<Result<_>>()?;

        if coords.len() % 2 != 0 {
            return Err(Error::node_failed(
                "adfgx",
                format!(
                    "{} coordinate symbols is odd, so they cannot pair into square \
                     cells",
                    coords.len()
                ),
            ));
        }
        let flat = untranspose(&coords, &rank);
        Ok(flat
            .chunks(2)
            .map(|rc| square[rc[0] * SIDE + rc[1]])
            .collect())
    }

    fn encode(&self, input: &[u8], p: &Params) -> Result<Vec<u8>> {
        let syms = Symbols::parse(p.opt_str("symbols").unwrap_or(ADFGX_SYMBOLS))?;
        let square = square_of(p)?;
        let rank = key_ranks(p)?;

        let mut coords: Vec<usize> = Vec::with_capacity(input.len() * 2);
        for &b in input {
            // Alphanumeric, matching `square_of`'s validation: a byte outside
            // the declared square's possible symbol domain (space,
            // punctuation, ...) is silently dropped, same as the classical
            // letters-only convention this generalises; a byte that looks
            // like a plausible symbol but isn't actually in *this* square is
            // still an error below, not silently dropped.
            if !b.is_ascii_alphanumeric() {
                continue;
            }
            let c = b.to_ascii_uppercase();
            // A letter absent from an I/J-merged square folds onto its partner, which
            // is the whole point of merging; anything else is an error.
            let cell = square
                .iter()
                .position(|&s| s == c)
                .or_else(|| match c {
                    b'J' => square.iter().position(|&s| s == b'I'),
                    b'I' => square.iter().position(|&s| s == b'J'),
                    _ => None,
                })
                .ok_or_else(|| {
                    Error::node_failed(
                        "adfgx",
                        format!("{:?} has no cell in this square", b as char),
                    )
                })?;
            coords.push(cell / SIDE);
            coords.push(cell % SIDE);
        }
        let mixed = transpose(&coords, &rank);
        let mut out = Vec::with_capacity(mixed.len() * syms.width);
        for c in mixed {
            out.extend_from_slice(&syms.list[c]);
        }
        Ok(out)
    }
}

impl Node for Adfgx {
    fn name(&self) -> &'static str {
        "adfgx"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/adfgx"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        ADFGX_SCHEMA
    }
    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let out = match params.opt_str("direction").unwrap_or("decode") {
            "decode" => self.decode(&input.data, params)?,
            "encode" => self.encode(&input.data, params)?,
            other => {
                return Err(Error::bad_param(
                    "adfgx",
                    "direction",
                    format!("expected \"decode\" or \"encode\", got {other:?}"),
                ))
            }
        };
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(ADFGX => || Box::new(Adfgx));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn adfgx() -> &'static dyn Node {
        registry().get("adfgx").unwrap()
    }

    /// rev4's ciphertext, verbatim from `data/revelations.json`.
    const REV4_CIPHERTEXT: &[u8] = b"142111225311221121212253141153212221221422145322141121142222111153212214221453212121215311212222\
215322221421111111111453222111212153222211111121111421222153145321112253111421211111212211212111\
222253211414112111531153211421221122212121221453532153141122222214222221112122111122211121221114\
111114222121531111145311531453141453221121142222222253532121212121212211532214145314531411112211\
142222225322211121212211535314532122212222531422532222212121531421111111221122145321222111222211\
211153141121225314111114142222225311532211142221111122222122212111115314532122221114141421212211\
141111112114212114211414112114532211142222222222211121221122111153532122222122145314";

    #[test]
    fn adfgx_is_xf_family_and_not_layer_forming() {
        let n = adfgx();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    /// Hand-computed. `A` is cell (0,0) so it encodes as `AA`, `B` is (0,1) so `AD`,
    /// giving the pre-transposition stream `AAAD`. The key `BA` has ranks `1 0`, so
    /// the two columns are read out second-then-first: column 1 is `AD`, column 0 is
    /// `AA`, and the ciphertext is `ADAA`.
    #[test]
    fn adfgx_decodes_a_hand_computed_two_column_case() {
        let out = adfgx()
            .apply(&Repr::bytes(b"ADAA".to_vec()), &params! {"key" => "BA"})
            .unwrap();
        assert_eq!(out.data, b"AB");
    }

    /// Column ranking with a repeated key letter: `AA` must rank left to right rather
    /// than tie, or the transposition is not a permutation.
    #[test]
    fn adfgx_ranks_repeated_key_letters_left_to_right() {
        assert_eq!(ranks(b"ZOMBIES"), vec![6, 4, 3, 0, 2, 1, 5]);
        assert_eq!(ranks(b"AA"), vec![0, 1]);
        assert_eq!(ranks(b"BAB"), vec![1, 0, 2]);
        // case-insensitive: the corpus spells its keys both ways
        assert_eq!(ranks(b"Zombies"), ranks(b"ZOMBIES"));
    }

    /// A message that does not fill the grid: the first `n % w` columns are the long
    /// ones, and getting that backwards misplaces every symbol after the first row.
    #[test]
    fn adfgx_handles_a_ragged_final_row() {
        let n = adfgx();
        let enc = params! {"key" => "ZOMBIES", "direction" => "encode"};
        let dec = params! {"key" => "ZOMBIES"};
        // 5 letters -> 10 symbols in 7 columns: rows of 7 and 3.
        let plain = Repr::bytes(b"HELLO".to_vec());
        let coded = n.apply(&plain, &enc).unwrap();
        assert_eq!(coded.data.len(), 10);
        assert_eq!(n.apply(&coded, &dec).unwrap().data, b"HELLO");
    }

    #[test]
    fn adfgx_round_trips_through_encode() {
        let n = adfgx();
        let enc = params! {"key" => "ZOMBIES", "direction" => "encode"};
        let dec = params! {"key" => "ZOMBIES"};
        let plain = Repr::bytes(b"ATTACKATDAWNFIVEUNITS".to_vec());
        let coded = n.apply(&plain, &enc).unwrap();
        assert!(coded
            .data
            .iter()
            .all(|c| ADFGX_SYMBOLS.contains(*c as char)));
        assert_eq!(n.apply(&coded, &dec).unwrap().data, plain.data);

        // and with rev4's two-character symbol transcription
        let enc2 = params! {"key" => "ZOMBIES", "symbols" => REV4_SYMBOLS, "direction" => "encode"};
        let dec2 = params! {"key" => "ZOMBIES", "symbols" => REV4_SYMBOLS};
        let coded2 = n.apply(&plain, &enc2).unwrap();
        assert!(coded2.data.iter().all(|c| c.is_ascii_digit()));
        assert_eq!(coded2.data.len(), plain.data.len() * 4);
        assert_eq!(n.apply(&coded2, &dec2).unwrap().data, plain.data);
    }

    /// **Recovered parameters, not documented by the corpus.** rev4's record says only
    /// "Polybius square conversion with transpose key 30957298 -> ZOMBIES". This pins
    /// the three things it does not say — that the five coordinate symbols are the
    /// two-digit codes `11 14 21 22 53` in that order, that the square is *unkeyed*,
    /// and that the transposition is 7 columns under the alphabetical ranking of
    /// `ZOMBIES` — by decoding rev4's real ciphertext. `30957298` plays no part; see
    /// the module docs.
    #[test]
    fn rev4_parameters_are_pinned_by_the_recorded_plaintext() {
        let p = params! {"key" => "ZOMBIES", "symbols" => REV4_SYMBOLS};
        let out = adfgx()
            .apply(&Repr::bytes(REV4_CIPHERTEXT.to_vec()), &p)
            .unwrap();
        let got = String::from_utf8(out.data).unwrap();
        assert!(
            got.starts_with("FROMALLOFUSATTREYARCHITHASBEENAFUNANDAMAZINGEXPERIENCE"),
            "{got}"
        );
        assert!(got.ends_with("THANKYOUFORPLAYING"), "{got}");
        assert_eq!(got.len(), 165);
    }

    /// The digit reading the ciphertext charset invites — `A D F G X` transcribed as
    /// `1 2 3 4 5` — is ruled out, not merely passed over: rev4 has an odd number of
    /// single-digit symbols, and even the 660 that do tokenise decode to noise.
    #[test]
    fn rev4_single_digit_symbol_reading_is_ruled_out() {
        let p = params! {"key" => "ZOMBIES", "symbols" => "12345"};
        let out = adfgx()
            .apply(&Repr::bytes(REV4_CIPHERTEXT.to_vec()), &p)
            .unwrap();
        let got = String::from_utf8(out.data).unwrap();
        assert_eq!(got.len(), 330);
        assert!(!got.starts_with("FROMALL"), "{got}");
    }

    /// The declared `square` is authoritative, not letters with an escape
    /// hatch: a 25-symbol square mixing all ten digits with fifteen letters
    /// round trips a digit-heavy message that a letters-only square could
    /// never have encoded in the first place.
    #[test]
    fn alphanumeric_square_is_a_working_alphabet() {
        let n = adfgx();
        let square = "0123456789ABCDEFGHIJKLMNO"; // 10 digits + 15 letters = 25
        let enc = params! {"key" => "ZOMBIES", "square" => square, "direction" => "encode"};
        let dec = params! {"key" => "ZOMBIES", "square" => square};
        let plain = Repr::bytes(b"1970".to_vec());
        let coded = n.apply(&plain, &enc).unwrap();
        // every symbol of the ciphertext is one of the five coordinate
        // symbols -- none of the digits were dropped as "not a letter".
        assert!(coded
            .data
            .iter()
            .all(|c| ADFGX_SYMBOLS.contains(*c as char)));
        assert_eq!(n.apply(&coded, &dec).unwrap().data, b"1970");
    }

    #[test]
    fn adfgx_rejects_malformed_parameters() {
        let n = adfgx();
        let d = Repr::bytes(b"ADAA".to_vec());
        for bad in [
            params! {"key" => ""},
            params! {"key" => "BA", "square" => "TOOSHORT"},
            params! {"key" => "BA", "square" => "ABCDEFGHIKLMNOPQRSTUVWXY!"}, // '!' isn't alnum

            params! {"key" => "BA", "square" => "AABCDEFGHIKLMNOPQRSTUVWXY"},
            params! {"key" => "BA", "symbols" => "ADFG"},
            params! {"key" => "BA", "symbols" => "AADFG"},
            params! {"key" => "BA", "symbols" => "1/22/3/4/5"},
            params! {"key" => "BA", "symbols" => "1//3/4/5"},
            params! {"key" => "BA", "direction" => "sideways"},
        ] {
            assert!(
                n.apply(&d, &bad).is_err(),
                "should have rejected {}",
                bad.canonical_json()
            );
        }
        // key is required
        assert!(n.apply(&d, &Params::new()).is_err());
    }

    #[test]
    fn adfgx_rejects_malformed_input() {
        let n = adfgx();
        let p = params! {"key" => "BA"};
        // a byte outside the symbol set
        assert!(n.apply(&Repr::bytes(b"ADZA".to_vec()), &p).is_err());
        // an odd number of symbols cannot pair into cells
        let e = n.apply(&Repr::bytes(b"ADA".to_vec()), &p).unwrap_err();
        assert!(e.to_string().contains("odd"), "{e}");
        // a length that is not a whole number of multi-byte symbols
        let e = n
            .apply(
                &Repr::bytes(b"11142".to_vec()),
                &params! {"key" => "BA", "symbols" => REV4_SYMBOLS},
            )
            .unwrap_err();
        assert!(e.to_string().contains("whole number"), "{e}");
    }

    /// Whitespace in the ciphertext is ignored, so a grouped transcription decodes
    /// identically to a flat one.
    /// Cross-check against practicalcryptography.com's own ADFGX tool
    /// (`http://practicalcryptography.com/ciphers/classical-era/adfgx/`), whose
    /// `Encrypt()`/`Decrypt()` were extracted verbatim and executed under Node
    /// (stubbing `document`) to produce this vector: keysquare
    /// `phqgiumeaylnofdxkrcvstzwb`, keyword `GERMAN`, plaintext `ATTACKATDAWN`
    /// encrypts to `XGFFGGGGDDDDDGDGDDXDXGXX`. PC's page lowercases its own
    /// output; this node uppercases by construction, so the comparison is on
    /// the uppercased text. The columnar-transposition convention (row-major
    /// grid fill, alphabetical-rank column read-out with left-to-right ties,
    /// first `n % w` *physical* columns carrying the extra symbol) and the
    /// unkeyed-square-as-raw-25-letters convention are both bit-for-bit the
    /// same as this node's, so `xf:adfgx` is verified to emulate
    /// practicalcryptography.com's tool, not just the corpus's rev4 usage.
    #[test]
    fn matches_practicalcryptography_com_convention() {
        let n = adfgx();
        let square = "PHQGIUMEAYLNOFDXKRCVSTZWB";
        let p = params! {"key" => "GERMAN", "square" => square};
        let out = n
            .apply(
                &Repr::bytes(b"XGFFGGGGDDDDDGDGDDXDXGXX".to_vec()),
                &p,
            )
            .unwrap();
        assert_eq!(out.data, b"ATTACKATDAWN");

        // and the encrypt-direction test helper round-trips it
        let enc = n
            .apply(
                &Repr::bytes(b"ATTACKATDAWN".to_vec()),
                &params! {"key" => "GERMAN", "square" => square, "direction" => "encode"},
            )
            .unwrap();
        assert_eq!(enc.data, b"XGFFGGGGDDDDDGDGDDXDXGXX");
    }

    /// Cross-check against the **2016** CrypTool Online ADFGX tool
    /// (`docs/toolsites/cryptool2016/js/adfgx.js`, `CTOAdfgxAlgorithm.encodePartA`/
    /// `encodePartB`), run directly under Node (task scratchpad `jstest/run_adfgx.js`)
    /// against the exact same key/square/plaintext as
    /// `matches_practicalcryptography_com_convention` above: it produces the identical
    /// ciphertext, confirming this node also emulates the 2016 CrypTool Online tool,
    /// not just practicalcryptography.com's.
    #[test]
    fn matches_2016_cryptool_online_adfgx_js() {
        let n = adfgx();
        let square = "PHQGIUMEAYLNOFDXKRCVSTZWB";
        let p = params! {"key" => "GERMAN", "square" => square};
        let out = n
            .apply(&Repr::bytes(b"XGFFGGGGDDDDDGDGDDXDXGXX".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"ATTACKATDAWN");
    }

    #[test]
    fn adfgx_skips_whitespace() {
        let n = adfgx();
        let p = params! {"key" => "BA"};
        assert_eq!(
            n.apply(&Repr::bytes(b"AD AA\n".to_vec()), &p).unwrap().data,
            n.apply(&Repr::bytes(b"ADAA".to_vec()), &p).unwrap().data
        );
    }
}
