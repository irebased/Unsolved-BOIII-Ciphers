//! rumkin.com's Railfence and One-Time Pad, ported from the recovered
//! `railfence.js` / `otp.js`.
//!
//! # Two behaviours a "sensible" implementation would not have
//!
//! 1. **Railfence refuses when there is not enough text.** The site returns the
//!    *string* `"You need less rails or more text."` when `rails >= text.length`,
//!    and `"You must have at least 2 rails..."` when `rails < 2` — i.e. the error
//!    lands in the output box as if it were ciphertext. This node raises a real
//!    error instead, but the *boundary* is reproduced exactly: `rails == len` is
//!    refused, `rails == len - 1` is allowed. See `railfence_boundary_matches_site`.
//!
//! 2. **A short one-time pad silently becomes no encryption at all.** `otp.js` has
//!    `if (pad.length == 0) pad = "AAAAAAAA";` — once the pad runs out it is refilled
//!    with `A`s, which shift by zero. So text beyond the pad's length passes through
//!    *in clear* rather than the tool refusing. That is a genuine confidentiality
//!    trap in the original and is reproduced here, with a test that pins it
//!    (`otp_exhausted_pad_leaves_plaintext_in_clear`).
//!
//! # Railfence's offset is a position in the zigzag, not a rail number
//!
//! The rail sequence is `0,1,..,r-1,r-2,..,1` (length `2r-2`) and `offset` indexes
//! *that* cycle, so it can start mid-descent. It is normalised into `[0, 2r-2)`,
//! including negatives.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: transforms at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const RAIL: &str = "rumkin_railfence";
const OTP: &str = "rumkin_otp";

fn dir(node: &'static str, params: &Params) -> Result<bool> {
    match params.opt_str("direction").unwrap_or("decrypt") {
        "encrypt" => Ok(true),
        "decrypt" => Ok(false),
        o => Err(Error::bad_param(node, "direction", format!("got {o:?}"))),
    }
}

/// The zigzag rail sequence: `0,1,...,r-1,r-2,...,1`, length `2r-2`.
fn rail_cycle(r: usize) -> Vec<usize> {
    let mut o: Vec<usize> = (0..r).collect();
    for j in 0..r.saturating_sub(2) {
        o.push(r - (j + 2));
    }
    o
}

const RAIL_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("rails", ParamType::Int, "number of rails (>= 2, and < text length)"),
    ParamSpec::opt("offset", ParamType::Int, "starting position in the zigzag cycle \
                                              (normalised into 0..2*rails-2)"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// `railfence.js`'s `Railfence(encdec, text, rails, offset)`.
pub struct RumkinRailfence;

impl Node for RumkinRailfence {
    fn name(&self) -> &'static str { RAIL }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_misc(railfence.js)" }
    fn params_schema(&self) -> &'static [ParamSpec] { RAIL_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let t = &input.data;
        let rails = params.req_i64(RAIL, "rails")?;
        if rails < 2 {
            return Err(Error::bad_param(
                RAIL, "rails",
                "the site answers \"You must have at least 2 rails.\" — 2 is the minimum",
            ));
        }
        let r = rails as usize;
        if r >= t.len() {
            return Err(Error::node_failed(
                RAIL,
                format!(
                    "the site answers \"You need less rails or more text.\" when rails >= \
                     text length; got rails={r} and {} characters",
                    t.len()
                ),
            ));
        }
        let period = 2 * r - 2;
        let mut off = params.opt_i64("offset", 0);
        while off < 0 {
            off += period as i64;
        }
        let off = (off as usize) % period;
        let cycle = rail_cycle(r);

        if dir(RAIL, params)? {
            let mut out_a: Vec<Vec<u8>> = vec![Vec::new(); r];
            let mut o = off;
            for &b in t.iter() {
                out_a[cycle[o]].push(b);
                o = (o + 1) % period;
            }
            Ok(Repr::new(out_a.concat(), Display::Bytes))
        } else {
            // which rail each output position belongs to, then refill in rail order
            let mut which = Vec::with_capacity(t.len());
            let mut o = off;
            for _ in 0..t.len() {
                which.push(cycle[o]);
                o = (o + 1) % period;
            }
            let mut counts = vec![0usize; r];
            for &w in which.iter() {
                counts[w] += 1;
            }
            let mut rails_buf: Vec<&[u8]> = Vec::with_capacity(r);
            let mut rest: &[u8] = t;
            for c in counts.iter() {
                let (a, b) = rest.split_at((*c).min(rest.len()));
                rails_buf.push(a);
                rest = b;
            }
            let mut taken = vec![0usize; r];
            let mut out = Vec::with_capacity(t.len());
            for &w in which.iter() {
                out.push(rails_buf[w][taken[w]]);
                taken[w] += 1;
            }
            Ok(Repr::new(out, Display::Bytes))
        }
    }
}

const OTP_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("pad", ParamType::Str, "the pad; non-letters are stripped, case ignored"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// `otp.js`'s `OneTimePad(encdec, text, key)`.
///
/// Letters only; case of the *text* is preserved, case of the pad is not. Non-letters
/// pass through and do not consume the pad.
pub struct RumkinOtp;

impl Node for RumkinOtp {
    fn name(&self) -> &'static str { OTP }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_misc(otp.js,refill-AAAAAAAA)" }
    fn params_schema(&self) -> &'static [ParamSpec] { OTP_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let ed: i64 = if dir(OTP, params)? { 1 } else { -1 };
        let mut pad: Vec<u8> = params
            .req_str(OTP, "pad")?
            .bytes()
            .map(|b| b.to_ascii_uppercase())
            .filter(|b| b.is_ascii_uppercase())
            .collect();
        let mut out = Vec::with_capacity(input.data.len());
        for &c in input.data.iter() {
            let base = if c.is_ascii_uppercase() {
                b'A'
            } else if c.is_ascii_lowercase() {
                b'a'
            } else {
                out.push(c);
                continue;
            };
            if pad.is_empty() {
                // the site's literal refill: an exhausted pad shifts by zero
                pad = b"AAAAAAAA".to_vec();
            }
            let v = (c - base) as i64 + ed * (pad[0] - b'A') as i64;
            out.push(base + (v.rem_euclid(26)) as u8);
            pad.remove(0);
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(RUMKIN_RAILFENCE => || Box::new(RumkinRailfence));
register_node!(RUMKIN_OTP => || Box::new(RumkinOtp));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn n(name: &str) -> &'static dyn Node { registry().get(name).unwrap() }

    #[test]
    fn both_are_xf() {
        for x in [RAIL, OTP] { assert_eq!(n(x).family(), Family::Xf); }
    }

    #[test]
    fn rail_cycle_is_the_zigzag() {
        assert_eq!(rail_cycle(3), vec![0, 1, 2, 1]);
        assert_eq!(rail_cycle(4), vec![0, 1, 2, 3, 2, 1]);
    }

    /// Classic 3-rail vector: WEAREDISCOVEREDFLEEATONCE -> WECRLTEERDSOEEFEAOCAIVDEN
    #[test]
    fn railfence_textbook_vector() {
        let out = n(RAIL)
            .apply(&Repr::bytes(b"WEAREDISCOVEREDFLEEATONCE".to_vec()),
                   &params! {"rails" => 3i64, "direction" => "encrypt"})
            .unwrap();
        assert_eq!(out.data, b"WECRLTEERDSOEEFEAOCAIVDEN");
    }

    #[test]
    fn railfence_round_trips_at_several_rails_and_offsets() {
        let msg = b"WEAREDISCOVEREDFLEEATONCE".to_vec();
        for rails in [2i64, 3, 5, 7] {
            for offset in [0i64, 1, 3, -2] {
                let p = params! {"rails" => rails, "offset" => offset};
                let e = n(RAIL).apply(&Repr::bytes(msg.clone()), &p.clone().set("direction","encrypt")).unwrap();
                let d = n(RAIL).apply(&e, &p).unwrap();
                assert_eq!(d.data, msg, "rails={rails} offset={offset}");
            }
        }
    }

    /// The site's refusal boundary, exactly: rails == len is refused, len-1 is fine.
    #[test]
    fn railfence_boundary_matches_site() {
        let five = Repr::bytes(b"ABCDE".to_vec());
        assert!(n(RAIL).apply(&five, &params! {"rails" => 5i64}).is_err());
        assert!(n(RAIL).apply(&five, &params! {"rails" => 4i64}).is_ok());
        assert!(n(RAIL).apply(&five, &params! {"rails" => 1i64}).is_err());
    }

    #[test]
    fn otp_round_trips_and_preserves_text_case() {
        let p = params! {"pad" => "XMCKL"};
        let e = n(OTP)
            .apply(&Repr::bytes(b"Hello".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(e.data, b"Eqnvz");
        assert_eq!(n(OTP).apply(&e, &p).unwrap().data, b"Hello");
    }

    /// The trap: once the pad is exhausted the site refills with `A`s, so the tail of
    /// the message is emitted UNENCRYPTED. Pinned so nobody "fixes" it by accident.
    #[test]
    fn otp_exhausted_pad_leaves_plaintext_in_clear() {
        let e = n(OTP)
            .apply(&Repr::bytes(b"AAAAAAAA".to_vec()),
                   &params! {"pad" => "B", "direction" => "encrypt"})
            .unwrap();
        // first letter shifted by B(=1), the remaining seven shifted by zero
        assert_eq!(e.data, b"BAAAAAAA");
    }

    #[test]
    fn otp_non_letters_pass_through_without_consuming_the_pad() {
        let e = n(OTP)
            .apply(&Repr::bytes(b"A-A".to_vec()),
                   &params! {"pad" => "BC", "direction" => "encrypt"})
            .unwrap();
        assert_eq!(e.data, b"B-C", "the '-' must not eat a pad character");
    }
}
