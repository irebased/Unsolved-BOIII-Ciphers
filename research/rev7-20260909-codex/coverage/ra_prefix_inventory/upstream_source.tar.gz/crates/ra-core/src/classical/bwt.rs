//! Burrows-Wheeler transform, matching geocachingtoolbox.com's implementation.
//!
//! The site's encoder appends a user-settable sentinel (`eof`, default `|`) to
//! the plaintext, forms every rotation, sorts the rotations in plain code-point
//! order (JS's default `Array.prototype.sort` on strings), and emits the last
//! column of the sorted matrix. There is no separately stored rotation index —
//! the sentinel carries that information, since it is unique and its position in
//! the sorted matrix pins down where the original string starts.
//!
//! This crate is decrypt-direction, so [`Bwt`] performs the **inverse** transform:
//! given the last column, reconstruct the original text. It is computed via the
//! O(n log n) LF-mapping walk (the standard BWT-inversion technique), not the
//! site's O(n^2 log n) prepend-and-sort — but [`inverse_bwt`] is proven to match
//! the site's algorithm exactly for every well-formed input; see the tests below,
//! which round-trip [`encode`] (a test-only re-implementation of the site's
//! encoder) through it.
//!
//! # Rejecting malformed input
//!
//! The site's decoder happily produces a periodic repetition of a substring when
//! fed a string that isn't an actual BWT output (i.e. whose LF-mapping does not
//! form a single n-cycle) — garbage that would flood a sweep with noise rather
//! than fail loudly. This node instead returns an error unless the input
//! contains exactly one `eof` byte *and* the LF-mapping is a single cycle
//! spanning every position. Both hold for any output that genuinely came from a
//! BWT encoding of some string over this sentinel.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

const BWT_SCHEMA: &[ParamSpec] = &[ParamSpec::opt(
    "eof",
    ParamType::Str,
    "sentinel byte marking the end of the original text in the site's rotation \
     matrix (default: '|'); must be exactly one byte",
)];

const DEFAULT_EOF: u8 = b'|';

/// Inverse Burrows-Wheeler transform via LF-mapping.
///
/// `l` is the BWT output (the sorted matrix's last column), `eof` the sentinel
/// byte the encoder appended before rotating. Returns [`Error::NodeFailed`]
/// unless `l` contains exactly one `eof` byte and the resulting LF-mapping is a
/// single cycle of length `l.len()` — both properties every well-formed BWT
/// output has, and whose absence means `l` did not actually come from a BWT
/// encoding over this sentinel.
pub fn inverse_bwt(l: &[u8], eof: u8) -> Result<Vec<u8>> {
    let n = l.len();
    if n == 0 {
        return Err(Error::node_failed("bwt", "input is empty"));
    }
    let eof_count = l.iter().filter(|&&b| b == eof).count();
    if eof_count != 1 {
        return Err(Error::node_failed(
            "bwt",
            format!(
                "input must contain exactly one eof byte (0x{eof:02x}); found {eof_count}"
            ),
        ));
    }

    // rank[i] = how many times l[i] has already occurred in l[..i] — its
    // occurrence rank, read in the order this last column actually appears.
    let mut counts = [0usize; 256];
    let mut rank = vec![0usize; n];
    for (i, &b) in l.iter().enumerate() {
        rank[i] = counts[b as usize];
        counts[b as usize] += 1;
    }
    // base[b] = the offset of byte b's block in F, the sorted first column.
    let mut base = [0usize; 256];
    let mut acc = 0usize;
    for (b, &c) in counts.iter().enumerate() {
        base[b] = acc;
        acc += c;
    }
    let mut f = l.to_vec();
    f.sort_unstable();

    // LF-mapping: row lf[i] in F holds the same rotation-occurrence as row i's
    // last column entry l[i]. Following it steps one position backwards through
    // the original (pre-rotation, pre-sentinel-append) circular string.
    let lf: Vec<usize> = (0..n).map(|i| base[l[i] as usize] + rank[i]).collect();

    // The row whose last column is the sentinel is the row whose first column
    // holds position 0 of the original augmented string (text + eof) — that is
    // where the walk below starts.
    let i0 = l
        .iter()
        .position(|&b| b == eof)
        .expect("checked above: exactly one eof byte");

    let mut visited = vec![false; n];
    let mut chars_at_pos = vec![0u8; n];
    let mut i = i0;
    for k in 0..n {
        if visited[i] {
            return Err(Error::node_failed(
                "bwt",
                format!(
                    "input is not a well-formed BWT: the LF-mapping is not a \
                     single {n}-cycle (it closed after {k} of {n} positions)"
                ),
            ));
        }
        visited[i] = true;
        // Step k of the walk visits the row holding augmented-string position
        // (n - k) mod n; position n-1 is the sentinel itself.
        let pos = (n - k) % n;
        chars_at_pos[pos] = f[i];
        i = lf[i];
    }

    // Position n-1 is the sentinel; positions 0..n-1 are the original text.
    Ok(chars_at_pos[..n - 1].to_vec())
}

/// Forward Burrows-Wheeler transform, matching the site's `ENCODE` exactly.
/// Test-only: this crate is decrypt-direction, so nothing but the test suite
/// (proving [`inverse_bwt`] agrees with the site's algorithm) needs it.
#[cfg(test)]
fn encode(text: &[u8], eof: u8) -> Vec<u8> {
    let mut chars = text.to_vec();
    chars.push(eof);
    let n = chars.len();
    let mut rotations: Vec<Vec<u8>> = (0..n)
        .map(|i| {
            let mut r = chars[i..].to_vec();
            r.extend_from_slice(&chars[..i]);
            r
        })
        .collect();
    rotations.sort();
    rotations.iter().map(|r| r[r.len() - 1]).collect()
}

/// Burrows-Wheeler transform, decrypting: reconstructs the original text from
/// the transform's last column.
pub struct Bwt;

impl Node for Bwt {
    fn name(&self) -> &'static str {
        "bwt"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        BWT_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let eof = match params.opt_str("eof") {
            None => DEFAULT_EOF,
            Some(s) => {
                let bytes = s.as_bytes();
                if bytes.len() != 1 {
                    return Err(Error::bad_param(
                        "bwt",
                        "eof",
                        format!("must be exactly one byte, got {:?} ({} bytes)", s, bytes.len()),
                    ));
                }
                bytes[0]
            }
        };
        let out = inverse_bwt(&input.data, eof)?;
        Ok(Repr::new(out, input.display))
    }
}

register_node!(BWT => || Box::new(Bwt));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    const VECTORS: &[(&str, &str)] = &[
        ("banana", "bnn|aaa"),
        ("BLACKOPS3", "SL|ACBKOP3"),
        ("The quick brown fox", "kne| ih Tucwrf bqoox"),
        (
            "kCmlgFi6GUJNgkNI1Q41fbfy",
            "I4Qikg6NUkJ1Gf1blNF|gmCfy",
        ),
    ];

    /// Ground truth computed from the site's exact algorithm (see task spec).
    #[test]
    fn encode_matches_site_ground_truth_vectors() {
        for (plain, want) in VECTORS {
            let got = encode(plain.as_bytes(), DEFAULT_EOF);
            assert_eq!(got, want.as_bytes(), "encode({plain:?})");
        }
    }

    /// `inverse_bwt` must agree with the site's O(n^2 log n) algorithm for every
    /// well-formed input — proven here by round-tripping through the test-only
    /// `encode`, which is a direct transliteration of the site's `ENCODE`.
    #[test]
    fn inverse_bwt_round_trips_encode_for_ground_truth_vectors() {
        for (plain, encoded) in VECTORS {
            let l = encode(plain.as_bytes(), DEFAULT_EOF);
            assert_eq!(l, encoded.as_bytes(), "sanity: encode({plain:?})");
            let recovered = inverse_bwt(&l, DEFAULT_EOF).unwrap();
            assert_eq!(recovered, plain.as_bytes(), "inverse_bwt(encode({plain:?}))");
        }
    }

    /// Broader agreement check: `inverse_bwt` must match the site's own O(n^2
    /// log n) decoder (the `stringArray` prepend-and-sort loop from the task
    /// spec), not just recover the original plaintext, over a range of inputs
    /// including ones with repeated characters and non-default sentinels.
    #[test]
    fn inverse_bwt_matches_sites_decode_algorithm_directly() {
        fn site_decode(l: &[u8], eof: u8) -> Vec<u8> {
            let n = l.len();
            let mut string_array: Vec<Vec<u8>> = vec![Vec::new(); n];
            for _ in 0..n {
                for i in 0..n {
                    let mut row = vec![l[i]];
                    row.extend_from_slice(&string_array[i]);
                    string_array[i] = row;
                }
                string_array.sort();
            }
            for row in &string_array {
                if *row.last().unwrap() == eof {
                    return row[..row.len() - 1].to_vec();
                }
            }
            panic!("site decode found no row ending in eof");
        }

        let samples: &[(&[u8], u8)] = &[
            (b"banana", b'|'),
            (b"BLACKOPS3", b'|'),
            (b"The quick brown fox", b'|'),
            (b"kCmlgFi6GUJNgkNI1Q41fbfy", b'|'),
            (b"aaaaaaaa", b'|'),
            (b"mississippi", b'#'),
            (b"", b'|'),
            (b"x", b'|'),
        ];
        for &(plain, eof) in samples {
            let l = encode(plain, eof);
            let want = site_decode(&l, eof);
            let got = inverse_bwt(&l, eof).unwrap();
            assert_eq!(got, want, "plain={plain:?} eof={eof:?}");
            assert_eq!(got, plain, "plain={plain:?} eof={eof:?}");
        }
    }

    #[test]
    fn bwt_node_decodes_default_eof() {
        let n = registry().get("bwt").unwrap();
        let p = params! {};
        let out = n.apply(&Repr::bytes(b"bnn|aaa".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"banana");
    }

    #[test]
    fn bwt_node_decodes_custom_eof() {
        let n = registry().get("bwt").unwrap();
        let l = encode(b"mississippi", b'#');
        let p = params! {"eof" => "#"};
        let out = n.apply(&Repr::bytes(l), &p).unwrap();
        assert_eq!(out.data, b"mississippi");
    }

    #[test]
    fn bwt_node_rejects_missing_eof_byte() {
        let n = registry().get("bwt").unwrap();
        let p = params! {};
        let err = n.apply(&Repr::bytes(b"nopipehere".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::NodeFailed { .. }), "{err}");
    }

    #[test]
    fn bwt_node_rejects_multiple_eof_bytes() {
        let n = registry().get("bwt").unwrap();
        let p = params! {};
        let err = n
            .apply(&Repr::bytes(b"b|nn|aaa".to_vec()), &p)
            .unwrap_err();
        assert!(matches!(err, Error::NodeFailed { .. }), "{err}");
    }

    #[test]
    fn bwt_node_rejects_multi_byte_eof_param() {
        let n = registry().get("bwt").unwrap();
        let p = params! {"eof" => "||"};
        let err = n.apply(&Repr::bytes(b"bnn|aaa".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    /// Regression: the TG4 ciphertext with a pipe at offset 90 is not a
    /// well-formed BWT of anything — its LF-mapping decomposes into 8 disjoint
    /// cycles rather than one covering all 192 positions — so it must be
    /// rejected rather than let the sweep evaluate whatever the walk produces.
    #[test]
    fn bwt_node_rejects_tg4_multi_cycle_ciphertext() {
        let n = registry().get("bwt").unwrap();
        let p = params! {};
        let ct = b"kCmlgFi6GUJNgkNI1Q41fbfyLoCFTCvlqkZil0KIAXAzP1U1uy1BE4UfPBfpKmmLObjYnQNRBaPtKiVWzc5A4v0w3x|e8FOhAGJZ7g4in0wndJxMOvO3dc1M82at2T6935roTqyWDgtGD/hwwRF3oHqFM5Vcw1JtlNbsgWRm4o4/quEDkZ7x1B275bX3/Fo1";
        assert_eq!(ct.len(), 192);
        let err = n.apply(&Repr::bytes(ct.to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::NodeFailed { .. }), "{err}");
    }

    #[test]
    fn bwt_preserves_display() {
        let n = registry().get("bwt").unwrap();
        let p = params! {};
        let out = n
            .apply(&Repr::new(b"bnn|aaa".to_vec(), Display::Hex), &p)
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn bwt_is_xf_family_and_not_layer_forming() {
        let n = registry().get("bwt").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
