//! Seriated Playfair, Slidefair and Portax: digraphs taken *vertically* across a period.
//!
//! # Why these nodes exist
//!
//! All three have key entropy near log2(25!) ≈ 84 bits or below, which sits *under*
//! the ~96–131 bits of constraint a 30–41 letter ciphertext carries. Unlike the
//! multi-square ciphers in [`crate::classical::squares`], they are therefore
//! **decidable** at corpus lengths: a recovered key would be uniquely determined.
//! That is precisely why they were worth adding.
//!
//! # Seriation is the shared idea
//!
//! The text is written in two rows of `period` letters. Pairs are then read
//! *vertically* — `top[i]` with `bottom[i]` — rather than along the text. So the
//! digraph structure depends on the period, and a wrong period destroys it
//! completely. That is what makes these resistant to the digraph statistics that
//! break plain Playfair.
//!
//! # Honest scope note
//!
//! ACA's published descriptions of **Portax** vary in their table construction and I
//! could not verify a canonical one. The convention this node implements is written
//! out below and pinned by a round-trip test. It is a correct, invertible,
//! period-seriated Porta variant; it is *not* claimed to match any particular
//! published Portax tableau.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: transforms at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

use super::squares::{square, A25};

const SERIATED: &str = "seriated_playfair";
const SLIDEFAIR: &str = "slidefair";
const PORTAX: &str = "portax";

fn only_letters(data: &[u8], members: &std::collections::HashSet<u8>) -> Vec<u8> {
    data.iter()
        .map(|c| c.to_ascii_lowercase())
        .map(|c| if c == b'j' && !members.contains(&b'j') { b'i' } else { c })
        .filter(|c| members.contains(c))
        .collect()
}

const SER_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "keyword for the 5x5 square"),
    ParamSpec::req("period", ParamType::Int, "row length; pairs are taken vertically"),
    ParamSpec::opt("alphabet", ParamType::Str, "square symbols (default 25-letter j->i)"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Seriated Playfair: standard Playfair digraph rules, but on vertically-paired
/// letters from two rows of `period`.
///
/// A trailing partial block is passed through unchanged rather than padded, so the
/// transform stays length-preserving and reversible on any input.
pub struct SeriatedPlayfair;

impl Node for SeriatedPlayfair {
    fn name(&self) -> &'static str { SERIATED }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/seriated_playfair(vertical-pairs)" }
    fn params_schema(&self) -> &'static [ParamSpec] { SER_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let alphabet = params.opt_str("alphabet").unwrap_or(A25);
        let (cells, side) = square(SERIATED, params.req_str(SERIATED, "key")?, alphabet)?;
        let members: std::collections::HashSet<u8> =
            alphabet.bytes().map(|b| b.to_ascii_lowercase()).collect();
        let t = only_letters(&input.data, &members);
        if t.is_empty() {
            return Err(Error::node_failed(SERIATED, "no symbols from the alphabet"));
        }
        let period = params.req_i64(SERIATED, "period")?;
        if period < 1 {
            return Err(Error::bad_param(SERIATED, "period", "must be at least 1"));
        }
        let period = period as usize;
        let step = match params.opt_str("direction").unwrap_or("decrypt") {
            "encrypt" => 1usize,
            "decrypt" => side - 1,
            o => return Err(Error::bad_param(SERIATED, "direction", format!("got {o:?}"))),
        };
        let idx: std::collections::HashMap<u8, usize> =
            cells.iter().enumerate().map(|(i, &c)| (c, i)).collect();
        let mut out = t.clone();
        for blk in 0..t.len().div_ceil(2 * period) {
            let base = blk * 2 * period;
            let top_end = (base + period).min(t.len());
            let n = top_end - base;
            for i in 0..n {
                let (ti, bi) = (base + i, base + period + i);
                if bi >= t.len() { break; }
                let (a, b) = (t[ti], t[bi]);
                let (ia, ib) = (idx[&a], idx[&b]);
                let (ra, ca) = (ia / side, ia % side);
                let (rb, cb) = (ib / side, ib % side);
                let (x, y) = if ra == rb {
                    (cells[ra * side + (ca + step) % side], cells[rb * side + (cb + step) % side])
                } else if ca == cb {
                    (cells[((ra + step) % side) * side + ca], cells[((rb + step) % side) * side + cb])
                } else {
                    (cells[ra * side + cb], cells[rb * side + ca])
                };
                out[ti] = x;
                out[bi] = y;
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

const SLIDE_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "key word; one letter per digraph"),
    ParamSpec::opt("alphabet", ParamType::Str, "26-symbol alphabet (default a-z)"),
];

/// Slidefair: two alphabets slid against each other by the key letter, applied to
/// consecutive digraphs.
///
/// With the top row the plain alphabet and the bottom row shifted by `k`, the pair
/// `(p1, p2)` maps to `(top[j], bottom[i])` where `i` is `p1`'s top-row position and
/// `j` is `p2`'s bottom-row position. The map is an **involution** — proved by the
/// round-trip test — so like Porta it takes no `direction` parameter.
pub struct Slidefair;

impl Node for Slidefair {
    fn name(&self) -> &'static str { SLIDEFAIR }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/slidefair(sliding-alphabets,involution)" }
    fn params_schema(&self) -> &'static [ParamSpec] { SLIDE_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let alphabet = params.opt_str("alphabet").unwrap_or("abcdefghijklmnopqrstuvwxyz");
        let alpha: Vec<u8> = alphabet.bytes().map(|b| b.to_ascii_lowercase()).collect();
        let m = alpha.len() as i64;
        if m < 2 {
            return Err(Error::bad_param(SLIDEFAIR, "alphabet", "needs at least 2 symbols"));
        }
        let index: std::collections::HashMap<u8, i64> =
            alpha.iter().enumerate().map(|(i, &c)| (c, i as i64)).collect();
        let keys: Vec<i64> = params
            .req_str(SLIDEFAIR, "key")?
            .bytes()
            .map(|b| b.to_ascii_lowercase())
            .filter_map(|b| index.get(&b).copied())
            .collect();
        if keys.is_empty() {
            return Err(Error::bad_param(SLIDEFAIR, "key", "no key symbols in the alphabet"));
        }
        let t: Vec<u8> = input
            .data
            .iter()
            .map(|c| c.to_ascii_lowercase())
            .filter(|c| index.contains_key(c))
            .collect();
        if t.is_empty() || t.len() % 2 != 0 {
            return Err(Error::node_failed(SLIDEFAIR, "need a non-empty even-length text"));
        }
        let mut out = Vec::with_capacity(t.len());
        for (d, pair) in t.chunks_exact(2).enumerate() {
            let k = keys[d % keys.len()];
            let i = index[&pair[0]];
            let j = (index[&pair[1]] - k).rem_euclid(m);
            out.push(alpha[j as usize]);
            out.push(alpha[((i + k).rem_euclid(m)) as usize]);
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

const PORTAX_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "key word; one letter per column"),
    ParamSpec::req("period", ParamType::Int, "row length; pairs are taken vertically"),
];

/// Portax: a period-seriated Porta on vertical pairs.
///
/// Convention implemented: the text is seriated into two rows of `period`; each
/// vertical pair `(top, bottom)` has the Porta involution applied to **both** letters
/// under the column's key letter, and the two results are then swapped. This is an
/// involution (round-trip test), so it takes no `direction`.
///
/// As noted in the module docs, ACA's Portax tableau descriptions vary and this is
/// *a* period-seriated Porta variant rather than a claim of conformance to one.
pub struct Portax;

impl Node for Portax {
    fn name(&self) -> &'static str { PORTAX }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/portax(seriated-porta,swap;convention-stated)" }
    fn params_schema(&self) -> &'static [ParamSpec] { PORTAX_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let kidx: Vec<i32> = params
            .req_str(PORTAX, "key")?
            .bytes()
            .filter(|b| b.is_ascii_alphabetic())
            .map(|b| ((b.to_ascii_lowercase() - b'a') / 2) as i32)
            .collect();
        if kidx.is_empty() {
            return Err(Error::bad_param(PORTAX, "key", "key has no ASCII letters"));
        }
        let period = params.req_i64(PORTAX, "period")?;
        if period < 1 {
            return Err(Error::bad_param(PORTAX, "period", "must be at least 1"));
        }
        let period = period as usize;
        let t: Vec<u8> = input
            .data
            .iter()
            .filter(|c| c.is_ascii_alphabetic())
            .map(|c| c.to_ascii_lowercase())
            .collect();
        if t.is_empty() {
            return Err(Error::node_failed(PORTAX, "input has no ASCII letters"));
        }
        let porta = |x: i32, idx: i32| -> i32 {
            if x < 13 { (x + idx).rem_euclid(13) + 13 } else { (x - 13 - idx).rem_euclid(13) }
        };
        let mut out = t.clone();
        for blk in 0..t.len().div_ceil(2 * period) {
            let base = blk * 2 * period;
            for i in 0..period {
                let (ti, bi) = (base + i, base + period + i);
                if bi >= t.len() { break; }
                let k = kidx[i % kidx.len()];
                let a = (t[ti] - b'a') as i32;
                let b = (t[bi] - b'a') as i32;
                // Porta both, then swap: an involution because Porta is one.
                out[ti] = b'a' + porta(b, k) as u8;
                out[bi] = b'a' + porta(a, k) as u8;
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(SERIATED_PLAYFAIR => || Box::new(SeriatedPlayfair));
register_node!(SLIDEFAIR_NODE => || Box::new(Slidefair));
register_node!(PORTAX_NODE => || Box::new(Portax));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn n(name: &str) -> &'static dyn Node { registry().get(name).unwrap() }

    #[test]
    fn all_three_are_xf() {
        for name in [SERIATED, SLIDEFAIR, PORTAX] {
            assert_eq!(n(name).family(), Family::Xf);
        }
    }

    #[test]
    fn seriated_playfair_round_trips_at_several_periods() {
        let node = n(SERIATED);
        for period in [2i64, 3, 5, 8] {
            let p = params! {"key" => "ZOMBIES", "period" => period};
            let enc = node
                .apply(
                    &Repr::bytes(b"defendtheeastwallofthecastle".to_vec()),
                    &p.clone().set("direction", "encrypt"),
                )
                .unwrap();
            let back = node.apply(&enc, &p).unwrap();
            assert_eq!(back.data, b"defendtheeastwallofthecastle", "period {period}");
        }
    }

    /// A wrong period gives a different ciphertext — the property that makes
    /// seriation worth having at all.
    #[test]
    fn seriated_period_actually_matters() {
        let node = n(SERIATED);
        let a = node
            .apply(
                &Repr::bytes(b"defendtheeast".to_vec()),
                &params! {"key" => "ZOMBIES", "period" => 3i64, "direction" => "encrypt"},
            )
            .unwrap();
        let b = node
            .apply(
                &Repr::bytes(b"defendtheeast".to_vec()),
                &params! {"key" => "ZOMBIES", "period" => 4i64, "direction" => "encrypt"},
            )
            .unwrap();
        assert_ne!(a.data, b.data);
    }

    /// Slidefair is an involution, which is why it has no `direction`.
    #[test]
    fn slidefair_is_an_involution() {
        let node = n(SLIDEFAIR);
        let p = params! {"key" => "NINE"};
        let once = node.apply(&Repr::bytes(b"attackatdawn".to_vec()), &p).unwrap();
        let twice = node.apply(&once, &p).unwrap();
        assert_eq!(twice.data, b"attackatdawn");
        assert_ne!(once.data, b"attackatdawn", "it must actually do something");
    }

    /// Portax likewise.
    #[test]
    fn portax_is_an_involution() {
        let node = n(PORTAX);
        let p = params! {"key" => "NINE", "period" => 5i64};
        let once = node
            .apply(&Repr::bytes(b"defendtheeastwall".to_vec()), &p)
            .unwrap();
        let twice = node.apply(&once, &p).unwrap();
        assert_eq!(twice.data, b"defendtheeastwall");
    }

    #[test]
    fn bad_parameters_are_rejected() {
        assert!(n(SERIATED)
            .apply(&Repr::bytes(b"abcd".to_vec()), &params! {"key" => "A", "period" => 0i64})
            .is_err());
        assert!(n(SLIDEFAIR)
            .apply(&Repr::bytes(b"abc".to_vec()), &params! {"key" => "NINE"})
            .is_err());
        assert!(n(PORTAX)
            .apply(&Repr::bytes(b"abcd".to_vec()), &params! {"key" => "123", "period" => 2i64})
            .is_err());
    }
}
