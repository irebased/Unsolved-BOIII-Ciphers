//! Integration tests against the real solved corpus in `data/`.
//!
//! These are the tests that matter. Unit tests prove the primitives are
//! self-consistent; only the corpus proves the *engine* reproduces ciphers that
//! were actually authored through mcrypt in 2016.

use std::path::PathBuf;

use ra_core::layer::{classify, ReprClass};
use ra_core::repr::decode_base64;
use ra_prim::{decrypt, KeyDerivation, Mode};

fn corpus(name: &str) -> serde_json::Value {
    let p = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../../data")
        .join(name);
    let s = std::fs::read_to_string(&p).unwrap_or_else(|e| panic!("reading {}: {e}", p.display()));
    serde_json::from_str(&s).expect("corpus is valid json")
}

fn record(map: &str, id: &str) -> serde_json::Value {
    corpus(map)
        .as_array()
        .expect("corpus is an array")
        .iter()
        .find(|r| r["id"] == id)
        .unwrap_or_else(|| panic!("no record {id}"))
        .clone()
}

fn ciphertext(map: &str, id: &str) -> String {
    record(map, id)["ciphertext"]
        .as_str()
        .unwrap_or_else(|| panic!("{id} has no ciphertext"))
        .to_string()
}

const IV: &[u8] = b"0000000000000000";

/// **The load-bearing corpus test.**
///
/// rev9's documented chain begins: base64 ciphertext -> DES/`cfb` (key `Zombies`,
/// IV ASCII `'0'`) -> "decode decimal". So a correct first layer must yield
/// whitespace-separated decimal groups. Nothing about the plaintext is needed —
/// the *shape* of the intermediate is the oracle, which makes this test immune to
/// the transcription inexactness that affects recorded plaintexts.
#[test]
fn rev9_first_layer_yields_decimal_groups() {
    let raw: String = ciphertext("revelations.json", "rev9")
        .chars()
        .filter(|c| !c.is_whitespace())
        .collect();
    let ct = decode_base64(raw.as_bytes()).expect("corpus ciphertext is base64");

    let out = decrypt(
        "des",
        Mode::Cfb8,
        b"Zombies",
        IV,
        KeyDerivation::NullPadMax,
        &ct,
    )
    .expect("DES/CFB-8 decrypt");

    let digits = out.iter().filter(|b| b.is_ascii_digit()).count();
    let printable = out
        .iter()
        .filter(|b| b.is_ascii_graphic() || **b == b' ')
        .count();
    let ratio = digits as f64 / out.len() as f64;

    assert_eq!(
        classify(&out),
        ReprClass::Decimal,
        "expected decimal groups, got {:?}: {:?}",
        classify(&out),
        String::from_utf8_lossy(&out[..60.min(out.len())])
    );
    assert!(ratio > 0.70, "digit ratio only {ratio:.3}");
    assert!(
        printable as f64 / out.len() as f64 > 0.99,
        "output should be effectively all printable"
    );
    assert!(
        out.starts_with(b"061 069 055 065 102 086"),
        "unexpected prefix: {:?}",
        String::from_utf8_lossy(&out[..24])
    );
}

/// Only CFB-8 reproduces rev9. Every other mode mcrypt offers must fail, which is
/// what makes the identification decisive rather than merely consistent.
#[test]
fn no_other_mode_reproduces_rev9() {
    let raw: String = ciphertext("revelations.json", "rev9")
        .chars()
        .filter(|c| !c.is_whitespace())
        .collect();
    let ct = decode_base64(raw.as_bytes()).expect("corpus ciphertext is base64");

    for m in Mode::ALL {
        // `stream` names a native stream cipher with no block-mode wrapper; it
        // is inapplicable to DES and correctly errors rather than producing
        // output to classify.
        if m == Mode::Stream {
            assert!(decrypt("des", m, b"Zombies", IV, KeyDerivation::NullPadMax, &ct).is_err());
            continue;
        }
        let out = decrypt("des", m, b"Zombies", IV, KeyDerivation::NullPadMax, &ct).unwrap();
        let is_decimal = classify(&out) == ReprClass::Decimal;
        if m == Mode::Cfb8 {
            assert!(is_decimal, "CFB-8 must reproduce rev9");
        } else {
            assert!(
                !is_decimal,
                "mode {m} unexpectedly also produced decimal groups"
            );
        }
    }
}

/// The ASCII-zero IV is not a null IV, demonstrated on real corpus bytes: swapping
/// it corrupts exactly `block_size` bytes and the stream then recovers *byte for
/// byte*. This is the empirical basis for the block-aware oracle.
#[test]
fn null_iv_corrupts_exactly_one_block_of_rev9_then_self_synchronises() {
    let raw: String = ciphertext("revelations.json", "rev9")
        .chars()
        .filter(|c| !c.is_whitespace())
        .collect();
    let ct = decode_base64(raw.as_bytes()).expect("corpus ciphertext is base64");

    let good = decrypt(
        "des",
        Mode::Cfb8,
        b"Zombies",
        IV,
        KeyDerivation::NullPadMax,
        &ct,
    )
    .unwrap();
    let bad = decrypt(
        "des",
        Mode::Cfb8,
        b"Zombies",
        &[0u8; 8],
        KeyDerivation::NullPadMax,
        &ct,
    )
    .unwrap();

    assert_ne!(good[..8], bad[..8], "first block must differ");
    assert_eq!(
        &good[8..],
        &bad[8..],
        "must recover after exactly one block"
    );

    // and the consequence the oracle exists to handle: a naive whole-output score
    // is degraded by the corrupt prefix, while a block-aware score is clean
    let naive = bad.iter().filter(|b| b.is_ascii_digit()).count() as f64 / bad.len() as f64;
    let aware =
        bad[8..].iter().filter(|b| b.is_ascii_digit()).count() as f64 / (bad.len() - 8) as f64;
    assert!(aware > naive, "block-aware score should be the higher one");
}

/// TG4's ciphertext must at least load and be the length the dossier states.
/// A claim over the wrong bytes covers nothing relevant, so the input is pinned.
#[test]
fn tg4_target_ciphertext_is_the_expected_shape() {
    let raw = ciphertext("the_giant.json", "tg4");
    assert_eq!(raw.len(), 192, "TG4 is 192 base64 characters");
    let bytes = decode_base64(raw.as_bytes()).expect("TG4 is base64");
    assert_eq!(bytes.len(), 144, "TG4 decodes to 144 bytes");
}

/// REV7's ciphertext is unambiguous hex; pin its decoded length too.
#[test]
fn rev7_target_ciphertext_is_the_expected_shape() {
    let raw: String = ciphertext("revelations.json", "rev7")
        .chars()
        .filter(|c| c.is_ascii_hexdigit())
        .collect();
    assert_eq!(raw.len(), 1092, "REV7 is 1092 hex characters");
    assert_eq!(hex::decode(&raw).unwrap().len(), 546);
}

/// **The vector that settled RC2's effective-key-bits question.**
///
/// rev5's recorded chain is RC2/`cfb` -> reverse -> `hex_to_base64` -> Blowfish ->
/// Loki97. Step 3 consumes hex, so a correct first layer *must* emit a hex string.
/// None of rev5's plaintext is needed, which makes this immune to transcription
/// drift. It is now corroborated end to end by
/// [`rev5_full_chain_recovers_known_plaintext`], but kept as a separate check
/// because it localises a regression to the RC2 layer.
///
/// libmcrypt's `rc2.c` has RFC 2268's Phase 2 key-size reduction stripped out, which
/// is `T1 = 1024` regardless of key length. RustCrypto's `new_from_slice` picks
/// `T1 = 8 * key_len`, i.e. 56 for `Zombies`, and produces noise.
#[test]
fn rev5_first_layer_yields_a_hex_string() {
    let raw: String = ciphertext("revelations.json", "rev5")
        .chars()
        .filter(|c| !c.is_whitespace())
        .collect();
    let ct = decode_base64(raw.as_bytes()).expect("corpus ciphertext is base64");
    assert_eq!(ct.len(), 1656, "rev5 decodes to 1656 bytes");

    let out = decrypt(
        "rc2",
        Mode::Cfb8,
        b"Zombies",
        IV,
        KeyDerivation::NullPadNextSupported,
        &ct,
    )
    .expect("RC2/CFB-8 decrypt");

    assert_eq!(
        classify(&out),
        ReprClass::Hex,
        "expected a hex string, got {:?}: {:?}",
        classify(&out),
        String::from_utf8_lossy(&out[..60.min(out.len())])
    );
    // 1650 hex characters and six trailing newlines: an even number of nibbles, so
    // the recorded `hex_to_base64` step can actually consume it.
    let hexchars = out.iter().filter(|b| b.is_ascii_hexdigit()).count();
    assert_eq!(hexchars, 1650);
    assert_eq!(&out[1650..], b"\n\n\n\n\n\n");
    assert!(out.starts_with(b"3e2b6f6ce123e42f13f45f955429fe0c"));
}

/// Only `T1 = 1024` reproduces rev5. Sweeping every multiple of 8 up to 1024 turns
/// the effective-key-bits value from an assumption into a finding, and rules out
/// both competing defaults explicitly: RFC 2268's `8 * key_len` (56 here) and
/// OpenSSL's 128.
#[test]
fn rev5_rules_out_every_other_effective_key_bits_value() {
    use cipher::generic_array::GenericArray;
    use cipher::BlockEncrypt;
    use ra_prim::MCRYPT_RC2_EFF_KEY_BITS;

    let raw: String = ciphertext("revelations.json", "rev5")
        .chars()
        .filter(|c| !c.is_whitespace())
        .collect();
    let ct = decode_base64(raw.as_bytes()).expect("corpus ciphertext is base64");

    // CFB-8 over the whole 1656 bytes for 128 candidate T1 values is slow, and the
    // prefix is already decisive: 64 hex characters is a 1-in-2^186 coincidence.
    let probe = &ct[..72];

    // an inlined CFB-8 decrypt, because `decrypt` deliberately exposes no
    // effective-key-bits knob — the mcrypt value is not a parameter of this engine
    let cfb8 = |eff: usize| -> Vec<u8> {
        let c = rc2::Rc2::new_with_eff_key_len(b"Zombies", eff);
        let mut reg = IV[..8].to_vec();
        probe
            .iter()
            .map(|&byte| {
                let mut b = GenericArray::clone_from_slice(&reg);
                c.encrypt_block(&mut b);
                let out = byte ^ b[0];
                reg.copy_within(1.., 0);
                reg[7] = byte;
                out
            })
            .collect()
    };

    let mut hits = Vec::new();
    for eff in (8..=1024).step_by(8) {
        // skip the corrupt first block: a wrong IV, not a wrong key, would explain it
        if cfb8(eff)[8..].iter().all(|b| b.is_ascii_hexdigit()) {
            hits.push(eff);
        }
    }
    assert_eq!(
        hits,
        vec![MCRYPT_RC2_EFF_KEY_BITS],
        "exactly one effective-key-bits value may reproduce rev5"
    );
    assert!(
        !hits.contains(&(b"Zombies".len() * 8)),
        "RFC 2268's default fails"
    );
    assert!(!hits.contains(&128), "OpenSSL's default fails");
}

/// The other half of the joint sweep: with `T1` pinned, only the key-derivation
/// policies that leave `Zombies` at its natural 7 bytes work. mcrypt reports no
/// discrete key sizes for RC2, so `null-pad-next-supported` is one of them — the
/// policy already established for the rest of the corpus needs no exception here.
#[test]
fn rev5_rules_out_the_padding_key_derivation_policies() {
    let raw: String = ciphertext("revelations.json", "rev5")
        .chars()
        .filter(|c| !c.is_whitespace())
        .collect();
    let ct = decode_base64(raw.as_bytes()).expect("corpus ciphertext is base64");

    for kd in KeyDerivation::ALL {
        let out = decrypt("rc2", Mode::Cfb8, b"Zombies", IV, kd, &ct[..72]).unwrap();
        let is_hex = out[8..].iter().all(|b| b.is_ascii_hexdigit());
        match kd {
            // RC2 accepts any length 1..=128, so "next supported" is 7: unpadded
            KeyDerivation::Natural | KeyDerivation::NullPadNextSupported => {
                assert!(is_hex, "{kd} should reproduce rev5")
            }
            // padding to 128 bytes changes Phase 1, which indexes `key[j - len]`
            _ => assert!(!is_hex, "{kd} unexpectedly also reproduced rev5"),
        }
    }
}

/// rev5's *fourth* step, which fixing RC2 unblocked. The fifth step is a Loki97
/// decrypt whose box base64-decodes its input, so the Blowfish layer must emit
/// base64 — and it does, over every byte. Kept as its own check now that
/// [`rev5_full_chain_recovers_known_plaintext`] runs the whole chain: it isolates
/// the Blowfish layer from the four others.
#[test]
fn rev5_blowfish_layer_yields_base64() {
    let raw: String = ciphertext("revelations.json", "rev5")
        .chars()
        .filter(|c| !c.is_whitespace())
        .collect();
    let ct = decode_base64(raw.as_bytes()).expect("corpus ciphertext is base64");

    let mut hexstr = decrypt(
        "rc2",
        Mode::Cfb8,
        b"Zombies",
        IV,
        KeyDerivation::NullPadNextSupported,
        &ct,
    )
    .unwrap();
    hexstr.reverse();
    // `hex_to_base64` then the decrypt box's implicit b64decode compose to a plain
    // hex decode; spelling both out would only re-encode and re-decode the bytes.
    let nibbles: Vec<u8> = hexstr
        .iter()
        .filter(|b| b.is_ascii_hexdigit())
        .copied()
        .collect();
    let inner = hex::decode(&nibbles).expect("the reversed first layer must be even-length hex");
    assert_eq!(inner.len(), 825);

    let out = decrypt(
        "blowfish",
        Mode::Cfb8,
        b"Zombies",
        IV,
        KeyDerivation::NullPadNextSupported,
        &inner,
    )
    .unwrap();
    assert_eq!(
        classify(&out),
        ReprClass::Base64ish,
        "expected base64 for the Loki97 box to consume, got {:?}: {:?}",
        classify(&out),
        String::from_utf8_lossy(&out[..60.min(out.len())])
    );
}

/// **rev5 recovered end to end against known plaintext — the vector that proves
/// Loki97.**
///
/// All five recorded layers plus the two implicit `b64decode`s the tools4noobs
/// decrypt box performs on its input:
///
/// ```text
/// b64decode -> rc2/cfb-8 -> reverse -> hex_to_base64 -> b64decode
///           -> blowfish/cfb-8 -> b64decode -> loki97/cfb-8
/// ```
///
/// This simultaneously converts rev5's RC2 and Blowfish checks from shape-based to
/// plaintext-backed: a wrong RC2 effective-key-bits value or a wrong Blowfish word
/// order cannot terminate in 615 bytes of the recorded OSS report.
#[test]
fn rev5_full_chain_recovers_known_plaintext() {
    let rec = record("revelations.json", "rev5");
    let raw: String = rec["ciphertext"]
        .as_str()
        .unwrap()
        .chars()
        .filter(|c| !c.is_whitespace())
        .collect();
    let ct = decode_base64(raw.as_bytes()).expect("corpus ciphertext is base64");
    let expected = rec["plaintext"].as_str().unwrap();

    let mut hexstr = decrypt(
        "rc2",
        Mode::Cfb8,
        b"Zombies",
        IV,
        KeyDerivation::NullPadNextSupported,
        &ct,
    )
    .unwrap();
    hexstr.reverse();
    // `hex_to_base64` followed by the decrypt box's implicit b64decode composes to a
    // plain hex decode.
    let nibbles: Vec<u8> = hexstr
        .iter()
        .filter(|b| b.is_ascii_hexdigit())
        .copied()
        .collect();
    let inner = hex::decode(&nibbles).unwrap();

    let b64 = decrypt(
        "blowfish",
        Mode::Cfb8,
        b"Zombies",
        IV,
        KeyDerivation::NullPadNextSupported,
        &inner,
    )
    .unwrap();
    let stripped: Vec<u8> = b64
        .iter()
        .copied()
        .filter(|b| !b.is_ascii_whitespace())
        .collect();
    let final_ct = decode_base64(&stripped).expect("the Blowfish layer must emit base64");

    let out = decrypt(
        "loki97",
        Mode::Cfb8,
        b"Zombies",
        IV,
        KeyDerivation::NullPadNextSupported,
        &final_ct,
    )
    .expect("loki97/cfb-8 decrypt");
    let recovered = String::from_utf8_lossy(&out);

    // Compare on a normalised substring: recorded plaintexts are transcriptions.
    // rev5's differs from the bytes in exactly one visible way — the record writes
    // "935's" with an ASCII apostrophe where the ciphertext carries a U+2019 — so the
    // usable common prefix stops short of that.
    let needle = &expected[..80];
    assert!(
        recovered.contains(needle),
        "rev5 did not recover.\n  expected to contain: {needle:?}\n  got: {:?}",
        &recovered[..120.min(recovered.len())]
    );
    assert!(
        recovered.starts_with("August, 1946. OSS report final T-7."),
        "recovered text should begin at the recorded plaintext: {:?}",
        &recovered[..60.min(recovered.len())]
    );
    assert_eq!(out.len(), 615, "rev5's plaintext is 615 bytes");
    assert_eq!(
        classify(&out),
        ReprClass::Text,
        "the final layer must be prose"
    );
}

/// Loki97's key schedule in libmcrypt is the 256-bit one for *every* key size, and
/// `internal_init_mcrypt` hands it a `calloc`ed 32-byte buffer, so both null-padding
/// policies collapse onto the same key. That makes rev5 unable to discriminate
/// between them — recorded here so nobody later reads its pass as evidence for one.
/// The two *repeat*-padding policies do differ, and must fail.
#[test]
fn rev5_loki97_layer_cannot_discriminate_the_null_padding_policies() {
    // A short synthetic round trip is enough: this is a property of the key
    // schedule, not of the corpus bytes.
    let probe = b"the quick brown fox jumped over.";
    let reference = ra_prim::encrypt(
        "loki97",
        Mode::Cfb8,
        b"Zombies",
        IV,
        KeyDerivation::NullPadNextSupported,
        probe,
    )
    .unwrap();

    for kd in KeyDerivation::ALL {
        let Ok(out) = ra_prim::encrypt("loki97", Mode::Cfb8, b"Zombies", IV, kd, probe) else {
            continue; // a natural 7-byte key is not a supported Loki97 key size
        };
        match kd {
            KeyDerivation::NullPadMax | KeyDerivation::NullPadNextSupported => assert_eq!(
                out, reference,
                "{kd} must agree: libmcrypt zero-extends every key to 32 bytes"
            ),
            _ => assert_ne!(out, reference, "{kd} pads with key material, not zeros"),
        }
    }
}

fn rot(data: &[u8], shift: u8) -> Vec<u8> {
    data.iter()
        .map(|&c| match c {
            b'A'..=b'Z' => (c - b'A' + shift) % 26 + b'A',
            b'a'..=b'z' => (c - b'a' + shift) % 26 + b'a',
            other => other,
        })
        .collect()
}

/// **The strongest corpus test: rev12 recovered against known plaintext.**
///
/// One vector pins four things at once — the XTEA round function and word order,
/// CFB-8 as the meaning of mcrypt's `cfb`, the ASCII-zero IV, and null-pad-max as
/// the key-derivation policy.
///
/// Two corpus conventions are asserted here rather than left as folklore:
/// the recorded `rot` shift is the *encryption* shift (so decryption applies its
/// inverse: documented "6" means ROT-20 outbound), and recorded plaintexts are
/// human transcriptions rather than bytes, so the comparison is on a normalised
/// substring.
#[test]
fn rev12_full_chain_recovers_known_plaintext() {
    let rec = record("revelations.json", "rev12");
    let raw: String = rec["ciphertext"]
        .as_str()
        .unwrap()
        .chars()
        .filter(|c| c.is_ascii_hexdigit())
        .collect();
    let ct = hex::decode(&raw).unwrap();
    let expected = rec["plaintext"].as_str().unwrap();

    // hexdecode -> xtea/cfb-8 -> reverse -> rot(inverse of the recorded shift)
    let mut out = decrypt(
        "xtea",
        Mode::Cfb8,
        b"Zombies",
        IV,
        KeyDerivation::NullPadMax,
        &ct,
    )
    .expect("xtea/cfb-8 decrypt");
    out.reverse();
    let recovered_bytes = rot(&out, 26 - 6);
    let recovered = String::from_utf8_lossy(&recovered_bytes);

    let needle = &expected[..80];
    assert!(
        recovered.contains(needle),
        "rev12 did not recover.\n  expected to contain: {needle:?}\n  got: {:?}",
        &recovered[..120.min(recovered.len())]
    );

    // The transcription is inexact, and this documents exactly how: three leading
    // newlines were trimmed and one byte became a multi-byte en-dash.
    assert_eq!(ct.len(), 211, "rev12 is 211 ciphertext bytes");
    assert_eq!(
        expected.chars().count(),
        205,
        "recorded plaintext is 205 chars"
    );
    assert_eq!(
        expected.len(),
        207,
        "…but 207 UTF-8 bytes, because one byte was transcribed as an en-dash"
    );
    assert!(
        ct.len() > expected.len(),
        "recorded plaintext is shorter than the ciphertext: the transcription is lossy"
    );
    assert!(
        recovered.trim_start().starts_with(needle),
        "recovered text should differ from the record only by leading whitespace"
    );
}

/// Only the correct key-derivation policy recovers rev12. This is what turns
/// null-pad-max from an assumption into a finding.
#[test]
fn rev12_rules_out_repeat_padding() {
    let rec = record("revelations.json", "rev12");
    let raw: String = rec["ciphertext"]
        .as_str()
        .unwrap()
        .chars()
        .filter(|c| c.is_ascii_hexdigit())
        .collect();
    let ct = hex::decode(&raw).unwrap();
    let needle = &rec["plaintext"].as_str().unwrap()[..60];

    for kd in KeyDerivation::ALL {
        let Ok(mut out) = decrypt("xtea", Mode::Cfb8, b"Zombies", IV, kd, &ct) else {
            continue; // natural-length keys are rejected by XTEA's fixed key size
        };
        out.reverse();
        let got = String::from_utf8_lossy(&rot(&out, 20)).contains(needle);
        match kd {
            // XTEA's only supported key size is 16, so these two coincide
            KeyDerivation::NullPadMax | KeyDerivation::NullPadNextSupported => {
                assert!(got, "{kd} should recover rev12")
            }
            _ => assert!(!got, "{kd} unexpectedly also recovered rev12"),
        }
    }
}
