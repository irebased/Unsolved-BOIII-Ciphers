//! mcrypt-faithful mode engine.
//!
//! The single most consequential fact in the dossier is that mcrypt's mode named
//! `cfb` is **8-bit feedback** (CFB-8), whereas modern libraries reserve that name
//! for full-block feedback. mcrypt spells the full-block variant `ncfb`. The same
//! `n`-prefix convention applies to OFB. This is why CyberChef and most tooling
//! structurally cannot reproduce these ciphers.
//!
//! Verified against the corpus: rev9's first layer is DES/`cfb` over its base64
//! ciphertext, and it must yield whitespace-separated decimal groups because the
//! next documented step is a decimal decode. CFB-8 produces exactly that; nCFB,
//! OFB, CBC and ECB all produce noise.

use std::fmt;

use serde::{Deserialize, Serialize};

use crate::prim::BlockPrim;

#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Mode {
    Ecb,
    Cbc,
    /// mcrypt `cfb`: 8-bit feedback. One block operation **per byte**.
    Cfb8,
    /// mcrypt `ncfb`: full-block feedback. What modern libraries call CFB.
    NCfb,
    /// mcrypt `ofb`: 8-bit output feedback.
    Ofb8,
    /// mcrypt `nofb`: full-block output feedback.
    NOfb,
    /// Native stream cipher (arcfour); no mode wrapper.
    Stream,
}

impl Mode {
    pub const ALL: [Mode; 7] = [
        Mode::Ecb,
        Mode::Cbc,
        Mode::Cfb8,
        Mode::NCfb,
        Mode::Ofb8,
        Mode::NOfb,
        Mode::Stream,
    ];

    /// The mcrypt spelling, which is the name that appears in coverage claims.
    pub fn as_str(self) -> &'static str {
        match self {
            Mode::Ecb => "ecb",
            Mode::Cbc => "cbc",
            Mode::Cfb8 => "cfb",
            Mode::NCfb => "ncfb",
            Mode::Ofb8 => "ofb",
            Mode::NOfb => "nofb",
            Mode::Stream => "stream",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        match s.to_ascii_lowercase().as_str() {
            "ecb" => Some(Mode::Ecb),
            "cbc" => Some(Mode::Cbc),
            // "cfb8" is accepted because the dossier's coverage vocabulary uses it
            "cfb" | "cfb8" => Some(Mode::Cfb8),
            "ncfb" => Some(Mode::NCfb),
            "ofb" | "ofb8" => Some(Mode::Ofb8),
            "nofb" => Some(Mode::NOfb),
            "stream" => Some(Mode::Stream),
            _ => None,
        }
    }

    pub fn uses_iv(self) -> bool {
        !matches!(self, Mode::Ecb | Mode::Stream)
    }

    /// Whether a wrong IV corrupts only a bounded prefix. True for the
    /// self-synchronising feedback modes, which is what the block-aware oracle
    /// exploits.
    pub fn self_synchronising(self) -> bool {
        matches!(self, Mode::Cfb8 | Mode::NCfb | Mode::Cbc)
    }
}

impl fmt::Display for Mode {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Fit an IV to the block size: truncate if long, null-pad if short.
fn fit_iv(iv: &[u8], bs: usize) -> Vec<u8> {
    let mut v = iv.to_vec();
    v.resize(bs, 0);
    v.truncate(bs);
    v
}

/// A `Mode` that cannot be run against the primitive it was asked to wrap.
///
/// [`Mode::Stream`] is libmcrypt's spelling for a *native* stream cipher
/// (arcfour) running with no block-mode wrapper at all — it is not a block
/// mode in its own right. [`decrypt`]/[`encrypt`] only ever receive a
/// [`BlockPrim`], so reaching this arm always means the candidate asked for a
/// mode that structurally does not exist for the primitive it named. Callers
/// must surface this as a failure, never as a pass-through of the input: an
/// identity result here is indistinguishable from a genuine decrypt that
/// happens to be an involution, which is the exact failure mode this type
/// exists to rule out.
#[derive(Debug, thiserror::Error)]
pub enum ModeError {
    #[error("mode 'stream' has no block-cipher wrapping; it names a native stream cipher and does not apply here")]
    StreamIsNotABlockMode,
}

/// Decrypt `data` under `prim` in `mode`.
///
/// Block modes process whole blocks and leave any trailing partial block
/// untouched, matching `mdecrypt_generic`'s behaviour on a non-multiple length.
pub fn decrypt(
    prim: &dyn BlockPrim,
    mode: Mode,
    data: &[u8],
    iv: &[u8],
) -> Result<Vec<u8>, ModeError> {
    let bs = prim.block_size();
    let out = match mode {
        Mode::Cfb8 => cfb8(prim, data, iv, Feedback::Ciphertext, Xor::Decrypt),
        Mode::Ofb8 => cfb8(prim, data, iv, Feedback::Keystream, Xor::Decrypt),
        Mode::NCfb => ncfb_decrypt(prim, data, iv),
        Mode::NOfb => nofb(prim, data, iv),
        Mode::Stream => return Err(ModeError::StreamIsNotABlockMode),
        Mode::Ecb => {
            let mut out = data.to_vec();
            for chunk in out.chunks_exact_mut(bs) {
                prim.decrypt_block(chunk);
            }
            out
        }
        Mode::Cbc => {
            let mut out = Vec::with_capacity(data.len());
            let mut prev = fit_iv(iv, bs);
            let whole = data.len() / bs * bs;
            for chunk in data[..whole].chunks(bs) {
                let mut b = chunk.to_vec();
                prim.decrypt_block(&mut b);
                for (x, p) in b.iter_mut().zip(prev.iter()) {
                    *x ^= *p;
                }
                out.extend_from_slice(&b);
                prev = chunk.to_vec();
            }
            out.extend_from_slice(&data[whole..]);
            out
        }
    };
    Ok(out)
}

/// Encrypt `data` under `prim` in `mode`. Needed to build conformance fixtures
/// and to demonstrate the IV/mode properties.
pub fn encrypt(
    prim: &dyn BlockPrim,
    mode: Mode,
    data: &[u8],
    iv: &[u8],
) -> Result<Vec<u8>, ModeError> {
    let bs = prim.block_size();
    let out = match mode {
        Mode::Cfb8 => cfb8(prim, data, iv, Feedback::Ciphertext, Xor::Encrypt),
        Mode::Ofb8 => cfb8(prim, data, iv, Feedback::Keystream, Xor::Encrypt),
        Mode::NCfb => ncfb_encrypt(prim, data, iv),
        // OFB is its own inverse
        Mode::NOfb => nofb(prim, data, iv),
        Mode::Stream => return Err(ModeError::StreamIsNotABlockMode),
        Mode::Ecb => {
            let mut out = data.to_vec();
            for chunk in out.chunks_exact_mut(bs) {
                prim.encrypt_block(chunk);
            }
            out
        }
        Mode::Cbc => {
            let mut out = Vec::with_capacity(data.len());
            let mut prev = fit_iv(iv, bs);
            let whole = data.len() / bs * bs;
            for chunk in data[..whole].chunks(bs) {
                let mut b = chunk.to_vec();
                for (x, p) in b.iter_mut().zip(prev.iter()) {
                    *x ^= *p;
                }
                prim.encrypt_block(&mut b);
                out.extend_from_slice(&b);
                prev = b;
            }
            out.extend_from_slice(&data[whole..]);
            out
        }
    };
    Ok(out)
}

#[derive(Clone, Copy)]
enum Feedback {
    /// CFB: shift the ciphertext byte into the register.
    Ciphertext,
    /// OFB: shift the keystream byte into the register.
    Keystream,
}

#[derive(Clone, Copy)]
enum Xor {
    Encrypt,
    Decrypt,
}

/// The shared 8-bit feedback loop.
///
/// One block operation per byte, which is why CFB-8 is roughly `block_size` times
/// slower than a full-block mode and is the dominant cost of any sweep.
fn cfb8(prim: &dyn BlockPrim, data: &[u8], iv: &[u8], fb: Feedback, dir: Xor) -> Vec<u8> {
    let bs = prim.block_size();
    let mut reg = fit_iv(iv, bs);
    let mut out = Vec::with_capacity(data.len());
    let mut buf = vec![0u8; bs];
    for &byte in data {
        buf.copy_from_slice(&reg);
        prim.encrypt_block(&mut buf);
        let ks = buf[0];
        let result = byte ^ ks;
        out.push(result);
        let shift_in = match fb {
            Feedback::Ciphertext => match dir {
                // the register always takes the *ciphertext* byte
                Xor::Encrypt => result,
                Xor::Decrypt => byte,
            },
            Feedback::Keystream => ks,
        };
        reg.copy_within(1.., 0);
        reg[bs - 1] = shift_in;
    }
    out
}

fn ncfb_decrypt(prim: &dyn BlockPrim, data: &[u8], iv: &[u8]) -> Vec<u8> {
    let bs = prim.block_size();
    let mut reg = fit_iv(iv, bs);
    let mut out = Vec::with_capacity(data.len());
    for chunk in data.chunks(bs) {
        let mut ks = reg.clone();
        prim.encrypt_block(&mut ks);
        out.extend(chunk.iter().zip(ks.iter()).map(|(c, k)| c ^ k));
        if chunk.len() == bs {
            reg.copy_from_slice(chunk);
        }
    }
    out
}

fn ncfb_encrypt(prim: &dyn BlockPrim, data: &[u8], iv: &[u8]) -> Vec<u8> {
    let bs = prim.block_size();
    let mut reg = fit_iv(iv, bs);
    let mut out = Vec::with_capacity(data.len());
    for chunk in data.chunks(bs) {
        let mut ks = reg.clone();
        prim.encrypt_block(&mut ks);
        let ct: Vec<u8> = chunk.iter().zip(ks.iter()).map(|(p, k)| p ^ k).collect();
        if ct.len() == bs {
            reg.copy_from_slice(&ct);
        }
        out.extend_from_slice(&ct);
    }
    out
}

fn nofb(prim: &dyn BlockPrim, data: &[u8], iv: &[u8]) -> Vec<u8> {
    let bs = prim.block_size();
    let mut reg = fit_iv(iv, bs);
    let mut out = Vec::with_capacity(data.len());
    for chunk in data.chunks(bs) {
        prim.encrypt_block(&mut reg);
        out.extend(chunk.iter().zip(reg.iter()).map(|(c, k)| c ^ k));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::prim::instantiate_block;

    fn des() -> Box<dyn BlockPrim> {
        instantiate_block("des", b"Zombies\x00").unwrap()
    }

    #[test]
    fn every_mode_round_trips() {
        let p = des();
        let pt = b"THE GIANT AWAITS BENEATH THE CLOCKTOWER AT MIDNIGHT.....";
        let iv = b"0".repeat(8);
        for m in Mode::ALL {
            if m == Mode::Stream {
                continue;
            }
            let ct = encrypt(&*p, m, pt, &iv).unwrap();
            let rt = decrypt(&*p, m, &ct, &iv).unwrap();
            assert_eq!(rt, pt.to_vec(), "mode {m} did not round trip");
        }
    }

    /// `stream` names a native stream cipher with no block-mode wrapper; it is
    /// structurally inapplicable to a [`BlockPrim`] and must error rather than
    /// pass the input through unchanged.
    #[test]
    fn stream_mode_is_inapplicable_to_a_block_primitive() {
        let p = des();
        let pt = b"twelve bytes";
        let iv = b"0".repeat(8);
        assert!(matches!(
            encrypt(&*p, Mode::Stream, pt, &iv),
            Err(ModeError::StreamIsNotABlockMode)
        ));
        assert!(matches!(
            decrypt(&*p, Mode::Stream, pt, &iv),
            Err(ModeError::StreamIsNotABlockMode)
        ));
    }

    /// The property the block-aware oracle rests on: under CFB-8 a wrong IV
    /// corrupts *exactly* `block_size` bytes, then the stream self-synchronises.
    #[test]
    fn cfb8_wrong_iv_corrupts_exactly_one_block_then_recovers() {
        let p = des();
        let pt = b"THE BODY OF THE GIANT LIES BENEATH AND THE KEEPER GUARDS THE WAY HOME";
        let ct = encrypt(&*p, Mode::Cfb8, pt, &b"0".repeat(8)).unwrap();

        let good = decrypt(&*p, Mode::Cfb8, &ct, &b"0".repeat(8)).unwrap();
        let bad = decrypt(&*p, Mode::Cfb8, &ct, &[0u8; 8]).unwrap();

        assert_eq!(good, pt.to_vec());
        assert_ne!(bad[..8], pt[..8]);
        assert_eq!(&bad[8..], &pt[8..], "stream must recover after one block");
    }

    /// cfb (8-bit) and ncfb (full-block) must differ. This is the whole reason
    /// modern tooling cannot reproduce the corpus.
    #[test]
    fn cfb8_and_ncfb_are_different_modes() {
        let p = des();
        let pt = b"identical plaintext for both modes";
        let iv = b"0".repeat(8);
        assert_ne!(
            encrypt(&*p, Mode::Cfb8, pt, &iv).unwrap(),
            encrypt(&*p, Mode::NCfb, pt, &iv).unwrap()
        );
    }

    /// ASCII-zero IV is not a null IV. Both are 16 bytes of "zero" in casual
    /// speech; they are entirely different keystreams.
    #[test]
    fn ascii_zero_iv_differs_from_null_iv() {
        let p = des();
        let pt = b"the first block is where this shows up";
        let a = encrypt(&*p, Mode::Cfb8, pt, &b"0".repeat(8)).unwrap();
        let b = encrypt(&*p, Mode::Cfb8, pt, &[0u8; 8]).unwrap();
        assert_ne!(a, b);
    }

    #[test]
    fn ofb8_is_its_own_inverse_and_differs_from_cfb8() {
        let p = des();
        let pt = b"output feedback keeps the register independent of the data";
        let iv = b"0".repeat(8);
        let ct = encrypt(&*p, Mode::Ofb8, pt, &iv).unwrap();
        assert_eq!(decrypt(&*p, Mode::Ofb8, &ct, &iv).unwrap(), pt.to_vec());
        assert_ne!(ct, encrypt(&*p, Mode::Cfb8, pt, &iv).unwrap());
    }

    /// OFB-8's register feeds back only the single keystream byte it just
    /// produced, so a null IV can reach a genuine fixed point (not a mode
    /// dispatch bug): if `E(0-block)`'s first byte happens to be zero for a
    /// given key, the register never moves off all-zero and the keystream
    /// stays zero forever. This is a real, key-dependent property of 8-bit
    /// OFB with a null IV, not evidence the mode failed to run — a different
    /// key reliably produces a non-zero keystream from the same all-zero
    /// register. See `ofb8_null_iv_transforms_for_a_generic_key` and the
    /// `fix/noop-modes` report for the full derivation.
    #[test]
    fn ofb8_null_iv_fixed_point_is_key_dependent_not_a_mode_bug() {
        // "Zombies" is the corpus-standard demo key; under Blowfish its
        // E(0-block) happens to start with a zero byte, which is the
        // degenerate case. A different key does not share that coincidence.
        let degenerate = instantiate_block("blowfish", b"Zombies").unwrap();
        let generic = instantiate_block("blowfish", b"a-different-key-entirely").unwrap();
        let iv = [0u8; 8];
        for len in [16usize, 24] {
            let pt = vec![b'A'; len];
            let degenerate_ct = decrypt(&*degenerate, Mode::Ofb8, &pt, &iv).unwrap();
            assert_eq!(
                degenerate_ct, pt,
                "the degenerate key's keystream is a real, reproducible fixed point"
            );
            let generic_ct = decrypt(&*generic, Mode::Ofb8, &pt, &iv).unwrap();
            assert_ne!(
                generic_ct, pt,
                "a generic key's OFB-8 keystream over a null IV is not a no-op"
            );
        }
    }

    #[test]
    fn block_modes_pass_through_a_trailing_partial_block() {
        let p = des();
        let data = b"0123456789"; // 10 bytes, block size 8
        let out = decrypt(&*p, Mode::Ecb, data, &[]).unwrap();
        assert_eq!(&out[8..], b"89");
    }

    #[test]
    fn mode_names_follow_mcrypt_spelling() {
        assert_eq!(Mode::Cfb8.as_str(), "cfb");
        assert_eq!(Mode::NCfb.as_str(), "ncfb");
        assert_eq!(Mode::parse("cfb"), Some(Mode::Cfb8));
        assert_eq!(Mode::parse("cfb8"), Some(Mode::Cfb8));
        assert_eq!(Mode::parse("ncfb"), Some(Mode::NCfb));
    }
}
