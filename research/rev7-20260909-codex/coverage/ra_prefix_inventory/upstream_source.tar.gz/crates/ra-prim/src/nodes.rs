//! One registered `dec` node **per primitive**.
//!
//! This is a deliberate departure from the dossier's `engine.py`, which exposes a
//! single `mcrypt` node parameterised by a `prim` argument. A single node means a
//! single `node_id` shared by all eleven primitives, and that breaks Document 6's
//! central payoff: revoking one defective Twofish build must void *only* Twofish
//! coverage and retain the rest. Per-primitive nodes give each its own identity,
//! version and implementation hash, so selective invalidation is exact.

use ra_core::error::{Error, Result};
use ra_core::node::{Family, Node, ParamSpec, ParamType};
use ra_core::params::Params;
use ra_core::repr::{Display, Repr};

use crate::keyderiv::KeyDerivation;
use crate::mode::{self, Mode};
use crate::prim::{ImplStatus, PrimInfo, PrimKind, PRIMS};

const DEC_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "passphrase, before key derivation"),
    ParamSpec::opt(
        "mode",
        ParamType::Str,
        "mcrypt mode name; 'cfb' means CFB-8 (default cfb)",
    ),
    ParamSpec::opt(
        "iv",
        ParamType::Hex,
        "hex IV (default 30..30, ASCII '0' x16 — not a null IV)",
    ),
    ParamSpec::opt(
        "keyderiv",
        ParamType::Str,
        "key-derivation policy (default null-pad-next-supported, the corpus-confirmed one); \
         includes the raw-byte policies (natural, null-pad-max, null-pad-next-supported, \
         repeat-pad-max) and the hash-derived family (md5, md5-hex, md5-hex-upper, sha1, \
         sha1-hex, sha1-hex-upper, sha256, sha256-hex, sha256-hex-upper, evp-md5, evp-sha256)",
    ),
];

/// The corpus IV: sixteen ASCII '0' bytes. Emphatically *not* a null IV.
pub const CORPUS_IV: [u8; 16] = [b'0'; 16];

/// A decryption node bound to exactly one primitive.
pub struct DecNode {
    info: &'static PrimInfo,
}

impl DecNode {
    fn resolve(&self, params: &Params) -> Result<(Mode, Vec<u8>, Vec<u8>)> {
        let name = self.info.mcrypt_name;
        let mode_s = params.opt_str("mode").unwrap_or("cfb");
        let mode = Mode::parse(mode_s)
            .ok_or_else(|| Error::bad_param(name, "mode", format!("unknown mode '{mode_s}'")))?;

        let kd_s = params
            .opt_str("keyderiv")
            .unwrap_or("null-pad-next-supported");
        let kd = KeyDerivation::parse(kd_s).ok_or_else(|| {
            Error::bad_param(name, "keyderiv", format!("unknown policy '{kd_s}'"))
        })?;

        let key = params.req_str(name, "key")?.as_bytes().to_vec();
        let derived = kd.derive(&key, self.info);

        let iv = match params.opt_hex(name, "iv")? {
            Some(v) => v,
            None => CORPUS_IV.to_vec(),
        };
        Ok((mode, derived, iv))
    }
}

impl Node for DecNode {
    fn name(&self) -> &'static str {
        self.info.mcrypt_name
    }

    fn version(&self) -> &'static str {
        self.info.version
    }

    fn family(&self) -> Family {
        Family::Dec
    }

    /// Folds the backing implementation's provenance into the node identity, so two
    /// independent implementations of the same logical primitive are distinguishable
    /// and their agreement is evidence rather than a tautology.
    fn source_digest(&self) -> &'static str {
        self.info.impl_source
    }

    fn params_schema(&self) -> &'static [ParamSpec] {
        DEC_SCHEMA
    }

    /// Reported so the block-aware oracle knows how many leading bytes a wrong IV
    /// can corrupt. Only meaningful for the self-synchronising modes.
    fn block_size(&self, params: &Params) -> Option<usize> {
        let mode = Mode::parse(params.opt_str("mode").unwrap_or("cfb"))?;
        if mode.self_synchronising() {
            Some(self.info.block_size)
        } else {
            None
        }
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        if self.info.status == ImplStatus::Declared {
            return Err(Error::Unimplemented(self.info.display_name));
        }
        let (mode, key, iv) = self.resolve(params)?;

        let out = match self.info.kind {
            PrimKind::Stream => {
                let p = crate::prim::instantiate_stream(self.info.mcrypt_name, &key, &iv)
                    .map_err(|e| Error::node_failed(self.info.mcrypt_name, e))?;
                let mut buf = input.data.clone();
                p.apply_keystream(&mut buf);
                buf
            }
            PrimKind::Block => {
                let p = crate::prim::instantiate_block(self.info.mcrypt_name, &key)
                    .map_err(|e| Error::node_failed(self.info.mcrypt_name, e))?;
                mode::decrypt(&*p, mode, &input.data, &iv)
                    .map_err(|e| Error::node_failed(self.info.mcrypt_name, e))?
            }
        };
        Ok(Repr::new(out, Display::Bytes))
    }
}

/// Registers one node per entry in [`PRIMS`], including the declared-but-
/// unimplemented ones, so the coverage vocabulary stays complete. A primitive
/// missing from the vocabulary would silently shrink the universe and make the
/// residual look smaller than it is.
macro_rules! dec_node {
    ($static:ident, $idx:expr) => {
        ra_core::register_node!($static => || Box::new(DecNode { info: &PRIMS[$idx] }));
    };
}

dec_node!(DEC_DES, 0);
dec_node!(DEC_RC2, 1);
dec_node!(DEC_RC4, 2);
dec_node!(DEC_BLOWFISH, 3);
dec_node!(DEC_BLOWFISH_COMPAT, 4);
dec_node!(DEC_TWOFISH, 5);
dec_node!(DEC_SERPENT, 6);
dec_node!(DEC_RIJNDAEL256, 7);
dec_node!(DEC_AES, 8);
dec_node!(DEC_XTEA, 9);
dec_node!(DEC_LOKI97, 10);
dec_node!(DEC_SAFERPLUS, 11);
dec_node!(DEC_TRIPLEDES, 12);
dec_node!(DEC_CAST128, 13);
dec_node!(DEC_IDEA, 14);
dec_node!(DEC_SALSA20, 15);

/// Forces this crate to be linked so its `distributed_slice` entries are present.
/// A pure-library dependency that the binary never names by path can otherwise be
/// dropped by the linker, silently emptying the registry.
pub fn link() {}

#[cfg(test)]
mod tests {
    use super::*;
    use ra_core::params;
    use ra_core::registry::registry;

    #[test]
    fn every_primitive_is_registered_as_a_node() {
        let reg = registry();
        for info in PRIMS {
            assert!(
                reg.contains(info.mcrypt_name),
                "primitive '{}' is not registered as a node",
                info.display_name
            );
        }
    }

    /// Each primitive must have a distinct node identity, or selective
    /// invalidation cannot localise a defect.
    #[test]
    fn primitives_have_distinct_node_identities() {
        let reg = registry();
        let mut ids = std::collections::HashSet::new();
        for info in PRIMS {
            let n = reg.get(info.mcrypt_name).unwrap();
            assert!(
                ids.insert(n.node_id().to_string()),
                "duplicate node id for {}",
                info.display_name
            );
        }
    }

    /// A `Declared` primitive deliberately absent from [`PRIMS`]. Every real entry
    /// is now `Implemented` — Loki97 was the last holdout — so the node-level
    /// guard is exercised against a synthetic one rather than allowed to become a
    /// vacuous pass.
    static DECLARED_ONLY: PrimInfo = PrimInfo {
        display_name: "Nonesuch",
        mcrypt_name: "nonesuch",
        block_size: 16,
        max_key_size: 32,
        supported_key_sizes: &[16, 24, 32],
        kind: PrimKind::Block,
        status: ImplStatus::Declared,
        impl_source: "",
        version: "0.0.0",
        vector_proof: None,
    };

    #[test]
    fn declared_primitives_error_rather_than_returning_garbage() {
        let n = DecNode {
            info: &DECLARED_ONLY,
        };
        let e = n
            .apply(
                &Repr::bytes(vec![0u8; 32]),
                &params! {"nonesuch" => "Zombies"},
            )
            .unwrap_err();
        assert!(matches!(e, Error::Unimplemented(_)), "{e}");

        // and every registered node whose primitive is declared must do the same
        for info in PRIMS.iter().filter(|p| p.status == ImplStatus::Declared) {
            let n = registry().get(info.mcrypt_name).unwrap();
            let e = n
                .apply(&Repr::bytes(vec![0u8; 32]), &params! {"key" => "Zombies"})
                .unwrap_err();
            assert!(
                matches!(e, Error::Unimplemented(_)),
                "{}: {e}",
                info.display_name
            );
        }
    }

    /// Loki97 is now a real, executing node: the vocabulary no longer contains an
    /// entry that errors on use.
    #[test]
    fn loki97_is_a_live_node() {
        let n = registry().get("loki97").unwrap();
        assert_eq!(n.source_digest(), "ra-prim/loki97(libmcrypt-port)");
        let out = n
            .apply(&Repr::bytes(vec![0u8; 32]), &params! {"key" => "Zombies"})
            .expect("loki97 must execute");
        assert_eq!(out.data.len(), 32);
        assert_ne!(out.data, vec![0u8; 32]);
    }

    #[test]
    fn defaults_are_the_corpus_invariants() {
        // cfb (=CFB-8) and the ASCII-zero IV, with no parameters supplied
        let n = registry().get("des").unwrap();
        let p = params! {"key" => "Zombies"};
        assert_eq!(n.block_size(&p), Some(8));

        let explicit = params! {
            "key" => "Zombies",
            "mode" => "cfb",
            "iv" => "30303030303030303030303030303030",
        };
        let a = n.apply(&Repr::bytes(b"abcdefghij".to_vec()), &p).unwrap();
        let b = n
            .apply(&Repr::bytes(b"abcdefghij".to_vec()), &explicit)
            .unwrap();
        assert_eq!(a.data, b.data, "defaults must equal the corpus invariants");
    }

    /// A hash-derived `keyderiv` policy must actually change the ciphertext relative
    /// to a raw-byte one — otherwise the hash-derived family would be wired up but
    /// inert. Reached through the node exactly as `--kd md5` would be from the CLI.
    #[test]
    fn hash_derived_keyderiv_changes_the_key_material() {
        let n = registry().get("des").unwrap();
        let d = Repr::bytes(b"abcdefghij".to_vec());
        let raw = n
            .apply(
                &d,
                &params! {"key" => "Zombies", "keyderiv" => "null-pad-max"},
            )
            .unwrap();
        let md5 = n
            .apply(&d, &params! {"key" => "Zombies", "keyderiv" => "md5"})
            .unwrap();
        assert_ne!(raw.data, md5.data);
    }

    #[test]
    fn ecb_reports_no_block_size_to_the_oracle() {
        let n = registry().get("des").unwrap();
        let p = params! {"key" => "Zombies", "mode" => "ecb"};
        assert_eq!(n.block_size(&p), None);
    }

    #[test]
    fn unknown_mode_and_policy_are_rejected() {
        let n = registry().get("des").unwrap();
        let d = Repr::bytes(vec![0u8; 16]);
        assert!(n
            .apply(&d, &params! {"key" => "Zombies", "mode" => "gcm"})
            .is_err());
        assert!(n
            .apply(&d, &params! {"key" => "Zombies", "keyderiv" => "pbkdf2"})
            .is_err());
    }

    #[test]
    fn decryption_is_layer_forming_and_keyed() {
        let n = registry().get("twofish").unwrap();
        assert!(n.layer_forming());
        assert!(!n.terminal());
        assert_eq!(n.family(), Family::Dec);
    }
}
