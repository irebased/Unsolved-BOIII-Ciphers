// Shared style + helper module for the BO3 cipher dossier papers.
// Formal research-paper aesthetic. No em dashes anywhere in generated text.
const docx = require("docx");
const {
  Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell,
  WidthType, BorderStyle, ShadingType, PageNumber, Header, Footer, TabStopType,
  TabStopPosition, LevelFormat, convertInchesToTwip,
} = docx;

const FONT = "Calibri";
const SERIF = "Cambria";
const MONO = "Consolas";
const INK = "1A1A1A";
const ACCENT = "5A2A2A";      // deep oxblood, thematic but restrained
const RULE = "9A9A9A";
const CELL_HEAD = "EDE7E7";
const CELL_ALT = "F7F4F4";

// US Letter
const PAGE = { size: { width: 12240, height: 15840 }, margin: {
  top: 1440, bottom: 1440, left: 1440, right: 1440 } };

function title(text) {
  return new Paragraph({
    alignment: AlignmentType.LEFT,
    spacing: { after: 60 },
    children: [new TextRun({ text, bold: true, size: 40, font: SERIF, color: INK })],
  });
}
function subtitle(text) {
  return new Paragraph({
    spacing: { after: 240 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: ACCENT, space: 8 } },
    children: [new TextRun({ text, italics: true, size: 22, font: SERIF, color: ACCENT })],
  });
}
function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 300, after: 120 },
    children: [new TextRun({ text, bold: true, size: 28, font: SERIF, color: ACCENT })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 220, after: 90 },
    children: [new TextRun({ text, bold: true, size: 23, font: SERIF, color: INK })],
  });
}
function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 160, after: 70 },
    children: [new TextRun({ text, bold: true, italics: true, size: 21, font: SERIF, color: INK })],
  });
}
// body paragraph from an array of runs (strings or {t,bold,italics,mono})
function p(runs, opts = {}) {
  const children = (Array.isArray(runs) ? runs : [runs]).map(r => {
    if (typeof r === "string") return new TextRun({ text: r, size: 21, font: FONT, color: INK });
    return new TextRun({
      text: r.t, bold: !!r.bold, italics: !!r.italics,
      font: r.mono ? MONO : FONT, size: r.mono ? 19 : 21,
      color: r.color || INK,
    });
  });
  return new Paragraph({
    spacing: { after: opts.after ?? 140, line: 276 },
    alignment: opts.align || AlignmentType.JUSTIFIED,
    children,
    ...(opts.keepNext ? { keepNext: true } : {}),
  });
}
// monospace block (ciphertext, chains)
function mono(text, opts = {}) {
  const lines = String(text).split("\n");
  return lines.map((ln, i) => new Paragraph({
    spacing: { after: i === lines.length - 1 ? (opts.after ?? 140) : 0, line: 240 },
    shading: { type: ShadingType.CLEAR, fill: "F2EFEF", color: "auto" },
    border: {
      left: { style: BorderStyle.SINGLE, size: 18, color: ACCENT, space: 6 },
      top: i === 0 ? { style: BorderStyle.SINGLE, size: 2, color: RULE, space: 4 } : undefined,
      bottom: i === lines.length - 1 ? { style: BorderStyle.SINGLE, size: 2, color: RULE, space: 4 } : undefined,
    },
    indent: { left: 120 },
    children: [new TextRun({ text: ln || " ", font: MONO, size: 17, color: INK })],
  }));
}
// bullet list item
function li(runs, level = 0) {
  const children = (Array.isArray(runs) ? runs : [runs]).map(r =>
    typeof r === "string"
      ? new TextRun({ text: r, size: 21, font: FONT, color: INK })
      : new TextRun({ text: r.t, bold: !!r.bold, italics: !!r.italics, font: r.mono ? MONO : FONT, size: r.mono ? 19 : 21, color: r.color || INK }));
  return new Paragraph({ numbering: { reference: "bullets", level }, spacing: { after: 70, line: 264 }, children });
}
function numItem(runs, ref = "steps", level = 0) {
  const children = (Array.isArray(runs) ? runs : [runs]).map(r =>
    typeof r === "string"
      ? new TextRun({ text: r, size: 21, font: FONT, color: INK })
      : new TextRun({ text: r.t, bold: !!r.bold, italics: !!r.italics, font: r.mono ? MONO : FONT, size: r.mono ? 19 : 21, color: r.color || INK }));
  return new Paragraph({ numbering: { reference: ref, level }, spacing: { after: 70, line: 264 }, children });
}

// simple table with header row; rows = array of arrays of strings
function table(header, rows, widths) {
  const totalW = widths.reduce((a, b) => a + b, 0);
  const mk = (text, { head = false, alt = false } = {}) => new TableCell({
    width: { size: 0, type: WidthType.AUTO },
    shading: { type: ShadingType.CLEAR, fill: head ? CELL_HEAD : (alt ? CELL_ALT : "FFFFFF"), color: "auto" },
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: String(text).split("\n").map(t => new Paragraph({
      spacing: { after: 0, line: 240 },
      children: [new TextRun({ text: t, bold: head, size: head ? 18 : 18, font: FONT, color: INK })],
    })),
  });
  const headerRow = new TableRow({
    tableHeader: true,
    children: header.map((h, i) => { const c = mk(h, { head: true }); c.options.width = { size: widths[i], type: WidthType.DXA }; return c; }),
  });
  const bodyRows = rows.map((r, ri) => new TableRow({
    children: r.map((cellText, i) => { const c = mk(cellText, { alt: ri % 2 === 1 }); c.options.width = { size: widths[i], type: WidthType.DXA }; return c; }),
  }));
  return new Table({
    columnWidths: widths,
    width: { size: totalW, type: WidthType.DXA },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 2, color: RULE },
      bottom: { style: BorderStyle.SINGLE, size: 2, color: RULE },
      left: { style: BorderStyle.SINGLE, size: 2, color: RULE },
      right: { style: BorderStyle.SINGLE, size: 2, color: RULE },
      insideHorizontal: { style: BorderStyle.SINGLE, size: 1, color: "CFCFCF" },
      insideVertical: { style: BorderStyle.SINGLE, size: 1, color: "CFCFCF" },
    },
    rows: [headerRow, ...bodyRows],
  });
}

// evidence-tier callout box
function callout(label, runs, color = ACCENT) {
  const children = [new TextRun({ text: label + "  ", bold: true, size: 19, font: FONT, color })];
  (Array.isArray(runs) ? runs : [runs]).forEach(r =>
    children.push(typeof r === "string"
      ? new TextRun({ text: r, size: 20, font: FONT, color: INK })
      : new TextRun({ text: r.t, bold: !!r.bold, italics: !!r.italics, font: r.mono ? MONO : FONT, size: r.mono ? 18 : 20, color: r.color || INK })));
  return new Paragraph({
    spacing: { before: 60, after: 140, line: 264 },
    shading: { type: ShadingType.CLEAR, fill: "F5F1F1", color: "auto" },
    border: {
      left: { style: BorderStyle.SINGLE, size: 20, color, space: 8 },
      top: { style: BorderStyle.SINGLE, size: 2, color: "DDD5D5", space: 4 },
      bottom: { style: BorderStyle.SINGLE, size: 2, color: "DDD5D5", space: 4 },
      right: { style: BorderStyle.SINGLE, size: 2, color: "DDD5D5", space: 4 },
    },
    indent: { left: 120, right: 120 },
    children,
  });
}

function spacer(after = 120) { return new Paragraph({ spacing: { after }, children: [] }); }

function makeHeaderFooter(shortTitle) {
  return {
    headers: { default: new Header({ children: [new Paragraph({
      alignment: AlignmentType.RIGHT,
      border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: RULE, space: 6 } },
      children: [new TextRun({ text: shortTitle, size: 16, font: FONT, color: RULE, italics: true })],
    })] }) },
    footers: { default: new Footer({ children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({ text: "BO3 Cipher Dossier   |   ", size: 15, font: FONT, color: RULE }),
        new TextRun({ children: ["Page ", PageNumber.CURRENT, " of ", PageNumber.TOTAL_PAGES], size: 15, font: FONT, color: RULE }),
      ],
    })] }) },
  };
}

const numbering = {
  config: [
    { reference: "bullets", levels: [
      { level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 460, hanging: 260 } } } },
      { level: 1, format: LevelFormat.BULLET, text: "\u2013", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 820, hanging: 260 } } } },
    ]},
    { reference: "steps", levels: [
      { level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 460, hanging: 260 } } } },
    ]},
    { reference: "steps2", levels: [
      { level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 460, hanging: 260 } } } },
    ]},
    { reference: "steps3", levels: [
      { level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 460, hanging: 260 } } } },
    ]},
  ],
};

module.exports = {
  docx, PAGE, numbering, title, subtitle, h1, h2, h3, p, mono, li, numItem,
  table, callout, spacer, makeHeaderFooter, FONT, SERIF, MONO, INK, ACCENT,
};
