# Layering pattern analysis: what the solved corpus tells us to try next

**Purpose.** Single-layer modern decryption is exhausted for both unsolved targets
(TG4, REV7) — forward and reverse ciphertext, forward/reverse key casing, every mcrypt
primitive, mode, and IV in the dossier, with the operator's own dedicated tool. Nothing.
So the answer, if it is a cipher of this family at all, is a **multi-layer composition**.
This document derives the *grammar* of those compositions from the 11 solved
modern/hybrid chains in the corpus, and turns it into a ranked, runnable set of
multi-layer skeleton hypotheses for TG4 and REV7.

Every chain below is from `data/evidence_base.json`. Claims are labelled **EVIDENCED**
(read from the corpus or measured), **INFERRED** (argued from evidence), or
**SPECULATION** (a lead worth cost, not a belief), matching the convention in
`docs/tg4-family-analysis.md`.

Family abbreviations: **DEC** modern keyed decrypt · **CDC** codec/decode (representation
change, not layer-forming) · **XF** byte transform (reverse/rot/insert/remove) · **CLA**
classical cipher layer.

---

## 1. The solved corpus as skeletons

Every solved cipher that contains at least one modern decrypt or a multi-step chain,
written as its family sequence. This is the evidence the grammar is read off.

| id | kind | len | modern layers | skeleton | detail |
|---|---|---|---|---|---|
| rev1 | hybrid | 64 | **2** | `CLA DEC XF DEC` | beaufort(ZOMBIES) → RC2/**ECB** → reverse → rijndael-256/**ECB** |
| rev2 | hybrid | 5907 | 1 | `XF CDC DEC CLA` | remove('v') → hex → DES/CFB(**ZOMBIES**) → bacon |
| rev5 | modern | 2208 | **3** | `DEC XF CDC DEC DEC` | RC2/CFB → reverse → hex_to_base64 → Blowfish/CFB → Loki97/CFB |
| rev6 | hybrid | 768 | 1 | `CDC XF CDC DEC CLA` | decimal → reverse → hex_to_base64 → Serpent/CFB → substitution |
| rev8 | modern | 4610 | 1 | `XF CDC XF CDC DEC CDC` | insert → hex → reverse → hex_to_base64 → Blowfish-compat/CFB → base64 |
| rev9 | modern | 1080 | **2** | `DEC CDC XF DEC` | DES/CFB → decimal → reverse → Twofish/CFB |
| rev10 | modern | 3734 | **2** | `CDC DEC CDC CDC DEC` | hex_to_base64 → RC4 → octal → hex_to_base64 → Saferplus/CFB |
| rev12 | modern | 422 | 1 | `CDC DEC XF XF` | hex_to_base64 → XTEA/CFB → reverse → rot(6) |
| rev11 | classical | 460 | 0 | `XF XF CLA XF XF XF CLA` | reverse → rot(6) → playfair(ZOMBIES) → edits → Trifid |
| rev3 | classical | 107 | 0 | `CDC CLA CLA` | base10 → straddling → substitution |
| rev13 | classical | 270 | 0 | `XF CLA` | reverse → affine(15,19) |

The Giant's solved ciphers are **all classical or physical puzzles** — tg3 Simplified
Lorenz (CIMT), tg5 Enigma M3 (Practical Cryptography), tg1/tg2/tg6 presentation puzzles.
**TG4 is the only Giant cipher attributed `Unknown / Unknown / N/A`** in
`data/zombies_sources.csv`. That is the single most important fact about it: it is an
outlier on its own map, and the Revelations invariants may not transfer to it (§6).

---

## 2. The layering grammar

Seven rules, each with its corpus support. Together they are a generative grammar: a
small set of skeletons that the author actually used, as opposed to the astronomically
larger set of skeletons that are merely *possible*.

**Rule 1 — Modern-layer depth is 1–3, never more. Total chain length ≤ 7.**
EVIDENCED. Modern-decrypt count across the 11 chains: 1 (rev2,6,8,12), 2 (rev1,9,10),
3 (rev5). Total step count peaks at 7 (rev11 classical, rev8 modern=6). So "up to five
layers" is best read as **total steps up to ~7, with at most 3 keyed decryptions.** A
multi-layer search bounded at 3 DEC and 7 total steps contains every shape the author
has ever shipped.

**Rule 2 — Every modern decrypt is fed text, via a codec, because the tool base64-decodes
its input.** EVIDENCED (`README.md`, `ARCHITECTURE.md`: the tools4noobs decrypt box
base64-decodes at every hop). So the real shape around a decrypt is
`… → [re-encode-as-text codec] → (implicit b64decode) → DEC → …`. The explicit
re-encoding codecs observed are `{hex, decimal, octal, base64, hex_to_base64}`. This is
why `hex_to_base64` opens rev6/rev10/rev12 and recurs inside rev5/rev8/rev10.

**Rule 3 — `reverse` is the dominant transform, and it lives between layers.** EVIDENCED.
`reverse` appears in **8 of 14** Revelations chains (rev1,5,6,8,9,11,12,13). It typically
sits immediately after a decrypt and before the next codec, or at the very start. `rot`
co-occurs as a *trailing* partner (rev11, rev12: `… reverse → rot`). The recorded `rot`
shift is the **encryption** shift; decryption applies the inverse (rev12's "shift 6" =
ROT-20).

**Rule 4 — Classical layers bracket the modern core; they never sit between two modern
layers.** EVIDENCED. Classical appears strictly first (rev1 beaufort) or strictly last
(rev2 bacon, rev6 substitution). The template is therefore

```
[ optional leading CLA/XF ]  →  MODERN CORE (1–3 DEC with inter-layer codecs)  →  [ optional trailing CLA ]
```

This is exactly the region the exhausted single-layer sweep did **not** cover.

**Rule 5 — Every intermediate between two layers is pure printable text in one of
{base64, hex, decimal, octal}.** INFERRED from Rule 2, and it is the load-bearing rule
for tractability (§3). A decrypt's binary output must be rendered as one of those four
alphabets before the next hop's implicit base64-decode can consume it.

**Rule 6 — Mode is CFB (= mcrypt CFB-8) for the Revelations modern era; ECB is the
exception, and it is the *earliest* one.** EVIDENCED. 9 of 10 modern decrypts are CFB;
rev1 alone is ECB, on both layers (RC2 and rijndael-256). rev1 is also the only chain
that opens with a classical layer. **INFERRED:** ECB + leading-classical is an *earlier*
authorial style than the later CFB-8 pipelines — which matters for TG4, a pre-Revelations
artefact (§6).

**Rule 7 — Key casing tracks layer type.** EVIDENCED. `Zombies` (title case) keys every
modern decrypt bar one; `ZOMBIES` (upper) keys the classical layers (beaufort rev1,
playfair rev11) and the single anomalous DES (rev2, the least carefully recorded step).
Classical layers use the 52-char mixed-case `A–Za–z` alphabet.

---

## 3. Tractability splits in two: where the layers begin decides everything

There is no single "multi-layer is tractable" story. It depends entirely on whether the
**modern layer comes first**. The operator's stuck point (stated directly) is precisely
the case where it does not, so the two cases must be separated.

### 3A. Modern-first chains are cheap — an intermediate oracle prunes depth

If the first keyed layer is modern (`b64decode → DEC → …`, as in rev5/rev9/rev10/rev12),
then breaking that one modern layer produces a **scoreable** intermediate. By Rule 5 a
layer-1 output can only feed a layer 2 if it is pure text in {base64, hex, decimal,
octal}, so scoring layer-1 output for charset purity tests *every deeper chain that could
route through it, at once*, without enumerating layer 2. This is validated:
`docs/tg4-family-analysis.md` §3 planted a two-layer canary (inner riddle → 3-digit
decimal → Blowfish/CFB) and the structural oracle **caught it at layer 1 by decimal
purity = 1.000**. The engine's `encoding-valid` oracle (`ValidEncodingAny`) is exactly
this instrument. Chance purities to beat: base64 0.258, hex 0.090, decimal 0.043, octal
0.035; a real intermediate sits at 1.0. No ambiguous middle.

**Consequence for modern-first: the search is a sequence of cheap single-layer sweeps,
not a product.** Sweep layer 1 over all settings, keep only outputs ≥~0.95 pure in some
alphabet (the corpus's true intermediates are 100% pure, so the threshold is safe),
expand only survivors. Depth is effectively free once the right layer-1 primitive is
found. This is where widening the primitive/key-derivation axes (§4) pays off directly.

### 3B. Classical-first chains are the hard case — no oracle exists until you clear the modern layer

This is the operator's actual blocker, and it is real. If a classical layer comes first
(rev1: `beaufort → … → DEC`), its output is a substitution/transposition of the
base64/hex text and therefore **still looks like high-entropy base64/hex** — same
alphabet, same symbol histogram (transposition preserves it exactly; substitution merely
relabels it), same entropy. There is **no measurement at the classical boundary that
distinguishes the right classical step from a wrong one.** Confirmation only arrives
*after* the modern layer is also broken and structure appears underneath.

So the classical-first search is an irreducible **joint product**: for every classical
config `C` and every modern config `M`, compute `DEC_M(b64decode(C(ciphertext)))` and
score *that*. The intermediate cannot prune. This is why it explodes — and why stacking
*several* classical layers before the modern one (`C₁ × C₂ × M`) is what the operator
found computationally hopeless.

**The corpus bounds the explosion, hard. Two facts, both EVIDENCED this session from
`data/evidence_base.json`:**

1. **At most ONE keyed classical layer ever precedes a modern core.** Of the 11
   modern/hybrid chains, exactly one (rev1) has a keyed classical before the first
   decrypt — a single Beaufort. Every other chain's leading steps are free transforms
   (`reverse`, `insert`, `remove`) and codecs (`hex`, `decimal`, `hex_to_base64`), which
   carry *no key search cost*. Stacked keyed-classical sequences occur **only** in
   fully-classical ciphers (rev3 straddling→substitution, rev11 playfair→Trifid), which
   have no modern layer at all.
2. **That classical layer is keyed by the known key set.** rev1's Beaufort key is
   `ZOMBIES`; rev11's Playfair key is `ZOMBIES`. The classical key is not an open search
   — it is drawn from the same ~6–8 keys already in the dossier.

**So the correct classical-first search is not "brute-force N classical ciphers in
sequence with open keys." It is: one keyed classical layer, key from the known set,
alphabet-preserving cipher, jointly with the modern axis, scored only after the modern
decrypt.** Everything the operator did that assumed a deeper or open-keyed classical
preamble was searching outside the evidenced grammar — which is exactly where the cost
became unpayable.

### 3C. Feasibility of the bounded joint search

With the classical axis constrained by §3B, the joint product is small. Take a
constrained leading-classical axis:

```
classical cipher type   ~10   (beaufort, vigenère, variant-beaufort, affine, columnar,
                                rail-fence, route, keyed-substitution, autokey, playfair)
classical key           ~8    (ZOMBIES/Zombies/zombies, TheGiant/thegiant/The Giant, …)
alphabet                ~3    (52-char A–Za–z, 64-char base64, 16-char hex where valid)
direction               ~2
                        ─────
|C|  ≈  500 – 2,000
```

against the modern axis `|M|` = 3,696 (narrow, as swept) or ~15,120 (widened per §4):

| target | |C| × |M| | × variants | total | verdict |
|---|---|---|---|---|---|
| REV7, narrow M | 500 × 3,696 | ×1 (hex, no glyph axis) | **1.85e6** | trivial (seconds) |
| REV7, wide M | 2,000 × 15,120 | ×1 | **3.0e7** | trivial (minutes) |
| TG4, narrow M, recorded reading | 500 × 3,696 | ×1 (v00) | **1.85e6** | trivial |
| TG4, wide M, all 128 readings | 2,000 × 15,120 | ×128 | **3.9e9** | feasible (hours) |

Contrast the *unbounded* version the operator hit — two open-keyed classical layers,
`(thousands)² × 15,120 × 128 ≈ 10¹³⁺` — which is genuinely intractable. **The entire
difference between hopeless and a few hours is the corpus bound in §3B.** That bound is
the central result of this analysis.

Two engineering consequences, both confirmed by the readiness audit (§4.1):

- The joint search must score **only after the modern decrypt** — the `encoding-valid` or
  `printable-and-english` oracle on the terminal output, never at the classical boundary.
- The classical axis must be *corpus-constrained*, not free. A general "try every
  classical cipher with every key" sweep re-creates the explosion; the win comes from
  enumerating only the evidenced `(type, known-key, alphabet)` triples.

---

## 4. The axes that were never widened

Single-layer exhaustion was over a *narrow* per-layer product. The corpus grammar and the
tool ecosystem say three axes carry almost no coverage. These are where a multi-layer
sweep must spend, per Rule 5's cheap depth.

| axis | swept so far | grammar/ecosystem says also try |
|---|---|---|
| **primitive** | 11 corpus-proven | **AES (`rijndael-128`)** — the tools4noobs default; 3DES; CAST-128; IDEA; and the untried mcrypt menu (gost, wake, cast-256, rijndael-192, **enigma**). All four of AES/3DES/CAST/IDEA are already implemented and validated against libmcrypt's own self-test vectors in `crates/ra-prim/src/prim.rs` — usable in exploratory sweeps today. |
| **key derivation** | 4 raw-byte policies | **hash-derived**: `md5/sha1/sha256(pass)` as raw digest **and** as lowercase/uppercase hex string; **`EVP_BytesToKey`** (OpenSSL's password→key, ubiquitous in PHP/JS crypto forms). Multiplies the axis ~4→9. |
| **skeleton bracket** | bare `codec → DEC` | **leading** classical/transform (rev1, rev8, rev11) and **trailing** classical (rev2, rev6). The `--pre` slot now exists; the trailing-classical slot is the corpus's other documented shape. |

Everything else (key list, IV set) is the best-evidenced and least productive axis —
do not widen it.

### 4.1 What the engine can express today, and the gaps that block the plan

Audited against the current `ra sweep` CLI (build green, 747 tests pass; AES/3DES
self-tests pass; all 15 primitives selectable).

**Expressible now:**
- Modern-first tiers T1/T2/T3 — including 2-modern-layer chains with an inter-layer codec
  (`--tier t3`, the rev9/rev10 shape).
- A **leading Beaufort / rot / reverse / stripws / group** before the first decode, and
  `+`-joined compositions of them (`--pre beaufort:key=ZOMBIES`, `--pre stripws+reverse`).
  This is the rev1 leading-classical shape for the *one* keyed classical the corpus
  supports, and it is exactly the §3B joint search — scored after the modern layer.
- The **`encoding-valid` oracle** (`ValidEncodingAny`) for intermediate charset-purity
  scoring (§3A), and `printable-and-english` for terminal hit-calling.
- All 15 primitives (incl. AES/`rijndael-128`, 3DES) and the expanded mode/IV axes.

**Three gaps that need a code change before the full plan runs** (each is a bounded,
testable task, not research):

| gap | corpus shape blocked | what it needs |
|---|---|---|
| **G1 — trailing classical** | rev2 (`DEC→bacon`), rev6 (`DEC→substitution`), rev12 (`DEC→reverse→rot`) | a transform/classical slot *after* the terminal `dec`; a new skeleton `… dec ∘ xf` / `dec ∘ cla`. **Highest value** — explains a null pure-modern search, and both targets plausibly end in a classical layer. |
| **G2 — richer leading classical** | any leading classical that is not Beaufort/rot/reverse (vigenère, columnar, affine, keyed substitution, route) | extend the `--pre` axis (or add a general classical-layer axis) to reference the registry classical solvers, which already exist and are conformance-proven. |
| **G3 — a third modern layer** | rev5 (3 modern), rev10/rev8 (2 modern + heavy codecs) | a T4 skeleton with a third `dec` slot; only worth building once §3A pruning is wired so the 2-layer prefix filters what feeds it. Lowest priority. |

The key-derivation widening (hash-derived + `EVP_BytesToKey`, §4) is also not yet a sweep
axis and is a prerequisite for the Family-B TG4 hypothesis (§6).

---

## 5. REV7 — ranked hypotheses

**What is fixed.** EVIDENCED. Hex surface, 16 symbols, entropy 3.99/sym, 1092 chars.
Repair is settled: **550 bytes, not 546** — 8 hex chars short in two grid gaps, confirmed
by parity and final-line width (`notes/rev7-repair-search.md`). It is on Revelations, the
map where **every** solved cipher uses tools4noobs / mcrypt / CFB-8 / key `Zombies`, so
the toolchain and invariants are near-certain here. It is a statistical twin of rev12
(a 4-step modern chain). The single-layer repair search is a rigorous null.

**INFERRED:** REV7 is a rev12/rev9/rev10-shaped multi-layer chain that opens by treating
the hex as a codec feed. Ranked skeletons, each tied to a corpus precedent:

| # | skeleton | precedent | why | conf |
|---|---|---|---|---|
| R1 | `hex_to_base64 → DEC → reverse → (DEC \| rot \| CLA)` | rev12 (twin), rev6 | hex surface → base64 feed → modern, with the reverse+trailing that rev12 uses | high |
| R2 | `hexdecode → DEC → decimal/octal → reverse → DEC` | rev9 | two modern layers with a decimal inter-layer codec and a mid-chain reverse | high |
| R3 | `hex_to_base64 → DEC → codec → hex_to_base64 → DEC` | rev10 | RC4/Saferplus-style double modern with repeated `hex_to_base64` | med |
| R4 | `DEC → … → CLA` (trailing bacon/substitution/affine) | rev2, rev6, rev13 | a classical *final* layer would explain why a pure-modern search never terminates in English | med |

**Sweep plan (uses §3, so it is cheap):**
- **Apply the 550-byte repair first.** The reverse skeletons (R1, R2 mid-reverse) cannot
  use the sequential prefix decomposition (`notes/rev7-repair-search.md` §8): reversing
  puts the still-unknown tail at the front. So either (a) pin the repair from the source
  image first, or (b) pay the joint `16⁵ × 14·16⁵` repair enumeration on the reverse
  branch. **Recommended: get `revelations_7.png` re-read to pin the two gaps — zero
  compute, and it unblocks every reverse skeleton.**
- Run a **layer-1 structural sweep**: `hex_to_base64 → DEC` and `hexdecode → DEC` over the
  full 15-primitive × expanded-key-derivation × 7-mode axes, key `Zombies`, IV ascii0,
  scoring each output for {base64/hex/decimal/octal} purity (Rule 5). Trivial size
  (~15k × few codecs). Any survivor names the layer-1 primitive and its feed alphabet.
- Expand survivors into layer 2 per R1–R3. Add a **trailing-classical** pass (R4) scoring
  the final output for English.

**REV7 is the higher-probability solve of the two** — the toolchain is pinned, only the
layering arrangement is open, and the structural oracle makes the whole 2–3 layer space
cheap once the repair is fixed.

---

## 6. TG4 — ranked hypotheses

**What is fixed.** EVIDENCED. Standard base64 surface (62/64 symbols, `+` and `S` merely
absent), 144 bytes, entropy 6.75/byte, incompressible. **Proved impossible** to be
classical, base64-of-7-bit-text, or a compression container (`tg4-family-analysis.md`
§2). So the payload is modern-cipher / CSPRNG output.

**The complication that reshapes the search.** TG4 shipped ~10 months *before*
Revelations. The `Zombies` / IV-`3030…` / CFB-8 / tools4noobs invariant is derived
**entirely** from Revelations and is *later* practice. The Giant's own tradition is
CIMT, Practical Cryptography, Cryptool Online — and TG4 is its lone `Unknown/Unknown`
outlier. **INFERRED:** the Revelations invariants are a *prior*, not a constraint, for
TG4. This is the deepest reason the Zombies-key single-layer search came up empty.

Two hypothesis families, both worth cost:

**Family A — TG4 is an early Revelations-style mcrypt chain (author reusing the tool
before Revelations shipped).** Ranked skeletons:

| # | skeleton | precedent | why | conf |
|---|---|---|---|---|
| A1 | `b64decode → DEC → codec → reverse → DEC` | rev9 | 2 modern layers, decimal/octal inter-layer, mid reverse — the commonest modern shape | high |
| A2 | `CLA(beaufort) → b64decode → DEC → reverse → DEC` (ECB) | **rev1** | rev1 is the earliest modern chain: leading Beaufort + **ECB** on both layers. TG4 being early makes rev1 its closest structural relative | high |
| A3 | `b64decode → DEC → reverse → rot / trailing CLA` | rev12, rev6, rev2 | single modern layer with a *trailing classical* — never swept, and it explains a null pure-modern search | med |
| A4 | `b64decode → DEC → codec → DEC → DEC` (3 layers) | rev5 | only if A1/A2 leave promising structural survivors; §3 makes the third layer cheap | low |

**Family B — TG4 is not mcrypt at all: a different modern web tool with hash-derived
keys.** SPECULATION, but it is where the untested axes point. AES-128/CBC or CFB with
`key = md5(passphrase)` or `EVP_BytesToKey(passphrase)` is the single most common
configuration of 2016-era browser/PHP crypto forms, and **AES is the tools4noobs
successor form's own default**. The passphrase is most likely `TheGiant`/`The Giant`
(the sheet label) rather than `Zombies`.

**Sweep plan:**
- **Widen the layer-1 axes to the full 15 primitives + the 9 key-derivation policies
  (§4), including AES and hash-derived/EVP keys**, over both key families (`Zombies…`
  *and* `TheGiant`/`The Giant`), both ECB and CFB-8, and score structurally (Rule 5) so
  one pass covers all depths. This is the highest-value TG4 sweep and it is small:
  15 prim × 7 mode × ~8 key × 9 kd × 2 iv × 128 variants ≈ 1.9M per skeleton.
- **Add the leading-`CLA`/`--pre` bracket (A2) and the trailing-`CLA` bracket (A3)** —
  the two brackets the corpus documents and the sweep never had.
- Keep the **128-variant transcription axis** on every TG4 run (it is cheap and derived).
- **Zero-compute first:** resolve the 7 open `I`/`l` glyphs (factor 128), and ask the
  owner whether the physical sheet carries a *number/date* — the author uses numeric date
  keys elsewhere (de7, gk11), which would be a new *evidenced* key rather than a guess.

---

## 7. What is newly in scope

Relative to the exhausted single-layer region, this analysis puts four things in scope
that were never swept, ranked by corpus support:

1. **A step before the first decryption** (leading `CLA`/`XF`) — 2 of 11 chains
   (rev1, rev8). Largest gap, cheapest to close, and rev1 makes it the *most* likely
   shape for early-era TG4.
2. **A classical layer after the last decryption** (trailing `CLA`) — 2 of 11
   (rev2, rev6). Explains a null pure-modern search that would otherwise look decisive.
3. **The full primitive + key-derivation product** (AES, 3DES, CAST, IDEA, enigma;
   hash-derived and EVP keys) — the axes §4 shows were never widened. AES especially.
4. **2–3 modern layers with inter-layer codecs**, made tractable by the structural
   oracle (§3) rather than by brute-force depth.

What stays **out** of scope and why: widening the key *list* (best-evidenced axis,
unproductive); enumerating depth as a product instead of a structural sequence (§3);
and — for REV7's reverse skeletons — the sequential prefix trick, which cannot cover a
leading full-stream reverse.

---

## 8. Execution roadmap, in priority order

Each step is tagged **[now]** (runs on the current engine) or **[needs Gx]** (blocked on a
§4.1 gap), and **modern-first** (cheap, §3A) or **joint** (classical-first, §3B).

1. **[now · modern-first] REV7 layer-1 structural sweep.** `hex_to_base64 → DEC` and
   `hexdecode → DEC` over all 15 primitives × expanded key-derivation × 7 modes, key
   `Zombies`, IV ascii0, `--oracle encoding-valid`. Trivial size; any survivor names the
   layer-1 primitive and feed alphabet. Do this before anything else — REV7 is the
   higher-probability solve and this is the cheapest decisive test.
2. **[now · joint] REV7 + TG4 leading-Beaufort joint sweep.** `--pre beaufort:key=<known
   keys>` into T1/T2, scored *after* the modern layer with `printable-and-english`. This
   is the rev1 shape, the one keyed-classical case the corpus supports, and it is exactly
   §3C's 1.85e6-candidate search. Cheap and evidenced.
3. **[now · modern-first] TG4 widened layer-1 structural sweep**, all 128 readings, 15
   primitives, both key families (`Zombies…` and `TheGiant…`), ECB **and** CFB-8,
   `--oracle encoding-valid`. Covers Family-A single-modern and feeds the T3 expansion.
4. **[needs G1 · joint] Trailing-classical pass** for both targets — the shape that
   explains a null pure-modern result (rev2/rev6). Build the post-`dec` slot first; it is
   the highest-value gap.
5. **[needs key-derivation axis · modern-first] Family-B TG4**: AES/CBC & CFB with
   `md5/sha1/sha256` and `EVP_BytesToKey` derivations, passphrase `TheGiant`/`The Giant`.
6. **[needs G2 · joint] Richer leading classical** (vigenère/columnar/affine/keyed-sub)
   — only if steps 1–4 are clean.
7. **[needs G3 · modern-first] Third modern layer** (rev5 shape) — last, and only with
   §3A pruning wired so the 2-layer prefix filters what feeds layer 3.

Sequencing rule from §3: never spend on a deeper/joint step (2, 4, 6, 7) before the
cheap structural layer-1 sweeps (1, 3) have named — or definitively excluded — a layer-1
primitive for that target.

## 8bis. Tool provenance reshapes the leading-classical axis

The mcrypt/tools4noobs invariant is a *known* tool, not the *only* tool. Two facts from
the operator change what the leading layer can be:

- **The tool list is known-incomplete.** The left-padded fixed-width zero decimal
  encoding used by several ciphers (rev6/rev9/rev10) has no identified tool; the author
  demonstrably used at least one tool nobody has pinned. So a negative over the known
  tools does not close the space — it must be stated as "empty for the known toolset."
- **The leading candidate tools carry no modern crypto.** Verified against the repo's own
  forensics (`docs/toolsites/`): **CrypTool Online** (the leading hypothesis for REV7's
  top layer) and **Geocaching Toolbox** (a hotter recent candidate) expose **only
  classical ciphers and encodings** — Vigenère, Beaufort, Autokey, Vernam/OTP, base64,
  ASCII (CTO); ADFGX, Affine, Bifid, Four-square, Gronsfeld, Playfair, Rail-fence,
  Trifid, base conversion, numbers-to-letters (GCT). Neither offers AES/DES/Blowfish/etc.

**Consequence.** If REV7's top layer is CrypTool Online, that top layer is **classical or
an encoding**, and the modern mcrypt core lives *beneath* it — exactly the §3B
classical-first joint search. But the leading axis is now pinned to a specific tool's
cipher set and, critically, its **exact option semantics** (CTO's alphabet templates,
"keep non-alphabet characters", custom alphabets), which decide whether the layer's output
stays valid base64/hex for the next hop. The engine's generic `beaufort`/`vigenère` nodes
are not guaranteed to match CTO byte-for-byte — the same tool-fidelity trap that CFB-8 and
RC2's key schedule already sprung (`ARCHITECTURE.md`). So the classical-first peel for REV7
should be run under **CrypTool-Online-faithful** Vigenère/Beaufort/Autokey/Vernam, not the
textbook versions.

This is why the leading candidate to *research and reproduce* is CrypTool Online's
classical/encoding menu, and (for TG4, provenance genuinely unknown) Geocaching Toolbox's.
The `--pre` axis today carries only `beaufort` among keyed classicals (§4.1 gap G2); a
CTO-faithful leading Vigenère/Autokey/Vernam layer is not yet expressible and is the
build that the REV7 hypothesis most needs.

## 8ter. Committed layer-1 baselines from this session

Both are exhaustive negatives over the **known mcrypt toolset**, recorded region and no
leading transform, structural (`encoding-valid`) oracle. Neither closes the space; each is
a committed set the residual can difference against.

| target | leading step | candidates | hits | scored region | FP budget |
|---|---|---|---|---|---|
| REV7 | none (raw) | 2,520 | **0** | 514–546 B | 2.8e-220 |
| REV7 | `reverse` (formatting-confirmed) | 2,520 | **0** | 514–546 B | 2.8e-220 |
| REV7 | `reverse + beaufort:key=ZOMBIES` (rev1 shape) | 2,520 | **0** | — | — |
| REV7 | `beaufort:key=ZOMBIES` | 2,520 | **0** | 363–395 B | 2.9e-155 |
| TG4 | none (raw) | 5,040 | **0** | 112–144 B | 6.5e-47 |
| TG4 | none, `--variants all` | 5,040 | **0** | 112–144 B | 6.5e-47 |

### Hash-derived key derivation — the axis that had never been swept

The `--kd` axis carries **15** policies, not the 4 raw-byte ones every prior sweep used:
`natural`, `null-pad-max`, `null-pad-next-supported`, `repeat-pad-max`, plus `md5`,
`sha1`, `sha256` (raw digest), `md5-hex`, `sha1-hex`, `sha256-hex` and their `-upper`
forms (the digest's hex *text* as key bytes), and `evp-md5`, `evp-sha256`
(OpenSSL `EVP_BytesToKey`, unsalted, matching `openssl enc -k <pass> -nosalt`). This is
the axis §4 identified as most likely untested, and it is now swept:

| target | leading step | oracle | candidates | hits | FP budget |
|---|---|---|---|---|---|
| TG4 | none | `encoding-valid` | 22,050 | **0** | 3.6e-46 |
| TG4 | none | `printable-0.75` | 22,050 | **0** | 2.3e-13 |
| REV7 | none | `encoding-valid` | 9,450 | **0** | 1.3e-219 |
| REV7 | none | `printable-0.75` | 9,450 | **0** | 2.9e-66 |
| REV7 | `reverse` | `encoding-valid` | 9,450 | **0** | 1.3e-219 |
| REV7 | `reverse` | `printable-0.75` | 9,450 | **0** | 2.9e-66 |

TG4 keys: `Zombies, ZOMBIES, zombies, TheGiant, thegiant, THEGIANT, TheGiant_b64`.
Committed as `claims/tg4-hashkd-t1-2026-07-31.json` and
`claims/rev7-hashkd-t1-2026-07-31.json`.

**So Family-B's key-derivation half is now eliminated at layer 1** for both targets: no
hash-derived or `EVP_BytesToKey` key over the 15-primitive menu yields either a structural
intermediate or printable text. What Family B still has open is the *tool*, not the key
derivation — a different mode/padding/IV convention, or an unidentified tool (§8quinquies).

### RESOLVED: conformance was circular, and the fix is a second proof class

*Decided by the project owner, 2026-07-31.* The section below records the problem as it
was first surfaced; the decision is stated here.

**The circularity.** Conformance admitted exactly one proof that a primitive may carry
coverage — reproducing a *solved* corpus chain. That conflates two different questions:

1. **Is this implementation correct?** Answerable by the algorithm's own normative test
   vectors (FIPS-197 C.1 for AES, eSTREAM for Salsa20, libmcrypt's compiled-in self-tests).
2. **Did the author use this primitive?** A *prior about the puzzle*, not a property of
   the code.

The gate used (2) as a proxy for (1). Its actual purpose — stopping a **defective**
implementation from manufacturing a false negative that silently deletes a region of the
search — is fully served by (1) alone. For the two unsolved ciphers, which may well use a
primitive that appears nowhere in the solved corpus, using (2) as the gate is
self-defeating: it can only ever certify what has already been witnessed, so it
structurally prevents crediting any search of genuinely new space. **TG4 and REV7 could be
something completely novel, and the accounting must not assume otherwise.**

**The decision: attack these ciphers with AES and Salsa20 as aggressively as with any
corpus-witnessed primitive.** Coverage accounting now carries two distinctly-tagged proof
classes:

| class | meaning | carries coverage |
|---|---|---|
| **CorpusProven** | reproduces a solved corpus chain end to end with known plaintext | yes |
| **VectorProven** | matches the algorithm's own published/normative test vectors | yes, tagged distinctly |
| **Unproven** | neither | **no — still exactly zero** |

The two proven classes are never silently merged; the precedent is this repo's existing
separation of heuristic `Solver` coverage from exhaustive coverage — visible, not
conflated. An auditor must be able to see at a glance which part of a negative rests on
the weaker (though still valid) proof. An unvalidated implementation still contributes
zero, so the safety property the gate exists for is preserved intact.

**One clarification worth stating, because it is easy to misread the warning.** The gate
never affected *search behaviour*. Every peel in §8ter already executed AES, 3DES,
CAST-128 and IDEA, and a hit would have been found and reported. Only the resulting
*negative's* contribution to the residual was suppressed. The search was already
aggressive; the accounting was conservative, and it is the accounting that is being
corrected.

### (Historical) The question as first surfaced

Emitting these claims printed:

```
WARNING: 4 swept primitive(s) are NOT proven and will contribute ZERO
coverage when this claim is folded: AES, 3DES, CAST-128, IDEA
```

That is conformance gating working as designed — but it means **the AES and 3DES sweeps
above record no coverage in the residual**, even though both are implemented and validated
against FIPS-197 C.1 and libmcrypt's own compiled-in self-test vectors. The conformance
model admits only one kind of proof: reproducing a *solved corpus chain*. No corpus cipher
uses AES or 3DES, so neither can ever be proven that way, and their coverage is
permanently zero no matter how much compute is spent on them.

This is a genuine design decision for the project owner, not a bug, and it should be made
deliberately:

- **Keep as is** — maximally conservative, but the two most probable primitives for a
  casual 2016 web-tool user (AES is the tools4noobs successor's own default) can never
  contribute coverage, so the residual will always overstate what is left.
- **Admit a second, weaker proof class** — a primitive validated against the *library's
  own published self-test vector* carries coverage, but is tagged distinctly from
  corpus-proven primitives so an auditor can tell the two apart, exactly as `Solver`
  coverage is already kept separate from exhaustive coverage.

The second option looks right by this project's own precedent (heuristic vs exhaustive
coverage are already distinguished rather than conflated), but it changes what every
existing residual figure means, so it is the owner's call.

Axes per row below: 15 primitives × 7 modes × {3 REV7 / 6 TG4} keys × 4 kd × 2 IVs. All include
AES/`rijndael-128`, 3DES, CAST-128 and IDEA — primitives the operator's own tool did not
carry — so these extend the single-layer negative to the full 15-primitive menu under the
structural oracle. **No bare mcrypt decryption of either recorded ciphertext, with or
without a leading reverse/Beaufort, yields a structural intermediate.**

Two caveats that bound what these rows mean, both important:

- **REV7 was swept at its recorded 546 bytes, not the repaired 550.** The repair
  (`notes/rev7-repair-search.md`) is the better hypothesis, and these rows do not test it.
  They are confirmatory of the existing single-layer null over a wider primitive menu, not
  a new test of the repaired stream.
- **TG4's variant axis is now a single point.** `--variants all` reports **0 open
  ambiguous glyph positions** — the 7 open `I`/`l` calls the README describes have since
  been resolved, and the 7 `0`/`O` were already fixed. The factor-128 reduction that §9
  lists as an outstanding zero-compute win has therefore **already been collected**;
  update §9 accordingly when confirmed with the project team.

The answer therefore lies in a leading classical/encoding layer (§8bis), a whitespace/
tool-artifact variation (§8quater), a non-mcrypt modern tool, or a trailing classical
layer (§4.1 G1) — not in a wider mcrypt layer-1.

## 8quater. Whitespace and tool artifacts are a coverage dimension, not just a nuisance

Flagged by the operator and confirmed in the corpus: recorded ciphertexts carry
whitespace as the norm, not the exception. REV7's display holds **218 whitespace
characters** (203 spaces, 15 newlines) in group-of-5 formatting; rev6's is
space-separated 3-digit zero-padded decimal with line wrapping.

The hazard has **two distinct forms, needing different fixes**:

1. **Scoring nuisance.** A genuinely correct intermediate that is pure hex except for a
   trailing `\n` fails a charset-purity check and is discarded — a **false negative**, the
   exact failure this project exists to prevent. Fix belongs at the classification/oracle
   boundary.
2. **Genuine coverage dimension.** The *true* intermediate may itself have carried a
   leading/trailing newline or space, because the author copied it out of a browser. Then
   the bytes fed to the next layer differ, and no amount of oracle tolerance recovers the
   chain — the candidate was never generated. Fix belongs in the enumerated axes.

The repo already models (2) for classical nodes: `crates/ra-core/src/classical/toolfmt.rs`
provides `InputNorm` (strip whitespace / strip outside-alphabet / force case / trim) and
`OutputFmt` (forced case, grouping into blocks of N, and `Trailing::{None,Lf,CrLf}`). Its
stated design intent is that these be run **both on and off**, because an
`.innerHTML`-backed tool's CRLF is invisible on the page but present in the copy buffer,
and nothing about the page reveals which the author pasted. Defaults are deliberately
per-node (`ascii_base_gctb` defaults to `Trailing::CrLf`; `copy_artifact_risk: "HIGH"`).

**Open question, under audit:** whether `ra sweep` actually *enumerates* that dimension.
If the classical nodes model it but no sweep axis varies it, the design intent is
unfulfilled and a chain whose true intermediate carried a trailing CRLF would never be
generated at all.

## 8sexies. THE ZERO-PADDING TOOL IS IDENTIFIED — `unit-conversion.info/texttools`

**Found by the project owner, 2026-07-31, and verified against the corpus here.** This
supersedes §8quinquies below, which recorded it as unidentified.

**The tool:** `https://www.unit-conversion.info/texttools/ascii` — its own page states
*"Convert text into ASCII number format. For example A is 065"* and *"097 is the ASCII
numerical representation of the character a."* That is **3-digit, left-zero-padded decimal
ASCII**, the exact encoding the corpus uses and that no previously-catalogued tool
produced. The companion `https://www.unit-conversion.info/texttools/octal/` states *"Each
character is represented by three numbers"* — 3-digit octal, matching rev10's octal step.

**Corpus verification (measured here):** rev6's ciphertext is **256 tokens, every one
exactly 3 characters wide, 198 of them carrying a leading zero**, maximum value 102. That
is a precise match for `A → 065` fixed-width zero-padded decimal, and it is *not* what
Geocaching Toolbox's converter emits (§8quinquies).

### Why this is the most consequential finding of the session

It is direct proof that the author used a site **nobody had catalogued**, and it hands us
that site's entire menu as candidate operations. Several entries bear directly on the two
unsolved ciphers:

| tool on that site | why it matters |
|---|---|
| **Salsa** (`/texttools/salsa/`) — "a Salsa10 or Salsa20 output"; Salsa20 is a **stream cipher** | A modern keyed primitive that is **NOT in libmcrypt's menu at all**, so no sweep in this repository has ever tried it. Length-preserving, so it fits any payload at any depth. A genuinely new layer-1 candidate for both targets. |
| **Gost** | libmcrypt has a `gost` *cipher*; this site lists Gost under "Hash & Encryption". Which one it is must be determined — it is on the untried-primitive list either way. |
| **Reverse text** *and* **Reverse words** — two DISTINCT tools | The corpus records `reverse` in 8 of 14 Revelations chains and the engine implements one thing: full character reversal. If any recorded `reverse` was actually *reverse words* (word order reversed, words intact), the engine reproduces a different operation. This is a fidelity risk on an already-solved step. |
| **Add line breaks by length** | Explains REV7's group-of-5 layout and rev6's line wrapping as a *tool artifact* rather than hand formatting — and therefore explains where the whitespace in §8quater comes from. |
| **Remove spaces / Remove extra spaces / Remove line breaks / Clean text** | The inverse artifact operations, i.e. exactly the `stripws` step REV7's arithmetic already forces. |
| Rot13, Base64, MD4/MD5/SHA/RipeMD/Tiger/Whirlpool/Snefru/Haval/Adler32/CRC | The hash menu corroborates the hash-derived-key hypothesis (§8ter) as an author-reachable option. |
| Column extractor, Sort/Reverse/Shuffle lines, Shuffle letters, Compress | Further transforms, mostly line-oriented; relevant if a layer operated on the *formatted* text rather than the compacted stream. |

### What this changes, concretely

1. **Salsa20 becomes a priority layer-1 candidate.** It is outside the mcrypt menu, so
   every negative in this repository — including this session's six peels — says nothing
   about it. It needs implementing and sweeping.
2. **`reverse` must be disambiguated.** Add a `reverse_words` transform and confirm which
   variant each solved chain actually used, by reproduction. A wrong `reverse` in a
   *solved* chain would be a latent conformance defect.
3. **The toolkit model is now three sites, not one**: tools4noobs (mcrypt modern layers),
   `unit-conversion.info/texttools` (encoding + formatting + possibly Salsa/Gost), and the
   classical sites (CIMT, Practical Cryptography, CrypTool Online, Geocaching Toolbox).
4. **The known-incomplete warning stands but is now sharper.** One unidentified tool has
   been found; the base rate suggests looking for others rather than assuming this closes
   the set.

**Recommended immediate work:** capture the site's actual behaviour (separator, line
wrapping, trailing whitespace — note §8quater) the way `ascii_base_gctb.rs` captured
Geocaching Toolbox's, i.e. by running its JavaScript verbatim rather than inferring from
prose; then implement `unit_conversion_ascii` / `unit_conversion_octal` codec nodes and a
`salsa20` primitive.

## 8quinquies. (Superseded by §8sexies) The zero-padded decimal tool as it stood before identification

Several corpus ciphers (rev6, and the decimal/octal inter-layer codecs of rev9/rev10) use
a **fixed-width 3-digit zero-padded decimal** encoding: rev6's ciphertext reads
`100 097 102 050 048 ...`, space-separated with line wrapping. No tool has been identified
that produces it, which is direct proof that **the known tool list is incomplete**.

The leading candidate has been tested and **refuted in-repo**. Geocaching Toolbox's
`asciiConversion` ("Base conversion of text (ASCII)") was ported and its JavaScript run
verbatim under Node (`crates/ra-core/src/classical/ascii_base_gctb.rs`):

- its `dec` output is **never zero-padded** (`72 105 33`; a single-digit value stays `5`,
  not `005`),
- `oct` and `hex` are likewise never padded,
- only `bin` pads, and to a fixed **8 bits**, not 3 decimal digits.

So GCT's ASCII converter is **not** the source. The node nonetheless exposes a
`zero_pad_width` parameter (default 0, matching the site) so a sweep can force fixed-width
output should some other undiscovered tool share its alphabet.

**Consequence for every negative in this repository:** they are claims about the *known*
toolset. At least one tool the author demonstrably used has never been identified, so no
negative here closes the space in the absolute. Stating it this way is the difference
between a bounded result and an overclaim.

## 9. External evidence that would collapse the search (zero compute)

- **Re-read `revelations_7.png`** to pin REV7's two repair gaps directly. Unblocks every
  reverse skeleton (R1, R2) without the `16⁵ × 14·16⁵` joint enumeration.
- **Re-read the TG4 sheet** for the 7 open `I`/`l` glyphs (factor 128) and for any
  number/date/second word that would be a new evidenced key.
- **Confirm the operator's own tool's exact axes** so this engine's negatives compose
  with it rather than duplicate it — in particular whether the operator's single-layer
  search already included AES and hash-derived keys, which would move those from
  "untested" to "tested" and refocus the multi-layer effort on the classical brackets.

---

*Generated 2026-07-31 from `data/evidence_base.json` (34 records) and
`data/zombies_sources.csv`. Companion to `docs/tg4-family-analysis.md` (family/base-rate)
and `notes/rev7-repair-search.md` (REV7 transcription repair).*
