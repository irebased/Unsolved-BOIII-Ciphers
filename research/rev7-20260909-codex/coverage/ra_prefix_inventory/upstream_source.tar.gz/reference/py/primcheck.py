# Which of the 11 CONFIRMED mcrypt primitives can we actually execute today?
OBSERVED = [
 ("RC2","ARC2 (pycryptodome)","available"),
 ("RC4","ARC4 (pycryptodome)","available"),
 ("DES","DES (pycryptodome)","available"),
 ("Blowfish","Blowfish (pycryptodome)","available"),
 ("Blowfish-compat","byte-order variant of Blowfish","NOT in std libs - needs custom"),
 ("Twofish","-","NOT in pycryptodome/cryptography"),
 ("Serpent","-","NOT in pycryptodome/cryptography"),
 ("Loki97","-","NOT in pycryptodome/cryptography"),
 ("Saferplus","-","NOT in pycryptodome/cryptography"),
 ("XTEA","-","NOT in pycryptodome/cryptography"),
 ("Rijndael-256","AES is 128-bit BLOCK only","NOT available - AES != Rijndael-256"),
]
avail = sum(1 for _,_,s in OBSERVED if s=="available")
print(f"{'PRIMITIVE':<18}{'STATUS'}")
print("-"*62)
for n,_,s in OBSERVED:
    print(f"{n:<18}{s}")
print("-"*62)
print(f"Executable with stock modern libs: {avail}/{len(OBSERVED)}")
print(f"Requires custom/legacy implementation: {len(OBSERVED)-avail}/{len(OBSERVED)}")

# Confirm the Rijndael-256 point concretely
from Crypto.Cipher import AES
print("\nAES block size in pycryptodome:", AES.block_size, "bytes (=128 bits)")
print("Rijndael-256 requires a 256-bit (32-byte) block. AES standardized only 128-bit blocks.")
print("=> No standard AES implementation can reproduce the Revelations 1 Rijndael-256 layer.")

# Full mcrypt menu (superset of observed)
MCRYPT_ALL = ["blowfish","blowfish-compat","cast-128","cast-256","des","tripledes","enigma",
              "gost","loki97","rc2","rijndael-128","rijndael-192","rijndael-256","saferplus",
              "serpent","twofish","xtea","arcfour","wake"]
MCRYPT_MODES = ["ecb","cbc","cfb","ofb","nofb","ncfb","stream"]
print(f"\nFull mcrypt cipher menu: {len(MCRYPT_ALL)} primitives")
print(f"Full mcrypt mode menu:   {len(MCRYPT_MODES)} modes (mcrypt 'cfb'=CFB-8, 'ncfb'=full-block CFB)")
print(f"Observed in solved corpus: 11 primitives, 2 modes (cfb8, ecb)")
