const S = require("./style.js");
const { docx, PAGE, numbering, title, subtitle, h1, h2, h3, p, mono, li, numItem, table, callout, spacer, makeHeaderFooter } = S;
const { Document, Packer, Paragraph, TextRun, BorderStyle } = docx;
const fs = require("fs");

const children = [];
const A = (...x) => children.push(...x);

A(title("Engine Architecture and Layer Semantics"));
A(subtitle("Node Taxonomy, libmcrypt Bindings, Macros, Solver Nodes, and a Computable Definition of a Layer"));
A(p([
  { t: "Document 7 of 7 (Engine). ", bold: true },
  "This document specifies the execution engine: the taxonomy of steps, parameter injection, macros, solver nodes, and the storage model. It also fixes the project terminology and turns the semantic definition of a layer into something a machine can evaluate. Three findings here revise earlier documents, and those revisions are marked where they occur.",
]));

// 1 Terminology
A(h1("1. Terminology"));
A(table(
  ["Term", "Definition"],
  [
    ["Step (node)", "A single operation of any granularity: reverse, tolower, base64 decode, AES decrypt. The unit of execution and the unit of versioning."],
    ["Layer", "A transition from one representation to another, achieved by any series of steps including at least one decryption or non-standard decoding. A semantic notion concerning what the ciphertext has become, combined with the work done to get there."],
    ["Macro", "A named composition of steps presented as a single perceived layer. The unit of reporting. Constituent steps remain individually versioned."],
    ["Chain", "An ordered composition of steps with bound parameters, identified by the hash of its constituent node identities plus that binding."],
  ],
  [1500, 7748]
));
A(p([
  "A layer is not simply a step that happens to be a decryption. Base64 to decimal is a step sequence that achieves nothing, because the underlying bytes are unchanged and only their display moves. Base64 to a standalone run of digits carrying structure is a breakthrough. Both look like a conversion; only one is a layer. Section 5 makes that distinction computable.",
]));

// 2 libmcrypt
A(h1("2. libmcrypt Bindings Close the Implementation Gap"));
A(p([
  "Document 4 identified the binding constraint on coverage: only four of the eleven confirmed primitives exist in modern cryptographic libraries. Binding directly to libmcrypt resolves this completely, and does so with the authentic implementation rather than a reconstruction. Since the ciphers were authored through an mcrypt front-end, the library's quirks are the quirks that produced them.",
]));
A(table(
  ["Primitive", "mcrypt name", "Block", "Key", "IV"],
  [
    ["RC2", "rc2", "8 B", "128 B", "8 B"],
    ["RC4", "arcfour", "stream", "-", "-"],
    ["DES", "des", "8 B", "8 B", "8 B"],
    ["Blowfish", "blowfish", "8 B", "56 B", "8 B"],
    ["Blowfish-compat", "blowfish-compat", "8 B", "56 B", "8 B"],
    ["Twofish", "twofish", "16 B", "32 B", "16 B"],
    ["Serpent", "serpent", "16 B", "32 B", "16 B"],
    ["Loki97", "loki97", "16 B", "32 B", "16 B"],
    ["Saferplus", "saferplus", "16 B", "32 B", "16 B"],
    ["XTEA", "xtea", "8 B", "16 B", "8 B"],
    ["Rijndael-256", "rijndael-256", "32 B", "32 B", "32 B"],
  ],
  [2100, 2700, 1500, 1500, 1448]
));
A(callout("Revision to Document 4.", [
  "Primitive availability moves from four of eleven to eleven of eleven. The claim in Document 4 that implementation is the binding constraint on coverage is now resolved rather than merely stated. Rijndael-256 is confirmed as a 32-byte block, which no AES implementation provides.",
], S.ACCENT));
A(h2("2.1 Empirical confirmation of the Document 1 invariants"));
A(p([
  "With the authentic library available, two invariants previously asserted from community reports were tested directly and hold:",
]));
A(...mono("cfb  (8-bit feedback)  = a7e78354e02f4d59272d37beeb83e34d6684e8db\nncfb (full-block)      = a715400d5a7ee2636b51e0d5a1434f94330a2aef\nidentical: False\n\nIV = '0'*16 (ASCII)    = a7e78354e02f4d59272d37beeb83e34d6684e8db\nIV = \\x00*16 (true null) = 16e096c26499866bca3a9b868644bbf60f09ba40\nidentical: False"));
A(p([
  "The first pair explains why CyberChef and comparable modern tooling failed even with the correct primitive, key, and IV. The second confirms that the ASCII-zero IV is genuinely distinct from a null IV, which was the cause of first-block corruption in reproduction attempts.",
]));

// 3 Oracle correction
A(h1("3. CFB-8 Self-Synchronisation and the Oracle"));
A(p([
  "A property discovered during verification materially changes the scoring design. Under CFB-8, an incorrect IV corrupts exactly one block and the stream then self-synchronises. Measured across three block sizes on a 70-byte plaintext:",
]));
A(table(
  ["Primitive", "Block size", "Bytes corrupted by wrong IV", "Recovery"],
  [
    ["DES", "8 B", "8 of 70", "Clean from byte 8"],
    ["Twofish", "16 B", "16 of 70", "Clean from byte 16"],
    ["Rijndael-256", "32 B", "32 of 70", "Clean from byte 32"],
  ],
  [2100, 1800, 3100, 2248]
));
A(p([
  "This means a fixed printability threshold is fragile. On the 144-byte TG4 payload, a Rijndael-256 hit with a wrong IV would present as only 77.8 percent printable, so a threshold of 0.80 would silently discard a correct solution, and the recommended 0.75 would pass it by a very thin margin.",
]));
A(callout("Revision to Document 5.", [
  "Replace the fixed printability oracle with a block-aware one: skip the first block-size bytes and score only the tail. Because the corrupt prefix is deterministic and bounded, this is exact rather than heuristic. It eliminates IV-mismatch false negatives and simultaneously lowers the false positive rate, since the scored region contains no known-corrupt data. Verified: a wrong-IV Twofish decryption scores 0.84 naively and 1.00 block-aware.",
], S.ACCENT));

// 4 Node taxonomy
A(h1("4. Node Taxonomy and Parameter Injection"));
A(table(
  ["Family", "Role", "Layer-forming", "Terminal"],
  [
    ["xf", "Representation-preserving transform (reverse, case, grouping, ROT)", "No", "No"],
    ["codec", "Encode or decode between displays (base64, hex, octal, decimal)", "No", "No"],
    ["dec", "Keyed decryption (libmcrypt and classical)", "Yes", "No"],
    ["solver", "Automated classical solver", "Yes", "Yes"],
  ],
  [1200, 4700, 1700, 1648]
));
A(p([
  "Every node carries its own version and content hash, so a chain is a composition of independently versioned units as specified in Document 6. Parameters are injected at bind time rather than baked into the node, which keeps key, configuration, and IV as free dimensions of the coverage claim:",
]));
A(...mono("dec:mcrypt@2.5.8#58c3d4cccc40\n  params: { prim, mode, key, iv, keyderiv }\n\nbinding: { prim: \"Twofish\", mode: \"cfb\", key: \"Zombies\",\n           iv: 30303030303030303030303030303030, keyderiv: \"nullpad\" }"));
A(p([
  "The keyderiv parameter deserves emphasis. The original front-end accepted arbitrary-length keys against primitives with fixed key sizes, and the padding rule it applied is not documented. Both null-padding and repeat-padding are therefore carried as an explicit search dimension rather than assumed.",
]));

// 5 Layer detection
A(h1("5. Making the Layer Definition Computable"));
A(p([
  "The governing insight is that pure re-encoding preserves the byte sequence a representation denotes. Hexadecimal, base64, decimal, and octal displays of the same value all normalise to identical canonical bytes, so any measure computed over canonical bytes is invariant under re-encoding. A genuine layer, by contrast, rewrites the byte sequence.",
]));
A(p("The engine therefore models a representation as a display plus a normalisation back to canonical bytes, and evaluates each step on three axes: whether canonical bytes changed, the change in byte-level entropy, and whether the representation class changed. Validation across the cases that define the distinction:"));
A(table(
  ["Case", "Entropy delta", "Class transition", "Layer"],
  [
    ["base64 to hex (pure re-encode)", "0.000", "opaque to opaque", "No"],
    ["base64 to decimal (same bytes)", "0.000", "opaque to opaque", "No"],
    ["reverse bytes (transform only)", "0.000", "opaque to opaque", "No"],
    ["Twofish CFB-8 decrypt to plaintext", "-1.804", "opaque to text", "Yes"],
    ["Serpent decrypt to standalone digit run", "-1.844", "opaque to decimal", "Yes"],
  ],
  [3600, 1700, 2300, 1648]
));
A(callout("Correspondence with the informal definition.", [
  "The second row is the case named as achieving nothing, and it registers a delta of exactly zero. The fifth row is the case named as a potential breakthrough, opaque bytes becoming a standalone digit sequence, and it registers as a layer through both entropy drop and class change. The metric reproduces the intended semantics without requiring a human judgement call.",
]));
A(p([
  "A layer boundary is recorded when a step is layer-forming and canonical bytes changed. Notability is recorded separately, when the byte sequence changed and either entropy moved by more than a quarter bit or the class transitioned into a structured category. A chain therefore reports both its step trace and its layer trace, and the layer trace is what should be surfaced to a human reader.",
]));

// 6 Macros
A(h1("6. Macros"));
A(p([
  "The semantic unit a person reasons about is usually several steps. Peeling an mcrypt layer in practice means stripping whitespace, decoding hex, decrypting, and re-encoding to base64 for the next stage. A macro names that composition and gives it a version, so it can be reported as one layer while remaining four independently versioned steps underneath.",
]));
A(...mono("macro:mcrypt_layer@1.0.0#c2b092d3db6e\n    xf:stripws@1.0.0#e9ae6a2ddbda\n    codec:hexdecode@1.0.0#46a7d2507438\n    dec:mcrypt@2.5.8#58c3d4cccc40      params=@inject\n    codec:b64encode@1.0.0#b41ba7e734b4"));
A(p([
  "The macro identity is derived from its constituent node identities, so revising any step produces a new macro identity automatically. Selective invalidation continues to operate at step granularity, which preserves the property from Document 6 that a defect voids only the coverage that depended on it.",
]));

// 7 Solver nodes
A(h1("7. Solver Nodes and the Two Kinds of Coverage"));
A(p([
  "A solver node runs an automated attack against a classical cipher rather than applying a fixed transformation. Solvers are terminal by construction: they emit plaintext, so no step may follow. They also introduce a distinction that must be enforced in the ledger.",
]));
A(callout("Critical coverage semantic.", [
  "An exhaustive sweep that returns nothing proves the searched region is empty. A solver that returns nothing proves only that its heuristic did not find a solution within its budget. These are different epistemic claims. Subtracting a heuristic failure from the residual would remove ground that was never actually cleared, silently poisoning the search in exactly the way Document 6 warns against.",
], S.ACCENT));
A(table(
  ["Coverage kind", "Produced by", "Recorded as", "Subtractable from residual"],
  [
    ["Exhaustive", "Enumerated parameter sweep", "Product set (Document 5)", "Yes"],
    ["Heuristic", "Solver node", "Policy, budget, seed, restarts", "No"],
  ],
  [1800, 2600, 2600, 2248]
));
A(p([
  "Heuristic claims are still worth recording, because they inform prioritisation and avoid duplicated effort, but they are held in a separate register and never reduce the exhaustive residual. A solver claim should carry its policy identifier, iteration budget, restart count, and random seed, so that a later run can be shown to be genuinely independent rather than a repetition of the same trajectory.",
]));

// 8 Storage
A(h1("8. Storage Model"));
A(p([
  "Retaining every candidate output is infeasible and unnecessary. The engine stores nothing beyond a running commitment, and writes to local disk only those candidates that exceed the oracle threshold. Reconciling that with the audit protocol of Document 6 requires the commitment to be built incrementally.",
]));
A(p([
  "A streaming Merkle construction folds each leaf into a frontier of at most log-N hashes, so committing to an arbitrarily large scan costs constant memory. Periodic subtree checkpoints allow a challenged leaf to be reproduced by replaying one small deterministic block rather than the entire scan.",
]));
A(table(
  ["Property", "Measured"],
  [
    ["Candidates committed", "200,000"],
    ["Resident memory", "26,400 bytes"],
    ["Per-candidate storage", "0.132 bytes"],
    ["Outputs retained", "None; only above-threshold hits written locally"],
    ["Audit replay cost", "One checkpoint block, not the full scan"],
  ],
  [3400, 5848]
));
A(callout("Consequence for the audit.", [
  "The engine can honour the requirement to discard results while still producing a commitment that binds it to having computed them. Storage falls to a fraction of a byte per candidate, and the Document 6 spot audit remains fully functional because deterministic enumeration allows any challenged leaf to be regenerated on demand.",
]));

// 9 Reference
A(h1("9. Reference Implementation"));
A(table(
  ["File", "Contents"],
  [
    ["tools/mcrypt_node.py", "ctypes binding to libmcrypt; algorithm enumeration; CFB-8 and IV verification"],
    ["tools/engine.py", "Node taxonomy, macros, layer detection, block-aware oracle, streaming Merkle"],
    ["tools/toolreg.py", "Per-tool identities and selective invalidation (Document 6)"],
    ["tools/verify.py", "Merkle audit, canaries, detection tables (Document 6)"],
    ["tools/covalg.py", "Coverage algebra (Document 5)"],
  ],
  [2600, 6648]
));
A(p([
  "System requirement: libmcrypt 2.5.8 (package libmcrypt-dev). The engine will not start without it, by design, since a partial primitive menu produces coverage claims that cannot be honoured.",
]));

A(spacer(60));
A(new Paragraph({
  border: { top: { style: BorderStyle.SINGLE, size: 4, color: "9A9A9A", space: 6 } },
  spacing: { before: 120 },
  children: [new TextRun({ text: "End of Document 7. Run python3 mcrypt_node.py and python3 engine.py to reproduce every figure in this paper.", italics: true, size: 18, color: "6A6A6A", font: S.FONT })],
}));

const doc = new Document({
  numbering,
  styles: { default: { document: { run: { font: S.FONT, size: 21, color: S.INK } } } },
  sections: [{ properties: { page: PAGE }, ...makeHeaderFooter("Engine Architecture and Layer Semantics"), children }],
});
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/claude/BO3_Cipher_Dossier/papers/07_Engine_Architecture.docx", buf);
  console.log("wrote 07_Engine_Architecture.docx", buf.length, "bytes");
});
