//! CrypTool Online's "Rail Fence" (Zigzag) tool — code-named "Jaeger" ("the
//! German name" per the German-language site's `CTOJaegerAlgorithm`).
//!
//! # 2016 vs modern: superseded reference
//!
//! This node was originally ported from the *current* `cryptool-org/cto`
//! repository (a later rewrite). The project owner has since supplied the
//! **2016 sources** (Wayback snapshot of cryptool-online.org, timestamp
//! `20160909182347`), committed at `docs/toolsites/cryptool2016/js/jaeger.js`
//! — the era in which this cipher tool was actually used to make puzzles.
//! That file is now this node's authoritative reference; see the "2016 vs
//! modern" section below for what changed.
//!
//! # Parameters actually used
//!
//! `jaeger.js`'s `crypt(text, type, depth, offset)` is driven only by
//! `depth` (rail count, `#key` select, default 5) and `offset` (`#offset`
//! select, default 0). There is no separate key.
//!
//! # The algorithm
//!
//! [`decrypt`] is transliterated line for line from the `else` branch of
//! `jaeger.js:63-120` (the "decrypt" arm of `crypt`). It is *not* the
//! textbook "simulate the zigzag, mark positions" rail fence — it works out
//! closed-form segment lengths for each of the `n = 2*depth-2` positions in
//! one zigzag period directly (`off[i]`, `blocklen`), then walks the
//! reconstructed rows in zigzag order. [`encrypt`] (test-only here) is the
//! direct row simulation: walk a `rails`-element row array back and forth,
//! placing one character per step; it is a different-looking but provably
//! equivalent construction to the site's own `encrypt` arm (`jaeger.js:27-60`,
//! which instead walks `plaintext` once per `d in 0..=n/2` picking out
//! positions where `j%n==d || j%n==n-d`) — see the classic Wikipedia example
//! test below, and the ground-truth vectors, both of which agree with the
//! site's real JS run under Node.
//!
//! `jaeger.js`'s closed-form decrypt distributes the `offset` placeholder
//! characters (`"X"` on the decrypt arm, `"#"` on the encrypt arm — two
//! different placeholder bytes for the two directions) into the *lowest*-
//! indexed rows first (`off[0]`, `off[1]`, ...), which the zigzag walk visits
//! before any other row — so all `offset` placeholders always land in the
//! first `offset` characters of the reconstructed string. [`decrypt`]
//! exploits this by truncating the first `offset` characters instead of a
//! literal `.replace(/X/g, "")`; this is mathematically equivalent (and
//! confirmed against the site's own JS output) but avoids depending on `X`
//! never occurring in genuine plaintext.
//!
//! # 2016 vs modern: `\W` stripping, faithfully defaulted to on
//!
//! Both the encrypt and decrypt arms of `jaeger.js`'s `crypt` unconditionally
//! strip every non-word character (`text.replace(/\W/g, "")` — JS `\W` is
//! `[^A-Za-z0-9_]`) from their input *before* running the zigzag algorithm at
//! all (`jaeger.js:33` on encrypt, `jaeger.js:70` on decrypt). This is not
//! whitespace-only stripping, and by default it is applied exactly as the
//! site applies it — always, before decrypting. But a rail fence is a
//! permutation of *positions*; it needs no alphabet at all, only a length, so
//! (matching `cc_railfence`/`cryptool_columnar`/etc) this stripping is the
//! *page's* input normalisation, not part of the cipher, and is modelled via
//! [`crate::classical::toolfmt`]'s `strip_non_alphabet` param defaulted to
//! `true` against `WORD_CHARS` (`[A-Za-z0-9_]`) for exact site fidelity. Set
//! `strip_non_alphabet=false` to run the same zigzag permutation over any
//! medium (e.g. hex ciphertext from an earlier layer), verified in
//! `cryptool_railfence_preserves_hex_medium_when_stripping_disabled` below.
//!
//! This node's earlier, modern-derived version stripped only whitespace, and
//! only via the optional `InputNorm` (default: no stripping at all) — a
//! narrower and opt-in behaviour that both undercounted (kept punctuation the
//! real tool discards) and, by default, applied no stripping whatsoever. See
//! `cryptool_railfence_decrypt_strips_all_punctuation_not_just_whitespace`
//! for a ground-truth vector proving the `\W` (not `\s`) scope, run through
//! the site's own `jaeger.js` under Node.
//!
//! `offset` selects both the starting rail and (implicitly) the direction:
//! `offset < rails` starts moving down (or up, if `offset == rails-1`, the
//! bottom rail); `offset >= rails` folds back (`offset = 2*rails-2-offset`)
//! and always starts moving up. This lets the tool start the zigzag partway
//! through a period rather than only at the top rail.
//!
//! # Ground truth
//!
//! Computed by running `docs/toolsites/cryptool2016/js/jaeger.js` (plus its
//! `ctolib.js` dependency, for the object it instantiates at load time)
//! directly under Node with a minimal `document`/`self`/`window` shim (the
//! `crypt` function itself never touches the DOM on the decrypt arm, and only
//! writes a debug string to a `<textarea>` on the encrypt arm, which the
//! shim absorbs) — see task scratchpad `jstest/run_jaeger.js`. Cross-checked
//! against the classic rails=3,offset=0 rail fence example
//! ("WEAREDISCOVEREDFLEEATONCE" -> "WECRLTEERDSOEEFEAOCAIVDEN", Wikipedia's
//! own worked example), which the site's `jaeger.js` reproduces exactly.
//!
//! # Engine direction
//!
//! Decrypt-direction: [`CryptoolRailfence::apply`] runs `decrypt`. `encrypt`
//! is reproduced test-only.

use crate::classical::toolfmt::{read_output_fmt, CaseFold, InputNorm, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

const CRYPTOOL_RAILFENCE_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "rails",
        ParamType::Int,
        "number of rails / zigzag depth, minimum 2 (default 5, matching the \
         site's #depth select default)"
    ),
    ParamSpec::opt(
        "offset",
        ParamType::Int,
        "starting rail / direction offset within one zigzag period, 0..2*rails-3 \
         (default 0, the site's #offset select default; out-of-range values \
         wrap via the site's own modulo)"
    ),
);

/// JS `\W` (non-word character): matches everything outside `[A-Za-z0-9_]`.
///
/// Only the test-only [`encrypt`] still calls this. The decrypt path now routes
/// the same filtering through `toolfmt::InputNorm`, so that the strip is a
/// parameter rather than a law — see this module's docs.
#[cfg(test)]
fn is_word_char(c: char) -> bool {
    c.is_ascii_alphanumeric() || c == '_'
}

/// JS `\w` (`[A-Za-z0-9_]`) as an explicit alphabet string, for
/// [`crate::classical::toolfmt`]'s `strip_non_alphabet` default — see the
/// module docs' "`\W` stripping, faithfully defaulted to on" section.
pub const WORD_CHARS: &str =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_";

/// `decrypt`, transliterated from `jaeger.js:63-120` (the "decrypt" arm of
/// `crypt`). `jaeger.js:70`'s `ciphertext.replace(/\W/g, "")` is applied by
/// the node's `apply` as [`crate::classical::toolfmt`] input normalisation
/// *before* calling this (default on, for site fidelity, but toggleable via
/// `strip_non_alphabet` — see module docs), so `msg` here is taken as given.
pub fn decrypt(msg: &str, rails: usize, offset: i64) -> Result<String> {
    if rails < 2 {
        return Err(Error::bad_param(
            "cryptool_railfence",
            "rails",
            "must be at least 2",
        ));
    }
    let msg: Vec<char> = msg.chars().collect();
    let one_turn = (2 * rails - 2) as i64;
    let half = (one_turn / 2) as usize;

    let mut offset = offset % one_turn;
    if offset < 0 {
        offset += one_turn;
    }

    let k = msg.len() as i64 + offset;

    let mut off = vec![0i64; half + 1];
    off[0] = ceil_div(offset, one_turn);
    for (i, slot) in off.iter_mut().enumerate().take(half).skip(1) {
        let i64_ = i as i64;
        *slot = ceil_div(offset - i64_, one_turn) + floor_div(offset + i64_ - 1, one_turn);
    }
    off[half] = ceil_div(offset - half as i64, one_turn);

    let mut xs: Vec<String> = vec![String::new(); half + 1];
    for (i, x) in xs.iter_mut().enumerate() {
        *x = match off[i] {
            0 => String::new(),
            1 => " ".to_string(),
            2 => "  ".to_string(),
            n => {
                return Err(Error::node_failed(
                    "cryptool_railfence",
                    format!("unexpected padding width {n} at segment {i}"),
                ))
            }
        };
    }

    // `msg` mutates as a growing/shrinking char queue in the JS; mirror with
    // an index cursor plus the small xs[.] prefixes.
    let mut a: Vec<Vec<char>> = vec![Vec::new(); half + 1];
    let mut cursor: Vec<char> = Vec::new();
    cursor.extend(xs[0].chars());
    cursor.extend(&msg);

    let take0 = ceil_div(k, one_turn).max(0) as usize;
    let take0 = take0.min(cursor.len());
    a[0] = cursor[..take0].to_vec();
    let mut rest: Vec<char> = xs[1].chars().collect();
    rest.extend_from_slice(&cursor[take0..]);
    cursor = rest;

    for i in 1..half {
        let i64_ = i as i64;
        let blocklen = (ceil_div(k - i64_, one_turn) + floor_div(k + i64_ - 1, one_turn)).max(0) as usize;
        let blocklen = blocklen.min(cursor.len());
        a[i] = cursor[..blocklen].to_vec();
        let mut rest: Vec<char> = xs[i + 1].chars().collect();
        rest.extend_from_slice(&cursor[blocklen..]);
        cursor = rest;
    }
    a[half] = cursor;

    let mut result = String::new();
    let mut j = 0i64;
    let mut increment = 1i64;
    loop {
        let row = &mut a[j as usize];
        if row.is_empty() {
            break;
        }
        result.push(row.remove(0));
        if j == 0 {
            increment = 1;
        }
        if j == half as i64 {
            increment = -1;
        }
        j += increment;
    }

    let offset_usize = offset as usize;
    let chars: Vec<char> = result.chars().collect();
    let out: String = if offset_usize < chars.len() {
        chars[offset_usize..].iter().collect()
    } else {
        String::new()
    };
    Ok(out)
}

fn ceil_div(a: i64, b: i64) -> i64 {
    // Matches JS `Math.ceil(a/b)` for the b>0 case used throughout this file.
    (a as f64 / b as f64).ceil() as i64
}
fn floor_div(a: i64, b: i64) -> i64 {
    (a as f64 / b as f64).floor() as i64
}

/// `encrypt`: a row-simulation reference matching the *result* of
/// `jaeger.js:27-60`'s "encrypt" arm (a different-looking but provably
/// equivalent construction — see the module docs). Test-only: this crate is
/// decrypt-direction, so nothing but the test suite (proving [`decrypt`]
/// agrees with the site's forward algorithm) needs it. `jaeger.js:33`'s
/// `plaintext.replace(/\W/g, "")` is unconditional and runs first, so it is
/// applied here too, matching the site exactly rather than only stripping
/// whitespace.
#[cfg(test)]
fn encrypt(msg: &str, rails: usize, offset: i64) -> String {
    let msg: Vec<char> = msg.chars().filter(|&c| is_word_char(c)).collect();
    let mut rows: Vec<Vec<char>> = vec![Vec::new(); rails];

    let (mut offset, mut dir) = if offset < rails as i64 {
        if offset == rails as i64 - 1 {
            (offset, -1i64)
        } else {
            (offset, 1i64)
        }
    } else {
        (rails as i64 * 2 - 2 - offset, -1i64)
    };

    for &c in &msg {
        for (j, row) in rows.iter_mut().enumerate() {
            if j as i64 == offset {
                row.push(c);
            } else {
                row.push(' ');
            }
        }
        offset += dir;
        if offset < 0 {
            offset = 1;
            dir = 1;
        } else if offset == rails as i64 {
            offset = rails as i64 - 2;
            dir = -1;
        }
    }

    let mut cipher = String::new();
    for row in &rows {
        cipher.extend(row);
    }
    // Not a site behaviour: this row-simulation construction fills unused
    // zigzag cells with a literal space placeholder (`msg` is already
    // \W-stripped above, so no genuine space can reach here), which must be
    // dropped to recover the assembled ciphertext.
    cipher.chars().filter(|c| !c.is_whitespace()).collect()
}

/// CrypTool Online's Rail Fence (Zigzag) tool, decrypting.
pub struct CryptoolRailfence;

impl Node for CryptoolRailfence {
    fn name(&self) -> &'static str {
        "cryptool_railfence"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CRYPTOOL_RAILFENCE_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let rails = params.opt_i64("rails", 5);
        if rails < 2 {
            return Err(Error::bad_param(
                "cryptool_railfence",
                "rails",
                "must be at least 2",
            ));
        }
        let offset = params.opt_i64("offset", 0);

        let in_norm = crate::classical::toolfmt::read_input_norm(
            "cryptool_railfence",
            params,
            InputNorm {
                strip_outside_alphabet: Some(WORD_CHARS.to_string()),
                ..InputNorm::default()
            },
        )?;
        let normalized = in_norm.apply(&input.data);
        let text = String::from_utf8(normalized)
            .map_err(|_| Error::node_failed("cryptool_railfence", "input is not valid UTF-8"))?;

        let plain = decrypt(&text, rails as usize, offset)?;

        // The site writes into a plain <textarea id="output"> via .val =, so
        // no trailing-CRLF risk by default.
        let out_fmt: OutputFmt = read_output_fmt(
            "cryptool_railfence",
            params,
            OutputFmt {
                case: CaseFold::Preserve,
                grouping: None,
                trailing: Trailing::None,
            },
        )?;
        let out = out_fmt.apply(plain.as_bytes());
        Ok(Repr::new(out, input.display))
    }
}

register_node!(CRYPTOOL_RAILFENCE => || Box::new(CryptoolRailfence));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    /// Wikipedia's own worked example for the standard (top-rail-first) rail
    /// fence: rails=3, offset=0. Confirmed against `jaeger.js` run under Node
    /// (task scratchpad `jstest/run_jaeger.js`): `crypt("WEAREDISCOVEREDFLEEATONCE",
    /// "encrypt", 3, 0)` returns this exact string.
    #[test]
    fn cryptool_railfence_classic_example() {
        let pt = "WEAREDISCOVEREDFLEEATONCE";
        let ct = encrypt(pt, 3, 0);
        assert_eq!(ct, "WECRLTEERDSOEEFEAOCAIVDEN");
        assert_eq!(decrypt(&ct, 3, 0).unwrap(), pt);
    }

    /// Ground-truth vectors from `jaeger.js` (`docs/toolsites/cryptool2016/js/jaeger.js`)
    /// run under Node with a minimal DOM shim (task scratchpad
    /// `jstest/run_jaeger.js`), covering a range of depths, offsets, and
    /// plaintexts (including one with `\W` characters, which `crypt` strips
    /// before railfencing on both arms — see the module docs).
    #[test]
    fn cryptool_railfence_matches_jaeger_js_ground_truth_vectors() {
        let cases: &[(&str, usize, i64, &str)] = &[
            ("WEAREDISCOVEREDFLEEATONCE", 3, 0, "WECRLTEERDSOEEFEAOCAIVDEN"),
            (
                "The quick brown fox jumps over the lazy dog",
                5,
                0,
                "Tbjrdhkrxuetyoecoomvhzgqiwfpoeaunsl",
            ),
            ("AttackAtDawn1234!?", 4, 2, "cwakan4AtAD13tt2"),
            ("Hello, World! Testing 123.", 3, 1, "lren3HloolTsig2eWdt1"),
            ("a", 2, 0, "a"),
            ("ab", 2, 1, "ba"),
            (
                "ThequickbrownfoxjumpsoverthelazydogThequickbrownfox",
                5,
                3,
                "ifoaeoucnosvlzhqrwqkwxpeeyTubnTebojmrhdgikfxhrutoco",
            ),
        ];
        for &(pt, rails, offset, want_ct) in cases {
            let ct = encrypt(pt, rails, offset);
            assert_eq!(ct, want_ct, "encrypt(pt={pt:?}, rails={rails}, offset={offset})");
            // decrypt recovers the \W-stripped plaintext, not necessarily the
            // literal input (see the module docs' "mandatory \W stripping").
            let want_pt: String = pt.chars().filter(|&c| is_word_char(c)).collect();
            let back = decrypt(&ct, rails, offset).unwrap();
            assert_eq!(back, want_pt, "decrypt(ct={ct:?}, rails={rails}, offset={offset})");
        }
    }

    /// Every (rails, offset) pair round-trips for a \W-free plaintext.
    #[test]
    fn cryptool_railfence_round_trips_every_rails_and_offset() {
        let pt = "WEAREDISCOVEREDFLEEATONCE";
        for rails in 2usize..=8 {
            for offset in 0..(2 * rails as i64 - 2).max(1) {
                let ct = encrypt(pt, rails, offset);
                let back = decrypt(&ct, rails, offset).unwrap();
                assert_eq!(back, pt, "rails={rails} offset={offset} ct={ct:?}");
            }
        }
    }

    /// Varied lengths, still round-tripping through this exact `encrypt`/
    /// `decrypt` pair (both apply the same mandatory `\W` filter, so a
    /// \W-free plaintext round-trips exactly).
    #[test]
    fn cryptool_railfence_round_trips_varied_lengths() {
        let samples = [
            "ThequickbrownfoxjumpsoverthelazydogThequickbrownfox",
            "a",
            "ab",
        ];
        for pt in samples {
            for rails in 2usize..=5 {
                for offset in 0..(2 * rails as i64 - 2) {
                    let ct = encrypt(pt, rails, offset);
                    let back = decrypt(&ct, rails, offset).unwrap();
                    assert_eq!(back, pt, "pt={pt:?} rails={rails} offset={offset}");
                }
            }
        }
    }

    /// A plaintext containing whitespace or punctuation does not round-trip
    /// to its *literal* self — both `crypt` arms strip every `\W` character
    /// before railfencing at all (`jaeger.js:33`/`jaeger.js:70`), so those
    /// characters never reach the ciphertext and cannot be restored. This
    /// supersedes an earlier version of this test pinned against the
    /// *modern* `cryptool-org/cto` rewrite, which (per that port's now-
    /// removed docs) stripped only whitespace, and only post-hoc from the
    /// assembled ciphertext — the 2016 machine that actually made these
    /// puzzles is broader (`\W`, not `\s`) and strips earlier (from the
    /// plaintext, before railfencing), so `decrypt` recovers the *\W-
    /// stripped* plaintext cleanly rather than site-specific garbage.
    #[test]
    fn cryptool_railfence_plaintext_with_punctuation_does_not_round_trip_literally() {
        let pt = "The quick brown fox jumps over the lazy dog";
        let ct = encrypt(pt, 5, 0);
        let back = decrypt(&ct, 5, 0).unwrap();
        assert_ne!(back, pt);
        // Ground truth: jaeger.js under Node recovers the \W-stripped text
        // cleanly, not corrupted garbage.
        assert_eq!(back, "Thequickbrownfoxjumpsoverthelazydog");
    }

    #[test]
    fn cryptool_railfence_node_decrypts_via_registry_default_params() {
        // Default rails=5, offset=0, matching the site's page-load defaults.
        // Whitespace-free plaintext (see module docs on why).
        let pt = "Thequickbrownfoxjumpsoverthelazydog";
        let ct = encrypt(pt, 5, 0);
        let n = registry().get("cryptool_railfence").unwrap();
        let out = n.apply(&Repr::bytes(ct.into_bytes()), &params! {}).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), pt);
    }

    #[test]
    fn cryptool_railfence_node_honours_explicit_rails_and_offset() {
        let pt = "ATTACKATDAWN";
        let ct = encrypt(pt, 4, 2);
        let n = registry().get("cryptool_railfence").unwrap();
        let p = params! {"rails" => 4i64, "offset" => 2i64};
        let out = n.apply(&Repr::bytes(ct.into_bytes()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), pt);
    }

    #[test]
    fn cryptool_railfence_rejects_rails_below_two() {
        let n = registry().get("cryptool_railfence").unwrap();
        let p = params! {"rails" => 1i64};
        assert!(n.apply(&Repr::bytes(b"X".to_vec()), &p).is_err());
    }

    #[test]
    fn cryptool_railfence_preserves_display() {
        let pt = "HELLOWORLD";
        let ct = encrypt(pt, 3, 0);
        let n = registry().get("cryptool_railfence").unwrap();
        let out = n
            .apply(&Repr::new(ct.into_bytes(), Display::Hex), &params! {})
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn cryptool_railfence_is_xf_family_and_not_layer_forming() {
        let n = registry().get("cryptool_railfence").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    /// The payoff: with `strip_non_alphabet` explicitly disabled, this
    /// zigzag transposition operates on any medium, not just `\w` text --
    /// proven here against a 1092-character hex string, the length of rev7's
    /// ciphertext. A rail fence is a permutation of positions; the site's
    /// `\W` filtering is its own input normalisation (reproduced by default
    /// for site fidelity), not part of the cipher.
    #[test]
    fn cryptool_railfence_preserves_hex_medium_when_stripping_disabled() {
        let hex: String = (0..1092).map(|i| "0123456789ABCDEF".as_bytes()[i % 16] as char).collect();
        let n = registry().get("cryptool_railfence").unwrap();
        let p = params! {"rails" => 5i64, "offset" => 2i64, "strip_non_alphabet" => false};
        let out = n.apply(&Repr::bytes(hex.clone().into_bytes()), &p).unwrap();
        assert_eq!(out.data.len(), 1092);
        let mut want: Vec<u8> = hex.into_bytes();
        want.sort();
        let mut got = out.data.clone();
        got.sort();
        assert_eq!(got, want, "must be a pure permutation: same multiset of bytes");
    }
}
