//! Classical cipher nodes.
//!
//! One file per cipher so that concurrent work does not collide in a single module.
//! Each file implements [`Node`](crate::node::Node) directly — see `ra-prim`'s
//! `DecNode` for the pattern — and registers itself with
//! [`register_node!`](crate::register_node).
//!
//! # Coverage semantics
//!
//! These are `Family::Xf` (a keyed or unkeyed re-representation of the same text),
//! **not** `Family::Solver`. A solver searches an implicit space heuristically and its
//! coverage must never subtract from the exhaustive residual. A classical *transform*
//! applied at stated parameters is exhaustive at those parameters, exactly like a
//! `dec` step. If you add an automated cracker later it must be `Family::Solver` and
//! terminal.

pub mod adfgvx;
pub mod adfgx;
pub mod affine;
pub mod ascii_base_gctb;
pub mod autokey;
pub mod bacon;
pub mod bifid;
pub mod bwt;
pub mod cc_columnar;
pub mod cc_myszkowski;
pub mod cc_permutation;
pub mod cc_railfence;
pub mod cimt_lorenz;
pub mod columnar;
pub mod cryptool_columnar;
pub mod cryptool_railfence;
pub mod cto2016;
pub mod dvorak_keyboard;
pub mod edits;
pub mod enigma;
pub mod four_square;
pub mod gct_railfence;
pub mod hill;
pub mod kamasutra;
pub mod kenny;
pub mod machines;
pub mod morse_gctb;
pub mod numbers_to_letters;
pub mod ook_bf;
pub mod otp;
pub mod pc_columnar;
pub mod pc_railfence;
pub mod playfair;
pub mod polyalpha_ext;
pub mod polybius;
pub mod porta;
pub mod rotate;
pub mod rumkin_encode;
pub mod rumkin_grid;
pub mod rumkin_misc;
pub mod rumkin_shift;
pub mod rumkin_text;
pub mod rumkin_trans;
pub mod seriated;
pub mod skip;
pub mod squares;
pub mod straddling;
pub mod substitution_ext;
pub mod toolfmt;
pub mod transpositions_ext;
pub mod trifid;
pub mod unit_conversion;
pub mod vanity;
pub mod vigenere;
pub(crate) mod rumkin_common;
