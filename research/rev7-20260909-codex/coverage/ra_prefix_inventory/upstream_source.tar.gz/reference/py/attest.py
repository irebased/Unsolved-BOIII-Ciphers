"""
attest.py  -  Bind a coverage claim to the software that produced it.

A coverage set says WHAT was tried. An attestation says WHETHER TO BELIEVE IT.

Three things can silently void a claim:

  1. A wrong primitive implementation. Seven of the eleven confirmed primitives
     have no stock implementation, so each harness rolls its own. A subtly wrong
     Twofish sweeps a space that is not the real one. The claim looks fine and
     covers nothing.

  2. A too-strict scoring oracle. A sweep that only accepts 100 percent printable
     output will discard a correct CFB-8 decryption whose first block is corrupt.
     Same pipelines, less coverage. The oracle is therefore PART of the claim.

  3. A different input. Sixteen admissible TG4 transcriptions exist. A claim over
     the wrong bytes covers nothing relevant.

CONFORMANCE GATING
------------------
Every confirmed primitive is exercised by at least one SOLVED cipher with known
plaintext, so the corpus is a complete conformance suite. A harness proves its
implementations by reproducing those chains. Coverage is then automatically
INTERSECTED with the set of primitives that passed. An unproven primitive
contributes zero coverage, regardless of what the claim asserts.
"""

from __future__ import annotations
import json, hashlib, datetime
from covalg import CoverageSet, Cover, Product, prod, cover

# --------------------------------------------------------------------------
# Conformance suite derived from the solved corpus.
# primitive -> list of (cipher_id, mode) that validate it
# --------------------------------------------------------------------------
CONFORMANCE_VECTORS = {
    "Blowfish":        [("rev5", "CFB")],
    "Blowfish-compat": [("rev8", "CFB")],
    "DES":             [("rev2", "CFB"), ("rev9", "CFB")],
    "Loki97":          [("rev5", "CFB")],
    "RC2":             [("rev1", "ECB"), ("rev5", "CFB")],
    "RC4":             [("rev10", "stream")],
    "Saferplus":       [("rev10", "CFB")],
    "Serpent":         [("rev6", "CFB")],
    "Twofish":         [("rev9", "CFB")],
    "XTEA":            [("rev12", "CFB")],
    "Rijndael-256":    [("rev1", "ECB")],
}

ORACLES = {
    "printable-1.00": {"metric": "printable_ascii_ratio", "threshold": 1.00,
                       "note": "Strict. Rejects CFB-8 first-block corruption. Under-covers."},
    "printable-0.75": {"metric": "printable_ascii_ratio", "threshold": 0.75,
                       "note": "Recommended. Tolerates one corrupt block. FP rate ~2.5e-20 at 144 B."},
    "encoding-valid": {"metric": "valid_encoding_any", "threshold": 1.00,
                       "note": "Accepts clean intermediate layers (hex/octal/base64/decimal)."},
}


def sha256_str(s: str) -> str:
    return "sha256:" + hashlib.sha256(s.encode()).hexdigest()


class Attestation:
    def __init__(self, claim_id, target, coverage: CoverageSet, ciphertext,
                 variant_id, harness, primitives, oracle_id, executed,
                 hits=None, notes=""):
        self.claim_id = claim_id
        self.target = target
        self.coverage = coverage
        self.ciphertext = ciphertext
        self.variant_id = variant_id
        self.harness = harness              # {name, version, git_commit, sha256}
        self.primitives = primitives        # {name: {impl, version, sha256, conformance}}
        self.oracle_id = oracle_id
        self.executed = executed            # {started, finished, candidates_evaluated}
        self.hits = hits or []
        self.notes = notes

    # ---- validation -------------------------------------------------------
    def validate(self):
        errs, warns = [], []

        if self.oracle_id not in ORACLES:
            errs.append(f"unknown oracle '{self.oracle_id}'")
        elif self.oracle_id == "printable-1.00":
            warns.append("oracle printable-1.00 is strict; a CFB-8 hit with a corrupt "
                         "first block would be rejected. Coverage is effectively reduced.")

        for f in ("name", "version", "sha256"):
            if not self.harness.get(f):
                errs.append(f"harness missing required field '{f}'")

        claimed = self._claimed_primitives()
        proven, unproven = set(), set()
        for p in sorted(claimed):
            rec = self.primitives.get(p)
            if not rec:
                unproven.add(p); errs.append(f"primitive '{p}' claimed but not declared")
                continue
            if not rec.get("sha256"):
                errs.append(f"primitive '{p}' declared without implementation hash")
            status = rec.get("conformance", {}).get("status")
            if status == "PASS":
                exp = {c for c, _ in CONFORMANCE_VECTORS.get(p, [])}
                got = set(rec["conformance"].get("vectors", []))
                if not got:
                    errs.append(f"primitive '{p}' claims PASS with no vectors cited")
                    unproven.add(p)
                elif not got & exp:
                    errs.append(f"primitive '{p}' cites vectors {sorted(got)} which do not "
                                f"validate it; expected one of {sorted(exp)}")
                    unproven.add(p)
                else:
                    proven.add(p)
            else:
                unproven.add(p)
                warns.append(f"primitive '{p}' conformance={status}; its coverage is void")

        return {"errors": errs, "warnings": warns,
                "proven": sorted(proven), "unproven": sorted(unproven)}

    def _claimed_primitives(self):
        out = set()
        for cov in self.coverage.covers.values():
            for p in cov.products:
                for k, v in p.dims.items():
                    if k.endswith(".prim"):
                        out |= set(v)
        return out

    # ---- effective coverage after gating ---------------------------------
    def effective_coverage(self) -> CoverageSet:
        """Coverage intersected with conformance-proven primitives."""
        res = self.validate()
        proven = set(res["proven"])
        out = CoverageSet()
        for sk, cov in self.coverage.covers.items():
            keep = []
            for p in cov.products:
                nd = {}
                empty = False
                for k, v in p.dims.items():
                    if k.endswith(".prim"):
                        nv = set(v) & proven
                        if not nv:
                            empty = True; break
                        nd[k] = nv
                    else:
                        nd[k] = set(v)
                if not empty:
                    keep.append(Product(nd))
            if keep:
                out.add(Cover(sk, keep))
        return out

    def to_json(self):
        eff = self.effective_coverage()
        res = self.validate()
        return {
            "schema": "bo3-coverage-attestation/v1",
            "claim_id": self.claim_id,
            "target": self.target,
            "input": {"variant_id": self.variant_id,
                      "ciphertext_sha256": sha256_str(self.ciphertext),
                      "ciphertext_len": len(self.ciphertext)},
            "coverage_claimed": self.coverage.to_json(),
            "coverage_claimed_digest": self.coverage.digest(),
            "coverage_effective_digest": eff.digest(),
            "coverage_claimed_size": self.coverage.size_exact(),
            "coverage_effective_size": eff.size_exact(),
            "oracle": {"id": self.oracle_id, **ORACLES.get(self.oracle_id, {})},
            "toolchain": {"harness": self.harness, "primitives": self.primitives},
            "execution": self.executed,
            "hits": self.hits,
            "validation": res,
            "notes": self.notes,
        }


# --------------------------------------------------------------------------
if __name__ == "__main__":
    from residual import (SK_T1, V_PREF, K_GIANT, IV_A, M_OBS, universe_tg4)

    TG4 = ("kCmlgFi6GUJNgkNI1Q41fbfyLoCFTCvIqkZiI0KIAXAzP1U1uy1BE4UfPBfpKmmLObjYnQNRBaPtKiVWzc5A"
           "4v0w3xle8FOhAGJZ7g4in0wndJxMOvO3dc1M82at2T6935roTqyWDgtGD/hwwRF3oHqFM5Vcw1JtINbsgWRm"
           "4o4/quEDkZ7x1B275bX3/Fo1")

    # A claim asserting the FULL confirmed primitive menu was swept
    claimed_prims = {"DES", "RC2", "RC4", "Blowfish", "Twofish", "Serpent", "XTEA"}
    cs = CoverageSet()
    cs.add(cover(SK_T1, prod(**{
        "0.variant": V_PREF, "1.key": K_GIANT, "1.kd": {"nullpad"},
        "1.prim": claimed_prims, "1.mode": M_OBS, "1.iv": IV_A})))

    att = Attestation(
        claim_id="tg4-sweep-2026-07-12-run17",
        target="tg4",
        coverage=cs,
        ciphertext=TG4,
        variant_id="oswald-preferred/v01",
        harness={"name": "pallas", "version": "0.4.2",
                 "git_commit": "9f3c1a7e",
                 "sha256": "sha256:" + "a"*64},
        primitives={
            "DES":      {"impl": "pycryptodome", "version": "3.23.0",
                         "sha256": "sha256:"+"1"*64,
                         "conformance": {"status": "PASS", "vectors": ["rev2", "rev9"]}},
            "RC2":      {"impl": "pycryptodome", "version": "3.23.0",
                         "sha256": "sha256:"+"2"*64,
                         "conformance": {"status": "PASS", "vectors": ["rev1"]}},
            "RC4":      {"impl": "pycryptodome", "version": "3.23.0",
                         "sha256": "sha256:"+"3"*64,
                         "conformance": {"status": "PASS", "vectors": ["rev10"]}},
            "Blowfish": {"impl": "pycryptodome", "version": "3.23.0",
                         "sha256": "sha256:"+"4"*64,
                         "conformance": {"status": "PASS", "vectors": ["rev5"]}},
            # the three that quietly void themselves
            "Twofish":  {"impl": "custom/twofish.py", "version": "0.1",
                         "sha256": "sha256:"+"5"*64,
                         "conformance": {"status": "UNTESTED", "vectors": []}},
            "Serpent":  {"impl": "custom/serpent.py", "version": "0.1",
                         "sha256": "sha256:"+"6"*64,
                         "conformance": {"status": "FAIL", "vectors": ["rev6"]}},
            "XTEA":     {"impl": "custom/xtea.py", "version": "0.2",
                         "sha256": "sha256:"+"7"*64,
                         "conformance": {"status": "PASS", "vectors": ["rev2"]}},  # wrong vector
        },
        oracle_id="printable-1.00",
        executed={"started": "2026-07-12T09:00:00Z", "finished": "2026-07-12T09:04:11Z",
                  "candidates_evaluated": 28},
        notes="Reported informally as 'brute forced every mcrypt combination'.",
    )

    r = att.validate()
    print("=" * 78); print("ATTESTATION VALIDATION"); print("=" * 78)
    print(f"claim: {att.claim_id}\n")
    print("ERRORS:")
    for e in r["errors"]: print("   x", e)
    if not r["errors"]: print("   (none)")
    print("\nWARNINGS:")
    for w in r["warnings"]: print("   !", w)
    print(f"\nproven primitives   : {r['proven']}")
    print(f"unproven (void)     : {r['unproven']}")

    eff = att.effective_coverage()
    print("\n" + "=" * 78); print("CLAIMED vs EFFECTIVE COVERAGE"); print("=" * 78)
    print(f"  claimed   = {att.coverage.size_exact():,} candidates   {att.coverage.digest()[:24]}...")
    print(f"  effective = {eff.size_exact():,} candidates   {eff.digest()[:24]}...")
    lost = att.coverage.size_exact() - eff.size_exact()
    print(f"  VOIDED    = {lost:,} candidates ({100*lost/att.coverage.size_exact():.0f}% of the claim)")

    U = universe_tg4(full=True)
    print(f"\n  universe  = {U.size_exact():,}")
    print(f"  effective coverage of universe = {100*eff.size_exact()/U.size_exact():.6f}%")

    with open("attestation_example.json", "w") as f:
        json.dump(att.to_json(), f, indent=2)
    print("\n  wrote attestation_example.json")
