//! mcrypt's RC2 parameterisation.
//!
//! RC2 (RFC 2268) has **two** independent key parameters: the key *length* in bytes
//! and the *effective key bits* `T1`, which Phase 2 of the key schedule uses to
//! collapse the expanded 128-byte key buffer back down to `T1` bits of entropy.
//! Implementations disagree about `T1`'s default, and the choice changes every
//! keystream byte, so a wrong default is a silently wrong cipher:
//!
//! | implementation | default `T1` for a `key_len`-byte key |
//! |---|---|
//! | RFC 2268 / RustCrypto `Rc2::new_from_slice` | `8 * key_len` |
//! | OpenSSL (`EVP` RC2 ciphers) | 128 |
//! | PyCryptodome `ARC2.new` | 1024 |
//! | **libmcrypt** | **1024, always** |
//!
//! # Why 1024, and how that was established
//!
//! libmcrypt's `modules/algorithms/rc2.c` does not take a `T1` argument at all. Its
//! own header comment says the effective-key-bits parameter "looks like an export
//! control hack. For normal use, it should always be set to 1024", and the body then
//! reads:
//!
//! ```text
//!     /* Phase 1: Expand input key to 128 bytes */
//!     for (j = len; j < 128; j++)
//!         xkey_p[j] = permute[(xkey_p[j - len] + xkey_p[j - 1]) % 256];
//!
//!     xkey_p[0] = permute[xkey_p[0]];
//!
//!     /* Phase 2 - reduce effective key size to "bits" */
//!     /* stripped */
//!
//!     /* Phase 3 - copy to xkey in little-endian order */
//! ```
//!
//! Phase 2 being *stripped* is exactly RFC 2268's Phase 2 evaluated at `T1 = 1024`:
//! `T8 = 128`, `TM = 0xff`, so the reduction degenerates to the single substitution
//! `L[0] = PI[L[0]]` that libmcrypt writes out by hand, and the backward loop over
//! `0..128-T8` is empty. So `T1 = 1024` is not a guess that happens to fit — it is
//! the literal semantics of the shipped C, and it is independent of the key length.
//!
//! That is the whole bug this module records. `ra` previously built RC2 through
//! `Rc2::new_from_slice`, which for the 7-byte corpus passphrase `Zombies` selects
//! `T1 = 56` and produces noise.
//!
//! # The corpus confirmation
//!
//! rev5's recorded chain is RC2/`cfb` -> reverse -> `hex_to_base64` -> Blowfish ->
//! Loki97. Step 3 consumes hex, so step 1's output *must* be a hex string, and no
//! plaintext is needed to check it. Under `T1 = 1024` with the natural 7-byte key,
//! the 1656-byte layer decrypts to 1650 hex characters followed by six newlines —
//! nothing else in the sweep of `T1 in {8, 16, .., 1024}` x
//! {natural, null-pad 8/16/24/32/128, repeat-pad 8/16/128} x {LE, BE word order}
//! comes close. See `tests/corpus.rs`.
//!
//! Cross-checked against an *independent* implementation rather than a second reading
//! of the same C: PyCryptodome's `ARC2` at its own default `effective_keylen=1024`
//! produces the identical first 1650 characters. The dossier's reference tool used
//! PyCryptodome (`reference/py/primcheck.py` records "ARC2 (pycryptodome)"), so the
//! reference was right here and this port introduced the discrepancy by reaching for
//! `Rc2::new_from_slice`.
//!
//! # Key derivation is *not* the variable here
//!
//! libmcrypt reports `max_key_size = 128` and an empty supported-key-sizes list for
//! RC2, so [`KeyDerivation::NullPadNextSupported`](crate::KeyDerivation) already
//! passes `Zombies` through at its natural 7 bytes, and that is the length the key
//! schedule needs — `Phase 1` indexes `xkey_p[j - len]`, so padding the key changes
//! the expansion. Only `Natural` and `NullPadNextSupported` reproduce rev5; the two
//! padding policies destroy it.

/// The effective key bits libmcrypt's RC2 always behaves as if it were given,
/// because its key schedule has RFC 2268's Phase 2 reduction stripped out.
///
/// Corpus-confirmed via rev5 and consistent with libmcrypt's own self-test vector.
pub const MCRYPT_RC2_EFF_KEY_BITS: usize = 1024;

#[cfg(test)]
mod tests {
    use super::*;
    use crate::mode::{self, Mode};
    use crate::prim::{instantiate_block, BlockPrim};
    use cipher::generic_array::GenericArray;
    use cipher::BlockEncrypt;

    fn enc_block(key: &[u8], eff_bits: usize, pt: [u8; 8]) -> [u8; 8] {
        let c = rc2::Rc2::new_with_eff_key_len(key, eff_bits);
        let mut b = GenericArray::clone_from_slice(&pt);
        c.encrypt_block(&mut b);
        b.into()
    }

    /// **Published known-answer vectors: RFC 2268 section 5, all eight.**
    ///
    /// These pin the round function, the mash schedule, the little-endian word
    /// packing *and* the Phase 2 effective-key-bits reduction, because the same
    /// 16-byte key appears at `T1 = 64` and `T1 = 128` with different answers. The
    /// last vector's `T1 = 129` exercises the partial-byte `TM` mask.
    #[test]
    fn rfc2268_section5_known_answer_vectors() {
        // (key, effective key bits, plaintext, ciphertext)
        const V: &[(&str, usize, &str, &str)] = &[
            (
                "0000000000000000",
                63,
                "0000000000000000",
                "ebb773f993278eff",
            ),
            (
                "ffffffffffffffff",
                64,
                "ffffffffffffffff",
                "278b27e42e2f0d49",
            ),
            (
                "3000000000000000",
                64,
                "1000000000000001",
                "30649edf9be7d2c2",
            ),
            ("88", 64, "0000000000000000", "61a8a244adacccf0"),
            ("88bca90e90875a", 64, "0000000000000000", "6ccf4308974c267f"),
            (
                "88bca90e90875a7f0f79c384627bafb2",
                64,
                "0000000000000000",
                "1a807d272bbe5db1",
            ),
            (
                "88bca90e90875a7f0f79c384627bafb2",
                128,
                "0000000000000000",
                "2269552ab0f85ca6",
            ),
            (
                "88bca90e90875a7f0f79c384627bafb216f80a6f85920584c42fceb0be255daf1e",
                129,
                "0000000000000000",
                "5b78d3a43dfff1f1",
            ),
        ];
        for (key, bits, pt, ct) in V {
            let k = hex::decode(key).unwrap();
            let p: [u8; 8] = hex::decode(pt).unwrap().try_into().unwrap();
            assert_eq!(
                hex::encode(enc_block(&k, *bits, p)),
                *ct,
                "RFC 2268 vector key={key} T1={bits} failed"
            );
        }
    }

    /// **libmcrypt's own self-test vector**, from `_mcrypt_self_test` in
    /// `modules/algorithms/rc2.c`: a 128-byte key `k[j] = (2j + 10) mod 256` over the
    /// plaintext `00 01 .. 07` must give `becbe4c8e6237a14`.
    ///
    /// It validates the cipher core against the exact C this engine is imitating.
    /// Note that it cannot by itself settle the effective-key-bits question — at
    /// `key_len = 128`, `8 * key_len` and 1024 coincide, which is presumably how the
    /// discrepancy survived in the first place.
    #[test]
    fn libmcrypt_self_test_vector() {
        let key: Vec<u8> = (0..128u32).map(|j| ((j * 2 + 10) % 256) as u8).collect();
        let pt: [u8; 8] = [0, 1, 2, 3, 4, 5, 6, 7];
        assert_eq!(
            hex::encode(enc_block(&key, MCRYPT_RC2_EFF_KEY_BITS, pt)),
            "becbe4c8e6237a14"
        );
        // the coincidence that hid the bug
        assert_eq!(
            enc_block(&key, MCRYPT_RC2_EFF_KEY_BITS, pt),
            enc_block(&key, key.len() * 8, pt)
        );
    }

    /// The behaviour under test: effective key bits are 1024 **regardless of key
    /// length**, so for any key shorter than 128 bytes mcrypt's RC2 differs from
    /// RFC 2268's default and from OpenSSL's.
    #[test]
    fn effective_key_bits_are_1024_not_eight_times_the_key_length() {
        let key = b"Zombies";
        let pt = [0u8; 8];
        let mcrypt = enc_block(key, MCRYPT_RC2_EFF_KEY_BITS, pt);
        let rfc_default = enc_block(key, key.len() * 8, pt);
        let openssl_default = enc_block(key, 128, pt);

        assert_ne!(mcrypt, rfc_default, "T1=1024 must differ from T1=8*key_len");
        assert_ne!(mcrypt, openssl_default, "T1=1024 must differ from T1=128");

        // and `instantiate_block` must select the mcrypt variant
        let p = instantiate_block("rc2", key).unwrap();
        let mut b = pt;
        p.encrypt_block(&mut b);
        assert_eq!(b, mcrypt, "instantiate_block must use T1=1024");
        assert_eq!(hex::encode(b), "c7e6ab07c8fd2928");
    }

    /// The one length at which the two conventions agree, stated as a test so the
    /// distinction above cannot be dismissed as an artefact of the constant.
    #[test]
    fn the_two_conventions_agree_only_at_a_full_128_byte_key() {
        let pt = [0x11u8; 8];
        for len in [1usize, 7, 8, 16, 32, 64, 127, 128] {
            let key: Vec<u8> = (0..len)
                .map(|i| (i as u8).wrapping_mul(7).wrapping_add(3))
                .collect();
            let same = enc_block(&key, MCRYPT_RC2_EFF_KEY_BITS, pt) == enc_block(&key, len * 8, pt);
            assert_eq!(
                same,
                len == 128,
                "key length {len}: agreement should hold only at 128"
            );
        }
    }

    fn rc2(key: &[u8]) -> Box<dyn BlockPrim> {
        instantiate_block("rc2", key).unwrap()
    }

    /// rev1 uses RC2 in ECB and rev5 uses it in CFB-8, so both must round trip.
    #[test]
    fn ecb_and_cfb8_round_trip() {
        let p = rc2(b"Zombies");
        let iv = b"0".repeat(8);
        let pt = b"THE MANY WORLDS ARE NOW ONE AND THE KEEPER GUARDS THE WAY HOME..";
        for m in [Mode::Ecb, Mode::Cfb8] {
            let ct = mode::encrypt(&*p, m, pt, &iv).unwrap();
            assert_ne!(ct, pt.to_vec(), "RC2/{m} was a no-op");
            assert_eq!(
                mode::decrypt(&*p, m, &ct, &iv).unwrap(),
                pt.to_vec(),
                "RC2/{m} did not round trip"
            );
        }
        // 64 bytes is a whole number of 8-byte blocks, so ECB has no tail to skip
        assert_eq!(pt.len() % 8, 0);
    }

    /// ECB and CFB-8 must not be confusable for RC2 either: rev1's ECB layer and
    /// rev5's CFB-8 layer are different claims.
    #[test]
    fn ecb_and_cfb8_differ_for_rc2() {
        let p = rc2(b"Zombies");
        let iv = b"0".repeat(8);
        let pt = b"identical plaintext for both modes";
        assert_ne!(
            mode::encrypt(&*p, Mode::Ecb, pt, &iv).unwrap(),
            mode::encrypt(&*p, Mode::Cfb8, pt, &iv).unwrap()
        );
    }

    #[test]
    fn block_size_is_eight_and_key_lengths_1_to_128_are_accepted() {
        assert_eq!(rc2(b"Zombies").block_size(), 8);
        for len in [1usize, 7, 64, 128] {
            assert!(
                instantiate_block("rc2", &vec![0x5au8; len]).is_ok(),
                "RC2 must accept a {len}-byte key"
            );
        }
        // longer than 128 cannot reach the cipher: key derivation truncates to
        // `max_key_size` first, so this is a defence-in-depth check on the adapter
        assert!(instantiate_block("rc2", &[0x5au8; 129]).is_err());
        assert!(instantiate_block("rc2", b"").is_err());
    }
}
