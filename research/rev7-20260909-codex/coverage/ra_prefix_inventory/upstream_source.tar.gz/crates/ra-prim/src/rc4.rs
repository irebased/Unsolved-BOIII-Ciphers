//! RC4 (mcrypt `arcfour`). A stream cipher, so it takes no mode wrapper and no IV.

use crate::prim::StreamPrim;

pub struct Rc4 {
    key: Vec<u8>,
}

impl Rc4 {
    pub fn new(key: &[u8]) -> Option<Self> {
        if key.is_empty() || key.len() > 256 {
            return None;
        }
        Some(Self { key: key.to_vec() })
    }
}

impl StreamPrim for Rc4 {
    /// Symmetric: encryption and decryption are the same operation.
    fn apply_keystream(&self, data: &mut [u8]) {
        let mut s: [u8; 256] = [0; 256];
        for (i, v) in s.iter_mut().enumerate() {
            *v = i as u8;
        }
        let mut j = 0u8;
        for i in 0..256 {
            j = j
                .wrapping_add(s[i])
                .wrapping_add(self.key[i % self.key.len()]);
            s.swap(i, j as usize);
        }
        let (mut i, mut j) = (0u8, 0u8);
        for byte in data.iter_mut() {
            i = i.wrapping_add(1);
            j = j.wrapping_add(s[i as usize]);
            s.swap(i as usize, j as usize);
            let k = s[(s[i as usize].wrapping_add(s[j as usize])) as usize];
            *byte ^= k;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Published RC4 test vectors (RFC 6229 / the original spec's examples).
    #[test]
    fn known_answer_vectors() {
        for (key, pt, want) in [
            (&b"Key"[..], &b"Plaintext"[..], "bbf316e8d940af0ad3"),
            (&b"Wiki"[..], &b"pedia"[..], "1021bf0420"),
            (
                &b"Secret"[..],
                &b"Attack at dawn"[..],
                "45a01f645fc35b383552544b9bf5",
            ),
        ] {
            let c = Rc4::new(key).unwrap();
            let mut buf = pt.to_vec();
            c.apply_keystream(&mut buf);
            assert_eq!(hex::encode(&buf), want, "key {key:?}");
        }
    }

    #[test]
    fn is_its_own_inverse() {
        let c = Rc4::new(b"Zombies").unwrap();
        let pt = b"the many worlds are now one".to_vec();
        let mut buf = pt.clone();
        c.apply_keystream(&mut buf);
        assert_ne!(buf, pt);
        c.apply_keystream(&mut buf);
        assert_eq!(buf, pt);
    }
}
