//! Dvorak keyboard remap, matching geocachingtoolbox.com's `dvorakConvert`
//! tool exactly.
//!
//! # Ground truth
//!
//! `docs/toolsites/geocachingtoolbox.json`, tool `"Dvorak keyboard"`
//! (`page_id: "dvorakKeyboard"`). The four 94-key layout tables
//! (`qwertyChars`/`dvorakTwoChars`/`dvorakRightChars`/`dvorakLeftChars`) and
//! `dvorakConvert` itself were run verbatim under Node (a DOM shim stands in
//! for `document.getElementById`) to produce every vector in the test module.
//!
//! # What this models
//!
//! Someone typed on a physical keyboard in layout A while their OS/software
//! was configured for layout B: every keystroke lands on the *position* of
//! the key they pressed, but produces the character layout B assigns to that
//! position. The site's tool (and this node) inverts that: given `from` (the
//! layout the typist's fingers used) and `to` (the layout that was actually
//! active), each input character is looked up by position in `from`'s table
//! and replaced by the character at the same position in `to`'s table. A
//! character not present in `from`'s table (any byte outside the 94-key ASCII
//! set — e.g. digits above `9` don't apply here since `1`-`0` *are* in the
//! table, but non-ASCII bytes, most control characters, etc. are not) passes
//! through unchanged, exactly as the site's `charIndex>-1` check does.
//!
//! # Direction
//!
//! This is a symmetric substitution table, not an encrypt/decrypt pair:
//! `decode(from=A, to=B)` and `decode(from=B, to=A)` are exact inverses of
//! each other by construction (same mechanism as [`crate::classical::playfair`]'s
//! digraph rule, but unkeyed and involution-free rather than requiring a
//! square). So unlike morse/numbers-to-letters in this module, no test-only
//! encode helper is needed: both directions are already reachable through the
//! `from`/`to` params, exactly as they are on the site.
//!
//! # Artifacts
//!
//! `output_method: "innerHTML"`, `copy_artifact_risk: "HIGH"`, result nested
//! in a `<textarea>` — reproduced as `Trailing::CrLf` default, matching every
//! other `.innerHTML` tool in this module.

use crate::classical::toolfmt::{read_output_fmt, CaseFold, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const NAME: &str = "dvorak_keyboard";

const SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "from",
        ParamType::Str,
        "the layout the keystrokes were physically typed on: qwerty|dvorak_two|\
         dvorak_right|dvorak_left (default: qwerty, the site's default)",
    ),
    ParamSpec::opt(
        "to",
        ParamType::Str,
        "the layout that was actually active: qwerty|dvorak_two|dvorak_right|dvorak_left \
         (default: dvorak_two, the site's default)",
    ),
);

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Layout {
    Qwerty,
    DvorakTwo,
    DvorakRight,
    DvorakLeft,
}

impl Layout {
    fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "qwerty" => Layout::Qwerty,
            "dvorak_two" => Layout::DvorakTwo,
            "dvorak_right" => Layout::DvorakRight,
            "dvorak_left" => Layout::DvorakLeft,
            _ => return None,
        })
    }

    fn table(self) -> &'static [u8; 94] {
        match self {
            Layout::Qwerty => QWERTY,
            Layout::DvorakTwo => DVORAK_TWO,
            Layout::DvorakRight => DVORAK_RIGHT,
            Layout::DvorakLeft => DVORAK_LEFT,
        }
    }
}

/// The four 94-entry key tables, transcribed verbatim from the site's
/// `qwertyChars`/`dvorakTwoChars`/`dvorakRightChars`/`dvorakLeftChars`
/// arrays (dumped via `node -e '...'`, see module doc). Position `i` in every
/// table names the *same physical key*, so `QWERTY[i]` -> `DVORAK_TWO[i]` is
/// exactly the remap a Dvorak-configured OS applies to a QWERTY-typed
/// keystroke.
// Every table below was generated programmatically from the site's own
// arrays (`node -e '...'`, joining each 94-entry JS array with no
// separator, then Rust-escaping backslash/quote) -- see the module doc.
// Do not hand-edit: a stray inserted byte silently breaks the by-position
// correspondence every lookup in this file depends on (caught by
// `tables_have_94_unique_entries` below).
#[rustfmt::skip]
const QWERTY: &[u8; 94] = b"~`!1@2#3$4%5^6&7*8(9)0_-+=QqWwEeRrTtYyUuIiOoPp{[}]|\\AaSsDdFfGgHhJjKkLl:;\"'ZzXxCcVvBbNnMm<,>.?/";
#[rustfmt::skip]
const DVORAK_TWO: &[u8; 94] = b"~`!1@2#3$4%5^6&7*8(9)0{[}]\"'<,>.PpYyFfGgCcRrLl?/+=|\\AaOoEeUuIiDdHhTtNnSs_-:;QqJjKkXxBbMmWwVvZz";
#[rustfmt::skip]
const DVORAK_RIGHT: &[u8; 94] = b"~`!1@2#3$4JjLlMmFfPp?/{[}]%5^6Qq>.OoRrSsUuYyBb:;+=|\\&7*8ZzAaEeHhTtDdCcKk_-(9)0Xx<,IiNnWwVvGg\"'";
#[rustfmt::skip]
const DVORAK_LEFT: &[u8; 94] = b"~`{[}]?/PpFfMmLlJj$4#3@2!1:;QqBbYyUuRrSsOo>.^6%5+=|\\_-KkCcDdTtHhEeAaZz*8&7\"'XxGgVvWwNnIi<,)0(9";

fn decode(input: &[u8], from: Layout, to: Layout) -> Vec<u8> {
    let from_table = from.table();
    let to_table = to.table();
    input
        .iter()
        .map(|&b| match from_table.iter().position(|&c| c == b) {
            Some(idx) => to_table[idx],
            None => b,
        })
        .collect()
}

pub struct DvorakKeyboard;

impl Node for DvorakKeyboard {
    fn name(&self) -> &'static str {
        NAME
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/dvorak_keyboard(geocachingtoolbox.com dvorakKeyboard tool)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let from = match params.opt_str("from") {
            Some(s) => Layout::parse(s).ok_or_else(|| {
                Error::bad_param(
                    NAME,
                    "from",
                    format!("expected qwerty|dvorak_two|dvorak_right|dvorak_left, got {s:?}"),
                )
            })?,
            None => Layout::Qwerty,
        };
        let to = match params.opt_str("to") {
            Some(s) => Layout::parse(s).ok_or_else(|| {
                Error::bad_param(
                    NAME,
                    "to",
                    format!("expected qwerty|dvorak_two|dvorak_right|dvorak_left, got {s:?}"),
                )
            })?,
            None => Layout::DvorakTwo,
        };

        let decoded = decode(&input.data, from, to);

        let fmt = read_output_fmt(
            NAME,
            params,
            OutputFmt {
                case: CaseFold::Preserve,
                grouping: None,
                trailing: Trailing::CrLf, // .innerHTML select-all copy risk (HIGH)
            },
        )?;
        Ok(Repr::new(fmt.apply(&decoded), Display::Bytes))
    }
}

register_node!(DVORAK_KEYBOARD => || Box::new(DvorakKeyboard));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn node() -> &'static dyn Node {
        registry().get(NAME).unwrap()
    }

    fn run(from: &str, to: &str, text: &[u8]) -> Vec<u8> {
        node()
            .apply(
                &Repr::bytes(text.to_vec()),
                &params! {"from" => from, "to" => to, "trailing" => "none"},
            )
            .unwrap()
            .data
    }

    /// Every table has exactly 94 entries and every byte in it is unique
    /// (both properties the site's `indexOf`-based lookup silently relies on).
    #[test]
    fn tables_have_94_unique_entries() {
        for table in [QWERTY, DVORAK_TWO, DVORAK_RIGHT, DVORAK_LEFT] {
            assert_eq!(table.len(), 94);
            let mut sorted = table.to_vec();
            sorted.sort_unstable();
            sorted.dedup();
            assert_eq!(sorted.len(), 94, "{table:?} has a duplicate byte");
        }
    }

    /// Ground truth: `node run_dvorak.js` running `dvorakConvert` from the
    /// site's own JS under a DOM shim.
    #[test]
    fn ground_truth_from_site_js() {
        assert_eq!(run("qwerty", "dvorak_two", b"hello world"), b"d.nnr ,rpne");
        assert_eq!(run("dvorak_two", "qwerty", b"pbkr xdpit"), b"rnvo bhrgk");
        assert_eq!(run("qwerty", "dvorak_right", b"test 123"), b"oq8o 123");
        assert_eq!(run("qwerty", "dvorak_left", b"test 123"), b"ubku []/");
        assert_eq!(run("qwerty", "qwerty", b"unchanged!"), b"unchanged!");
        assert_eq!(
            run("qwerty", "dvorak_two", b"Hello, World! [test] {ok}"),
            "D.nnrw <rpne! /y.oy= ?rt+".as_bytes()
        );
    }

    #[test]
    fn bytes_outside_the_table_pass_through_unchanged() {
        // '\n', '\t' and DEL (0x7f) are not in any of the 94-key tables.
        assert_eq!(run("qwerty", "dvorak_two", b"a\n\t\x7f"), b"a\n\t\x7f");
    }

    #[test]
    fn round_trip_swapping_from_and_to() {
        for (from, to) in [
            ("qwerty", "dvorak_two"),
            ("qwerty", "dvorak_right"),
            ("dvorak_left", "dvorak_right"),
        ] {
            let text = b"The Quick, Brown Fox! [123]";
            let there = run(from, to, text);
            let back = run(to, from, &there);
            assert_eq!(back, text, "from={from} to={to}");
        }
    }

    #[test]
    fn malformed_layout_is_rejected() {
        let err = node()
            .apply(
                &Repr::bytes(b"hi".to_vec()),
                &params! {"from" => "sideways"},
            )
            .unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn node_applies_default_trailing_artifact() {
        let out = node()
            .apply(&Repr::bytes(b"hello world".to_vec()), &params! {})
            .unwrap();
        assert_eq!(out.data, b"d.nnr ,rpne\r\n");
    }

    #[test]
    fn is_xf_family_and_not_layer_forming() {
        let n = node();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
