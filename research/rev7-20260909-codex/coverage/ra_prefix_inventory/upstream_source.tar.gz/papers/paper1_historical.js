const S = require("./style.js");
const { docx, PAGE, numbering, title, subtitle, h1, h2, h3, p, mono, li, numItem, table, callout, spacer, makeHeaderFooter } = S;
const { Document, Packer, Paragraph, TextRun, AlignmentType, BorderStyle } = docx;
const fs = require("fs");

const children = [];
const A = (...x) => children.push(...x);

// ---------- Front matter ----------
A(title("The Black Ops III Zombies Cipher Corpus"));
A(subtitle("A Historical and Forensic Reference for the Two Remaining Unsolved Ciphers"));
A(p([
  { t: "Document 1 of 3 (Shared Reference). ", bold: true },
  "This paper establishes the historical record, the confirmed solution methods, and the tool-attribution forensics for the Black Ops III (BO3) Zombies cipher corpus authored by Jason Blundell. It is written to serve two audiences at once: a human reader seeking a rigorous narrative, and an automated agent that will consume the accompanying machine-readable evidence base to constrain a search. The two target papers, one for The Giant 4 and one for Revelations 7, reference this document for shared context and do not repeat it.",
]));
A(callout("Scope note.", [
  "Cipher identifiers in this dossier follow the texture-file alphabetical ordering used by the irebased documentation project. This ordering differs from the numbering used in several community posts, including the widely circulated Reddit index. Where a claim depends on identifier, the identifier is given in the irebased convention and should be cross-checked before transfer to any external tool.",
]));

// ---------- 1. Abstract ----------
A(h1("1. Abstract"));
A(p([
  "Between 2015 and 2016, the Zombies mode of Call of Duty: Black Ops III shipped a large body of ciphers as environmental collectibles across six maps. Most were solved within the game's active period. A residue of high-difficulty ciphers, concentrated in the final map, Revelations, resisted solution for approximately nine years. In early 2026 the community established that these holdouts used modern block and stream ciphers implemented by the deprecated PHP library mcrypt, keyed uniformly with the string ",
  { t: "Zombies", mono: true },
  ". This finding, together with a parallel breakthrough on the last classical holdout in Gorod Krovi, reduced the unsolved set to two ciphers: The Giant 4 and Revelations 7. This paper documents the corpus, extracts the invariant properties of the confirmed modern-encryption solutions, and consolidates the tool-attribution forensics that materially narrowed the search space in every recent solve.",
]));

// ---------- 2. The corpus and its timeline ----------
A(h1("2. The Corpus and Its Release Timeline"));
A(p([
  "BO3 Zombies released its ciphers in six tranches. The base game shipped two map cipher sets simultaneously: Shadows of Evil (SOE) and The Giant. Four downloadable content packs followed at roughly three-month intervals: Der Eisendrache (DE), Zetsubou No Shima (ZNS), Gorod Krovi (GK), and Revelations (REV). The release cadence matters for attribution because the author's tool habits evolved over the cycle. Early maps show a wide and varied tool set; later maps show consolidation onto a smaller, repeatedly used core. A cipher's position in this timeline therefore bounds the set of tools plausibly available to its author at authoring time.",
]));
A(table(
  ["Tranche", "Map (abbrev.)", "Release position", "Cipher count", "Status"],
  [
    ["Launch", "Shadows of Evil (SOE)", "Base game", "6", "All solved"],
    ["Launch", "The Giant (TG)", "Base game", "6 (5 ciphers, 1 scrap)", "5 of 6 solved; TG4 open"],
    ["DLC 1", "Der Eisendrache (DE)", "+3 months", "12", "All solved"],
    ["DLC 2", "Zetsubou No Shima (ZNS)", "+6 months", "13", "All solved"],
    ["DLC 3", "Gorod Krovi (GK)", "+9 months", "14", "All solved"],
    ["DLC 4", "Revelations (REV)", "+12 months", "14", "13 solved; REV7 open"],
  ],
  [1500, 2900, 1700, 1900, 1640]
));
A(callout("Hard fact.", [
  "As of the compilation date, exactly two ciphers in the BO3 corpus remain unsolved: The Giant 4 (TG4) and Revelations 7 (REV7). Both present as high-entropy encoded text and both are treated by the documentation project as likely modern encryption.",
]));

// ---------- 3. The nine-year assumption and its collapse ----------
A(h1("3. The Central Assumption and Its Collapse"));
A(p([
  "For most of the corpus's life the community operated under a stated constraint attributed to the author: that he would not use cipher techniques invented after the 1960s, and that he did not need modern encryption to defeat solvers. This was read as excluding modern symmetric ciphers entirely. The reading is understandable but, in hindsight, over-broad. Base conversions such as Base64 postdate the 1960s as encodings, yet were treated as admissible because they are encodings rather than encryption. The same latitude was not extended to modern ciphers, and the resulting blind spot plausibly cost the community years.",
]));
A(p([
  "The assumption collapsed in February 2026. A solver cracked the first layer of Revelations 10 by applying an RC4 decryption keyed with ",
  { t: "Zombies", mono: true },
  ", producing a clean intermediate layer of octal text. Because a wrong modern decryption yields pseudorandom bytes rather than structured output, a clean intermediate is strong positive evidence that the correct primitive has been found. This single result reframed the entire holdout set as modern-encryption candidates and directly enabled the cascade of solves that followed.",
]));
A(callout("Informed guess, now falsified.", [
  "The prior belief that the unsolved ciphers avoided modern encryption is false for at least nine of the ten former Revelations holdouts. Any agent search that inherits the no-modern-encryption prior as a hard constraint will fail on both remaining targets and must not apply it.",
]));

// ---------- 4. Invariants of the modern solutions ----------
A(h1("4. Invariants of the Confirmed Modern Solutions"));
A(p([
  "The thirteen solved Revelations ciphers, read together, expose a set of properties that recur with enough regularity to be treated as near-invariants of the author's modern-encryption practice. These are the highest-value transferable facts in the dossier because they collapse otherwise unbounded parameter spaces (key, IV, mode) to fixed values.",
]));
A(h2("4.1 Key"));
A(p([
  "Every confirmed modern layer across the corpus uses the key ",
  { t: "Zombies", mono: true },
  " (capital Z, remaining letters lowercase). Some classical layers use the uppercase variant ",
  { t: "ZOMBIES", mono: true },
  " (for example the Beaufort layer of Revelations 1 and the Playfair layer of Revelations 11). No confirmed layer uses any other key. This is the single most load-bearing invariant in the dossier.",
]));
A(h2("4.2 Initialization vector"));
A(p([
  "Confirmed modern layers use the IV given in hexadecimal as ",
  { t: "30303030303030303030303030303030", mono: true },
  ". This is not a true null IV. It is the ASCII string of sixteen '0' characters, each the byte 0x30. The distinction is the crux of a class of first-block failures: a solver who supplies a genuinely zeroed IV will corrupt the first block while later blocks decrypt correctly. The tools4noobs front-end over mcrypt supplied this ASCII-zero IV implicitly, which is why reproducing the solves requires matching it exactly.",
]));
A(h2("4.3 Mode and library"));
A(p([
  "The distinguishing implementation detail is the feedback mode. mcrypt implements CFB as an 8-bit feedback (CFB-8) rather than the full-block feedback (nCFB) used by most modern libraries. A cipher enciphered under mcrypt CFB-8 cannot be reproduced by tools that assume nCFB, which is why CyberChef and comparable modern tooling failed on these ciphers even with the correct primitive, key, and IV. mcrypt was officially deprecated at the end of 2016, shortly after these ciphers were authored, which places the relevant tool at the edge of its supported lifetime.",
]));
A(table(
  ["Property", "Value", "Confidence"],
  [
    ["Key (modern layers)", "Zombies", "Confirmed across all solved modern layers"],
    ["Key (some classical layers)", "ZOMBIES", "Confirmed (Beaufort, Playfair, ADFGX-derived)"],
    ["IV (hex)", "30303030303030303030303030303030", "Confirmed; ASCII '0' x16, not a null IV"],
    ["Feedback mode", "CFB-8 (mcrypt), not nCFB", "Confirmed; explains CyberChef failures"],
    ["Library / front-end", "mcrypt via tools4noobs", "High; primary evidence in randomiser solves"],
  ],
  [3050, 3550, 3040]
));

// ---------- 5. The modern primitives observed ----------
A(h1("5. The Modern Primitives Observed"));
A(p([
  "Across the solved modern layers the author drew from the family of block ciphers exposed by the tools4noobs front-end, most of which are AES-competition ciphers or their contemporaries. The observed set is a concrete, finite menu that an agent should enumerate rather than treating the primitive as free.",
]));
A(li([{ t: "Confirmed primitives: ", bold: true }, { t: "RC2, RC4, DES, Blowfish, Blowfish-compat, Twofish, Serpent, Loki97, Saferplus, XTEA, and Rijndael-256.", mono: false }]));
A(li([{ t: "Modes seen: ", bold: true }, "predominantly CFB (as CFB-8); ECB observed on the RC2 and Rijndael-256 layers of Revelations 1."]));
A(li([{ t: "Layering: ", bold: true }, "one to three modern layers per cipher, frequently interleaved with a base conversion (hex to Base64) and an occasional reverse or ROT transform between layers."]));
A(callout("Design pattern.", [
  "The recurring inter-layer motif is: decode a base representation, decrypt one modern primitive under Zombies with the ASCII-zero IV, then either reverse, re-decode, or apply a light classical transform before the next primitive. This is the template both remaining targets should be tested against.",
]));

// ---------- 6. The two recent breakthroughs ----------
A(h1("6. The Two Recent Breakthroughs"));
A(h2("6.1 Gorod Krovi 12: a Quagmire III autokey"));
A(p([
  "The last Gorod Krovi holdout was a short cipher whose brevity defeated ordinary cryptanalysis: the ciphertext was too short to expose period structure, and its repeated bigrams were coincidental rather than diagnostic. The solution arrived through two non-analytic levers. First, a day-one DLC bug briefly colocated all Gorod Krovi cipher scraps at a single map position, and a recording of that state survived. Because nearly every other GK cipher was already solved in plaintext, the colocated grouping revealed that the scraps were organized by topic, with the target's column pertaining to a great battle. Second, a crib built around the phrase ",
  { t: "great battle", mono: true },
  " was run through a community-built cribbing tool. The cipher resolved as a Vigenere autokey in Quagmire III configuration, with cipher key ",
  { t: "TRYTHIS", mono: true },
  " and keyed alphabet ",
  { t: "ZOMBIESAREEVERYWHERE", mono: true },
  ".",
]));
A(callout("Transferable lesson.", [
  "The GK12 solve did not come from stronger analysis of the ciphertext. It came from an external context leak (topic grouping) that supplied a crib, plus a tool matched to the exact cipher variant. Both remaining targets are short or structurally ambiguous enough that the same shape of solution, external constraint plus variant-exact tooling, is more likely than a purely analytic break.",
]));
A(h2("6.2 The Revelations cascade"));
A(p([
  "Following the Revelations 10 first-layer break, one solver reconstructed the mcrypt and tools4noobs pipeline and, on 22 February 2026, reported solutions to a batch of Revelations ciphers. The final classical holdout, Revelations 11, fell on 10 March 2026, and Revelations 1, whose outermost layer is classical over a modern core, fell on 11 April 2026. The residue after this cascade is Revelations 7 alone.",
]));

// ---------- 7. Tool-attribution forensics ----------
A(h1("7. Tool-Attribution Forensics"));
A(p([
  "The most productive method the community developed is not cryptanalysis but tool fingerprinting. Because the author encoded ciphers by pasting text into web tools and copying the output largely untouched, each cipher carries the idiosyncrasies of its generating tool: casing conventions, grouping widths, whitespace and line-ending handling, padding behavior, and the presence of tool-specific bugs. Matching these fingerprints against period-correct tools, recovered where necessary from the Internet Archive, narrows the candidate transformation at each layer far more tightly than analysis alone.",
]));
A(h2("7.1 The core tool set"));
A(p("The tools that recur across the BO3 corpus, with their characteristic tells, are summarized below. Confidence values are those recorded by the forensic compiler and should be read as the community's calibrated belief, not certainty."));
A(table(
  ["Tool", "Primary use in BO3", "Characteristic tell"],
  [
    ["tools4noobs", "mcrypt modern encryption front-end", "CFB-8 feedback; implicit ASCII-zero IV; key 'Zombies'"],
    ["Rumkin", "Vigenere family, autokey/Quagmire, transposition", "Preserves whitespace in transposition; keymaker alphabets; niche ciphers (Skip, Rotate)"],
    ["Cryptool Online (CTO)", "Playfair, Bifid, Homophonic, AMSCO, others", "Groups into 5; W=VV option; German-frequency homophonic table"],
    ["Cryptii V2", "Base conversions, Baudot, Atbash, Navajo", "LF-without-CR artifact at end; ASCII-to-Roman oddity"],
    ["Practical Cryptography", "Porta, Four-Square, Straddling Checkerboard, Enigma", "Deranged-alphabet generators; default keys match CT"],
    ["Geocaching Toolbox", "hex/base conversions, classical utilities", "Candidate for periodic-table and several Rev classical layers"],
    ["Braingle", "Trifid, Polybius", "Space-preserving Polybius; non-standard Trifid ruleset"],
  ],
  [1750, 3350, 4140]
));
A(h2("7.2 The absence argument"));
A(p([
  "Attribution is strengthened by what is not present. dCode, a large and popular cryptography site, shows no confirmed use anywhere in the corpus. Its absence is informative: it lets the search exclude the broad menu of dCode-only transforms and concentrate on the narrow, niche tool set the author actually favored. This is a genuine constraint and should be encoded as such, while remaining a probabilistic rather than absolute exclusion.",
]));
A(h2("7.3 The missing zero-padding encoder"));
A(p([
  "One tool fingerprint recurs without a confirmed source: a base-conversion encoder that left-pads decimal and octal values with zeros to a fixed width (for example rendering 4 as 004 and 40 as 040). This behavior appears in several Revelations decimal and octal layers. A leading candidate is a multi-function unit-conversion site (provisionally, a domain of the form unit-convert), which produces left-padded output and carries additional cipher utilities alongside its conversion tools. Confirming this tool would resolve the encoding step in more than one Revelations chain and may bear on Revelations 7.",
]));
A(callout("Open forensic lead.", [
  "The zero-padding encoder is an unresolved but high-value lead. It is an informed hypothesis, not a fact. It should be investigated by direct testing of candidate sites against known-good Revelations decimal and octal layers before any weight is placed on it for Revelations 7.",
]));
A(h2("7.4 Lost tooling"));
A(p([
  "Two attribution problems are structural. First, the contemporaneous version of CrypTool performed much of its processing on a back-end server, so while the Wayback Machine preserves the client interface, the transforms themselves are not reproducible from the archive. A specific casualty is a suspected CrypTool feature that produced all-uppercase output with five-character grouping, which would directly explain the surface form of Revelations 7. Second, several tools have been silently fixed since 2016, so their period bugs, which are exactly the fingerprints of interest, no longer reproduce on the live sites and must be reconstructed from archived snapshots.",
]));

// ---------- 8. Evidence taxonomy ----------
A(h1("8. Evidence Taxonomy for Downstream Use"));
A(p([
  "To prevent hypotheses from hardening into false constraints, every claim carried forward into the two target papers is tagged by evidence tier. The tiers are defined here and used consistently across the dossier.",
]));
A(numItem([{ t: "Hard fact. ", bold: true }, "Directly observed and independently reproducible: ciphertext content and length, character set, computed statistics, block alignment, and any solution chain confirmed against recovered plaintext. Safe to use as a search constraint."], "steps"));
A(numItem([{ t: "Forensic inference. ", bold: true }, "A tool or method attribution supported by fingerprint evidence but not proven. Usable as a strong prior that biases search order; must remain falsifiable and reversible."], "steps"));
A(numItem([{ t: "Working hypothesis. ", bold: true }, "A plausible but unverified conjecture, including the leading structural readings of the two targets. Must be tested, never assumed, and must never prune the search space on its own authority."], "steps"));
A(callout("Instruction to downstream agents.", [
  "Constrain search using hard facts only. Order and prioritize search using forensic inferences. Generate candidate pipelines from working hypotheses, but treat a failed hypothesis as information, not as a dead end for the whole target. A single incorrect assumption invalidates every brute-force result that inherited it, so assumptions must be logged, scoped, and independently reversible.",
], S.ACCENT));

// ---------- 9. References ----------
A(h1("9. Sources and References"));
A(p("Primary and secondary sources underpinning this dossier. Machine-readable extracts of the first source accompany this document as evidence_base.json.", { after: 100 }));
A(numItem(["irebased, Unsolved BO3 Ciphers documentation project. Per-cipher records (ciphertext, metadata, confirmed solution chains) at irebased.github.io/Unsolved-BOIII-Ciphers, with source data under lavender/src/data/ciphers."], "steps2"));
A(numItem(["Community tool-attribution spreadsheet, Zombies Sources (published Google Sheet). Per-cipher tool hypotheses with confidence values and explanatory notes."], "steps2"));
A(numItem(["Solver-reported breakthroughs, Skite's Aether community, February to April 2026: Revelations first-layer break, mcrypt/CFB-8 identification, and the Revelations solve cascade."], "steps2"));
A(numItem(["Contributor-supplied Revelations tool hypotheses (this dossier, Appendix reconciliation), including candidates not present in the published spreadsheet."], "steps2"));
A(numItem(["Internet Archive (Wayback Machine) snapshots of Rumkin, CrypTool, and related tools, used to recover period-correct behavior."], "steps2"));

A(spacer(60));
A(new Paragraph({
  border: { top: { style: BorderStyle.SINGLE, size: 4, color: "9A9A9A", space: 6 } },
  spacing: { before: 120 },
  children: [new TextRun({ text: "End of Document 1. Continue to Document 2 (The Giant 4) and Document 3 (Revelations 7).", italics: true, size: 18, color: "6A6A6A", font: S.FONT })],
}));

// ---------- assemble ----------
const doc = new Document({
  numbering,
  styles: { default: { document: { run: { font: S.FONT, size: 21, color: S.INK } } } },
  sections: [{
    properties: { page: PAGE },
    ...makeHeaderFooter("The BO3 Zombies Cipher Corpus  -  Historical & Forensic Reference"),
    children,
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/claude/BO3_Cipher_Dossier/papers/01_Historical_Forensic_Reference.docx", buf);
  console.log("wrote 01_Historical_Forensic_Reference.docx", buf.length, "bytes");
});
