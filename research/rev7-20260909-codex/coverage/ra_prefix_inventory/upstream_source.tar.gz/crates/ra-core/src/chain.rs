//! Chain execution and content-addressed chain identity.

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

use crate::error::{Error, Result};
use crate::layer::{layer_delta, LayerDelta};
use crate::node::Node;
use crate::params::Params;
use crate::registry::registry;
use crate::repr::Repr;

/// One bound step: a registered node name plus its parameters.
#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub struct Step {
    pub node: String,
    #[serde(default, skip_serializing_if = "Params::is_empty")]
    pub params: Params,
}

impl Step {
    pub fn new(node: impl Into<String>, params: Params) -> Self {
        Self {
            node: node.into(),
            params,
        }
    }

    pub fn bare(node: impl Into<String>) -> Self {
        Self::new(node, Params::new())
    }
}

/// An ordered composition of steps, validated at construction.
#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
#[serde(transparent)]
pub struct Chain {
    steps: Vec<Step>,
}

/// A traced execution: the value after each step plus what that step achieved.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TraceEntry {
    pub node_id: String,
    pub step: Step,
    pub delta: LayerDelta,
}

impl Chain {
    /// Build a chain, rejecting unknown nodes and misplaced terminal nodes.
    ///
    /// A [`Family::Solver`](crate::node::Family::Solver) node emits plaintext, so
    /// nothing may follow it. Enforcing that here means an invalid pipeline cannot
    /// be constructed at all, let alone claimed as coverage.
    pub fn new(steps: Vec<Step>) -> Result<Self> {
        if steps.is_empty() {
            return Err(Error::EmptyChain);
        }
        let reg = registry();
        let last = steps.len() - 1;
        for (i, s) in steps.iter().enumerate() {
            let node = reg
                .get(&s.node)
                .ok_or_else(|| Error::UnknownNode(s.node.clone()))?;
            if node.terminal() && i != last {
                return Err(Error::TerminalNotLast {
                    node: s.node.clone(),
                    index: i,
                });
            }
            // fail fast on missing required parameters
            for spec in node.params_schema() {
                if spec.required && s.params.get(spec.name).is_none() {
                    return Err(Error::MissingParam {
                        node: s.node.clone(),
                        param: spec.name.to_string(),
                    });
                }
            }
        }
        Ok(Self { steps })
    }

    pub fn steps(&self) -> &[Step] {
        &self.steps
    }

    pub fn len(&self) -> usize {
        self.steps.len()
    }

    pub fn is_empty(&self) -> bool {
        self.steps.is_empty()
    }

    fn nodes(&self) -> impl Iterator<Item = &'static dyn Node> + '_ {
        let reg = registry();
        self.steps.iter().filter_map(|s| reg.get(&s.node))
    }

    /// Content hash over the ordered *node identities* and the bound parameters.
    ///
    /// Both halves matter. Including node identities means two workers running
    /// different implementations of the same logical primitive produce different
    /// chain ids, so agreement between them is evidence rather than a tautology.
    /// Including parameters means the same code at different settings is a
    /// distinct claim.
    pub fn chain_id(&self) -> String {
        let ids: Vec<String> = self.nodes().map(|n| n.node_id().to_string()).collect();
        let canon = serde_json::to_string(&self.steps).unwrap_or_default();
        let mut h = Sha256::new();
        h.update(ids.join("|").as_bytes());
        h.update(canon.as_bytes());
        format!("chain:{}", &hex::encode(h.finalize())[..24])
    }

    /// The block size of the final layer-forming step, for the block-aware oracle.
    ///
    /// Under CFB-8 a wrong IV corrupts exactly `block_size` bytes before the stream
    /// self-synchronises, so this is the number of leading bytes the oracle must
    /// skip to avoid discarding a correct decryption.
    pub fn terminal_block_size(&self) -> Option<usize> {
        let reg = registry();
        self.steps
            .iter()
            .rev()
            .find_map(|s| reg.get(&s.node)?.block_size(&s.params))
    }

    pub fn run(&self, input: &Repr) -> Result<Repr> {
        let reg = registry();
        let mut cur = input.clone();
        for s in &self.steps {
            let node = reg
                .get(&s.node)
                .ok_or_else(|| Error::UnknownNode(s.node.clone()))?;
            cur = node.apply(&cur, &s.params)?;
        }
        Ok(cur)
    }

    pub fn run_traced(&self, input: &Repr) -> Result<(Repr, Vec<TraceEntry>)> {
        let reg = registry();
        let mut cur = input.clone();
        let mut trace = Vec::with_capacity(self.steps.len());
        for s in &self.steps {
            let node = reg
                .get(&s.node)
                .ok_or_else(|| Error::UnknownNode(s.node.clone()))?;
            let before = cur.clone();
            cur = node.apply(&before, &s.params)?;
            trace.push(TraceEntry {
                node_id: node.node_id().to_string(),
                step: s.clone(),
                delta: layer_delta(&before, &cur, node),
            });
        }
        Ok((cur, trace))
    }

    /// Number of layer boundaries actually crossed, per the computable definition.
    pub fn observed_layers(&self, input: &Repr) -> Result<usize> {
        let (_, trace) = self.run_traced(input)?;
        Ok(trace.iter().filter(|t| t.delta.is_layer_boundary).count())
    }
}

/// A named composition of steps reported as a single layer.
///
/// Macros exist because the semantic unit a human reasons about ("peel the mcrypt
/// layer") is usually several steps ("strip whitespace, hex decode, decrypt,
/// base64 encode"). The macro is the unit of *reporting*; the steps remain the
/// unit of *versioning*, so a defect in any constituent step still invalidates
/// surgically rather than voiding the platform.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Macro {
    pub name: String,
    pub version: String,
    pub steps: Vec<Step>,
}

impl Macro {
    pub fn new(name: impl Into<String>, version: impl Into<String>, steps: Vec<Step>) -> Self {
        Self {
            name: name.into(),
            version: version.into(),
            steps,
        }
    }

    pub fn macro_id(&self) -> String {
        let reg = registry();
        let inner: Vec<String> = self
            .steps
            .iter()
            .filter_map(|s| reg.get(&s.node).map(|n| n.node_id().to_string()))
            .collect();
        let mut h = Sha256::new();
        h.update(inner.join("|").as_bytes());
        format!(
            "macro:{}@{}#{}",
            self.name,
            self.version,
            &hex::encode(h.finalize())[..12]
        )
    }

    pub fn expand(&self) -> Vec<Step> {
        self.steps.clone()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;

    #[test]
    fn unknown_node_is_rejected_at_construction() {
        let e = Chain::new(vec![Step::bare("no_such_node")]).unwrap_err();
        assert!(matches!(e, Error::UnknownNode(_)));
    }

    #[test]
    fn empty_chain_is_rejected() {
        assert!(matches!(Chain::new(vec![]), Err(Error::EmptyChain)));
    }

    #[test]
    fn missing_required_param_is_caught_before_execution() {
        let e = Chain::new(vec![Step::bare("substitute")]).unwrap_err();
        assert!(matches!(e, Error::MissingParam { .. }));
    }

    #[test]
    fn chain_id_is_order_and_param_sensitive() {
        let a = Chain::new(vec![Step::bare("reverse"), Step::bare("hexencode")]).unwrap();
        let b = Chain::new(vec![Step::bare("hexencode"), Step::bare("reverse")]).unwrap();
        assert_ne!(a.chain_id(), b.chain_id());

        let c = Chain::new(vec![Step::new("rot", params! {"n" => 6i64})]).unwrap();
        let d = Chain::new(vec![Step::new("rot", params! {"n" => 7i64})]).unwrap();
        assert_ne!(c.chain_id(), d.chain_id());
    }

    #[test]
    fn chain_id_is_stable_across_equal_chains() {
        let mk = || Chain::new(vec![Step::bare("reverse"), Step::bare("b64encode")]).unwrap();
        assert_eq!(mk().chain_id(), mk().chain_id());
    }

    /// Pure re-encoding crosses no layer boundary, however many steps it takes.
    #[test]
    fn re_encoding_chain_crosses_no_layers() {
        let c = Chain::new(vec![
            Step::bare("hexencode"),
            Step::bare("hexdecode"),
            Step::bare("b64encode"),
        ])
        .unwrap();
        let input = Repr::bytes(b"some opaque payload bytes".to_vec());
        assert_eq!(c.observed_layers(&input).unwrap(), 0);
    }

    #[test]
    fn traced_run_reports_one_entry_per_step() {
        let c = Chain::new(vec![Step::bare("reverse"), Step::bare("hexencode")]).unwrap();
        let (out, trace) = c.run_traced(&Repr::bytes(b"abc".to_vec())).unwrap();
        assert_eq!(trace.len(), 2);
        assert_eq!(out.data, b"636261");
        // reverse changed bytes but is not layer-forming
        assert!(trace[0].delta.bytes_changed);
        assert!(!trace[0].delta.is_layer_boundary);
        // hexencode changed the display but not the denoted bytes
        assert!(!trace[1].delta.bytes_changed);
    }
}
