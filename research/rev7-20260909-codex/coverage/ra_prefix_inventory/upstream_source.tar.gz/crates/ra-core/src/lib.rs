//! Core engine types for the BO3 cipher dossier: representations, the node
//! taxonomy, the plugin registry, chain execution, and computable layer detection.
//!
//! # Terminology (normative, per Document 7)
//!
//! - **step / node** — a single operation of any granularity (`reverse`, `hexdecode`,
//!   `mcrypt` decrypt). Steps are the unit of *execution* and the unit of *versioning*.
//! - **layer** — a transition from one representation to another achieved by at least
//!   one decryption or non-standard decoding. Semantic, not syntactic.
//! - **macro** — a named composition of steps reported as one layer; the constituent
//!   steps stay individually versioned so a defect invalidates surgically.
//!
//! The distinction is load-bearing: `base64 -> hex` is a step sequence that achieves
//! nothing (the denoted bytes are unchanged, only their display), whereas
//! `base64 -> a structured digit run` is a breakthrough. [`layer::layer_delta`] makes
//! that computable instead of a matter of judgement, by comparing
//! [`Repr::canonical_bytes`] across the step.

pub mod chain;
pub mod classical;
pub mod error;
pub mod layer;
pub mod nodes;
pub mod node;
pub mod params;
pub mod registry;
pub mod repr;

/// Re-exported so downstream plugin crates can use [`register_node!`] without
/// taking their own `linkme` dependency.
pub use linkme;

pub use chain::{Chain, Step};
pub use error::{Error, Result};
pub use layer::{classify, shannon, LayerDelta, ReprClass};
pub use node::{Family, Node, NodeId, ParamSpec, ParamType};
pub use params::{Params, Value};
pub use registry::{registry, Registry};
pub use repr::{Display, Repr};
