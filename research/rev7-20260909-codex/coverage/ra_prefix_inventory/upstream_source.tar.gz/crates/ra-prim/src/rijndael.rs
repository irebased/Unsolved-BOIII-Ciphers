//! Variable-block Rijndael, which AES is only a special case of.
//!
//! `rijndael-256` in the corpus means a **256-bit block**, not a 256-bit key. AES
//! standardised only the 128-bit block, so no AES implementation can reproduce it —
//! this is the primitive Document 4 identifies as unavailable in every stock library.
//!
//! Correctness strategy: the same generic code path serves Nb=4, so it is pinned
//! against the published FIPS-197 AES-128 and AES-256 test vectors. A Nb=8
//! configuration that shares that code inherits the confidence.

use crate::gf::{boxes, gmul};
use crate::prim::BlockPrim;

/// Row shift offsets. Nb=8 uses (1,3,4) rather than (1,2,3); getting this wrong is
/// the classic variable-block Rijndael bug.
fn shift_offsets(nb: usize) -> [usize; 4] {
    if nb >= 8 {
        [0, 1, 3, 4]
    } else if nb == 7 {
        [0, 1, 2, 4]
    } else {
        [0, 1, 2, 3]
    }
}

pub struct Rijndael {
    nb: usize,
    nr: usize,
    /// Flattened round keys: (nr + 1) * 4 * nb bytes.
    round_keys: Vec<u8>,
}

impl Rijndael {
    /// `block_size` and `key` length are in bytes and must each be 16, 24 or 32.
    pub fn new(block_size: usize, key: &[u8]) -> Option<Self> {
        if !matches!(block_size, 16 | 24 | 32) || !matches!(key.len(), 16 | 24 | 32) {
            return None;
        }
        let nb = block_size / 4;
        let nk = key.len() / 4;
        let nr = nb.max(nk) + 6;
        Some(Self {
            nb,
            nr,
            round_keys: expand_key(key, nb, nk, nr),
        })
    }

    fn add_round_key(&self, state: &mut [u8], round: usize) {
        let off = round * 4 * self.nb;
        for (i, b) in state.iter_mut().enumerate() {
            *b ^= self.round_keys[off + i];
        }
    }

    fn sub_bytes(&self, state: &mut [u8], inverse: bool) {
        let b = boxes();
        let table = if inverse { &b.inv_sbox } else { &b.sbox };
        for x in state.iter_mut() {
            *x = table[*x as usize];
        }
    }

    fn shift_rows(&self, state: &mut [u8], inverse: bool) {
        let c = shift_offsets(self.nb);
        let src = state.to_vec();
        for r in 1..4 {
            for col in 0..self.nb {
                let from = if inverse {
                    (col + self.nb - c[r]) % self.nb
                } else {
                    (col + c[r]) % self.nb
                };
                state[4 * col + r] = src[4 * from + r];
            }
        }
    }

    fn mix_columns(&self, state: &mut [u8], inverse: bool) {
        let m: [u8; 4] = if inverse {
            [14, 11, 13, 9]
        } else {
            [2, 3, 1, 1]
        };
        for col in 0..self.nb {
            let s = [
                state[4 * col],
                state[4 * col + 1],
                state[4 * col + 2],
                state[4 * col + 3],
            ];
            for r in 0..4 {
                state[4 * col + r] = (0..4)
                    .map(|k| gmul(m[(k + 4 - r) % 4], s[k]))
                    .fold(0, |a, b| a ^ b);
            }
        }
    }
}

impl BlockPrim for Rijndael {
    fn block_size(&self) -> usize {
        self.nb * 4
    }

    fn encrypt_block(&self, block: &mut [u8]) {
        self.add_round_key(block, 0);
        for round in 1..self.nr {
            self.sub_bytes(block, false);
            self.shift_rows(block, false);
            self.mix_columns(block, false);
            self.add_round_key(block, round);
        }
        self.sub_bytes(block, false);
        self.shift_rows(block, false);
        self.add_round_key(block, self.nr);
    }

    fn decrypt_block(&self, block: &mut [u8]) {
        self.add_round_key(block, self.nr);
        for round in (1..self.nr).rev() {
            self.shift_rows(block, true);
            self.sub_bytes(block, true);
            self.add_round_key(block, round);
            self.mix_columns(block, true);
        }
        self.shift_rows(block, true);
        self.sub_bytes(block, true);
        self.add_round_key(block, 0);
    }
}

fn expand_key(key: &[u8], nb: usize, nk: usize, nr: usize) -> Vec<u8> {
    let b = boxes();
    let total = nb * (nr + 1);
    let mut w: Vec<[u8; 4]> = Vec::with_capacity(total);
    for i in 0..nk {
        w.push([key[4 * i], key[4 * i + 1], key[4 * i + 2], key[4 * i + 3]]);
    }
    let mut rcon = 1u8;
    for i in nk..total {
        let mut t = w[i - 1];
        if i % nk == 0 {
            t = [
                b.sbox[t[1] as usize] ^ rcon,
                b.sbox[t[2] as usize],
                b.sbox[t[3] as usize],
                b.sbox[t[0] as usize],
            ];
            rcon = gmul(rcon, 2);
        } else if nk > 6 && i % nk == 4 {
            t = [
                b.sbox[t[0] as usize],
                b.sbox[t[1] as usize],
                b.sbox[t[2] as usize],
                b.sbox[t[3] as usize],
            ];
        }
        let p = w[i - nk];
        w.push([p[0] ^ t[0], p[1] ^ t[1], p[2] ^ t[2], p[3] ^ t[3]]);
    }
    w.into_iter().flatten().collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    /// FIPS-197 Appendix C.1: AES-128.
    #[test]
    fn matches_fips197_aes128() {
        let key = hex::decode("000102030405060708090a0b0c0d0e0f").unwrap();
        let pt = hex::decode("00112233445566778899aabbccddeeff").unwrap();
        let want = hex::decode("69c4e0d86a7b0430d8cdb78070b4c55a").unwrap();

        let r = Rijndael::new(16, &key).unwrap();
        let mut b = pt.clone();
        r.encrypt_block(&mut b);
        assert_eq!(b, want, "AES-128 encryption mismatch");
        r.decrypt_block(&mut b);
        assert_eq!(b, pt, "AES-128 decryption mismatch");
    }

    /// FIPS-197 Appendix C.3: AES-256. Exercises the `nk > 6` key-schedule branch
    /// that Rijndael-256 also depends on.
    #[test]
    fn matches_fips197_aes256() {
        let key = hex::decode("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
            .unwrap();
        let pt = hex::decode("00112233445566778899aabbccddeeff").unwrap();
        let want = hex::decode("8ea2b7ca516745bfeafc49904b496089").unwrap();

        let r = Rijndael::new(16, &key).unwrap();
        let mut b = pt.clone();
        r.encrypt_block(&mut b);
        assert_eq!(b, want, "AES-256 encryption mismatch");
        r.decrypt_block(&mut b);
        assert_eq!(b, pt);
    }

    /// The configuration the corpus actually needs: 256-bit block, 256-bit key.
    #[test]
    fn rijndael_256_block_round_trips() {
        let r = Rijndael::new(32, &[0x42u8; 32]).unwrap();
        assert_eq!(r.block_size(), 32);
        assert_eq!(r.nr, 14);
        let pt: Vec<u8> = (0..32u8).collect();
        let mut b = pt.clone();
        r.encrypt_block(&mut b);
        assert_ne!(b, pt);
        r.decrypt_block(&mut b);
        assert_eq!(b, pt);
    }

    /// A 256-bit block is not two AES blocks; the wide ShiftRows offsets must make
    /// the halves interdependent.
    #[test]
    fn rijndael_256_diffuses_across_the_whole_block() {
        let r = Rijndael::new(32, &[0u8; 32]).unwrap();
        let mut a = [0u8; 32];
        let mut b = [0u8; 32];
        b[0] = 1;
        r.encrypt_block(&mut a);
        r.encrypt_block(&mut b);
        let differing = a.iter().zip(b.iter()).filter(|(x, y)| x != y).count();
        assert!(
            differing > 16,
            "a one-bit input change should affect both halves, changed {differing} bytes"
        );
    }

    #[test]
    fn rejects_invalid_geometries() {
        assert!(Rijndael::new(20, &[0u8; 16]).is_none());
        assert!(Rijndael::new(16, &[0u8; 7]).is_none());
    }
}
