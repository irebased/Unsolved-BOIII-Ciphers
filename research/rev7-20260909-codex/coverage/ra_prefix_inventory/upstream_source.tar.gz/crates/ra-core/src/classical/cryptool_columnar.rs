//! CrypTool Online's "Simple Columnar Transposition" tool.
//!
//! Vendored source: `.claude/vendor/cto/_ctoApps/transposition/src/transposition/`.
//! The page's actual algorithm runs as Python under Pyodide (`transposition.js`
//! ships the interpreter and hands it the code below verbatim); the JS wrapper
//! only builds the `sys.argv` the Python `argparse` reads. The Python source is
//! embedded in `fragment.html`'s CodeMirror textarea (`#yourcode`,
//! `fragment.html:230-354`) and is transliterated here line for line:
//!
//! ```text
//! rows = math.ceil(len(cipher) / len(key))
//! diff = rows * len(key) - len(cipher)          # blank cells in the last row
//! sorted_key = sorted(dictKey.items(), key=lambda pair: alphabet.index(pair[1]))
//! ```
//!
//! `sorted()` is Python's stable sort, so repeated key letters keep their
//! original left-to-right order among themselves — matching the site's own
//! description of `sortByCustomAlphabet` (a stable bubble sort) in
//! `transposition.js`.
//!
//! # 2016 vs modern: cross-checked, no changes needed
//!
//! This node was ported from the *current* `cryptool-org/cto` repository (a
//! later Pyodide/Python rewrite). The project owner has since supplied the
//! **2016 sources** (Wayback snapshot of cryptool-online.org, timestamp
//! `20160909182347`), committed at
//! `docs/toolsites/cryptool2016/js/transposition.js`
//! (`CTOTranspositionAlgorithm.encodePartB`/`decodePartA`) — the era that
//! actually made these puzzles. That 2016 implementation is a completely
//! different piece of code (plain JS `substr` arithmetic vs an embedded
//! Python grid), but it is **mathematically equivalent** to what is
//! transliterated here: same "stable sort of key letters by alphabet index"
//! column ordering, same "first `extracols` original columns get the extra
//! character" irregular-grid rule. Verified by running the 2016 JS directly
//! under Node against this port for a battery of vectors, including a
//! non-divisible length, a custom alphabet containing a space, and a
//! ciphertext shorter than the key — see
//! `cryptool_columnar_matches_2016_transposition_js_ground_truth_vectors`.
//! No behavioural change was needed for this node.
//!
//! # The alphabet is the load-bearing parameter
//!
//! Columns are **not** ordered A–Z; they are ordered by each key letter's
//! position in a user-definable `alphabet` string (`-a`/`--alphabet`), built in
//! the page from togglable character classes (upper, lower, digits,
//! punctuation, blanks, umlauts, special characters) or typed in directly. The
//! default, with only the upper/lower toggles on, is
//! `"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"` — see
//! `initSiteBeforePythonLoaded` in `transposition.js`. [`DEFAULT_ALPHABET`]
//! matches that default exactly. The alphabet also filters: any input or key
//! character not in it is deleted before the grid is built
//! (`re.sub("[^{alphabet}]", "", ...)`), so an alphabet that omits punctuation
//! and blanks will silently drop them from both the key and the message.
//!
//! # Irregular columnar (uneven grid)
//!
//! Unlike this crate's generic `columnar` node (which requires an exact
//! rectangle), the site pads implicitly: `rows = ceil(len / key_len)`, and the
//! last `diff = rows*key_len - len` cells are missing, always from the
//! highest-indexed columns of the *original* (pre-sort) key order — i.e. the
//! columns that come last in the plaintext's own left-to-right key positions,
//! not the sorted order. `decrypt_message` accounts for this by giving those
//! columns one fewer row when carving the ciphertext back into columns.
//!
//! # Message stripping is the page's input normalisation, not the cipher
//!
//! A columnar transposition permutes *positions*; it needs a key (ordered
//! against `alphabet`) but the *message* itself needs no alphabet at all. The
//! site's `re.sub("[^{alphabet}]", "", cipher)` filtering of the ciphertext is
//! a property of this specific web page (it only ever expected the toggled
//! character classes), not of the transposition itself, so — matching
//! `cc_columnar`/`cc_railfence`/etc — it is reproduced by default (for site
//! fidelity) via [`crate::classical::toolfmt`]'s `strip_non_alphabet` param,
//! defaulting to the same `alphabet` used for column ordering, rather than
//! hardcoded inside [`decrypt_message`]. Set `strip_non_alphabet=false` to run
//! the same permutation over any medium (e.g. hex ciphertext from an earlier
//! layer), verified in
//! `cryptool_columnar_preserves_hex_medium_when_stripping_disabled` below. The
//! *key*'s own filtering against `alphabet` is unaffected by this toggle: a
//! typed-in keyword is not the medium being transposed, so it is always
//! matched against `alphabet` inside [`decrypt_message`], exactly as before.
//!
//! # Engine direction
//!
//! This crate is decrypt-direction: [`CryptoolColumnar::apply`] runs
//! `decrypt_message`. `encrypt_message` is reproduced test-only, to prove the
//! round trip and to generate ground-truth vectors.
//!
//! # rev14 — attempted and does not reproduce
//!
//! rev14's recorded solution ("6x27 grid, rotate columns by 3, read bottom to
//! top") is *not* expressible by this tool at all: the site's algorithm has no
//! rotation and no reversed-row read — a column is always read out as a
//! contiguous run in the ciphertext, and rows are always filled and read
//! top-to-bottom. An exhaustive search over all 6! = 720 possible column
//! orderings (i.e. every key of length 6, whatever its actual letters) against
//! rev14's ciphertext, using this exact `decrypt_message` transliteration,
//! found **no** ordering that reproduces the recorded plaintext. So the
//! existing `columnar:width=6,rotate=3,direction=btt,trailer=-M` parameters
//! (see `columnar.rs`) do not correspond to anything a puzzle-maker could have
//! produced by typing a plain key into this tool — the rotate/direction
//! mechanism this corpus's rev14 needs genuinely has no CrypTool-columnar
//! equivalent, plain key or otherwise. This is a negative result, not a bug:
//! see the module tests for the exhaustive search that established it.

use crate::classical::toolfmt::{read_output_fmt, CaseFold, InputNorm, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

/// The site's default alphabet with only the upper/lower toggles enabled (its
/// initial state on page load) — see `initSiteBeforePythonLoaded` in
/// `transposition.js`.
pub const DEFAULT_ALPHABET: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

const CRYPTOOL_COLUMNAR_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::req("key", ParamType::Str, "transposition key (any length >= 1)"),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "characters columns are ordered by (position in this string), and the \
         only characters kept in the key/message; default matches the site's \
         upper+lower toggle: A-Za-z"
    ),
    ParamSpec::opt(
        "case_sensitive",
        ParamType::Bool,
        "match key characters against the alphabet case-sensitively (default \
         true, the site's own default with #casesensitive checked); when \
         false the key is uppercased before matching"
    ),
);

/// `decrypt_message`, transliterated from `fragment.html`'s embedded Python
/// (see module docs). `key` is filtered to `alphabet` first (`key` is
/// uppercased first when `case_sensitive` is false); `cipher` is taken as
/// given, un-filtered — the node's `apply` runs the site's `cipher` filtering
/// as [`crate::classical::toolfmt`] input normalisation *before* calling this
/// (see module docs, "Message stripping is the page's input normalisation"),
/// so it can be disabled independently of the key's own alphabet matching.
pub fn decrypt_message(
    cipher: &str,
    key: &str,
    alphabet: &str,
    case_sensitive: bool,
) -> Result<String> {
    let mut key = key.to_string();
    if !case_sensitive {
        key = key.to_uppercase();
    }
    let keep = |s: &str| -> String { s.chars().filter(|c| alphabet.contains(*c)).collect() };
    let cipher: Vec<char> = cipher.chars().collect();
    let key: Vec<char> = keep(&key).chars().collect();

    if key.is_empty() {
        return Err(Error::bad_param(
            "cryptool_columnar",
            "key",
            "key has no characters left after filtering to the alphabet",
        ));
    }
    let klen = key.len();

    let rows = cipher.len().div_ceil(klen);
    let diff = rows * klen - cipher.len();

    // sorted_key: original column indices, stable-sorted by the key char's
    // position in `alphabet`.
    let mut sorted_key: Vec<usize> = (0..klen).collect();
    let idx_of = |c: char| -> Result<usize> {
        alphabet.find(c).ok_or_else(|| {
            Error::node_failed(
                "cryptool_columnar",
                format!("key character {c:?} is not in the alphabet"),
            )
        })
    };
    let mut key_idx = Vec::with_capacity(klen);
    for &c in &key {
        key_idx.push(idx_of(c)?);
    }
    sorted_key.sort_by_key(|&col| key_idx[col]); // stable: ties keep original order

    let mut empty_matrix: Vec<Vec<char>> = vec![Vec::new(); klen];
    let mut char_pointer = 0usize;
    for &col in &sorted_key {
        let rows_max = if col >= klen - diff { rows - 1 } else { rows };
        for _ in 0..rows_max {
            if char_pointer == cipher.len() {
                break;
            }
            empty_matrix[col].push(cipher[char_pointer]);
            char_pointer += 1;
        }
    }

    let mut out = String::with_capacity(cipher.len());
    for row in 0..rows {
        for col in empty_matrix.iter().take(klen) {
            if row < col.len() {
                out.push(col[row]);
            }
        }
    }
    Ok(out)
}

/// `encrypt_message`, transliterated from the same Python source. Test-only:
/// this crate is decrypt-direction, so nothing but the test suite (proving
/// [`decrypt_message`] agrees with the site's forward algorithm) needs it.
/// The site's `blocks_of_five`/`remove_spaces`/`replace_char` options are
/// output-artifact concerns and are intentionally not reproduced here — they
/// belong to [`crate::classical::toolfmt`], not to the core transposition.
#[cfg(test)]
fn encrypt_message(message: &str, key: &str, alphabet: &str, case_sensitive: bool) -> String {
    let mut key = key.to_string();
    if !case_sensitive {
        key = key.to_uppercase();
    }
    let keep = |s: &str| -> String { s.chars().filter(|c| alphabet.contains(*c)).collect() };
    let message: Vec<char> = keep(message).chars().collect();
    let key: Vec<char> = keep(&key).chars().collect();
    let klen = key.len();

    let mut columns: Vec<Vec<char>> = vec![Vec::new(); klen];
    for (i, &c) in message.iter().enumerate() {
        columns[i % klen].push(c);
    }

    let mut sorted_key: Vec<usize> = (0..klen).collect();
    let key_idx: Vec<usize> = key.iter().map(|&c| alphabet.find(c).unwrap()).collect();
    sorted_key.sort_by_key(|&col| key_idx[col]);

    let mut out = String::with_capacity(message.len());
    for col in sorted_key {
        out.extend(&columns[col]);
    }
    out
}

/// CrypTool Online's Simple Columnar Transposition tool, decrypting.
pub struct CryptoolColumnar;

impl Node for CryptoolColumnar {
    fn name(&self) -> &'static str {
        "cryptool_columnar"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CRYPTOOL_COLUMNAR_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = params.req_str("cryptool_columnar", "key")?;
        let alphabet = params.opt_str("alphabet").unwrap_or(DEFAULT_ALPHABET);
        let case_sensitive = params.opt_bool("case_sensitive", true);

        // Key alphabet-matching is part of the algorithm itself (handled
        // inside decrypt_message, unaffected by strip_non_alphabet -- see
        // module docs). The message's own alphabet filtering is the site's
        // input normalisation, defaulted to `alphabet` for site fidelity but
        // toggleable via strip_non_alphabet. The site writes into a plain
        // <textarea id="output"> via .val =, so the default trailing is None
        // (no select-all-copy CRLF risk).
        let in_norm = crate::classical::toolfmt::read_input_norm(
            "cryptool_columnar",
            params,
            InputNorm {
                strip_outside_alphabet: Some(alphabet.to_string()),
                ..InputNorm::default()
            },
        )?;
        let normalized = in_norm.apply(&input.data);
        let text = String::from_utf8(normalized)
            .map_err(|_| Error::node_failed("cryptool_columnar", "input is not valid UTF-8"))?;

        let plain = decrypt_message(&text, key, alphabet, case_sensitive)?;

        let out_fmt: OutputFmt = read_output_fmt(
            "cryptool_columnar",
            params,
            OutputFmt {
                case: CaseFold::Preserve,
                grouping: None,
                trailing: Trailing::None,
            },
        )?;
        let out = out_fmt.apply(plain.as_bytes());
        Ok(Repr::new(out, input.display))
    }
}

register_node!(CRYPTOOL_COLUMNAR => || Box::new(CryptoolColumnar));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    /// Ground truth: computed by transliterating the site's Python to Python
    /// directly and running it (task scratchpad `cryptool_col.py`), re-run
    /// here through the Rust port. Key "KEY" (K=idx10,E=idx4,Y=idx24 ->
    /// sorted order E,K,Y = original cols 1,0,2), message "HELLOWORLD" (10
    /// chars, 3 cols -> rows=ceil(10/3)=4, diff=2, so cols 1,2 (0-indexed,
    /// since klen-diff=1) get 3 rows, col 0 gets 4).
    #[test]
    fn cryptool_columnar_hand_computed() {
        let ct = encrypt_message("HELLOWORLD", "KEY", DEFAULT_ALPHABET, true);
        assert_eq!(ct, "EORHLODLWL");
        let pt = decrypt_message("EORHLODLWL", "KEY", DEFAULT_ALPHABET, true).unwrap();
        assert_eq!(pt, "HELLOWORLD");
    }

    #[test]
    fn cryptool_columnar_round_trips_over_representative_inputs() {
        let alphabet = DEFAULT_ALPHABET;
        let messages = [
            "TheQuickBrownFoxJumpsOverTheLazyDog",
            "PackMyBoxWithFiveDozenLiquorJugs",
            "ab",
            "abcdefghijklmnopqrstuvwxyz",
        ];
        let keys = ["A", "ZY", "KEY", "CIPHER", "ABCDEFGHIJ"];
        for msg in messages {
            for key in keys {
                let ct = encrypt_message(msg, key, alphabet, true);
                let back = decrypt_message(&ct, key, alphabet, true).unwrap();
                assert_eq!(back, msg, "msg={msg:?} key={key:?}");
            }
        }
    }

    /// Repeated key letters: ties keep their original left-to-right order
    /// (Python's `sorted` is stable). Key "BAB": B(col0) and B(col2) tie at
    /// the same alphabet position, so col0 sorts before col2 between them;
    /// sorted order is [col1(A), col0(B), col2(B)].
    #[test]
    fn cryptool_columnar_repeated_key_letters_are_stable() {
        let ct = encrypt_message("ABCDEF", "BAB", DEFAULT_ALPHABET, true);
        // cols: col0="AD", col1="BE", col2="CF"; sorted order [1,0,2] -> "BE"+"AD"+"CF"
        assert_eq!(ct, "BEADCF");
        let back = decrypt_message(&ct, "BAB", DEFAULT_ALPHABET, true).unwrap();
        assert_eq!(back, "ABCDEF");
    }

    #[test]
    fn cryptool_columnar_case_insensitive_uppercases_key_only() {
        let ct = encrypt_message("HELLOWORLD", "KEY", DEFAULT_ALPHABET, true);
        let pt_lower_key = decrypt_message(&ct, "key", DEFAULT_ALPHABET, false).unwrap();
        assert_eq!(pt_lower_key, "HELLOWORLD");
    }

    #[test]
    fn cryptool_columnar_alphabet_filters_key_and_message() {
        let alphabet = DEFAULT_ALPHABET;
        let msg = "ABC123DEF";
        let ct = encrypt_message(msg, "K3EY", alphabet, true);
        let ct2 = encrypt_message(msg, "KEY", alphabet, true);
        assert_eq!(
            ct, ct2,
            "digit in key must be filtered identically to omitting it"
        );
    }

    #[test]
    fn cryptool_columnar_node_decrypts_via_registry() {
        let n = registry().get("cryptool_columnar").unwrap();
        let p = params! {"key" => "KEY"};
        let out = n.apply(&Repr::bytes(b"EORHLODLWL".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"HELLOWORLD");
    }

    #[test]
    fn cryptool_columnar_node_supports_custom_alphabet() {
        // Custom alphabet including a space, in reverse order, matching the
        // site's "blanks" toggle plus a user-defined ordering.
        let alphabet = "ZYXWVUTSRQPONMLKJIHGFEDCBA ";
        let ct = encrypt_message("HELLO WORLD", "KEY", alphabet, true);
        let n = registry().get("cryptool_columnar").unwrap();
        let p = params! {"key" => "KEY", "alphabet" => alphabet};
        let out = n.apply(&Repr::bytes(ct.into_bytes()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "HELLO WORLD");
    }

    #[test]
    fn cryptool_columnar_rejects_key_char_outside_alphabet() {
        let n = registry().get("cryptool_columnar").unwrap();
        let alphabet = "ABC"; // deliberately excludes 'K','E','Y'
        let p = params! {"key" => "KEY", "alphabet" => alphabet};
        let err = n.apply(&Repr::bytes(b"XYZ".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn cryptool_columnar_preserves_display() {
        let n = registry().get("cryptool_columnar").unwrap();
        let p = params! {"key" => "KEY"};
        let out = n
            .apply(&Repr::new(b"EORHLODLWL".to_vec(), Display::Hex), &p)
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    /// Ground truth from the **2016** sources (`docs/toolsites/cryptool2016/js/transposition.js`,
    /// `CTOTranspositionAlgorithm.encodePartB`/`decodePartA`), the era that
    /// actually made these puzzles — run under Node with a minimal
    /// DOM/global shim (task scratchpad `jstest/run_transposition.js`).
    ///
    /// 2016's implementation looks nothing like the modern Pyodide/Python
    /// tool this node was originally ported from: it computes `colLength`
    /// via plain (sometimes fractional) division and reads columns with
    /// `substr` offsets instead of an explicit `ceil`-sized grid, and it
    /// derives the sorted column order by repeatedly scanning the alphabet
    /// and blanking matched key positions rather than calling a `sorted()`.
    /// But it is **mathematically equivalent**: the "first `extracols`
    /// original columns get one extra character" placement rule and the
    /// "stable sort of key letters by alphabet index" ordering rule both
    /// hold in 2016 too, which is why every vector below (including a
    /// non-divisible length, a custom alphabet containing a space, and a
    /// ciphertext shorter than the key) matches this node's existing
    /// implementation exactly with no changes needed. Verdict: **identical**.
    #[test]
    fn cryptool_columnar_matches_2016_transposition_js_ground_truth_vectors() {
        let alphabet = DEFAULT_ALPHABET;
        let cases: &[(&str, &str, &str, &str)] = &[
            ("HELLOWORLD", "KEY", alphabet, "EORHLODLWL"),
            ("ABCDEF", "BAB", alphabet, "BEADCF"),
            (
                "TheQuickBrownFoxJumpsOverTheLazyDog",
                "CIPHER",
                alphabet,
                "TcnmrzuoJvLgQrxOeohkFpTyeBoshDiwuea",
            ),
            (
                "PackMyBoxWithFiveDozenLiquorJugs",
                "ZY",
                alphabet,
                "akyoWtFvDzniurusPcMBxihieoeLqoJg",
            ),
            ("ab", "ABCDEFGHIJ", alphabet, "ab"),
        ];
        for &(msg, key, alpha, want_ct) in cases {
            let ct = encrypt_message(msg, key, alpha, true);
            assert_eq!(ct, want_ct, "encrypt_message(msg={msg:?}, key={key:?})");
            let back = decrypt_message(&ct, key, alpha, true).unwrap();
            assert_eq!(back, msg, "decrypt_message roundtrip msg={msg:?} key={key:?}");
        }

        // A custom alphabet including a space, in reverse order.
        let ct = encrypt_message("HELLO WORLD", "KEY", "ZYXWVUTSRQPONMLKJIHGFEDCBA ", true);
        assert_eq!(ct, "L RHLWLEOOD");

        // Edge case: ciphertext shorter than the key (colLength truncates to
        // 0 via `parseInt`/integer division on both eras' implementations).
        // 2016's decodePartA("XY", "KEY") returns "YX", matching this port.
        let back = decrypt_message("XY", "KEY", alphabet, true).unwrap();
        assert_eq!(back, "YX");
    }

    #[test]
    fn cryptool_columnar_is_xf_family_and_not_layer_forming() {
        let n = registry().get("cryptool_columnar").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    /// The payoff: with `strip_non_alphabet` explicitly disabled, this
    /// transposition operates on any medium, not just the default A-Za-z
    /// alphabet -- proven here against a 1092-character hex string, the
    /// length of rev7's ciphertext. A transposition is a permutation of
    /// positions; the site's alphabet filtering of the *message* is the
    /// tool's input normalisation (reproduced by default for site fidelity),
    /// not part of the cipher -- the key's own alphabet matching is
    /// unaffected and still required.
    #[test]
    fn cryptool_columnar_preserves_hex_medium_when_stripping_disabled() {
        let hex: String = (0..1092).map(|i| "0123456789ABCDEF".as_bytes()[i % 16] as char).collect();
        let n = registry().get("cryptool_columnar").unwrap();
        let p = params! {
            "key" => "ZOMBIES",
            "strip_non_alphabet" => false,
        };
        let out = n.apply(&Repr::bytes(hex.clone().into_bytes()), &p).unwrap();
        assert_eq!(out.data.len(), 1092);
        let mut want: Vec<u8> = hex.into_bytes();
        want.sort();
        let mut got = out.data.clone();
        got.sort();
        assert_eq!(got, want, "must be a pure permutation: same multiset of bytes");
    }

    // -- rev14 research: attempted and does NOT reproduce -----------------
    //
    // See module docs for the full account. This exhaustively proves it: over
    // all 6! = 720 possible column orderings for a width-6 key (i.e. every
    // key a person could type, regardless of its actual letters), none
    // reproduces rev14's recorded plaintext through this exact decrypt
    // algorithm. The site's tool has no rotation and no reversed-row read, so
    // rev14's recorded recipe ("rotate columns by 3, read bottom to top") is
    // not expressible here at all, plain key or otherwise.
    #[test]
    fn cryptool_columnar_rev14_negative_result_exhaustive_width6() {
        let ct_full = "st. reomet s ge toime. Tgodng cki fuank Thse.verunial finhe m tfroed urgn \
                        pbeeas 5 h llthell , ahiasoped alln ctioraponte c thandis Maxof ce ifiacre \
                        s th tonksTha-M";
        let pt_full = "Thanks to the sacrifice of Maxis and the contraption called Sophia all the \
                        115 has been purged from the final universe. Thank fucking god. Time to \
                        get some rest. -M";
        let ct_body = &ct_full[..ct_full.len() - 2];
        let pt_body = &pt_full[..pt_full.len() - 2];

        // Alphabet wide enough to keep every character in ct_body/pt_body
        // verbatim (letters, space, digits, and this ciphertext's punctuation).
        let alphabet = format!("{DEFAULT_ALPHABET} 0123456789.,:;!?()");

        let base: Vec<char> = "ABCDEF".chars().collect();
        let mut any_match = false;
        let mut perm = [0usize, 1, 2, 3, 4, 5];
        loop {
            let key: String = perm.iter().map(|&i| base[i]).collect();
            if let Ok(got) = decrypt_message(ct_body, &key, &alphabet, true) {
                if got == pt_body {
                    any_match = true;
                    break;
                }
            }
            if !next_permutation(&mut perm) {
                break;
            }
        }
        assert!(
            !any_match,
            "unexpected: found a CrypTool-columnar key reproducing rev14 -- \
             this would overturn the module docs' negative finding"
        );
    }

    /// Lexicographic next-permutation (Rust's std has no built-in for arrays).
    fn next_permutation(a: &mut [usize; 6]) -> bool {
        let n = a.len();
        let mut i = n - 1;
        while i > 0 && a[i - 1] >= a[i] {
            i -= 1;
        }
        if i == 0 {
            return false;
        }
        let mut j = n - 1;
        while a[j] <= a[i - 1] {
            j -= 1;
        }
        a.swap(i - 1, j);
        a[i..].reverse();
        true
    }
}
