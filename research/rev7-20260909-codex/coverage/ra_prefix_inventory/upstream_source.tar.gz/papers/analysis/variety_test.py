#!/usr/bin/env python3
"""Does the corpus's cipher variety beat chance?  Recomputed over all six maps.

The owner's null hypothesis is that the author deliberately varied technique.
An "each technique used once" RULE has to beat that null and survive its
counter-evidence.

Run: python3 papers/analysis/variety_test.py   (stdlib only)
"""
import os
import sys
import collections
from fractions import Fraction
from math import comb, factorial

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reuse_matrix import load, CIPHER_TYPES  # noqa: E402

MCRYPT19 = [
    "blowfish", "blowfish_compat", "cast_128", "cast_256", "des", "enigma",
    "gost", "loki97", "rc2", "rc4", "rijndael_128", "rijndael_192",
    "rijndael_256", "saferplus", "serpent", "tripledes", "twofish", "wake",
    "xtea",
]


def p_distinct(n, menu, k):
    """P(exactly k distinct) for n uniform iid draws from a menu of size `menu`."""
    S = [[0] * (n + 1) for _ in range(n + 1)]
    S[0][0] = 1
    for i in range(1, n + 1):
        for j in range(1, i + 1):
            S[i][j] = j * S[i - 1][j] + S[i - 1][j - 1]
    return Fraction(comb(menu, k) * factorial(k) * S[n][k], menu ** n)


def tail(n, menu, k):
    return sum(p_distinct(n, menu, j) for j in range(k, n + 1))


def main():
    records, steps, per_map = load()
    named = [s for s in steps if s["method"]]

    print(f"records across 6 maps : {records}")
    print(f"steps carrying a method: {len(named)}")
    print()

    # ---------------------------------------------------------------- mcrypt
    draws = [(s["rec"], s["method"]) for s in named if s["type"] == "decrypt"]
    used = collections.Counter(m for _, m in draws)
    n, k = len(draws), len(used)
    print("=" * 70)
    print("1. THE MCRYPT TEST  (the only axis with a known menu)")
    print("=" * 70)
    print(f"  menu               : {len(MCRYPT19)} primitives")
    print(f"  draws              : {n}")
    print(f"  distinct           : {k}")
    print(f"  repeats            : {dict((m, c) for m, c in used.items() if c > 1)}")
    unused = sorted(set(MCRYPT19) - set(used))
    print(f"  never used ({len(unused)})     : {unused}")
    print()
    print("  Draws contributed by each map:")
    for m in per_map:
        c = sum(1 for s in named if s["map"] == m and s["type"] == "decrypt")
        print(f"    {m:<22}{c:>3}")
    print()
    print("  >>> The three maps imported in this revision contribute ZERO new")
    print("      draws: every one of their 31 ciphers is classical. So this")
    print("      test is numerically UNCHANGED by doubling the corpus.")
    print()
    exp = len(MCRYPT19) * (1 - (1 - Fraction(1, len(MCRYPT19))) ** n)
    t = tail(n, len(MCRYPT19), k)
    print(f"  E[distinct] under uniform selection : {float(exp):.2f}")
    print(f"  observed                            : {k}")
    print(f"  P(distinct >= {k})                    : {float(t):.4f}")
    print(f"  >>> p = {float(t):.2f}. Variety still does not beat chance.")
    print()

    # ------------------------------------------------------------ strict rule
    print("=" * 70)
    print("2. THE STRICT RULE, NOW WITH MORE COUNTER-EVIDENCE")
    print("=" * 70)
    ciph = [s["method"] for s in named if s["type"] in CIPHER_TYPES]
    rep = {m: c for m, c in collections.Counter(ciph).items() if c > 1}
    where = collections.defaultdict(list)
    for s in named:
        if s["type"] in CIPHER_TYPES:
            where[s["method"]].append(s["rec"])
    print(f"  repeated CIPHERS: {len(rep)} (was 3 on the three-map corpus)")
    for m in sorted(rep):
        print(f"    {rep[m]}x  {m:<28}{where[m]}")
    print()
    print("  P(observation | strict once-only rule) = 0. Refuted, and refuted")
    print("  harder than before: the three new maps add five more repeats.")
    print()

    # --------------------------------------------------- classical sensitivity
    print("=" * 70)
    print("3. CLASSICAL CIPHERS: a sensitivity analysis, not a test")
    print("=" * 70)
    cl = [s["method"] for s in named
          if s["type"] in CIPHER_TYPES and s["type"] != "decrypt"]
    kc = len(set(cl))
    print(f"  classical cipher draws   : {len(cl)}")
    print(f"  distinct                 : {kc}")
    print("  The menu size is UNKNOWN here, so this cannot be a test. Below is")
    print("  the p-value under several assumed menu sizes, to show how much the")
    print("  conclusion depends on an unmeasured quantity.")
    print(f"  {'assumed menu':>14}{'E[distinct]':>14}{'P(>= observed)':>18}")
    for menu in (60, 100, 200, 400):
        if menu < kc:
            continue
        e = menu * (1 - (1 - Fraction(1, menu)) ** len(cl))
        tt = tail(len(cl), menu, kc)
        print(f"  {menu:>14}{float(e):>14.2f}{float(tt):>18.4f}")
    print()
    print("  >>> The answer swings on the assumption. dcode.fr alone advertises")
    print("      'more than 200 ciphers', and no menu the author actually used")
    print("      is known. No conclusion is drawn from this section; it is")
    print("      reported to show why none can be.")
    print()

    # -------------------------------------------------------------- modern map
    print("=" * 70)
    print("4. MODERN CIPHERS ARE CONFINED TO REVELATIONS")
    print("=" * 70)
    for m in per_map:
        tot = sum(1 for s in named if s["map"] == m and s["type"] in CIPHER_TYPES)
        mod = sum(1 for s in named if s["map"] == m and s["type"] == "decrypt")
        print(f"  {m:<22}{mod:>3} modern of {tot:>3} cipher steps")
    non_rev = sum(1 for s in named if s["map"] != "revelations"
                  and s["type"] in CIPHER_TYPES)
    print()
    print(f"  0 modern ciphers in {non_rev} non-Revelations cipher steps.")
    print(f"  Rule of three: 95% upper bound on the modern rate outside")
    print(f"  Revelations = 3/{non_rev} = {3 / non_rev:.1%}")
    print()
    print("  This is far stronger than the three-map version could show, and it")
    print("  bears directly on whether TG4 should be searched as a modern")
    print("  cipher: its MAP argues against, its own high-entropy base64")
    print("  ciphertext argues for. The paper states both.")
    print()

    print("=" * 70)
    print("5. WHAT REV7's PRIMITIVE PROBABILITY BECOMES")
    print("=" * 70)
    print(f"  Under uniform selection : {len(unused)}/{len(MCRYPT19)} = "
          f"{len(unused) / len(MCRYPT19):.1%}")
    print("  Under the refuted strict rule (upper bound) : 100%")
    print("  >>> UNCHANGED at 'at least 42%'. The new maps add no modern data,")
    print("      so they cannot move this figure. The engine still models 0 of")
    print("      the 8, so the gap is unchanged too.")


if __name__ == "__main__":
    main()
