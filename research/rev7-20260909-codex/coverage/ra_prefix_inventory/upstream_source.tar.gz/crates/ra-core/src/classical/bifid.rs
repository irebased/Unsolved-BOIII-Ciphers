//! Bifid: Polybius coordinates fractionated across a period, then recombined.
//!
//! # Why this node exists
//!
//! `trifid` was already here but its two-dimensional sibling was not, which left a
//! real hole: bifid is the classical way to *flatten* a letter distribution without
//! a long key, and a flat distribution is exactly the fingerprint some corpus
//! ciphertexts show (BO4 IX's ix9 has 19 distinct letters in 30 — more than any
//! English text of that length).
//!
//! # The period is the whole cipher
//!
//! Encryption writes each letter's (row, col) vertically under it, reads the rows
//! then the columns off *within each period-sized block*, and re-pairs the resulting
//! digit stream. With period >= the text length it degenerates to a single block;
//! with period 1 it degenerates to a plain Polybius substitution. Neither is a bug,
//! and both are reachable here deliberately.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: a transform at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const NAME: &str = "bifid";

/// 25 letters, `j` folded onto `i` — the classical square.
pub const DEFAULT_ALPHABET: &str = "abcdefghiklmnopqrstuvwxyz";

const SCHEMA: &[ParamSpec] = &[
    ParamSpec::req(
        "key",
        ParamType::Str,
        "keyword for the square; unused alphabet symbols follow in order",
    ),
    ParamSpec::opt(
        "period",
        ParamType::Int,
        "block length for the fractionation (default 0 = one block over the whole text)",
    ),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "square symbols (default the 25-letter j-onto-i alphabet); length must be a \
         perfect square",
    ),
    ParamSpec::opt(
        "merge",
        ParamType::Str,
        "two symbols \"ab\": 'a' folds onto 'b' before the square is built (default \
         \"ji\")",
    ),
    ParamSpec::opt(
        "direction",
        ParamType::Str,
        "\"decrypt\" (default) or \"encrypt\"",
    ),
];

fn build_square(key: &str, alphabet: &str, merge: (u8, u8)) -> Result<(Vec<u8>, usize)> {
    let members: std::collections::HashSet<u8> =
        alphabet.bytes().map(|b| b.to_ascii_lowercase()).collect();
    let mut cells = Vec::new();
    let mut seen = std::collections::HashSet::new();
    for c in key.bytes().chain(alphabet.bytes()) {
        let mut c = c.to_ascii_lowercase();
        if !members.contains(&c) {
            continue;
        }
        if c == merge.0 {
            c = merge.1;
        }
        if seen.insert(c) {
            cells.push(c);
        }
    }
    let side = (cells.len() as f64).sqrt().round() as usize;
    if side * side != cells.len() || side == 0 {
        return Err(Error::bad_param(
            NAME,
            "alphabet",
            format!("{} symbols is not a perfect square", cells.len()),
        ));
    }
    Ok((cells, side))
}

pub struct Bifid;

impl Node for Bifid {
    fn name(&self) -> &'static str {
        NAME
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/bifid(keyed-square,period-fractionation)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let ms = params.opt_str("merge").unwrap_or("ji");
        let mb = ms.as_bytes();
        if mb.len() != 2 || mb[0] == mb[1] {
            return Err(Error::bad_param(
                NAME,
                "merge",
                format!("expected two distinct bytes, got {ms:?}"),
            ));
        }
        let merge = (mb[0].to_ascii_lowercase(), mb[1].to_ascii_lowercase());
        let alphabet = params.opt_str("alphabet").unwrap_or(DEFAULT_ALPHABET);
        let (cells, side) = build_square(params.req_str(NAME, "key")?, alphabet, merge)?;
        let index: std::collections::HashMap<u8, usize> =
            cells.iter().enumerate().map(|(i, &c)| (c, i)).collect();

        let letters: Vec<u8> = input
            .data
            .iter()
            .map(|c| c.to_ascii_lowercase())
            .map(|c| if c == merge.0 { merge.1 } else { c })
            .filter(|c| index.contains_key(c))
            .collect();
        if letters.is_empty() {
            return Err(Error::node_failed(
                NAME,
                "input has no symbols from the square, so there is nothing to fractionate",
            ));
        }
        let period = params.opt_i64("period", 0);
        if period < 0 {
            return Err(Error::bad_param(NAME, "period", "must not be negative"));
        }
        let period = if period == 0 {
            letters.len()
        } else {
            period as usize
        };
        let direction = params.opt_str("direction").unwrap_or("decrypt");

        let mut out = Vec::with_capacity(letters.len());
        for block in letters.chunks(period) {
            let n = block.len();
            match direction {
                "encrypt" => {
                    let mut rows = Vec::with_capacity(n);
                    let mut cols = Vec::with_capacity(n);
                    for &c in block {
                        let i = index[&c];
                        rows.push(i / side);
                        cols.push(i % side);
                    }
                    rows.extend(cols);
                    for pair in rows.chunks_exact(2) {
                        out.push(cells[pair[0] * side + pair[1]]);
                    }
                }
                "decrypt" => {
                    let mut seq = Vec::with_capacity(2 * n);
                    for &c in block {
                        let i = index[&c];
                        seq.push(i / side);
                        seq.push(i % side);
                    }
                    let (rows, cols) = seq.split_at(n);
                    for (r, c) in rows.iter().zip(cols.iter()) {
                        out.push(cells[r * side + c]);
                    }
                }
                other => {
                    return Err(Error::bad_param(
                        NAME,
                        "direction",
                        format!("expected \"decrypt\" or \"encrypt\", got {other:?}"),
                    ))
                }
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(BIFID => || Box::new(Bifid));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn node() -> &'static dyn Node {
        registry().get(NAME).unwrap()
    }

    #[test]
    fn is_xf_family() {
        assert_eq!(node().family(), Family::Xf);
    }

    /// The textbook vector: square "BGWKZQPNDSIOAXEFCLUMTHYVR", plaintext
    /// FLEEATONCE.
    ///
    /// The published example fractionates over the *whole* message, giving
    /// UAEOLWRINS. Asserting the period-5 answer too (UAIEYYDINS, worked by hand)
    /// pins the block boundary, which is the part an implementation actually gets
    /// wrong — a period bug is invisible if only the single-block case is tested.
    #[test]
    fn textbook_vector_and_period_boundary() {
        let base = params! {
            "key" => "BGWKZQPNDSIOAXEFCLUMTHYVR",
            "alphabet" => "abcdefghiklmnopqrstuvwxyz",
            "direction" => "encrypt"
        };
        let whole = node()
            .apply(&Repr::bytes(b"FLEEATONCE".to_vec()), &base)
            .unwrap();
        assert_eq!(String::from_utf8(whole.data).unwrap(), "uaeolwrins");

        let p5 = node()
            .apply(
                &Repr::bytes(b"FLEEATONCE".to_vec()),
                &base.clone().set("period", 5i64),
            )
            .unwrap();
        assert_eq!(String::from_utf8(p5.data).unwrap(), "uaieyydins");
    }

    #[test]
    fn round_trips_at_several_periods() {
        let n = node();
        for period in [0i64, 1, 3, 5, 7, 100] {
            let enc = n
                .apply(
                    &Repr::bytes(b"defendtheeastwallofthecastle".to_vec()),
                    &params! {"key" => "ZOMBIES", "period" => period, "direction" => "encrypt"},
                )
                .unwrap();
            let back = n
                .apply(&enc, &params! {"key" => "ZOMBIES", "period" => period})
                .unwrap();
            assert_eq!(
                back.data, b"defendtheeastwallofthecastle",
                "period {period} failed to round trip"
            );
        }
    }

    /// Period 1 degenerates to a plain Polybius substitution — a real property,
    /// so it is asserted rather than forbidden.
    #[test]
    fn period_one_is_monoalphabetic() {
        let n = node();
        let out = n
            .apply(
                &Repr::bytes(b"aaaa".to_vec()),
                &params! {"key" => "ZOMBIES", "period" => 1i64, "direction" => "encrypt"},
            )
            .unwrap();
        assert!(
            out.data.windows(2).all(|w| w[0] == w[1]),
            "identical inputs must give identical outputs at period 1"
        );
    }

    #[test]
    fn malformed_parameters_are_rejected() {
        let n = node();
        let d = Repr::bytes(b"abcd".to_vec());
        for bad in [
            params! {"key" => "ZOMBIES", "period" => -1i64},
            params! {"key" => "ZOMBIES", "merge" => "j"},
            params! {"key" => "ZOMBIES", "merge" => "jj"},
            params! {"key" => "ZOMBIES", "alphabet" => "abcdef"},
            params! {"key" => "ZOMBIES", "direction" => "sideways"},
        ] {
            assert!(n.apply(&d, &bad).is_err(), "{bad:?} should be rejected");
        }
    }
}
