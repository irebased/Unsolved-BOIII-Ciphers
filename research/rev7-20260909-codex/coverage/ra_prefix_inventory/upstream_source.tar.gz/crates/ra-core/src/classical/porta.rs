//! Porta and Bellaso: reciprocal polyalphabetics over paired half-alphabets.
//!
//! # Why these nodes exist
//!
//! The Black Ops 4 "IX" set records `porta` with key `Nine` for ix10. Encrypting that
//! puzzle's known plaintext with this node reproduces the opening read off the in-game
//! image (`AYXATC…`) — see `reproduces_ix10_opening`.
//!
//! # Porta is reciprocal, which is a real property and not a convenience
//!
//! Each key letter selects one of 13 fixed involutory alphabets, so encryption and
//! decryption are the *same* operation. That is why this node has no `direction`
//! parameter: offering one would imply a distinction that does not exist, and would
//! let a caller believe they had undone something they had merely repeated.
//! `porta(porta(t)) == t` is asserted below.
//!
//! # Bellaso (1553) is the ancestor, not a synonym
//!
//! Bellaso's original tableau pairs the half-alphabets the other way round: the shift
//! is applied to the *lower* half rather than the upper. The two agree on some key
//! letters and differ on others, so a text that resists one may yield to the other —
//! which is exactly why both are here rather than one standing in for both.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: transforms at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const PORTA: &str = "porta";
const BELLASO: &str = "bellaso";

const SCHEMA: &[ParamSpec] = &[
    ParamSpec::req(
        "key",
        ParamType::Str,
        "key word, repeated cyclically; each letter selects one of 13 reciprocal \
         alphabets (letters pair up, so A and B select the same one)",
    ),
    ParamSpec::opt(
        "strip_non_alphabet",
        ParamType::Bool,
        "drop non-letters before enciphering (default true). When false they pass \
         through unchanged and do NOT consume a key position.",
    ),
];

/// One Porta step. `idx` is the key letter's alphabet index (0..=12).
///
/// Upper half (`a..m`) maps into the lower half and vice versa, which is what makes
/// the map an involution.
fn porta_step(x: i32, idx: i32) -> i32 {
    if x < 13 {
        (x + idx).rem_euclid(13) + 13
    } else {
        (x - 13 - idx).rem_euclid(13)
    }
}

/// One Bellaso step: the 1553 tableau shifts the opposite half.
fn bellaso_step(x: i32, idx: i32) -> i32 {
    if x < 13 {
        (x - idx).rem_euclid(13) + 13
    } else {
        (x + idx).rem_euclid(13)
    }
}

fn run(name: &'static str, input: &Repr, params: &Params, step: fn(i32, i32) -> i32) -> Result<Repr> {
    let key = params.req_str(name, "key")?;
    let kidx: Vec<i32> = key
        .bytes()
        .filter(|b| b.is_ascii_alphabetic())
        .map(|b| ((b.to_ascii_lowercase() - b'a') / 2) as i32)
        .collect();
    if kidx.is_empty() {
        return Err(Error::bad_param(
            name,
            "key",
            "key has no ASCII letters, so it selects no alphabet",
        ));
    }
    let strip = params.opt_bool("strip_non_alphabet", true);

    let mut out = Vec::with_capacity(input.data.len());
    let mut i = 0usize;
    for &c in input.data.iter() {
        if c.is_ascii_alphabetic() {
            let x = (c.to_ascii_lowercase() - b'a') as i32;
            let v = step(x, kidx[i % kidx.len()]);
            out.push(b'a' + v as u8);
            i += 1;
        } else if !strip {
            out.push(c);
        }
    }
    if out.is_empty() {
        return Err(Error::node_failed(
            name,
            "input has no ASCII letters, so there is nothing to encipher",
        ));
    }
    Ok(Repr::new(out, Display::Bytes))
}

pub struct Porta;
impl Node for Porta {
    fn name(&self) -> &'static str {
        PORTA
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/porta(13-reciprocal-alphabets)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }
    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        run(PORTA, input, params, porta_step)
    }
}

pub struct Bellaso;
impl Node for Bellaso {
    fn name(&self) -> &'static str {
        BELLASO
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/bellaso(1553-tableau)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }
    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        run(BELLASO, input, params, bellaso_step)
    }
}

register_node!(PORTA_NODE => || Box::new(Porta));
register_node!(BELLASO_NODE => || Box::new(Bellaso));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn porta() -> &'static dyn Node {
        registry().get(PORTA).unwrap()
    }
    fn bellaso() -> &'static dyn Node {
        registry().get(BELLASO).unwrap()
    }

    /// Conformance: ix10 is `porta` keyed `Nine`. Enciphering its known plaintext
    /// reproduces the opening transcribed from the in-game image.
    #[test]
    fn reproduces_ix10_opening() {
        let pt = "THEPATHYOUTRAVELWILLNEVERFILLYOUREMPTYHEART";
        let out = porta()
            .apply(
                &Repr::bytes(pt.as_bytes().to_vec()),
                &params! {"key" => "NINE"},
            )
            .unwrap();
        let s = String::from_utf8(out.data).unwrap();
        assert!(s.starts_with("ayxatc"), "got {s}");
    }

    /// Porta is an involution — the property that makes a `direction` parameter
    /// meaningless. Asserted rather than assumed.
    #[test]
    fn porta_is_reciprocal() {
        let n = porta();
        let once = n
            .apply(
                &Repr::bytes(b"attackatdawn".to_vec()),
                &params! {"key" => "NINE"},
            )
            .unwrap();
        let twice = n.apply(&once, &params! {"key" => "NINE"}).unwrap();
        assert_eq!(twice.data, b"attackatdawn");
    }

    #[test]
    fn bellaso_is_reciprocal_and_differs_from_porta() {
        let b = bellaso();
        let once = b
            .apply(
                &Repr::bytes(b"attackatdawn".to_vec()),
                &params! {"key" => "NINE"},
            )
            .unwrap();
        let twice = b.apply(&once, &params! {"key" => "NINE"}).unwrap();
        assert_eq!(twice.data, b"attackatdawn");

        let p = porta()
            .apply(
                &Repr::bytes(b"attackatdawn".to_vec()),
                &params! {"key" => "NINE"},
            )
            .unwrap();
        assert_ne!(once.data, p.data, "the 1553 tableau is not the modern one");
    }

    /// Key letters pair up: A and B select the same alphabet, C and D the next.
    #[test]
    fn key_letters_pair_up() {
        let n = porta();
        let a = n
            .apply(&Repr::bytes(b"hello".to_vec()), &params! {"key" => "A"})
            .unwrap();
        let b = n
            .apply(&Repr::bytes(b"hello".to_vec()), &params! {"key" => "B"})
            .unwrap();
        assert_eq!(a.data, b.data);
        let c = n
            .apply(&Repr::bytes(b"hello".to_vec()), &params! {"key" => "C"})
            .unwrap();
        assert_ne!(a.data, c.data);
    }

    /// Passthrough characters must not consume a key position — the convention the
    /// corpus already relies on for the other polyalphabetics.
    #[test]
    fn passthrough_does_not_advance_the_key() {
        let n = porta();
        let plain = n
            .apply(&Repr::bytes(b"abcd".to_vec()), &params! {"key" => "NINE"})
            .unwrap();
        let spaced = n
            .apply(
                &Repr::bytes(b"a b-c d".to_vec()),
                &params! {"key" => "NINE", "strip_non_alphabet" => false},
            )
            .unwrap();
        let letters: Vec<u8> = spaced
            .data
            .into_iter()
            .filter(|b| b.is_ascii_alphabetic())
            .collect();
        assert_eq!(letters, plain.data);
    }

    #[test]
    fn empty_key_or_letterless_input_is_an_error() {
        let n = porta();
        assert!(n
            .apply(&Repr::bytes(b"abcd".to_vec()), &params! {"key" => "123"})
            .is_err());
        assert!(n
            .apply(&Repr::bytes(b"1234".to_vec()), &params! {"key" => "NINE"})
            .is_err());
    }
}
