//! `unit-conversion.info/texttools`'s fixed-width, zero-padded ASCII and octal
//! number tools (`/texttools/ascii/` and `/texttools/octal/`).
//!
//! # Why this tool exists in this module
//!
//! `docs/layering-pattern-analysis.md` §8sexies: rev6's ciphertext is 256
//! tokens, every one exactly 3 characters wide, 198 with a leading zero, max
//! value 102 -- an exact match for "A is 065" fixed-width, left-zero-padded
//! decimal ASCII, and *not* what any previously-catalogued tool in this repo
//! produces (`ascii_base_gctb`'s `dec`/`oct` are never padded; see that
//! module's doc). This is the tool the corpus was actually encoded with.
//!
//! # Ground truth: **live HTTP capture, not JavaScript, and not corpus inference**
//!
//! `ascii_base_gctb.rs`'s precedent is to run a site's *client-side* JS
//! verbatim under a DOM shim. That approach does not apply here: this site's
//! `/texttools/js/main.js` contains no conversion logic at all -- it is a
//! thin jQuery AJAX wrapper (`$.ajax({ type: "POST", url:
//! form.attr('action')+'?ajax=1', data: form.serialize(), success: function
//! (response) { $("#output").val(response); } })`). The actual ASCII/octal
//! conversion runs **server-side** (PHP, judging by the `PHPSESSID` cookie
//! and response shape), so there is no client-side algorithm to capture.
//!
//! Ground truth here is instead **live-probed**: `curl -F "form[text]=..."
//! -F "form[convert]=1|2" "https://www.unit-conversion.info/texttools/{ascii,octal}/?ajax=1"`,
//! run against the real site on 2026-07-31, with the exact request/response
//! pairs recorded in this module's tests and doc comments below. This is
//! *tool-confirmed*, not corpus-inferred -- but it is confirmed by
//! black-box probing of the live server, not by reading source, since the
//! server's PHP is not visible to us. Every behaviour this module encodes
//! (separator, width, line-wrap absence, the encode/decode edge cases below)
//! was checked directly against the site's HTTP responses; none of it is
//! guessed from prose or extrapolated from the corpus.
//!
//! # The `.val()` finding: this is a *clean* tool, not an `.innerHTML` one
//!
//! `main.js` sets the result via jQuery `$("#output").val(response)`, i.e.
//! a `<textarea>`'s `.value` property -- exactly the "clean" case
//! `toolfmt.rs`'s module doc contrasts with `.innerHTML` tools. A select-all
//! copy out of a `.value`-backed field does not carry the trailing-CRLF
//! artifact `ascii_base_gctb` models for its `.innerHTML` tool. This module's
//! default is therefore `Trailing::None`, and unlike `ascii_base_gctb` this is
//! not a guess pending sweep discovery: it is read directly off `main.js`.
//! `copy_artifact_risk: "LOW"`.
//!
//! # Encode direction (`direction = "encode"`, the site's default: `form[convert]=1`)
//!
//! Each input byte becomes a **3-digit, left-zero-padded** token in the given
//! base (decimal for `unit_conversion_ascii`, octal for
//! `unit_conversion_octal`), tokens joined by a **single space**, with:
//!
//! - **no line wrapping at any length** -- probed up to 2000 input bytes
//!   (7999-byte single-line response, no `\n`/`\r` anywhere in it);
//! - **no padding beyond 3 digits even when the value needs more** -- this
//!   never actually arises since a byte's decimal range (`000`-`255`) and
//!   octal range (`000`-`377`) both fit in 3 digits, so this is stated for
//!   completeness rather than as an observed truncation behaviour;
//! - **empty input maps to empty output** (0 bytes back), not a lone
//!   trailing-terminator artifact;
//! - operates on raw bytes, not Unicode code points: encoding `café` (UTF-8:
//!   `63 61 66 c3 a9`) returns `099 097 102 195 169` -- the two-byte UTF-8
//!   encoding of `é` becomes two independent 3-digit tokens, confirming the
//!   server treats the POSTed body as a raw byte string.
//!
//! # Decode direction (`direction = "decode"`, `form[convert]=2`)
//!
//! This direction's real behaviour is **not** "split on whitespace, parse
//! each token" (that is `decimaldecode`/`octaldecode`'s model, and it is
//! wrong for this tool even though it happens to agree with this tool on
//! well-formed, exactly-3-digit-padded, single-space-separated input like the
//! corpus's). The site's actual algorithm, confirmed by probing malformed and
//! adversarial inputs directly:
//!
//! 1. **Strip every byte that is not an ASCII digit `0`-`9`** from the whole
//!    input -- spaces, newlines, letters, `-`, `.` all vanish, wherever they
//!    occur. (`"abc072"` decodes to the single byte `H` (`0x48`), not two
//!    bytes with a `\0` standing in for `"abc"` -- the letters are removed
//!    before any chunk is ever formed, they do not parse as `0`.)
//! 2. **Re-chunk the surviving digit string into runs of up to 3 characters,
//!    left to right** -- irrespective of where the original separators were.
//!    (`"72 105 33"`, i.e. the *unpadded* tokens `ascii_base_gctb` itself
//!    emits, decodes to `\xd1\x35\x03`, not `"Hi!"`: stripped to `"7210533"`
//!    (7 digits), chunked as `"721"`, `"053"`, `"3"` -> `721 % 256 = 209`,
//!    `53`, `3`. This is a striking, confirmed divergence from
//!    `decimaldecode`'s token-based model, and it is *only* safe to ignore
//!    when every token in the input is already exactly 3 digits wide with a
//!    single-character separator -- which the corpus's rev6 ciphertext is.)
//! 3. **Parse each chunk as an integer in the target base:**
//!    - decimal: ordinary base-10 parse (every surviving character is
//!      already a valid decimal digit after step 1, so there is nothing more
//!      to filter);
//!    - octal: **PHP `octdec()` semantics, not "stop at the first invalid
//!      digit"**. `8` and `9` are removed from *within* the chunk (wherever
//!      they occur, not just trailing) before the remainder is parsed as
//!      octal; an all-`8`/`9` chunk parses to `0`. Confirmed directly:
//!      `"189"` (all one octal-decode call) -> `octdec` sees chunk `"189"`,
//!      drops the `8` and `9`, parses `"1"` -> `1` (`chr(1)`, **not**
//!      `chr(1)` from "stop at 8" coincidentally agreeing here, see the
//!      next two which disambiguate). `"180"` -> drop `8` -> `"10"` ->
//!      `octdec("10") = 8` (`0x08`), and `"190"` -> drop `9` -> `"10"` -> `8`
//!      (`0x08`) again -- both agree with each other and disagree with a
//!      "stop at first invalid digit" model, which would have given `1` for
//!      both (only the leading `1` survives before the invalid digit). This
//!      distinguishes "ignore invalid digits wherever they are" (right) from
//!      "truncate at the first invalid digit" (wrong) unambiguously.
//!      `"170"` (all valid octal digits) parses normally: `0o170 = 120 =
//!      0x78`. The filtering is **per 3-character chunk, after chunking**,
//!      not applied to the whole digit string before chunking:
//!      `"8180"` (4 raw digits) chunks as `"818"`, `"0"` *first*, then each
//!      chunk is filtered/parsed independently -> `chr(1), chr(0)`
//!      (`01 00`), not the single `chr(8)` a whole-string-first filter
//!      (`"8180"` -> drop 8s -> `"10"` -> `octdec("10")=8`) would produce.
//! 4. **Value mod 256 -> one output byte**, matching PHP `chr()`'s wraparound
//!    for out-of-range integers (`"300"` decimal -> `300 % 256 = 44` ->
//!    `,`; `"777"` octal -> `0o777 = 511 % 256 = 255` -> `0xff`).
//! 5. **An empty (post-strip) digit string decodes to empty output** --
//!    confirmed for both the empty string and a string with no digits at all
//!    (e.g. `"abc"` alone strips to nothing and decodes to 0 bytes).
//!
//! Every numbered claim above has a corresponding test in this module keyed
//! to the literal `curl` probe that established it.
//!
//! # Cross-check against `decimaldecode` on rev6 (mandatory per spec)
//!
//! rev6's own ciphertext (`data/revelations.json`, id `rev6`) is well-formed
//! for this tool's fast path: every token is exactly 3 digits, single-space
//! (and single-newline, at the corpus's own line wraps) separated, so the
//! "strip-then-rechunk" algorithm above produces byte-identical output to
//! `decimaldecode`'s naive "split on whitespace, parse each token" for this
//! specific input. `unit_conversion_tests::rev6_cross_check_against_decimaldecode`
//! proves this directly against the corpus record rather than asserting it.
//! It is not a coincidence that would hold for arbitrary input (see point 2
//! above), only for input this well-formed -- which is exactly what this
//! codec is for.

use crate::classical::toolfmt::{read_output_fmt, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Base {
    Decimal,
    Octal,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Direction {
    Encode,
    Decode,
}

impl Direction {
    fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "encode" => Direction::Encode,
            "decode" => Direction::Decode,
            _ => return None,
        })
    }
}

/// Encode: one 3-digit, zero-padded token per byte, single-space-joined.
/// Empty input -> empty output. See module doc, "Encode direction".
fn encode(base: Base, bytes: &[u8]) -> Vec<u8> {
    let mut out = String::new();
    for (i, &b) in bytes.iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        match base {
            Base::Decimal => out.push_str(&format!("{b:03}")),
            Base::Octal => out.push_str(&format!("{b:03o}")),
        }
    }
    out.into_bytes()
}

/// Decode: strip to digits, rechunk into runs of <=3, parse per-chunk, mod
/// 256 -> byte. See module doc, "Decode direction", for why this is *not*
/// "split on whitespace and parse each token".
fn decode(base: Base, text: &str) -> Vec<u8> {
    let digits: Vec<u8> = text.bytes().filter(u8::is_ascii_digit).collect();
    digits
        .chunks(3)
        .map(|chunk| {
            let value: u32 = match base {
                Base::Decimal => chunk.iter().fold(0u32, |acc, &d| acc * 10 + (d - b'0') as u32),
                Base::Octal => chunk
                    .iter()
                    .copied()
                    .filter(|&d| d != b'8' && d != b'9') // octdec()-style: ignore, don't truncate
                    .fold(0u32, |acc, d| acc * 8 + (d - b'0') as u32),
            };
            (value % 256) as u8
        })
        .collect()
}

const SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(ParamSpec::opt(
    "direction",
    ParamType::Str,
    "encode|decode: encode is text -> zero-padded fixed-width tokens (the site's default, \
     form[convert]=1); decode is tokens -> text (form[convert]=2)",
));

fn apply(base: Base, name: &'static str, input: &Repr, params: &Params) -> Result<Repr> {
    let direction = match params.opt_str("direction") {
        Some(s) => Direction::parse(s).ok_or_else(|| {
            Error::bad_param(name, "direction", format!("expected encode|decode, got {s:?}"))
        })?,
        None => Direction::Encode,
    };

    let out_bytes = match direction {
        Direction::Encode => encode(base, &input.data),
        Direction::Decode => {
            let text = String::from_utf8_lossy(&input.data).into_owned();
            decode(base, &text)
        }
    };

    let fmt = read_output_fmt(
        name,
        params,
        OutputFmt {
            case: crate::classical::toolfmt::CaseFold::Preserve,
            grouping: None,
            // Confirmed from main.js: `$("#output").val(response)`, a
            // `.value =`-style write, not `.innerHTML` -- no copy artifact.
            trailing: Trailing::None,
        },
    )?;
    Ok(Repr::new(fmt.apply(&out_bytes), Display::Bytes))
}

pub struct UnitConversionAscii;

impl Node for UnitConversionAscii {
    fn name(&self) -> &'static str {
        "unit_conversion_ascii"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/unit_conversion(unit-conversion.info/texttools/ascii, \
         live HTTP probe 2026-07-31)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }
    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        apply(Base::Decimal, "unit_conversion_ascii", input, params)
    }
}

pub struct UnitConversionOctal;

impl Node for UnitConversionOctal {
    fn name(&self) -> &'static str {
        "unit_conversion_octal"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/unit_conversion(unit-conversion.info/texttools/octal, \
         live HTTP probe 2026-07-31)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }
    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        apply(Base::Octal, "unit_conversion_octal", input, params)
    }
}

register_node!(UNIT_CONVERSION_ASCII => || Box::new(UnitConversionAscii));
register_node!(UNIT_CONVERSION_OCTAL => || Box::new(UnitConversionOctal));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn ascii() -> &'static dyn Node {
        registry().get("unit_conversion_ascii").unwrap()
    }
    fn octal() -> &'static dyn Node {
        registry().get("unit_conversion_octal").unwrap()
    }

    fn run(n: &dyn Node, direction: &str, data: &[u8]) -> Vec<u8> {
        n.apply(&Repr::bytes(data.to_vec()), &params! {"direction" => direction})
            .unwrap()
            .data
    }

    // -- Ground truth: `curl -F "form[text]=Hi!" -F "form[convert]=1" \
    //    "https://www.unit-conversion.info/texttools/ascii/?ajax=1"` -> "072 105 033" --
    #[test]
    fn ascii_encode_ground_truth() {
        assert_eq!(run(ascii(), "encode", b"Hi!"), b"072 105 033");
        assert_eq!(
            run(ascii(), "encode", b"Hello, World! 123"),
            b"072 101 108 108 111 044 032 087 111 114 108 100 033 032 049 050 051"
        );
    }

    #[test]
    fn ascii_encode_empty_is_empty() {
        assert_eq!(run(ascii(), "encode", b""), b"");
    }

    /// Confirmed by POSTing a raw byte 0xFF: emits "255", not "377" (that's octal's job).
    #[test]
    fn ascii_encode_high_byte() {
        assert_eq!(run(ascii(), "encode", &[0xffu8]), b"255");
        assert_eq!(run(ascii(), "encode", &[0u8]), b"000");
    }

    /// `café` in UTF-8 is `63 61 66 c3 a9`; the site encodes each raw byte
    /// independently, confirming it operates on bytes, not code points.
    #[test]
    fn ascii_encode_operates_on_raw_utf8_bytes() {
        assert_eq!(run(ascii(), "encode", "café".as_bytes()), b"099 097 102 195 169");
    }

    /// No line wrap at any length: probed live up to 2000 bytes; this test
    /// pins the same property at a smaller, fast-to-run size.
    #[test]
    fn ascii_encode_no_line_wrap() {
        let input = vec![b'A'; 300];
        let out = run(ascii(), "encode", &input);
        assert!(!out.contains(&b'\n'));
        assert!(!out.contains(&b'\r'));
        assert_eq!(out.len(), 300 * 3 + 299);
    }

    // -- Decode: naive whitespace-split agrees with the real algorithm only
    //    on well-formed, exactly-3-digit tokens --
    #[test]
    fn ascii_decode_well_formed_tokens() {
        assert_eq!(run(ascii(), "decode", b"072 105 033"), b"Hi!");
        assert_eq!(run(ascii(), "decode", b"072105033"), b"Hi!"); // no separator needed at all
    }

    /// The striking divergence from `decimaldecode`: *unpadded* tokens (which
    /// `decimaldecode` parses token-by-token as 72, 105, 33) get re-chunked
    /// by raw digit position instead: "7210533" -> "721","053","3".
    /// Ground truth: curl probe against unpadded "72 105 33".
    #[test]
    fn ascii_decode_unpadded_tokens_rechunk_by_digit_position_not_by_token() {
        assert_eq!(run(ascii(), "decode", b"72 105 33"), &[0xd1, 0x35, 0x03]);
    }

    /// Non-digit characters vanish before chunking, they are never treated as
    /// a zero digit or as a chunk boundary. Ground truth: curl probe.
    #[test]
    fn ascii_decode_strips_non_digits_before_chunking() {
        assert_eq!(run(ascii(), "decode", b"abc072"), b"H");
        assert_eq!(run(ascii(), "decode", b"-72"), b"H");
        assert_eq!(run(ascii(), "decode", b"1a2"), &[0x0c]); // digits-only "12" -> 12
    }

    /// Out-of-range chunk values wrap mod 256, matching PHP `chr()`. Ground truth: curl probe.
    #[test]
    fn ascii_decode_wraps_mod_256() {
        assert_eq!(run(ascii(), "decode", b"300 072"), b",H");
    }

    #[test]
    fn ascii_decode_no_digits_at_all_is_empty() {
        assert_eq!(run(ascii(), "decode", b""), b"");
        assert_eq!(run(ascii(), "decode", b"abc"), b"");
        assert_eq!(run(ascii(), "decode", b"   "), b"");
    }

    #[test]
    fn ascii_round_trip() {
        let input = b"Hello, World! 123";
        assert_eq!(run(ascii(), "decode", &run(ascii(), "encode", input)), input);
    }

    // -- Octal --

    /// Ground truth: `curl` "Hi!" -> "110 151 041"; "110 151 041" -> "Hi!".
    #[test]
    fn octal_encode_and_decode_ground_truth() {
        assert_eq!(run(octal(), "encode", b"Hi!"), b"110 151 041");
        assert_eq!(run(octal(), "decode", b"110 151 041"), b"Hi!");
        assert_eq!(run(octal(), "decode", b"110151041"), b"Hi!");
    }

    #[test]
    fn octal_encode_high_byte_is_377() {
        assert_eq!(run(octal(), "encode", &[0xffu8]), b"377");
    }

    /// The `octdec()` finding: `8`/`9` are ignored wherever they occur in a
    /// chunk, they do not truncate the parse. `"180"`/`"190"` both drop the
    /// invalid digit and parse the remaining two as octal ("10" -> 8), which
    /// disambiguates this from a "stop at first invalid digit" model (which
    /// would give 1 for both instead of 8). Ground truth: curl probes.
    #[test]
    fn octal_decode_ignores_invalid_digits_within_a_chunk_rather_than_truncating() {
        assert_eq!(run(octal(), "decode", b"189"), &[0x01]); // drop 8,9 -> "1" -> 1
        assert_eq!(run(octal(), "decode", b"180"), &[0x08]); // drop 8 -> "10" -> 8
        assert_eq!(run(octal(), "decode", b"190"), &[0x08]); // drop 9 -> "10" -> 8
        assert_eq!(run(octal(), "decode", b"170"), &[0x78]); // all valid: 0o170 = 120
        assert_eq!(run(octal(), "decode", b"800"), &[0x00]); // drop 8 -> "00" -> 0
        assert_eq!(run(octal(), "decode", b"888"), &[0x00]);
        assert_eq!(run(octal(), "decode", b"819"), &[0x01]); // drop 8,9 -> "1" -> 1
    }

    /// Filtering happens *after* chunking into runs of 3, not on the whole
    /// digit string first: "8180" chunks as "818","0" *before* either chunk
    /// is filtered, giving two bytes (1, 0), not the single byte 8 a
    /// whole-string-first filter ("8180" -> "10" -> 8) would produce.
    /// Ground truth: curl probe, the decisive disambiguator.
    #[test]
    fn octal_decode_filters_per_chunk_after_chunking_not_on_the_whole_string_first() {
        assert_eq!(run(octal(), "decode", b"8180"), &[0x01, 0x00]);
    }

    #[test]
    fn octal_decode_wraps_mod_256() {
        assert_eq!(run(octal(), "decode", b"777"), &[0xff]); // 0o777 = 511, 511 % 256 = 255
    }

    #[test]
    fn octal_decode_no_valid_digits_is_empty_byte_string() {
        assert_eq!(run(octal(), "decode", b""), b"");
    }

    #[test]
    fn octal_round_trip() {
        let input = b"Hello, World! 123";
        assert_eq!(run(octal(), "decode", &run(octal(), "encode", input)), input);
    }

    // -- Trailing / artifact defaults --

    /// Confirmed from `main.js`'s `$("#output").val(response)`: a `.value =`
    /// write, so unlike `ascii_base_gctb` (an `.innerHTML` tool) this default
    /// is `Trailing::None`, not `CrLf` -- and it is read off the site's own
    /// JS, not inferred.
    #[test]
    fn default_trailing_is_none_per_val_not_innerhtml() {
        let out = ascii()
            .apply(&Repr::bytes(b"Hi!".to_vec()), &params! {"direction" => "encode"})
            .unwrap();
        assert_eq!(out.data, b"072 105 033");
        assert!(!out.data.ends_with(b"\n"));
        assert!(!out.data.ends_with(b"\r\n"));
    }

    #[test]
    fn malformed_direction_is_rejected() {
        let err = ascii()
            .apply(&Repr::bytes(b"hi".to_vec()), &params! {"direction" => "sideways"})
            .unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn is_xf_family_and_not_layer_forming() {
        for n in [ascii(), octal()] {
            assert_eq!(n.family(), Family::Xf);
            assert!(!n.layer_forming());
            assert!(!n.terminal());
        }
    }

    // -- Mandatory rev6 cross-check against the pre-existing `decimaldecode` codec --

    /// rev6's ciphertext (`data/revelations.json`, id `rev6`) is well-formed
    /// for this tool's fast path (every token exactly 3 digits, single-space
    /// or single-newline separated), so decoding it with
    /// `unit_conversion_ascii` must produce byte-identical output to
    /// `decimaldecode` (registered in `crate::nodes`). If it did not, that
    /// would mean rev6's own ciphertext is *not* actually well-formed in the
    /// way the corpus record claims -- a real finding, not something to
    /// paper over. It matches.
    #[test]
    fn rev6_cross_check_against_decimaldecode() {
        let data_dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../data/revelations.json");
        let raw = std::fs::read_to_string(&data_dir)
            .unwrap_or_else(|e| panic!("reading {}: {e}", data_dir.display()));
        let v: serde_json::Value = serde_json::from_str(&raw).unwrap();
        let rec = v
            .as_array()
            .unwrap()
            .iter()
            .find(|r| r["id"].as_str() == Some("rev6"))
            .expect("rev6 present in data/revelations.json");
        let ciphertext = rec["ciphertext"].as_str().unwrap();

        let via_unit_conversion = decode(Base::Decimal, ciphertext);

        let via_decimaldecode = crate::repr::decode_radix(ciphertext.as_bytes(), 10)
            .expect("decimaldecode's own parser accepts rev6's ciphertext");

        assert_eq!(
            via_unit_conversion, via_decimaldecode,
            "unit_conversion_ascii and decimaldecode must agree on rev6's well-formed \
             3-digit-padded ciphertext"
        );
        // Sanity: this must actually have decoded to something, not silently
        // agreed on an empty vector.
        assert!(!via_unit_conversion.is_empty());
    }
}
