use std::fmt;

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

use crate::error::Result;
use crate::params::Params;
use crate::repr::Repr;

/// Node families. The family determines the coverage semantics of the step.
#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Family {
    /// Representation-preserving transform (reverse, rot, tolower).
    Xf,
    /// Encode/decode between displays.
    Codec,
    /// Keyed decryption. Always layer-forming.
    Dec,
    /// Automated classical solver. **Terminal**, and its coverage is *heuristic*.
    ///
    /// An exhaustive sweep returning nothing proves its region is empty. A solver
    /// returning nothing proves only that its heuristic missed within budget.
    /// Heuristic claims must never subtract from the exhaustive residual, or the
    /// residual comes to include ground that was never actually cleared.
    Solver,
}

impl Family {
    pub fn as_str(self) -> &'static str {
        match self {
            Family::Xf => "xf",
            Family::Codec => "codec",
            Family::Dec => "dec",
            Family::Solver => "solver",
        }
    }
}

impl fmt::Display for Family {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ParamType {
    Str,
    Int,
    Bool,
    /// Hex-encoded bytes.
    Hex,
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize)]
pub struct ParamSpec {
    pub name: &'static str,
    pub ty: ParamType,
    pub required: bool,
    pub doc: &'static str,
}

impl ParamSpec {
    pub const fn req(name: &'static str, ty: ParamType, doc: &'static str) -> Self {
        Self {
            name,
            ty,
            required: true,
            doc,
        }
    }
    pub const fn opt(name: &'static str, ty: ParamType, doc: &'static str) -> Self {
        Self {
            name,
            ty,
            required: false,
            doc,
        }
    }
}

/// A fully qualified, content-addressed step identity.
#[derive(Clone, PartialEq, Eq, Debug, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub struct NodeId {
    pub family: Family,
    pub name: String,
    pub version: String,
    /// First 12 hex chars of the implementation hash.
    pub hash12: String,
}

impl fmt::Display for NodeId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "{}:{}@{}#{}",
            self.family, self.name, self.version, self.hash12
        )
    }
}

/// One versioned step.
///
/// Implementors are the plugin surface of the engine. A plugin crate implements
/// this trait and registers a constructor with
/// [`register_node!`](crate::register_node); the set of nodes is fixed at link
/// time but resolved by name at runtime.
pub trait Node: Send + Sync + 'static {
    fn name(&self) -> &'static str;
    fn version(&self) -> &'static str;
    fn family(&self) -> Family;

    /// Digest of the *source or build artifact*, folded into the implementation
    /// hash. Two independent implementations of the same logical primitive must
    /// return different values here, otherwise N-version cross-checking
    /// degenerates into a tautology.
    fn source_digest(&self) -> &'static str {
        ""
    }

    fn params_schema(&self) -> &'static [ParamSpec] {
        &[]
    }

    /// Declared block size under these parameters, when the node is a block
    /// cipher. Consumed by the block-aware oracle to skip the deterministically
    /// corrupt CFB-8 prefix.
    fn block_size(&self, _params: &Params) -> Option<usize> {
        None
    }

    /// Whether this step can constitute a layer boundary.
    fn layer_forming(&self) -> bool {
        matches!(self.family(), Family::Dec | Family::Solver)
    }

    /// Terminal nodes emit plaintext, so nothing may follow them.
    fn terminal(&self) -> bool {
        matches!(self.family(), Family::Solver)
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr>;

    fn impl_hash(&self) -> String {
        let mut h = Sha256::new();
        h.update(self.family().as_str().as_bytes());
        h.update(b"|");
        h.update(self.name().as_bytes());
        h.update(b"|");
        h.update(self.version().as_bytes());
        h.update(b"|");
        h.update(self.source_digest().as_bytes());
        hex::encode(h.finalize())
    }

    fn node_id(&self) -> NodeId {
        let h = self.impl_hash();
        NodeId {
            family: self.family(),
            name: self.name().to_string(),
            version: self.version().to_string(),
            hash12: h[..12].to_string(),
        }
    }
}
