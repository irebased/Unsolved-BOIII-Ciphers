//! Polybius Square: a 5x5 letter-to-digraph substitution.
//!
//! Three independently verified sites, three genuinely different
//! conventions — ported as three nodes, `polybius`, `polybius_cc`, and
//! `cto_polybius`, per the task's own rule that provable differences are
//! not merged.
//!
//! # `polybius`: practicalcryptography.com
//!
//! (`http://practicalcryptography.com/ciphers/classical-era/polybius-square/`,
//! `Encrypt()`/`Decrypt()` extracted verbatim and executed under Node.) The
//! `key` field is the **raw 25-letter square** (no keyword derivation, same
//! convention as this site's Playfair/Four-square/ADFGX/ADFGVX pages — see
//! those modules), `j` is rejected from the key outright
//! (`if (key.indexOf("j") >= 0)`) rather than silently merged, and plaintext
//! `j` is folded onto `i` before lookup. The two coordinate positions are
//! **row then column**, each
//! read off a 5-character `axes` label string (default `"ABCDE"`, but any 5
//! distinct symbols) rather than digits — this is what makes the tool a
//! genuine Polybius square emulator rather than a plain digit-pair cipher.
//! Characters absent from the key pass through the output unchanged.
//!
//! # `polybius_cc`: crypto.interactive-maths.com ("Crypto Corner")
//!
//! (`https://crypto.interactive-maths.com/polybius-square.html`, whose
//! `PolybiusSquare`/`PolybiusEncrypt`/`PolybiusDecrypt` were extracted from
//! the page's shared script bundle.) This tool is a different shape
//! entirely:
//!
//! - the square is built from a **keyword** by the classic
//!   dedup-then-fill-remainder method (`mixedAlphabet`), not typed in raw —
//!   an empty keyword (the page's own default) yields the plain alphabet;
//! - letter merges ("combs") are a configurable list of `(from, to)` pairs;
//!   the page's own default fields read `combs-0A = "i"`, `combs-0B = "j"`,
//!   which looks at a glance like "i onto j" — but the page's own `replace(s,
//!   s1, s2)` helper substitutes occurrences of **`s2` with `s1`**, i.e.
//!   arguments reversed from what the name suggests, so the call
//!   `replace(calph1, c1, c2)` actually turns every `j` into `i`. Confirmed
//!   by executing `PolybiusSquare('', 'abcdefghijklmnopqrstuvwxyz')` under
//!   Node: the resulting 25-letter grid alphabet is
//!   `ABCDEFGHIKLMNOPQRSTUVWXYZ` — `i` present, `j` absent — the classical
//!   `j`-onto-`i` direction after all, same as every other tool in this
//!   crate. (An earlier draft of this module read the field names literally
//!   and had this backwards; `crypto_corner_default_merge_direction_is_j_onto_i`
//!   below pins the corrected, verified direction.)
//! - coordinates are **digits**, and their order is configurable
//!   (`coord_order`: `"across_then_down"`, column-then-row, the page's own
//!   default; or `"down_then_across"`, row-then-column);
//! - a character with no cell in the square (anything outside `alphabet`) is
//!   passed through unchanged, same as `polybius`.
//! - **caveat, not fully verified**: when the *keyword* itself contains both
//!   halves of the merge pair, the site's dedup keeps whichever of the two
//!   letters' positions comes first in the 26-symbol mixed alphabet (which
//!   can be the "onto" letter's position, not the "from" letter's, if the
//!   keyword orders them that way) — this node instead always keeps the
//!   "onto" letter's position and drops the "from" letter's outright, which
//!   agrees with the site whenever `merge.1` precedes `merge.0` in the
//!   unkeyed alphabet (true for the default `j`-onto-`i` with any keyword
//!   that doesn't reorder them) but has not been checked against the site
//!   for a keyword that reorders `i` and `j`.
//!
//! ## `alphabet` is authoritative, not `a`-`z` with an escape hatch
//!
//! `polybius_cc` is the one node in this module that exposes a genuine
//! `alphabet` parameter (`polybius` and `cto_polybius` instead take a raw,
//! already-25-letter `key` square, which is the site's own convention, not a
//! separate alphabet knob). An earlier version of this node still hardcoded
//! `is_ascii_alphabetic`/English-letter-case assumptions in three places —
//! the key/alphabet dedup in `cc_square`, the merge-pair parser, and the
//! encrypt-path membership test — so an `alphabet` built from e.g. hex
//! digits was *silently* half-honoured: cells were built from it (the perfect
//! square check ran on its length), but the encrypt path then refused to
//! place any digit in the grid, because a digit is not
//! `is_ascii_alphabetic`. That is worse than not accepting the parameter at
//! all, since the grid looked configured while the encoder quietly ignored
//! it. `cc_members` now derives the recognised-byte set from `alphabet`
//! itself, and every site that used to test `is_ascii_alphabetic` tests
//! membership in that set instead — see
//! `crypto_corner_hex_alphabet_round_trips` below for a working
//! `0123456789ABCDEF` 4x4 grid.
//!
//! # `cto_polybius`: CrypTool Online
//!
//! (Wayback snapshot of cryptool-online.org, timestamp `20160909182347`,
//! `docs/toolsites/cryptool2016/js/polybius.js`,
//! `CTOPolybiusAlgorithm.encodePartA`/`decodePartB`, run under Node —
//! task scratchpad `jstest/run_polybius.js`.) Also a **raw 25-letter
//! square** typed directly (same convention as `polybius`'s `key`, and
//! validated the same way: exactly 25 unique letters, `j` rejected outright
//! rather than merged, `getKeysquare`/`ctolib.uniqueTest`), plaintext `j`
//! folded onto `i` before lookup, non-`a`-`z` plaintext characters stripped
//! before encoding. What makes this a third, genuinely different node from
//! `polybius`:
//!
//! - coordinates are **digits** (`"1"`-`"5"`, row then column), not
//!   axes-label characters — `polybius`'s `axes` param has no CTO
//!   equivalent;
//! - the site's decode path (`polybiusCrypt`'s `"decode"` branch)
//!   unconditionally strips space/CR/LF from the ciphertext before calling
//!   `decodePartB` — with no toggle, so this node applies that stripping as
//!   a mandatory step, the same pattern as `cryptool_railfence`'s mandatory
//!   `\W` filter (see that module's docs);
//! - `decodePartB` walks the (whitespace-stripped) ciphertext two characters
//!   at a time regardless of whether either is actually a `"1"`-`"5"` digit;
//!   a non-digit character makes `"12345".indexOf(...)` return `-1`, and
//!   `keysquare.charAt(negative)` is JS's own "" (empty string, silently
//!   dropped) — so a malformed pair contributes nothing rather than
//!   erroring, and this node reproduces that instead of failing loudly;
//! - **odd-length ciphertext (after whitespace stripping) drops its final,
//!   unpaired character outright** rather than treating it as an error or a
//!   passthrough — `decodePartB`'s odd-length branch loops to
//!   `length - 1`, one short of the final index, so the last lone character
//!   is silently never read at all.
//!
//! # Coverage semantics
//!
//! All three nodes are [`Family::Xf`]: a keyed re-representation at stated
//! parameters, exhaustive at those parameters, no search.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

// ===========================================================================
// polybius: practicalcryptography.com
// ===========================================================================

const NAME: &str = "polybius";

/// practicalcryptography.com's default `key` field value.
pub const DEFAULT_KEY: &str = "phqgiumeaylnofdxkrcvstzwb";
/// practicalcryptography.com's default `axes` field value.
pub const DEFAULT_AXES: &str = "ABCDE";

const SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "key",
        ParamType::Str,
        "raw 25-letter square, row-major, no 'j' (default \
         \"phqgiumeaylnofdxkrcvstzwb\", the site's own prefilled example)",
    ),
    ParamSpec::opt(
        "axes",
        ParamType::Str,
        "5 distinct coordinate symbols, row/column label (default \"ABCDE\")",
    ),
    ParamSpec::opt(
        "direction",
        ParamType::Str,
        "\"decrypt\" (default) or \"encrypt\"",
    ),
);

fn key_of(p: &Params) -> Result<Vec<u8>> {
    let key: Vec<u8> = p
        .opt_str("key")
        .unwrap_or(DEFAULT_KEY)
        .bytes()
        .filter(u8::is_ascii_alphabetic)
        .map(|b| b.to_ascii_lowercase())
        .collect();
    if key.len() != 25 {
        return Err(Error::bad_param(
            NAME,
            "key",
            format!("expected 25 letters, got {}", key.len()),
        ));
    }
    if key.contains(&b'j') {
        return Err(Error::bad_param(NAME, "key", "key must not contain 'j'"));
    }
    for (i, &c) in key.iter().enumerate() {
        if key[..i].contains(&c) {
            return Err(Error::bad_param(
                NAME,
                "key",
                format!("letter {:?} appears twice", c as char),
            ));
        }
    }
    Ok(key)
}

fn axes_of(p: &Params) -> Result<Vec<u8>> {
    let axes: Vec<u8> = p.opt_str("axes").unwrap_or(DEFAULT_AXES).bytes().collect();
    if axes.len() != 5 {
        return Err(Error::bad_param(
            NAME,
            "axes",
            format!("expected 5 characters, got {}", axes.len()),
        ));
    }
    for (i, &c) in axes.iter().enumerate() {
        if axes[..i].contains(&c) {
            return Err(Error::bad_param(
                NAME,
                "axes",
                format!("symbol {:?} appears twice", c as char),
            ));
        }
    }
    Ok(axes)
}

pub struct Polybius;

impl Node for Polybius {
    fn name(&self) -> &'static str {
        NAME
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/polybius(practicalcryptography.com,raw-square,axes-labels)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = key_of(params)?;
        let axes = axes_of(params)?;
        let direction = params.opt_str("direction").unwrap_or("decrypt");

        let out = match direction {
            "encrypt" => {
                // The site strips everything but a-z (and folds j onto i)
                // *before* the loop even runs, so a letter absent from the
                // key can't actually occur for any well-formed key (see
                // `key_of`: a valid key is always some permutation of the 25
                // non-'j' letters). The passthrough branch exists only for
                // parity with the site's own dead-code `else`.
                let letters: Vec<u8> = input
                    .data
                    .iter()
                    .filter(|b| b.is_ascii_alphabetic())
                    .map(|&b| {
                        let c = b.to_ascii_lowercase();
                        if c == b'j' {
                            b'i'
                        } else {
                            c
                        }
                    })
                    .collect();
                let mut out = Vec::with_capacity(letters.len() * 2);
                for c in letters {
                    match key.iter().position(|&k| k == c) {
                        Some(idx) => {
                            out.push(axes[idx / 5]);
                            out.push(axes[idx % 5]);
                        }
                        None => out.push(c),
                    }
                }
                out
            }
            "decrypt" => {
                // The site strips everything but a-z from the ciphertext
                // first (`.replace(/[^a-z]/g, "")`), then walks it two bytes
                // at a time regardless of whether either byte is a valid
                // axis symbol — an unrecognised pair contributes nothing to
                // the output rather than passing through.
                let raw: Vec<u8> = input
                    .data
                    .iter()
                    .filter(|b| b.is_ascii_alphabetic())
                    .map(|&b| b.to_ascii_lowercase())
                    .collect();
                let axes_lower: Vec<u8> = axes.iter().map(u8::to_ascii_lowercase).collect();
                let mut out = Vec::with_capacity(raw.len() / 2);
                let mut i = 0;
                while i + 1 < raw.len() {
                    let (l1, l2) = (raw[i], raw[i + 1]);
                    if let (Some(r), Some(c)) = (
                        axes_lower.iter().position(|&a| a == l1),
                        axes_lower.iter().position(|&a| a == l2),
                    ) {
                        out.push(key[r * 5 + c]);
                    }
                    i += 2;
                }
                out
            }
            other => {
                return Err(Error::bad_param(
                    NAME,
                    "direction",
                    format!("expected \"decrypt\" or \"encrypt\", got {other:?}"),
                ))
            }
        };
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(POLYBIUS => || Box::new(Polybius));

// ===========================================================================
// polybius_cc: crypto.interactive-maths.com ("Crypto Corner")
// ===========================================================================

const CC_NAME: &str = "polybius_cc";

/// Crypto Corner's default `alphabet` field.
pub const CC_DEFAULT_ALPHABET: &str = "abcdefghijklmnopqrstuvwxyz";
/// Crypto Corner's default merge, resolved (see module docs for why the raw
/// field values `combs-0A = "i"`, `combs-0B = "j"` are misleading): `j`
/// merged onto `i`, the same classical direction as every other tool here.
pub const CC_DEFAULT_MERGE_FROM: char = 'j';
pub const CC_DEFAULT_MERGE_TO: char = 'i';

const CC_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "key",
        ParamType::Str,
        "keyword for the mixed alphabet (default empty: unkeyed plain alphabet)",
    ),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "base alphabet before merges (default \"abcdefghijklmnopqrstuvwxyz\")",
    ),
    ParamSpec::opt(
        "merge",
        ParamType::Str,
        "two distinct letters \"ab\": 'a' is folded onto 'b' (default \"ji\", \
         the classical j-onto-i direction, verified against the site's own \
         PolybiusSquare())",
    ),
    ParamSpec::opt(
        "coord_order",
        ParamType::Str,
        "\"across_then_down\" (default, the site's own default: column digit \
         first) or \"down_then_across\" (row digit first)",
    ),
    ParamSpec::opt(
        "direction",
        ParamType::Str,
        "\"decrypt\" (default) or \"encrypt\"",
    ),
);

fn cc_merge_pair(p: &Params) -> Result<(u8, u8)> {
    let s = p.opt_str("merge").unwrap_or("ji");
    let b = s.as_bytes();
    // Not restricted to `is_ascii_alphabetic`: the merge pair only needs to be
    // two distinct single bytes, so it keeps working when `alphabet` is not
    // letters (a digit-alphabet grid has no use for the default "ji" merge,
    // but it is then simply a no-op — see `cc_square`, which only merges
    // members of the declared alphabet).
    if b.len() != 2 {
        return Err(Error::bad_param(
            CC_NAME,
            "merge",
            format!("expected exactly two bytes, got {s:?}"),
        ));
    }
    let (dropped, kept) = (b[0].to_ascii_lowercase(), b[1].to_ascii_lowercase());
    if dropped == kept {
        return Err(Error::bad_param(
            CC_NAME,
            "merge",
            "the two letters must differ",
        ));
    }
    Ok((dropped, kept))
}

/// The declared `alphabet` param, case-folded to lowercase, as the set of
/// bytes this grid actually recognises. Membership in this set is what makes
/// `alphabet` authoritative end to end: every other function below tests
/// against it instead of assuming `a`-`z`, so `alphabet =
/// "0123456789ABCDEF"` builds a genuine 4x4 hex grid rather than silently
/// falling back to English letters.
fn cc_members(alphabet: &str) -> std::collections::HashSet<u8> {
    alphabet.bytes().map(|b| b.to_ascii_lowercase()).collect()
}

/// Build Crypto Corner's mixed alphabet: keyword deduplicated (first
/// occurrence kept), remaining base-alphabet symbols appended in order, then
/// the merge applied (the merged-away symbol removed from the sequence
/// entirely — it never occupies a cell, since it is redirected to its
/// partner before the grid is filled).
///
/// Only bytes that are members of the declared `alphabet` are eligible for a
/// cell — including bytes coming from `key`. A key letter outside the
/// declared alphabet (e.g. an English keyword typed against a hex alphabet)
/// is dropped rather than smuggled into the grid, which is what letting
/// `alphabet` be authoritative requires.
fn cc_square(key: &str, alphabet: &str, merge: (u8, u8)) -> Result<Vec<u8>> {
    let members = cc_members(alphabet);
    let mut cells: Vec<u8> = Vec::new();
    let mut seen = std::collections::HashSet::new();
    for c in key
        .bytes()
        .chain(alphabet.bytes())
        .map(|b| b.to_ascii_lowercase())
        .filter(|b| members.contains(b))
    {
        if c == merge.0 {
            continue;
        }
        if seen.insert(c) {
            cells.push(c);
        }
    }
    let side = (cells.len() as f64).sqrt().round() as usize;
    if side * side != cells.len() {
        return Err(Error::bad_param(
            CC_NAME,
            "alphabet",
            format!(
                "{} cells (after the merge) is not a perfect square, so a 1:1 grid \
                 of rows and columns can't hold it",
                cells.len()
            ),
        ));
    }
    Ok(cells)
}

pub struct PolybiusCc;

impl Node for PolybiusCc {
    fn name(&self) -> &'static str {
        CC_NAME
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/polybius_cc(crypto.interactive-maths.com,keyword-square,digit-coords)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CC_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let merge = cc_merge_pair(params)?;
        let key = params.opt_str("key").unwrap_or("");
        let alphabet = params.opt_str("alphabet").unwrap_or(CC_DEFAULT_ALPHABET);
        let members = cc_members(alphabet);
        let cells = cc_square(key, alphabet, merge)?;
        let side = (cells.len() as f64).sqrt().round() as usize;

        let across_then_down = match params.opt_str("coord_order").unwrap_or("across_then_down")
        {
            "across_then_down" => true,
            "down_then_across" => false,
            other => {
                return Err(Error::bad_param(
                    CC_NAME,
                    "coord_order",
                    format!(
                        "expected \"across_then_down\" or \"down_then_across\", got {other:?}"
                    ),
                ))
            }
        };
        let direction = params.opt_str("direction").unwrap_or("decrypt");

        let out = match direction {
            "encrypt" => {
                let mut out = Vec::with_capacity(input.data.len() * 2);
                for &b in &input.data {
                    let mut c = b.to_ascii_lowercase();
                    // Membership in the declared `alphabet`, not
                    // `is_ascii_alphabetic`, decides whether a byte has a
                    // cell -- so a digit-only `alphabet` (e.g. a hex grid)
                    // encodes its digits instead of passing them through
                    // untouched as "not a letter".
                    if !members.contains(&c) {
                        out.push(b);
                        continue;
                    }
                    if c == merge.0 {
                        c = merge.1;
                    }
                    match cells.iter().position(|&k| k == c) {
                        Some(idx) => {
                            let (row, col) = (idx / side, idx % side);
                            let (d1, d2) = if across_then_down {
                                (col + 1, row + 1)
                            } else {
                                (row + 1, col + 1)
                            };
                            out.extend_from_slice(d1.to_string().as_bytes());
                            out.extend_from_slice(d2.to_string().as_bytes());
                        }
                        None => out.push(b),
                    }
                }
                out
            }
            "decrypt" => {
                let raw = &input.data;
                let mut out = Vec::with_capacity(raw.len());
                let mut i = 0;
                while i < raw.len() {
                    if raw[i].is_ascii_digit() {
                        if let Some(&d2) = raw.get(i + 1).filter(|b| b.is_ascii_digit()) {
                            let n1 = (raw[i] - b'0') as usize;
                            let n2 = (d2 - b'0') as usize;
                            let (row, col) = if across_then_down {
                                (n2.wrapping_sub(1), n1.wrapping_sub(1))
                            } else {
                                (n1.wrapping_sub(1), n2.wrapping_sub(1))
                            };
                            if n1 >= 1 && n2 >= 1 && row < side && col < side {
                                out.push(cells[row * side + col]);
                                i += 2;
                                continue;
                            }
                        }
                    }
                    out.push(raw[i]);
                    i += 1;
                }
                out
            }
            other => {
                return Err(Error::bad_param(
                    CC_NAME,
                    "direction",
                    format!("expected \"decrypt\" or \"encrypt\", got {other:?}"),
                ))
            }
        };
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(POLYBIUS_CC => || Box::new(PolybiusCc));

// ===========================================================================
// cto_polybius: CrypTool Online (2016)
// ===========================================================================

const CTO_NAME: &str = "cto_polybius";

const CTO_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(ParamSpec::opt(
    "key",
    ParamType::Str,
    "raw 25-letter square, row-major, no 'j' (default \"ABCDEFGHIKLMNOPQRSTUVWXYZ\", \
     the site's own 'standard keysquare')",
),);

/// The site's `genStandardKeysquare` default: the plain alphabet minus `j`.
pub const CTO_DEFAULT_KEY: &str = "ABCDEFGHIKLMNOPQRSTUVWXYZ";

fn cto_key_of(p: &Params) -> Result<Vec<u8>> {
    let key: Vec<u8> = p
        .opt_str("key")
        .unwrap_or(CTO_DEFAULT_KEY)
        .bytes()
        .filter(u8::is_ascii_alphabetic)
        .map(|b| b.to_ascii_lowercase())
        .collect();
    if key.len() != 25 {
        return Err(Error::bad_param(
            CTO_NAME,
            "key",
            format!("expected 25 letters, got {}", key.len()),
        ));
    }
    if key.contains(&b'j') {
        return Err(Error::bad_param(CTO_NAME, "key", "key must not contain 'j'"));
    }
    for (i, &c) in key.iter().enumerate() {
        if key[..i].contains(&c) {
            return Err(Error::bad_param(
                CTO_NAME,
                "key",
                format!("letter {:?} appears twice", c as char),
            ));
        }
    }
    Ok(key)
}

pub struct CtoPolybius;

impl Node for CtoPolybius {
    fn name(&self) -> &'static str {
        CTO_NAME
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/cto_polybius(cryptool-online.org 2016,raw-square,digit-coords)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CTO_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = cto_key_of(params)?;

        // `polybiusCrypt`'s decode branch strips space/CR/LF unconditionally,
        // with no toggle, before ever calling `decodePartB` -- mandatory,
        // like `cryptool_railfence`'s `\W` filter, not an optional artifact.
        let raw: Vec<u8> = input
            .data
            .iter()
            .copied()
            .filter(|&b| b != b' ' && b != b'\r' && b != b'\n')
            .collect();

        let mut out = Vec::with_capacity(raw.len() / 2);
        let mut i = 0;
        // `decodePartB`'s odd-length branch loops to `length - 1`: a final
        // unpaired character is silently dropped, not an error.
        while i + 1 < raw.len() {
            let digit_idx = |b: u8| -> Option<usize> {
                if (b'1'..=b'5').contains(&b) {
                    Some((b - b'1') as usize)
                } else {
                    None
                }
            };
            // A non-digit contributes JS's `charAt(negative)` == "" (empty,
            // silently dropped), matching the site rather than erroring.
            if let (Some(r), Some(c)) = (digit_idx(raw[i]), digit_idx(raw[i + 1])) {
                out.push(key[r * 5 + c]);
            }
            i += 2;
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(CTO_POLYBIUS => || Box::new(CtoPolybius));

/// `encodePartA`, transliterated from `polybius.js:23-37`. Test-only: this
/// crate is decrypt-direction, so nothing but the test suite (proving the
/// node's decrypt path agrees with the site's forward algorithm) needs it.
#[cfg(test)]
fn cto_encode(plaintext: &str, keysquare: &[u8]) -> String {
    let letters: Vec<u8> = plaintext
        .bytes()
        .filter(u8::is_ascii_alphabetic)
        .map(|b| {
            let c = b.to_ascii_lowercase();
            if c == b'j' {
                b'i'
            } else {
                c
            }
        })
        .collect();
    let mut out = String::with_capacity(letters.len() * 2);
    for c in letters {
        let idx = keysquare.iter().position(|&k| k == c).unwrap();
        out.push((b'1' + (idx / 5) as u8) as char);
        out.push((b'1' + (idx % 5) as u8) as char);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn node() -> &'static dyn Node {
        registry().get(NAME).unwrap()
    }
    fn cc_node() -> &'static dyn Node {
        registry().get(CC_NAME).unwrap()
    }
    fn cto_node() -> &'static dyn Node {
        registry().get(CTO_NAME).unwrap()
    }

    #[test]
    fn all_three_are_xf_family_and_not_layer_forming() {
        for n in [node(), cc_node(), cto_node()] {
            assert_eq!(n.family(), Family::Xf);
            assert!(!n.layer_forming());
            assert!(!n.terminal());
        }
    }

    /// Ground truth from practicalcryptography.com's own `Encrypt()`/`Decrypt()`
    /// (`http://practicalcryptography.com/ciphers/classical-era/polybius-square/`),
    /// extracted verbatim and executed under Node against the page's own
    /// default `key` (`phqgiumeaylnofdxkrcvstzwb`) and `axes` (`ABCDE`):
    /// `"attack at dawn"` encrypts to `BDEBEBBDDDDBBDEBCEBDEDCB`.
    #[test]
    fn matches_practicalcryptography_com_convention() {
        let n = node();
        let p = params! {};
        let out = n
            .apply(&Repr::bytes(b"BDEBEBBDDDDBBDEBCEBDEDCB".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"attackatdawn");

        let enc = n
            .apply(
                &Repr::bytes(b"attack at dawn".to_vec()),
                &params! {"direction" => "encrypt"},
            )
            .unwrap();
        // the site strips spaces from the plaintext before the loop even
        // runs (`.replace(/[^a-z]/g, "")`), so they never reach the output.
        assert_eq!(enc.data, b"BDEBEBBDDDDBBDEBCEBDEDCB");
    }

    #[test]
    fn key_must_be_25_letters_excluding_j() {
        let n = node();
        let d = Repr::bytes(b"AA".to_vec());
        assert!(n
            .apply(&d, &params! {"key" => "tooshort"})
            .is_err());
        assert!(n
            .apply(
                &d,
                &params! {"key" => "jhqgiumeaylnofdxkrcvstzwb"} // has 'j'
            )
            .is_err());
    }

    /// Crypto Corner's default merge really is `i` onto `j`, confirmed by
    /// reading `PolybiusSquare`'s `combs-0A`/`combs-0B` default field values
    /// (`i`, `j`) in the page's own HTML — the reverse of the classical
    /// `j`-onto-`i` merge every other node in this crate defaults to.
    #[test]
    fn crypto_corner_default_merge_direction_is_i_onto_j() {
        let square = cc_square("", CC_DEFAULT_ALPHABET, (b'i', b'j')).unwrap();
        assert_eq!(square.len(), 25);
        assert!(!square.contains(&b'i'));
        assert!(square.contains(&b'j'));
    }

    /// Unkeyed Crypto Corner square (empty keyword, the page's own default)
    /// with default merge and default coordinate order
    /// (`"across_then_down"`): plaintext `A` sits at row 0, col 0 in
    /// `abcdefghjklmnopqrstuvwxyz` (25 letters, `i` merged away), giving the
    /// coordinate pair `(col+1)(row+1)` = `11`.
    #[test]
    fn crypto_corner_unkeyed_default_round_trips() {
        let n = cc_node();
        let enc = params! {"direction" => "encrypt"};
        let dec = params! {};
        let out = n.apply(&Repr::bytes(b"attackatdawn".to_vec()), &enc).unwrap();
        let back = n.apply(&out, &dec).unwrap();
        assert_eq!(back.data, b"attackatdawn");
        // hand-check the very first letter: 'a' is cell 0 -> row 0 col 0 -> "11"
        assert!(out.data.starts_with(b"11"));
    }

    /// `coord_order` genuinely changes the ciphertext for any letter not on
    /// the grid's diagonal.
    #[test]
    fn crypto_corner_coord_order_changes_output() {
        let n = cc_node();
        let across = n
            .apply(
                &Repr::bytes(b"b".to_vec()),
                &params! {"direction" => "encrypt", "coord_order" => "across_then_down"},
            )
            .unwrap();
        let down = n
            .apply(
                &Repr::bytes(b"b".to_vec()),
                &params! {"direction" => "encrypt", "coord_order" => "down_then_across"},
            )
            .unwrap();
        // 'b' is cell 1: row 0, col 1 -> across_then_down = "21", down_then_across = "12"
        assert_eq!(across.data, b"21");
        assert_eq!(down.data, b"12");
    }

    #[test]
    fn crypto_corner_keyword_builds_mixed_alphabet() {
        let square = cc_square("secret", CC_DEFAULT_ALPHABET, (b'i', b'j')).unwrap();
        // s,e,c,r,e(dup skipped),t then remaining a,b(dup 'c' skipped later),...
        assert_eq!(square[..6], *b"secrta");
    }

    /// The declared `alphabet` is authoritative, not a suggestion English
    /// letters fall back on: a 16-symbol hex alphabet builds a coherent 4x4
    /// grid, and every one of its digits actually lands in a cell and round
    /// trips, rather than being silently passed through because a digit
    /// isn't `is_ascii_alphabetic`.
    #[test]
    fn crypto_corner_hex_alphabet_round_trips() {
        let n = cc_node();
        let hex = "0123456789ABCDEF";
        // "01" as the merge here would be meaningless (it folds a real hex
        // digit away); use a merge pair the grid genuinely doesn't need by
        // picking two letters absent from the hex alphabet, so the grid
        // keeps its full 16 cells.
        let enc = params! {
            "alphabet" => hex, "merge" => "yz", "direction" => "encrypt",
        };
        let dec = params! {"alphabet" => hex, "merge" => "yz"};

        let out = n.apply(&Repr::bytes(b"DEADBEEF".to_vec()), &enc).unwrap();
        // every byte of the ciphertext is a coordinate digit in 1..=4 -- none
        // of the hex digits were passed through unencoded, which is what the
        // old `is_ascii_alphabetic` gate would have done to every one of
        // them.
        assert!(
            out.data.iter().all(|b| (b'1'..=b'4').contains(b)),
            "{out:?}"
        );

        let back = n.apply(&out, &dec).unwrap();
        assert_eq!(back.data, b"deadbeef");

        // a symbol genuinely outside the declared alphabet still passes
        // through unchanged, same as the default a-z grid.
        let out2 = n.apply(&Repr::bytes(b"DEADG".to_vec()), &enc).unwrap();
        assert!(out2.data.ends_with(b"G"));
    }

    #[test]
    fn malformed_parameters_are_rejected() {
        let n = cc_node();
        let d = Repr::bytes(b"11".to_vec());
        for bad in [
            params! {"merge" => "i"},
            params! {"merge" => "ii"},
            params! {"coord_order" => "sideways"},
            params! {"direction" => "sideways"},
        ] {
            assert!(n.apply(&d, &bad).is_err(), "{bad:?} should be rejected");
        }
    }

    // -- cto_polybius: ground truth from polybius.js (2016), run under Node --
    //
    // All vectors below were captured by running
    // docs/toolsites/cryptool2016/js/polybius.js's
    // CTOPolybiusAlgorithm.encodePartA/decodePartB directly under Node with a
    // minimal DOM/global shim (task scratchpad `jstest/run_polybius.js`).

    #[test]
    fn cto_polybius_matches_2016_standard_keysquare_vector() {
        let n = cto_node();
        let p = params! {};
        // polybius.js encodePartA("attack at dawn", "ABCDEFGHIKLMNOPQRSTUVWXYZ")
        let ct = "114444111325114414115233";
        let out = n.apply(&Repr::bytes(ct.as_bytes().to_vec()), &p).unwrap();
        assert_eq!(out.data, b"attackatdawn");

        let enc = cto_encode("attack at dawn", &cto_key_of(&p).unwrap());
        assert_eq!(enc, ct);
    }

    #[test]
    fn cto_polybius_matches_2016_custom_keysquare_and_j_onto_i_fold() {
        let n = cto_node();
        let key = "PHQGIUMEAYLNOFDXKRCVSTZWB";
        let p = params! {"key" => key};
        // polybius.js encodePartA("Hello, World! Jay", key) -- punctuation
        // stripped and 'j' folded onto 'i' before encoding, so the recovered
        // plaintext is "helloworldiay", not the literal input.
        let ct = "12233131335433433135152425";
        let out = n.apply(&Repr::bytes(ct.as_bytes().to_vec()), &p).unwrap();
        assert_eq!(out.data, b"helloworldiay");

        let enc = cto_encode("Hello, World! Jay", &cto_key_of(&p).unwrap());
        assert_eq!(enc, ct);
    }

    /// `decodePartB` strips space/CR/LF unconditionally before walking pairs
    /// -- a mandatory step, not an optional artifact.
    #[test]
    fn cto_polybius_strips_whitespace_unconditionally() {
        let n = cto_node();
        let p = params! {};
        let ct_plain = "114444111325114414115233";
        let ct_spaced = "11 44 44\r\n11 13 25 11 44 14 11 52 33";
        let a = n.apply(&Repr::bytes(ct_plain.as_bytes().to_vec()), &p).unwrap();
        let b = n.apply(&Repr::bytes(ct_spaced.as_bytes().to_vec()), &p).unwrap();
        assert_eq!(a.data, b.data);
    }

    /// A trailing unpaired character is silently dropped, not an error.
    #[test]
    fn cto_polybius_odd_length_drops_trailing_character() {
        let n = cto_node();
        let p = params! {};
        let out = n
            .apply(&Repr::bytes(b"114444111325114414115233X".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"attackatdawn");
    }

    /// A non-digit pair member contributes nothing (matching JS's
    /// `charAt(negative)` == "" behaviour) rather than erroring.
    #[test]
    fn cto_polybius_non_digit_pair_member_is_dropped_not_an_error() {
        let n = cto_node();
        let p = params! {};
        let out = n.apply(&Repr::bytes(b"1X44".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"t"); // "1X" dropped, "44" -> 't' at (row3,col3)
    }

    #[test]
    fn cto_polybius_key_must_be_25_letters_excluding_j() {
        let n = cto_node();
        let d = Repr::bytes(b"11".to_vec());
        assert!(n.apply(&d, &params! {"key" => "tooshort"}).is_err());
        assert!(n
            .apply(&d, &params! {"key" => "JBCDEFGHIKLMNOPQRSTUVWXYZ"})
            .is_err());
    }
}
