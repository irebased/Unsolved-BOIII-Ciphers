def fmt(n):
    for u,d in [("e18",1e18),("e15",1e15),("e12",1e12),("e9",1e9),("e6",1e6),("e3",1e3)]:
        if n>=d: return f"{n/d:,.1f}{u}"
    return f"{n:,.0f}"
from math import factorial

# Base costs
TG4_T1  = 16*6*2*399          # transcription x key x keyderiv x (prim*mode*iv)
REV7_T1 = 1*3*2*399
TG4_T13 = 305.7e6             # through two modern layers
REV7_T13= 9.6e6

MONTH_2M  = 2_000_000*2_592_000      # 5.18e12
WEEK_2M   = 2_000_000*604_800
MONTH_GPU = 100_000_000*2_592_000    # 2.59e14

UNKNOWNS = [
 ("ROT shifts on outer layer", 26),
 ("Affine (a,b) pairs", 312),
 ("4-row route/read permutations", 24),
 ("Columnar keys <= len 7", sum(factorial(i) for i in range(2,8))),
 ("Columnar keys <= len 8", sum(factorial(i) for i in range(2,9))),
 ("Columnar keys <= len 9", sum(factorial(i) for i in range(2,10))),
 ("10k keyword dict (keyed alphabets)", 10_000),
 ("100k keyword dict", 100_000),
 ("Columnar keys <= len 10", sum(factorial(i) for i in range(2,11))),
 ("Columnar keys <= len 12", sum(factorial(i) for i in range(2,13))),
 ("Free 26-letter substitution", factorial(26)),
]

print("="*88)
print("REACHABILITY: unknown dimension X, combined with a given base, 1 month @ 2M/s")
print("="*88)
for basename, base in [("TG4 + single modern layer", TG4_T1),
                       ("TG4 + two modern layers", TG4_T13),
                       ("REV7 + single modern layer", REV7_T1),
                       ("REV7 + two modern layers", REV7_T13)]:
    cap = MONTH_2M/base
    print(f"\n{basename}   (base={fmt(base)}, headroom = x{cap:,.0f})")
    print("-"*88)
    for name,sz in UNKNOWNS:
        ok = "OK" if sz<=cap else "no"
        print(f"   [{ok}] {name:<42}{fmt(sz):>18}")

print("\n" + "="*88)
print("KEY ASYMMETRY")
print("="*88)
print(f"TG4 base cost is {TG4_T1/REV7_T1:.0f}x REV7's, driven entirely by:")
print(f"   - 16 transcription variants (REV7 has 1, hex is unambiguous)")
print(f"   - 6 key candidates vs 3 (TheGiant ambiguity)")
print(f"=> Resolving the TG4 transcription to a single variant cuts its space 16x")
print(f"=> Resolving the TheGiant key question cuts it a further ~2-6x")
print(f"   Combined, TG4 forensics is worth up to ~{16*2:.0f}-{16*6:.0f}x, i.e. more than")
print(f"   an order of magnitude more compute, for zero compute spend.")
