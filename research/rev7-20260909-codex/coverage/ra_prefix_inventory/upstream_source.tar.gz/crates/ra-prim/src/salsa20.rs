//! Salsa20, Bernstein's stream cipher: 20 rounds, a 64-byte keystream block,
//! a 32-byte key and an 8-byte nonce.
//!
//! # Why this primitive exists here
//!
//! `https://www.unit-conversion.info/texttools/salsa/` offers "a Salsa10 or
//! Salsa20 output" as one of its tools (see
//! `docs/layering-pattern-analysis.md` §8sexies). Salsa20 is **not** in
//! libmcrypt's own menu, so it has never been part of any sweep in this
//! repository — every negative result recorded elsewhere says nothing about
//! it. It is a genuinely new, length-preserving, keyed layer-1 candidate for
//! both unsolved ciphers.
//!
//! # Conformance status: UNPROVEN
//!
//! No corpus cipher is known to use Salsa20, so — exactly like AES
//! (`rijndael-128`), 3DES (`tripledes`), CAST-128 and IDEA before it — this
//! primitive carries **zero** gated coverage even though it is a real,
//! tested implementation. It is validated here only against the published
//! Salsa20 test vectors (below), never against a corpus decrypt.
//!
//! # Scope: the 32-byte-key variant only
//!
//! The original Salsa20 specification also defines a 16-byte-key variant
//! (`k0 = k1 = key`, using the "expand 16-byte k" constants in place of
//! "expand 32-byte k"). The RustCrypto `salsa20` crate's `Salsa20` type only
//! exposes the 32-byte-key ("expand 32-byte k") constant set — its `Key`
//! alias is hard-coded to 32 bytes — so the 16-byte-key variant is not
//! reachable through this crate and is **not implemented** here. This is a
//! deliberate, documented gap, not an oversight: [`PrimInfo::supported_key_sizes`]
//! for `salsa20` is `&[32]` only.
//!
//! # Nonce handling
//!
//! Salsa20 needs an 8-byte nonce, distinct from a block cipher's IV. This
//! primitive is reached through the same `dec` node machinery as every block
//! cipher, which already carries an `iv` parameter (default: 16 ASCII `'0'`
//! bytes, [`crate::nodes::CORPUS_IV`]) — there being no other place in the
//! parameter schema for cipher-specific keyed state. [`Salsa20Prim::new`]
//! therefore fits whatever `iv` bytes it is given to exactly 8 bytes,
//! truncating a longer value or null-padding a shorter one (the same
//! truncate-or-pad convention [`crate::mode::decrypt`]/[`crate::mode::encrypt`]
//! use for a block cipher's IV), rather than inventing a second `nonce`
//! parameter that would need its own default and its own sweep axis.
//!
//! # Ground truth
//!
//! The published Salsa20 test vectors (Bernstein's reference vectors, as
//! reproduced and pinned by RustCrypto's own `salsa20` crate test suite,
//! `salsa20/tests/mod.rs` in `RustCrypto/stream-ciphers`): the all-zero-key
//! vectors distinguished only by nonce/high-bit placement, and one
//! `KEY_LONG`/`IV_LONG` vector covering 256 keystream bytes (four internal
//! blocks). See the test module below for the exact vectors and their
//! source.

use salsa20::cipher::{KeyIvInit, StreamCipher};
use salsa20::Salsa20;

use crate::prim::StreamPrim;

pub struct Salsa20Prim {
    key: [u8; 32],
    nonce: [u8; 8],
}

impl Salsa20Prim {
    /// `key` must be exactly 32 bytes (see the module doc's scope note).
    /// `nonce` is fit to exactly 8 bytes: truncated if longer, null-padded if
    /// shorter — the same convention [`crate::mode`] uses for a block
    /// cipher's IV.
    pub fn new(key: &[u8], nonce: &[u8]) -> Option<Self> {
        if key.len() != 32 {
            return None;
        }
        let mut k = [0u8; 32];
        k.copy_from_slice(key);
        let mut n = [0u8; 8];
        let take = nonce.len().min(8);
        n[..take].copy_from_slice(&nonce[..take]);
        Some(Self { key: k, nonce: n })
    }
}

impl StreamPrim for Salsa20Prim {
    /// A fresh cipher instance per call: [`StreamPrim::apply_keystream`] takes
    /// `&self`, not `&mut self` (mirroring [`crate::rc4::Rc4`], which
    /// recomputes its whole key schedule per call for the same reason), so
    /// each call must restart the Salsa20 keystream from position 0 rather
    /// than carrying state across calls.
    fn apply_keystream(&self, data: &mut [u8]) {
        let mut cipher = Salsa20::new(&self.key.into(), &self.nonce.into());
        cipher.apply_keystream(data);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn keystream(key: &[u8], nonce: &[u8], len: usize) -> Vec<u8> {
        let c = Salsa20Prim::new(key, nonce).unwrap();
        let mut buf = vec![0u8; len];
        c.apply_keystream(&mut buf);
        buf
    }

    /// Bernstein's reference vector: key `80 00...00` (32 bytes), nonce all
    /// zero. Pinned in RustCrypto's `salsa20/tests/mod.rs` as
    /// `EXPECTED_KEY1_IV0`.
    #[test]
    fn published_vector_key1_iv0() {
        let mut key = [0u8; 32];
        key[0] = 0x80;
        let want = hex::decode(concat!(
            "e3be8fdd8beca2e3ea8ef9475b29a6e7",
            "003951e1097a5c38d23b7a5fad9f6844",
            "b22c97559e2723c7cbbd3fe4fc8d9a07",
            "44652a83e72a9c461876af4d7ef1a117",
        ))
        .unwrap();
        assert_eq!(keystream(&key, &[0u8; 8], 64), want);
    }

    /// All-zero key, nonce `80 00 00 00 00 00 00 00`. RustCrypto's
    /// `EXPECTED_KEY0_IV1`.
    #[test]
    fn published_vector_key0_iv1() {
        let key = [0u8; 32];
        let nonce = hex::decode("8000000000000000").unwrap();
        let want = hex::decode(concat!(
            "2aba3dc45b4947007b14c851cd694456",
            "b303ad59a465662803006705673d6c3e",
            "29f1d3510dfc0405463c03414e0e07e3",
            "59f1f1816c68b2434a19d3eee0464873",
        ))
        .unwrap();
        assert_eq!(keystream(&key, &nonce, 64), want);
    }

    /// All-zero key, nonce `00...01` (the counter's high bit exercised via the
    /// nonce field). RustCrypto's `EXPECTED_KEY0_IVHI`.
    #[test]
    fn published_vector_key0_ivhi() {
        let key = [0u8; 32];
        let nonce = hex::decode("0000000000000001").unwrap();
        let want = hex::decode(concat!(
            "b47f96aa96786135297a3c4ec56a613d",
            "0b80095324ff43239d684c57ffe42e1c",
            "44f3cc011613db6cdc880999a1e65aed",
            "1287fcb11c839c37120765afa73e5075",
        ))
        .unwrap();
        assert_eq!(keystream(&key, &nonce, 64), want);
    }

    /// A non-trivial key/nonce over four internal 64-byte blocks (256 bytes),
    /// exercising the keystream generator past its first block. RustCrypto's
    /// `EXPECTED_LONG`.
    #[test]
    fn published_vector_long_key_and_nonce_four_blocks() {
        let key = hex::decode(concat!(
            "0102030405060708090A0B0C0D0E0F10",
            "1112131415161718191A1B1C1D1E1F20",
        ))
        .unwrap();
        let nonce = hex::decode("0301040105090206").unwrap();
        let want = hex::decode(concat!(
            "6ebcbdbf76fccc64ab05542bee8a67cb",
            "c28fa2e141fbefbb3a2f9b221909c8d7",
            "d4295258cb539770dd24d7ac3443769f",
            "fa27a50e60644264dc8b6b612683372e",
            "085d0a12bf240b189ce2b78289862b56",
            "fdc9fcffc33bef9325a2e81b98fb3fb9",
            "aa04cf434615ceffeb985c1cb08d8440",
            "e90b1d56ddeaea16d9e15affff1f698c",
            "483c7a466af1fe062574adfd2b06a62b",
            "4d98440719ea776385c470349a7ed696",
            "9583463ed5d26b8fefccb205da0f5bfa",
            "98c77812fe756b09eacc282aa42f4baf",
            "a79633189046e2b20f35b3e0e54aa3b9",
            "29e23c0f47dc7bcd4f928b2a9764be7d",
            "4b8a50f980a50b35ad8087375e0c556e",
            "cbe6a7161e8653ce9391e1e6710ed4f1",
        ))
        .unwrap();
        assert_eq!(keystream(&key, &nonce, 256), want);
    }

    #[test]
    fn is_its_own_inverse() {
        let key = b"0123456789abcdef0123456789abcdef".to_vec();
        let c = Salsa20Prim::new(&key[..32], b"a-nonce8").unwrap();
        let pt = b"the many worlds are now one".to_vec();
        let mut buf = pt.clone();
        c.apply_keystream(&mut buf);
        assert_ne!(buf, pt);
        c.apply_keystream(&mut buf);
        assert_eq!(buf, pt);
    }

    #[test]
    fn rejects_a_key_that_is_not_32_bytes() {
        assert!(Salsa20Prim::new(b"short", &[0u8; 8]).is_none());
        assert!(Salsa20Prim::new(&[0u8; 16], &[0u8; 8]).is_none());
    }

    /// A short or long nonce is fit to 8 bytes rather than rejected, mirroring
    /// how a block cipher's IV is fit in `crate::mode`.
    #[test]
    fn nonce_is_truncated_or_null_padded_to_8_bytes() {
        let key = [0u8; 32];
        let short = keystream(&key, b"ab", 16);
        let mut padded_nonce = [0u8; 8];
        padded_nonce[..2].copy_from_slice(b"ab");
        let explicit = keystream(&key, &padded_nonce, 16);
        assert_eq!(short, explicit, "a short nonce must be null-padded, not rejected");

        let long = keystream(&key, b"abcdefghij", 16); // 10 bytes, truncated to 8
        let truncated = keystream(&key, b"abcdefgh", 16);
        assert_eq!(long, truncated, "a long nonce must be truncated, not rejected");
    }
}
