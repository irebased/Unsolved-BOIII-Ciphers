//! Ragbaby, Condi, Phillips, Albam, Atbah, Key Phrase, Numbered Key, Headlines.
//!
//! # Why these nodes exist
//!
//! All are substitution-family ciphers with key entropy at or below log2(26!) ≈ 88
//! bits, so they are decidable against a 30–41 letter ciphertext. Several are
//! *position-dependent* (Ragbaby, Condi, Phillips) — the same plaintext letter
//! encrypts differently depending on where it sits — which flattens unigram statistics
//! without a long key. That is the property a flat-but-short corpus ciphertext needs
//! explaining, and none of these were previously available to test it with.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: transforms at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const A26: &str = "abcdefghijklmnopqrstuvwxyz";
/// Ragbaby's classical alphabet: 24 letters, `j` and `x` omitted.
const A24: &str = "abcdefghiklmnopqrstuvwyz";

fn keyed(key: &str, alphabet: &str) -> Vec<u8> {
    let members: std::collections::HashSet<u8> = alphabet.bytes().collect();
    let mut out = Vec::new();
    let mut seen = std::collections::HashSet::new();
    for c in key.bytes().chain(alphabet.bytes()) {
        let c = c.to_ascii_lowercase();
        if members.contains(&c) && seen.insert(c) {
            out.push(c);
        }
    }
    out
}

fn letters_in(data: &[u8], members: &std::collections::HashSet<u8>) -> Vec<u8> {
    data.iter()
        .map(|c| c.to_ascii_lowercase())
        .filter(|c| members.contains(c))
        .collect()
}

fn dir(node: &'static str, params: &Params) -> Result<bool> {
    match params.opt_str("direction").unwrap_or("decrypt") {
        "encrypt" => Ok(true),
        "decrypt" => Ok(false),
        o => Err(Error::bad_param(node, "direction", format!("got {o:?}"))),
    }
}

// ---------------------------------------------------------------- Ragbaby

const RAGBABY: &str = "ragbaby";
const RAG_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "keyword for the 24-letter alphabet"),
    ParamSpec::opt(
        "word_lengths",
        ParamType::Str,
        "comma-separated word lengths, e.g. \"3,4,2\". Ragbaby's shift depends on WORD \
         position, so without word divisions the cipher is not defined; the default \
         treats the whole text as one word.",
    ),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Ragbaby: shift = (word number) + (position within the word), over a 24-letter
/// keyed alphabet.
///
/// The word divisions are part of the key material, not decoration: two texts with
/// identical letters but different word breaks encrypt differently. Since a stripped
/// ciphertext has lost them, `word_lengths` makes that dependency explicit rather than
/// silently assuming one word.
pub struct Ragbaby;

impl Node for Ragbaby {
    fn name(&self) -> &'static str { RAGBABY }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/ragbaby(24-letter,word+letter-position)" }
    fn params_schema(&self) -> &'static [ParamSpec] { RAG_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let alpha = keyed(params.req_str(RAGBABY, "key")?, A24);
        let m = alpha.len() as i64;
        let idx: std::collections::HashMap<u8, i64> =
            alpha.iter().enumerate().map(|(i, &c)| (c, i as i64)).collect();
        let members: std::collections::HashSet<u8> = A24.bytes().collect();
        let t = letters_in(&input.data, &members);
        if t.is_empty() {
            return Err(Error::node_failed(RAGBABY, "no letters from the 24-letter alphabet"));
        }
        let lens: Vec<usize> = match params.opt_str("word_lengths") {
            Some(s) => s
                .split(',')
                .filter(|x| !x.trim().is_empty())
                .map(|x| {
                    x.trim().parse::<usize>().map_err(|_| {
                        Error::bad_param(RAGBABY, "word_lengths", format!("{x:?} is not a number"))
                    })
                })
                .collect::<Result<_>>()?,
            None => vec![t.len()],
        };
        let enc = dir(RAGBABY, params)?;
        let mut out = Vec::with_capacity(t.len());
        let mut p = 0usize;
        let mut wi = 0usize;
        while p < t.len() {
            let wlen = if wi < lens.len() { lens[wi] } else { t.len() - p };
            for li in 0..wlen {
                if p >= t.len() { break; }
                let shift = (wi as i64 + 1) + (li as i64 + 1);
                let x = idx[&t[p]];
                let v = if enc { x + shift } else { x - shift };
                out.push(alpha[(v.rem_euclid(m)) as usize]);
                p += 1;
            }
            wi += 1;
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

// ---------------------------------------------------------------- Condi

const CONDI: &str = "condi";
const CONDI_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "keyword for the 26-letter alphabet"),
    ParamSpec::opt("init", ParamType::Int, "initial shift before the first letter (default 1)"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Condi: the shift for each letter is the *previous plaintext letter's* alphabet
/// position, plus one.
///
/// Like [`crate::classical::polyalpha_ext::InterruptedKey`], the key stream depends on
/// the plaintext, so decryption must reconstruct it as it goes. There is no period to
/// find, which is exactly what makes it worth having when period analysis has come up
/// empty.
pub struct Condi;

impl Node for Condi {
    fn name(&self) -> &'static str { CONDI }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/condi(previous-plaintext-shift)" }
    fn params_schema(&self) -> &'static [ParamSpec] { CONDI_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let alpha = keyed(params.req_str(CONDI, "key")?, A26);
        let idx: std::collections::HashMap<u8, i64> =
            alpha.iter().enumerate().map(|(i, &c)| (c, i as i64)).collect();
        let members: std::collections::HashSet<u8> = A26.bytes().collect();
        let t = letters_in(&input.data, &members);
        if t.is_empty() {
            return Err(Error::node_failed(CONDI, "input has no ASCII letters"));
        }
        let enc = dir(CONDI, params)?;
        let mut shift = params.opt_i64("init", 1);
        let mut out = Vec::with_capacity(t.len());
        for &c in t.iter() {
            let x = idx[&c];
            if enc {
                out.push(alpha[((x + shift).rem_euclid(26)) as usize]);
                shift = x + 1;
            } else {
                let p = (x - shift).rem_euclid(26);
                out.push(alpha[p as usize]);
                shift = p + 1;
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

// ---------------------------------------------------------------- Phillips

const PHILLIPS: &str = "phillips";
const PH_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "keyword for the base 5x5 square"),
    ParamSpec::opt("block", ParamType::Int, "letters per square before advancing (default 5)"),
    ParamSpec::opt(
        "rc",
        ParamType::Bool,
        "Phillips-RC: cycle rows AND columns rather than rows only (default false)",
    ),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Phillips: eight squares derived from one base square by cycling its rows, used in
/// turn for successive blocks.
///
/// Square `n` is the base with its rows rotated by `n`. Phillips-RC (`rc = true`)
/// rotates columns as well, giving a different eight. Each block of `block` letters is
/// substituted through one square, so the same plaintext letter maps differently in
/// different blocks — a positional flattening with only ~84 bits of key.
pub struct Phillips;

fn rotate_square(base: &[u8], n: usize, rc: bool) -> Vec<u8> {
    let mut rows: Vec<Vec<u8>> = base.chunks(5).map(|r| r.to_vec()).collect();
    rows.rotate_left(n % 5);
    if rc {
        for r in rows.iter_mut() {
            r.rotate_left(n % 5);
        }
    }
    rows.concat()
}

impl Node for Phillips {
    fn name(&self) -> &'static str { PHILLIPS }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/phillips(8-squares,row|rowcol-cycled)" }
    fn params_schema(&self) -> &'static [ParamSpec] { PH_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        const A25: &str = "abcdefghiklmnopqrstuvwxyz";
        let base = keyed(params.req_str(PHILLIPS, "key")?, A25);
        if base.len() != 25 {
            return Err(Error::bad_param(PHILLIPS, "key", "the square must hold 25 letters"));
        }
        let block = params.opt_i64("block", 5);
        if block < 1 {
            return Err(Error::bad_param(PHILLIPS, "block", "must be at least 1"));
        }
        let rc = params.opt_bool("rc", false);
        let enc = dir(PHILLIPS, params)?;
        let members: std::collections::HashSet<u8> = A25.bytes().collect();
        let t: Vec<u8> = input
            .data
            .iter()
            .map(|c| c.to_ascii_lowercase())
            .map(|c| if c == b'j' { b'i' } else { c })
            .filter(|c| members.contains(c))
            .collect();
        if t.is_empty() {
            return Err(Error::node_failed(PHILLIPS, "no letters from the square"));
        }
        let squares: Vec<Vec<u8>> = (0..8).map(|n| rotate_square(&base, n, rc)).collect();
        let mut out = Vec::with_capacity(t.len());
        for (i, &c) in t.iter().enumerate() {
            let sq = &squares[(i / block as usize) % 8];
            let v = if enc {
                let p = base.iter().position(|&x| x == c).unwrap();
                sq[p]
            } else {
                let p = sq.iter().position(|&x| x == c).ok_or_else(|| {
                    Error::node_failed(PHILLIPS, format!("'{}' not in square", c as char))
                })?;
                base[p]
            };
            out.push(v);
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

// ------------------------------------------------- Albam / Atbah (fixed maps)

const ALBAM: &str = "albam";
const ATBAH: &str = "atbah";
const NO_SCHEMA: &[ParamSpec] = &[];

/// Albam: the Hebrew method that swaps the two halves of the alphabet.
///
/// Over 26 Latin letters this is exactly ROT-13, and it is an involution. It is
/// registered under its own name because a corpus that records "Albam" should be
/// runnable as written rather than silently rewritten to `rot n=13`.
pub struct Albam;

impl Node for Albam {
    fn name(&self) -> &'static str { ALBAM }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/albam(half-alphabet-swap)" }
    fn params_schema(&self) -> &'static [ParamSpec] { NO_SCHEMA }

    fn apply(&self, input: &Repr, _params: &Params) -> Result<Repr> {
        let out: Vec<u8> = input
            .data
            .iter()
            .map(|&c| {
                if c.is_ascii_lowercase() {
                    b'a' + (c - b'a' + 13) % 26
                } else if c.is_ascii_uppercase() {
                    b'A' + (c - b'A' + 13) % 26
                } else {
                    c
                }
            })
            .collect();
        Ok(Repr::new(out, input.display))
    }
}

/// Atbah: the Hebrew method pairing letters whose positions sum to a constant within
/// each half of the alphabet.
///
/// Positions 0..12 pair as `i <-> 12 - i` and 13..25 as `i <-> 38 - i`, so it is an
/// involution over both halves. Unlike Atbash (which reverses the whole alphabet) it
/// keeps each letter inside its own half.
pub struct Atbah;

impl Node for Atbah {
    fn name(&self) -> &'static str { ATBAH }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/atbah(within-half-pairing)" }
    fn params_schema(&self) -> &'static [ParamSpec] { NO_SCHEMA }

    fn apply(&self, input: &Repr, _params: &Params) -> Result<Repr> {
        let map = |i: u8| -> u8 {
            if i < 13 { 12 - i } else { 38 - i }
        };
        let out: Vec<u8> = input
            .data
            .iter()
            .map(|&c| {
                if c.is_ascii_lowercase() {
                    b'a' + map(c - b'a')
                } else if c.is_ascii_uppercase() {
                    b'A' + map(c - b'A')
                } else {
                    c
                }
            })
            .collect();
        Ok(Repr::new(out, input.display))
    }
}

// ------------------------------------------- Key Phrase / Numbered Key / Headlines

const KEYPHRASE: &str = "key_phrase";
const KP_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("phrase", ParamType::Str, "exactly 26 letters: the cipher alphabet, \
                                              read against a,b,c,..."),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Key phrase: a simple substitution whose cipher alphabet is written out as a
/// 26-letter phrase.
///
/// The phrase need not be a permutation — historical key phrases repeat letters,
/// which makes encryption many-to-one and decryption ambiguous. That case is rejected
/// rather than silently resolved, because a node that returns one of several possible
/// plaintexts without saying so is worse than one that refuses.
pub struct KeyPhrase;

impl Node for KeyPhrase {
    fn name(&self) -> &'static str { KEYPHRASE }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/key_phrase(26-letter-cipher-alphabet)" }
    fn params_schema(&self) -> &'static [ParamSpec] { KP_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let phrase: Vec<u8> = params
            .req_str(KEYPHRASE, "phrase")?
            .bytes()
            .filter(|b| b.is_ascii_alphabetic())
            .map(|b| b.to_ascii_lowercase())
            .collect();
        if phrase.len() != 26 {
            return Err(Error::bad_param(
                KEYPHRASE,
                "phrase",
                format!("expected 26 letters, got {}", phrase.len()),
            ));
        }
        let distinct: std::collections::HashSet<u8> = phrase.iter().copied().collect();
        if distinct.len() != 26 {
            return Err(Error::bad_param(
                KEYPHRASE,
                "phrase",
                "the phrase repeats a letter, so the map is not a bijection and \
                 decryption would be ambiguous",
            ));
        }
        let enc = dir(KEYPHRASE, params)?;
        let out: Vec<u8> = input
            .data
            .iter()
            .map(|&c| {
                if c.is_ascii_alphabetic() {
                    let lc = c.to_ascii_lowercase();
                    if enc {
                        phrase[(lc - b'a') as usize]
                    } else {
                        b'a' + phrase.iter().position(|&x| x == lc).unwrap() as u8
                    }
                } else {
                    c
                }
            })
            .collect();
        Ok(Repr::new(out, Display::Bytes))
    }
}

const HEADLINES: &str = "headlines";
const HL_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("shifts", ParamType::Str, "comma-separated Caesar shifts, one per segment"),
    ParamSpec::req("lengths", ParamType::Str, "comma-separated segment lengths"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Headlines: a different Caesar shift applied to each segment of the text.
///
/// The classical puzzle applies one shift per headline; here the segmentation is
/// explicit, because a stripped ciphertext no longer carries it. Segment lengths and
/// shifts must have the same count — mismatches are an error, not a silent recycle.
pub struct Headlines;

impl Node for Headlines {
    fn name(&self) -> &'static str { HEADLINES }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/headlines(per-segment-caesar)" }
    fn params_schema(&self) -> &'static [ParamSpec] { HL_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let parse = |s: &str, what: &'static str| -> Result<Vec<i64>> {
            s.split(',')
                .filter(|x| !x.trim().is_empty())
                .map(|x| {
                    x.trim().parse::<i64>().map_err(|_| {
                        Error::bad_param(HEADLINES, what, format!("{x:?} is not a number"))
                    })
                })
                .collect()
        };
        let shifts = parse(params.req_str(HEADLINES, "shifts")?, "shifts")?;
        let lengths = parse(params.req_str(HEADLINES, "lengths")?, "lengths")?;
        if shifts.is_empty() || shifts.len() != lengths.len() {
            return Err(Error::bad_param(
                HEADLINES,
                "lengths",
                format!(
                    "need one shift per segment: got {} shifts and {} lengths",
                    shifts.len(),
                    lengths.len()
                ),
            ));
        }
        let enc = dir(HEADLINES, params)?;
        let t: Vec<u8> = input
            .data
            .iter()
            .filter(|c| c.is_ascii_alphabetic())
            .map(|c| c.to_ascii_lowercase())
            .collect();
        let mut out = Vec::with_capacity(t.len());
        let mut p = 0usize;
        for (seg, &len) in lengths.iter().enumerate() {
            for _ in 0..len {
                if p >= t.len() { break; }
                let s = shifts[seg];
                let x = (t[p] - b'a') as i64;
                let v = if enc { x + s } else { x - s };
                out.push(b'a' + (v.rem_euclid(26)) as u8);
                p += 1;
            }
        }
        while p < t.len() {
            out.push(t[p]);
            p += 1;
        }
        if out.is_empty() {
            return Err(Error::node_failed(HEADLINES, "input has no ASCII letters"));
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(RAGBABY_NODE => || Box::new(Ragbaby));
register_node!(CONDI_NODE => || Box::new(Condi));
register_node!(PHILLIPS_NODE => || Box::new(Phillips));
register_node!(ALBAM_NODE => || Box::new(Albam));
register_node!(ATBAH_NODE => || Box::new(Atbah));
register_node!(KEY_PHRASE => || Box::new(KeyPhrase));
register_node!(HEADLINES_NODE => || Box::new(Headlines));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn n(name: &str) -> &'static dyn Node { registry().get(name).unwrap() }

    #[test]
    fn all_are_xf() {
        for name in [RAGBABY, CONDI, PHILLIPS, ALBAM, ATBAH, KEYPHRASE, HEADLINES] {
            assert_eq!(n(name).family(), Family::Xf);
        }
    }

    #[test]
    fn ragbaby_round_trips_and_word_breaks_matter() {
        let node = n(RAGBABY);
        let p = params! {"key" => "NINE", "word_lengths" => "3,4,5"};
        let enc = node
            .apply(&Repr::bytes(b"theeagerbeaver".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(node.apply(&enc, &p).unwrap().data, b"theeagerbeaver");

        let other = node
            .apply(
                &Repr::bytes(b"theeagerbeaver".to_vec()),
                &params! {"key" => "NINE", "word_lengths" => "5,4,3", "direction" => "encrypt"},
            )
            .unwrap();
        assert_ne!(enc.data, other.data, "word divisions are key material");
    }

    #[test]
    fn condi_round_trips() {
        let node = n(CONDI);
        let p = params! {"key" => "NINE"};
        let enc = node
            .apply(&Repr::bytes(b"defendtheeastwall".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(node.apply(&enc, &p).unwrap().data, b"defendtheeastwall");
    }

    #[test]
    fn phillips_round_trips_in_both_variants() {
        let node = n(PHILLIPS);
        for rc in [false, true] {
            let p = params! {"key" => "ZOMBIES", "rc" => rc};
            let enc = node
                .apply(&Repr::bytes(b"defendtheeastwall".to_vec()), &p.clone().set("direction", "encrypt"))
                .unwrap();
            assert_eq!(node.apply(&enc, &p).unwrap().data, b"defendtheeastwall", "rc={rc}");
        }
    }

    /// Phillips must actually change square between blocks, otherwise it is just a
    /// Polybius substitution wearing a different name.
    #[test]
    fn phillips_advances_between_blocks() {
        let node = n(PHILLIPS);
        let out = node
            .apply(
                &Repr::bytes(b"aaaaaaaaaa".to_vec()),
                &params! {"key" => "ZOMBIES", "block" => 5i64, "direction" => "encrypt"},
            )
            .unwrap();
        assert_ne!(out.data[0], out.data[5], "block 2 must use a different square");
    }

    #[test]
    fn albam_is_rot13_and_atbah_stays_within_halves() {
        let a = n(ALBAM)
            .apply(&Repr::bytes(b"abcnop".to_vec()), &Params::new())
            .unwrap();
        assert_eq!(a.data, b"nopabc");
        // involution
        let back = n(ALBAM).apply(&a, &Params::new()).unwrap();
        assert_eq!(back.data, b"abcnop");

        let t = n(ATBAH)
            .apply(&Repr::bytes(b"an".to_vec()), &Params::new())
            .unwrap();
        // 'a'(0) -> 12 = 'm' (still first half); 'n'(13) -> 25 = 'z' (still second half)
        assert_eq!(t.data, b"mz");
        let back = n(ATBAH).apply(&t, &Params::new()).unwrap();
        assert_eq!(back.data, b"an");
    }

    #[test]
    fn key_phrase_round_trips_and_rejects_a_repeating_phrase() {
        let node = n(KEYPHRASE);
        let p = params! {"phrase" => "zyxwvutsrqponmlkjihgfedcba"};
        let enc = node
            .apply(&Repr::bytes(b"attack".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(enc.data, b"zggzxp");
        assert_eq!(node.apply(&enc, &p).unwrap().data, b"attack");

        assert!(node
            .apply(
                &Repr::bytes(b"attack".to_vec()),
                &params! {"phrase" => "aaaaaaaaaaaaaaaaaaaaaaaaaa"}
            )
            .is_err());
    }

    #[test]
    fn headlines_applies_a_shift_per_segment() {
        let node = n(HEADLINES);
        let p = params! {"shifts" => "1,2", "lengths" => "3,3"};
        let enc = node
            .apply(&Repr::bytes(b"aaaaaa".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(enc.data, b"bbbccc");
        assert_eq!(node.apply(&enc, &p).unwrap().data, b"aaaaaa");

        assert!(node
            .apply(&Repr::bytes(b"aaa".to_vec()), &params! {"shifts" => "1,2", "lengths" => "3"})
            .is_err());
    }
}
