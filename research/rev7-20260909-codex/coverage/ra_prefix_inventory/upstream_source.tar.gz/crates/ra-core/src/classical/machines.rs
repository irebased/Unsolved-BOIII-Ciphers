//! Jefferson disk (M-94), Bazeries, Chaocipher and running key.
//!
//! # Why these nodes exist
//!
//! Three of these are *stateful* — the alphabet in force changes as the message
//! progresses — which is a mechanism no other node here had. Chaocipher in particular
//! permutes both its alphabets after every letter, so it has no period at all, and a
//! corpus ciphertext that resists every period analysis is exactly the case it exists
//! to test.
//!
//! # Decidability, stated up front
//!
//! * **Jefferson/M-94** with *known* disc alphabets: the key is the disc ordering,
//!   log2(25!) ≈ 84 bits — decidable against 30+ letters.
//! * **Chaocipher**: two independent starting alphabets, 2 × log2(26!) ≈ 177 bits —
//!   **undecidable** below ~55 letters. It is here for completeness and for encrypting
//!   known material, not because ciphertext-only recovery is feasible at corpus length.
//! * **Running key** with an English key text: the key carries ~1.5 bits/letter, so
//!   both streams being English is what makes it attackable at all.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: transforms at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const A26: &str = "abcdefghijklmnopqrstuvwxyz";

fn letters(data: &[u8]) -> Vec<u8> {
    data.iter()
        .filter(|c| c.is_ascii_alphabetic())
        .map(|c| c.to_ascii_lowercase())
        .collect()
}

fn keyed(key: &str) -> Vec<u8> {
    let mut out = Vec::new();
    let mut seen = std::collections::HashSet::new();
    for c in key.bytes().chain(A26.bytes()) {
        let c = c.to_ascii_lowercase();
        if c.is_ascii_lowercase() && seen.insert(c) {
            out.push(c);
        }
    }
    out
}

// ---------------------------------------------------------------- Jefferson

const JEFFERSON: &str = "jefferson";
const JEFF_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req(
        "discs",
        ParamType::Str,
        "semicolon-separated 26-letter disc alphabets, e.g. \"abc...;xyz...\"",
    ),
    ParamSpec::opt(
        "order",
        ParamType::Str,
        "comma-separated disc indices giving the assembly order (default: as listed)",
    ),
    ParamSpec::req(
        "offset",
        ParamType::Int,
        "how many rows below the plaintext row to read the ciphertext from (1..25)",
    ),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Jefferson disk / M-94: a stack of alphabet discs, aligned to spell the plaintext,
/// read off some other row.
///
/// Each disc handles one letter of a block, so the message is processed in chunks of
/// `discs.len()`. Decryption is the same operation with the offset negated — the
/// device has no separate mode, and neither does this node beyond that sign.
pub struct Jefferson;

impl Node for Jefferson {
    fn name(&self) -> &'static str { JEFFERSON }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/jefferson(m94-disc-stack)" }
    fn params_schema(&self) -> &'static [ParamSpec] { JEFF_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let discs: Vec<Vec<u8>> = params
            .req_str(JEFFERSON, "discs")?
            .split(';')
            .filter(|s| !s.trim().is_empty())
            .map(|s| {
                s.bytes()
                    .filter(|b| b.is_ascii_alphabetic())
                    .map(|b| b.to_ascii_lowercase())
                    .collect::<Vec<u8>>()
            })
            .collect();
        if discs.is_empty() {
            return Err(Error::bad_param(JEFFERSON, "discs", "no discs given"));
        }
        for (i, d) in discs.iter().enumerate() {
            if d.len() != 26 {
                return Err(Error::bad_param(
                    JEFFERSON,
                    "discs",
                    format!("disc {i} has {} letters, expected 26", d.len()),
                ));
            }
        }
        let order: Vec<usize> = match params.opt_str("order") {
            Some(s) => s
                .split(',')
                .filter(|x| !x.trim().is_empty())
                .map(|x| {
                    x.trim().parse::<usize>().map_err(|_| {
                        Error::bad_param(JEFFERSON, "order", format!("{x:?} is not an index"))
                    })
                })
                .collect::<Result<_>>()?,
            None => (0..discs.len()).collect(),
        };
        if order.iter().any(|&i| i >= discs.len()) {
            return Err(Error::bad_param(JEFFERSON, "order", "index out of range"));
        }
        let offset = params.req_i64(JEFFERSON, "offset")?;
        if !(1..=25).contains(&offset) {
            return Err(Error::bad_param(JEFFERSON, "offset", "must be 1..=25"));
        }
        let enc = match params.opt_str("direction").unwrap_or("decrypt") {
            "encrypt" => true,
            "decrypt" => false,
            o => return Err(Error::bad_param(JEFFERSON, "direction", format!("got {o:?}"))),
        };
        let off = if enc { offset } else { 26 - offset };
        let t = letters(&input.data);
        if t.is_empty() {
            return Err(Error::node_failed(JEFFERSON, "input has no ASCII letters"));
        }
        let w = order.len();
        let mut out = Vec::with_capacity(t.len());
        for (i, &c) in t.iter().enumerate() {
            let d = &discs[order[i % w]];
            let p = d.iter().position(|&x| x == c).ok_or_else(|| {
                Error::node_failed(JEFFERSON, format!("'{}' not on disc", c as char))
            })?;
            out.push(d[((p as i64 + off).rem_euclid(26)) as usize]);
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

// ---------------------------------------------------------------- Bazeries

const BAZERIES: &str = "bazeries";
const BAZ_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("number", ParamType::Int, "the key number; its digits give the \
                                              transposition group sizes"),
    ParamSpec::req("key", ParamType::Str, "keyword for the substitution square"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Bazeries: a digit-driven group reversal followed by a keyed substitution.
///
/// Encryption splits the text into groups whose sizes cycle through the digits of
/// `number`, reverses each group, then substitutes through a square keyed by `key`.
/// Decryption undoes them in the opposite order. The classical cipher spells the
/// number out in words to build the second alphabet; that spelling is language-specific,
/// so it is supplied here as `key` instead of being assumed to be English.
pub struct Bazeries;

impl Node for Bazeries {
    fn name(&self) -> &'static str { BAZERIES }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/bazeries(digit-groups+keyed-substitution)" }
    fn params_schema(&self) -> &'static [ParamSpec] { BAZ_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let num = params.req_i64(BAZERIES, "number")?;
        if num <= 0 {
            return Err(Error::bad_param(BAZERIES, "number", "must be positive"));
        }
        let digits: Vec<usize> = num
            .to_string()
            .bytes()
            .map(|b| (b - b'0') as usize)
            .filter(|&d| d > 0)
            .collect();
        if digits.is_empty() {
            return Err(Error::bad_param(BAZERIES, "number", "needs a non-zero digit"));
        }
        let alpha = keyed(params.req_str(BAZERIES, "key")?);
        let enc = match params.opt_str("direction").unwrap_or("decrypt") {
            "encrypt" => true,
            "decrypt" => false,
            o => return Err(Error::bad_param(BAZERIES, "direction", format!("got {o:?}"))),
        };
        let t = letters(&input.data);
        if t.is_empty() {
            return Err(Error::node_failed(BAZERIES, "input has no ASCII letters"));
        }
        let group_reverse = |v: &[u8]| -> Vec<u8> {
            let mut out = Vec::with_capacity(v.len());
            let mut p = 0usize;
            let mut d = 0usize;
            while p < v.len() {
                let n = digits[d % digits.len()].min(v.len() - p);
                let mut g = v[p..p + n].to_vec();
                g.reverse();
                out.extend(g);
                p += n;
                d += 1;
            }
            out
        };
        let subst = |v: &[u8], forward: bool| -> Vec<u8> {
            v.iter()
                .map(|&c| {
                    if forward {
                        alpha[(c - b'a') as usize]
                    } else {
                        b'a' + alpha.iter().position(|&x| x == c).unwrap_or(0) as u8
                    }
                })
                .collect()
        };
        let out = if enc {
            subst(&group_reverse(&t), true)
        } else {
            group_reverse(&subst(&t, false))
        };
        Ok(Repr::new(out, Display::Bytes))
    }
}

// ---------------------------------------------------------------- Chaocipher

const CHAO: &str = "chaocipher";
const CHAO_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("left", ParamType::Str, "26-letter starting cipher alphabet"),
    ParamSpec::req("right", ParamType::Str, "26-letter starting plain alphabet"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Chaocipher: both alphabets permute after every single letter.
///
/// After enciphering at index `i`: the left alphabet is rotated so the cipher letter
/// leads, then its position-1 letter is extracted and reinserted at position 13; the
/// right alphabet is rotated so the plain letter leads plus one more, then its
/// position-2 letter is extracted and reinserted at position 13. The state therefore
/// depends on the whole message so far, which is why no period exists to find.
///
/// Key entropy 2 × log2(26!) ≈ 177 bits — ciphertext-only recovery is not possible
/// below roughly 55 letters, and that is a property of the cipher, not of any search.
pub struct Chaocipher;

fn chao_permute(left: &mut Vec<u8>, right: &mut Vec<u8>, i: usize) {
    left.rotate_left(i);
    let z = left.remove(1);
    left.insert(13, z);
    right.rotate_left((i + 1) % 26);
    let y = right.remove(2);
    right.insert(13, y);
}

impl Node for Chaocipher {
    fn name(&self) -> &'static str { CHAO }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/chaocipher(dual-permuting-alphabets)" }
    fn params_schema(&self) -> &'static [ParamSpec] { CHAO_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let get = |k: &str| -> Result<Vec<u8>> {
            let v: Vec<u8> = params
                .req_str(CHAO, k)?
                .bytes()
                .filter(|b| b.is_ascii_alphabetic())
                .map(|b| b.to_ascii_lowercase())
                .collect();
            if v.len() != 26 || v.iter().collect::<std::collections::HashSet<_>>().len() != 26 {
                return Err(Error::bad_param(CHAO, k, "must be a permutation of 26 letters"));
            }
            Ok(v)
        };
        let mut left = get("left")?;
        let mut right = get("right")?;
        let enc = match params.opt_str("direction").unwrap_or("decrypt") {
            "encrypt" => true,
            "decrypt" => false,
            o => return Err(Error::bad_param(CHAO, "direction", format!("got {o:?}"))),
        };
        let t = letters(&input.data);
        if t.is_empty() {
            return Err(Error::node_failed(CHAO, "input has no ASCII letters"));
        }
        let mut out = Vec::with_capacity(t.len());
        for &c in t.iter() {
            let i = if enc {
                right.iter().position(|&x| x == c)
            } else {
                left.iter().position(|&x| x == c)
            }
            .ok_or_else(|| Error::node_failed(CHAO, format!("'{}' not in alphabet", c as char)))?;
            out.push(if enc { left[i] } else { right[i] });
            chao_permute(&mut left, &mut right, i);
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

// ---------------------------------------------------------------- Running key

const RUNNING: &str = "running_key";
const RUN_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("keytext", ParamType::Str, "the running key text, at least as long \
                                               as the message"),
    ParamSpec::opt("offset", ParamType::Int, "start position within the key text (default 0)"),
    ParamSpec::opt("mode", ParamType::Str, "\"vigenere\" (default), \"beaufort\" or \"variant\""),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Running key: a Vigenère-family cipher whose key is a long text rather than a
/// repeating word.
///
/// A key text shorter than the message is an error rather than being silently
/// recycled — recycling would quietly turn it into a periodic Vigenère, which is a
/// different cipher with a different attack surface.
pub struct RunningKey;

impl Node for RunningKey {
    fn name(&self) -> &'static str { RUNNING }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/running_key(no-recycle)" }
    fn params_schema(&self) -> &'static [ParamSpec] { RUN_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let kt = letters(params.req_str(RUNNING, "keytext")?.as_bytes());
        let offset = params.opt_i64("offset", 0);
        if offset < 0 {
            return Err(Error::bad_param(RUNNING, "offset", "must not be negative"));
        }
        let offset = offset as usize;
        let t = letters(&input.data);
        if t.is_empty() {
            return Err(Error::node_failed(RUNNING, "input has no ASCII letters"));
        }
        if kt.len() < offset + t.len() {
            return Err(Error::bad_param(
                RUNNING,
                "keytext",
                format!(
                    "need {} key letters from offset {offset}, have {}. A short key text is \
                     rejected rather than recycled: recycling would silently make this a \
                     periodic Vigenere, a different cipher.",
                    t.len(),
                    kt.len().saturating_sub(offset)
                ),
            ));
        }
        let mode = params.opt_str("mode").unwrap_or("vigenere");
        let enc = match params.opt_str("direction").unwrap_or("decrypt") {
            "encrypt" => true,
            "decrypt" => false,
            o => return Err(Error::bad_param(RUNNING, "direction", format!("got {o:?}"))),
        };
        let mut out = Vec::with_capacity(t.len());
        for (i, &c) in t.iter().enumerate() {
            let x = (c - b'a') as i64;
            let k = (kt[offset + i] - b'a') as i64;
            let v = match mode {
                "beaufort" => (k - x).rem_euclid(26),
                "variant" => {
                    if enc { (x - k).rem_euclid(26) } else { (x + k).rem_euclid(26) }
                }
                _ => {
                    if enc { (x + k).rem_euclid(26) } else { (x - k).rem_euclid(26) }
                }
            };
            out.push(b'a' + v as u8);
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(JEFFERSON_NODE => || Box::new(Jefferson));
register_node!(BAZERIES_NODE => || Box::new(Bazeries));
register_node!(CHAOCIPHER => || Box::new(Chaocipher));
register_node!(RUNNING_KEY => || Box::new(RunningKey));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn n(name: &str) -> &'static dyn Node { registry().get(name).unwrap() }

    fn two_discs() -> String {
        format!("{};{}", "zyxwvutsrqponmlkjihgfedcba", "bcdefghijklmnopqrstuvwxyza")
    }

    #[test]
    fn all_are_xf() {
        for name in [JEFFERSON, BAZERIES, CHAO, RUNNING] {
            assert_eq!(n(name).family(), Family::Xf);
        }
    }

    #[test]
    fn jefferson_round_trips() {
        let node = n(JEFFERSON);
        let p = params! {"discs" => two_discs(), "offset" => 7i64};
        let enc = node
            .apply(&Repr::bytes(b"attackatdawn".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(node.apply(&enc, &p).unwrap().data, b"attackatdawn");
    }

    #[test]
    fn jefferson_rejects_bad_discs_and_offsets() {
        let node = n(JEFFERSON);
        assert!(node
            .apply(&Repr::bytes(b"ab".to_vec()), &params! {"discs" => "abc", "offset" => 3i64})
            .is_err());
        assert!(node
            .apply(&Repr::bytes(b"ab".to_vec()), &params! {"discs" => two_discs(), "offset" => 0i64})
            .is_err());
    }

    #[test]
    fn bazeries_round_trips() {
        let node = n(BAZERIES);
        let p = params! {"number" => 3752i64, "key" => "ZOMBIES"};
        let enc = node
            .apply(&Repr::bytes(b"defendtheeastwall".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(node.apply(&enc, &p).unwrap().data, b"defendtheeastwall");
    }

    #[test]
    fn chaocipher_round_trips_and_is_not_periodic() {
        let node = n(CHAO);
        let p = params! {
            "left" => "hxuczvamdslkpefjrigtwobnyq",
            "right" => "ptlnbqdeoysfavzkgjrihwxumc"
        };
        let enc = node
            .apply(&Repr::bytes(b"welldonesiryouhavewon".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(node.apply(&enc, &p).unwrap().data, b"welldonesiryouhavewon");

        // identical plaintext letters must not give identical ciphertext letters:
        // that is the whole claim of a permuting-alphabet machine
        let flat = node
            .apply(&Repr::bytes(b"aaaaaaaa".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert!(
            flat.data.windows(2).any(|w| w[0] != w[1]),
            "alphabets are not permuting"
        );
    }

    #[test]
    fn chaocipher_rejects_a_non_permutation() {
        assert!(n(CHAO)
            .apply(
                &Repr::bytes(b"ab".to_vec()),
                &params! {"left" => "aaaaaaaaaaaaaaaaaaaaaaaaaa",
                          "right" => "ptlnbqdeoysfavzkgjrihwxumc"}
            )
            .is_err());
    }

    #[test]
    fn running_key_round_trips_and_refuses_to_recycle() {
        let node = n(RUNNING);
        let p = params! {"keytext" => "thequickbrownfoxjumpsoverthelazydog"};
        let enc = node
            .apply(&Repr::bytes(b"attackatdawn".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(node.apply(&enc, &p).unwrap().data, b"attackatdawn");

        let e = node
            .apply(&Repr::bytes(b"attackatdawn".to_vec()), &params! {"keytext" => "short"})
            .unwrap_err();
        assert!(format!("{e}").contains("rejected rather than recycled"), "{e}");
    }
}
