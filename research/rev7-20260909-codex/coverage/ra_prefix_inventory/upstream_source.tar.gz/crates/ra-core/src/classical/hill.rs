//! Hill: a polygraphic substitution by matrix multiplication modulo the alphabet size.
//!
//! # Why this node exists
//!
//! The Black Ops 4 "IX" cipher set records `hill` with key `2 15 18 22` for ix8, and
//! that key **reproduces the in-game ciphertext exactly** (46/46 characters) under the
//! column-vector convention with `A = 0`. See `reproduces_ix8` below.
//!
//! # The singular-key trap
//!
//! `det [[2,15],[18,22]] = 2*22 - 15*18 = -226 = 8 (mod 26)`, and `gcd(8, 26) = 2`, so
//! **that key is not invertible**. The puzzle author encrypts with a singular matrix.
//! This matters far more than it looks:
//!
//! * Every "invert the matrix and decrypt" implementation silently *skips* such keys,
//!   because it can only enumerate the invertible ones. A brute force over invertible
//!   2x2 matrices covers 157,248 of the 456,976 candidates and misses the rest.
//! * A singular key is not injective, so decryption is genuinely one-to-many: each
//!   ciphertext block has 0 or `k` preimages. There is no matrix that inverts it.
//!
//! So `direction = "encrypt"` accepts any matrix, while `direction = "decrypt"` requires
//! an invertible one and says plainly why when it is not. Reproducing ix8 therefore runs
//! the node in the encrypt direction against the known plaintext, which is exactly how
//! the conformance test below is written.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: a transform at stated parameters, exhaustive at those parameters.
//! Searching the key space is a solver's job, not this node's.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const NAME: &str = "hill";

/// The classical base alphabet: 26 letters, `a = 0`.
pub const DEFAULT_ALPHABET: &str = "abcdefghijklmnopqrstuvwxyz";

const SCHEMA: &[ParamSpec] = &[
    ParamSpec::req(
        "key",
        ParamType::Str,
        "matrix entries in row-major order, separated by spaces or commas; the count \
         must be a perfect square (4 gives 2x2, 9 gives 3x3)",
    ),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "symbol set indexed by the matrix (default the 26 lowercase letters). Its \
         length is the modulus.",
    ),
    ParamSpec::opt(
        "direction",
        ParamType::Str,
        "\"decrypt\" (default; requires an invertible matrix) or \"encrypt\" (accepts \
         any matrix, including singular ones)",
    ),
    ParamSpec::opt(
        "convention",
        ParamType::Str,
        "\"column\" (default, c = K*p) or \"row\" (c = p*K); the two differ by a \
         transpose",
    ),
];

fn egcd(a: i64, b: i64) -> (i64, i64, i64) {
    if b == 0 {
        (a, 1, 0)
    } else {
        let (g, x, y) = egcd(b, a % b);
        (g, y, x - (a / b) * y)
    }
}

/// Modular inverse of `a` mod `m`, or `None` when `gcd(a, m) != 1`.
pub fn mod_inv(a: i64, m: i64) -> Option<i64> {
    let a = a.rem_euclid(m);
    let (g, x, _) = egcd(a, m);
    if g != 1 {
        None
    } else {
        Some(x.rem_euclid(m))
    }
}

/// Determinant of a square matrix modulo `m`, by cofactor expansion.
pub fn det_mod(m: &[Vec<i64>], modulus: i64) -> i64 {
    let n = m.len();
    if n == 1 {
        return m[0][0].rem_euclid(modulus);
    }
    if n == 2 {
        return (m[0][0] * m[1][1] - m[0][1] * m[1][0]).rem_euclid(modulus);
    }
    let mut acc = 0i64;
    for c in 0..n {
        let minor: Vec<Vec<i64>> = m[1..]
            .iter()
            .map(|row| {
                row.iter()
                    .enumerate()
                    .filter(|(j, _)| *j != c)
                    .map(|(_, v)| *v)
                    .collect()
            })
            .collect();
        let sign = if c % 2 == 0 { 1 } else { -1 };
        acc += sign * m[0][c] * det_mod(&minor, modulus);
    }
    acc.rem_euclid(modulus)
}

/// Matrix inverse modulo `m` via the adjugate, or `None` when the determinant is
/// not a unit — which is precisely the singular case the IX author's key falls into.
pub fn inv_mod(m: &[Vec<i64>], modulus: i64) -> Option<Vec<Vec<i64>>> {
    let n = m.len();
    let d = det_mod(m, modulus);
    let di = mod_inv(d, modulus)?;
    let mut out = vec![vec![0i64; n]; n];
    for i in 0..n {
        for j in 0..n {
            let minor: Vec<Vec<i64>> = m
                .iter()
                .enumerate()
                .filter(|(r, _)| *r != i)
                .map(|(_, row)| {
                    row.iter()
                        .enumerate()
                        .filter(|(c, _)| *c != j)
                        .map(|(_, v)| *v)
                        .collect()
                })
                .collect();
            let cof = if (i + j) % 2 == 0 { 1 } else { -1 } * det_mod(&minor, modulus);
            // adjugate is the transpose of the cofactor matrix
            out[j][i] = (cof * di).rem_euclid(modulus);
        }
    }
    Some(out)
}

fn parse_key(s: &str) -> Result<Vec<Vec<i64>>> {
    let nums: Vec<i64> = s
        .split(|c: char| c == ',' || c.is_whitespace())
        .filter(|t| !t.is_empty())
        .map(|t| {
            t.parse::<i64>()
                .map_err(|_| Error::bad_param(NAME, "key", format!("{t:?} is not an integer")))
        })
        .collect::<Result<_>>()?;
    let n = (nums.len() as f64).sqrt().round() as usize;
    if n * n != nums.len() || n == 0 {
        return Err(Error::bad_param(
            NAME,
            "key",
            format!(
                "{} entries is not a perfect square, so they cannot fill a matrix",
                nums.len()
            ),
        ));
    }
    Ok(nums.chunks(n).map(|c| c.to_vec()).collect())
}

pub struct Hill;

impl Node for Hill {
    fn name(&self) -> &'static str {
        NAME
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/hill(NxN-matrix,singular-aware,column|row)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let alphabet = params.opt_str("alphabet").unwrap_or(DEFAULT_ALPHABET);
        let alpha: Vec<u8> = alphabet.bytes().map(|b| b.to_ascii_lowercase()).collect();
        let modulus = alpha.len() as i64;
        if modulus < 2 {
            return Err(Error::bad_param(NAME, "alphabet", "needs at least 2 symbols"));
        }
        let mut key = parse_key(params.req_str(NAME, "key")?)?;
        let n = key.len();

        match params.opt_str("convention").unwrap_or("column") {
            "column" => {}
            "row" => {
                let mut t = vec![vec![0i64; n]; n];
                for i in 0..n {
                    for j in 0..n {
                        t[i][j] = key[j][i];
                    }
                }
                key = t;
            }
            other => {
                return Err(Error::bad_param(
                    NAME,
                    "convention",
                    format!("expected \"column\" or \"row\", got {other:?}"),
                ))
            }
        }

        let direction = params.opt_str("direction").unwrap_or("decrypt");
        let matrix = match direction {
            "encrypt" => key,
            "decrypt" => inv_mod(&key, modulus).ok_or_else(|| {
                let d = det_mod(&key, modulus);
                Error::bad_param(
                    NAME,
                    "key",
                    format!(
                        "determinant {d} is not invertible mod {modulus} (gcd != 1), so this \
                         matrix has no inverse and cannot decrypt. It can still ENCRYPT: a \
                         singular Hill key is many-to-one, which is why some real ciphers \
                         (e.g. the BO4 IX set's `2 15 18 22`) cannot be undone by matrix \
                         inversion at all."
                    ),
                )
            })?,
            other => {
                return Err(Error::bad_param(
                    NAME,
                    "direction",
                    format!("expected \"decrypt\" or \"encrypt\", got {other:?}"),
                ))
            }
        };

        let index: std::collections::HashMap<u8, i64> = alpha
            .iter()
            .enumerate()
            .map(|(i, &c)| (c, i as i64))
            .collect();
        let text: Vec<i64> = input
            .data
            .iter()
            .map(|c| c.to_ascii_lowercase())
            .filter_map(|c| index.get(&c).copied())
            .collect();
        if text.is_empty() {
            return Err(Error::node_failed(
                NAME,
                "input has no symbols from the alphabet, so there is no block text",
            ));
        }
        if text.len() % n != 0 {
            return Err(Error::node_failed(
                NAME,
                format!(
                    "a Hill text must be a whole number of {n}-symbol blocks; got {} symbols",
                    text.len()
                ),
            ));
        }

        let mut out = Vec::with_capacity(text.len());
        for block in text.chunks_exact(n) {
            for row in matrix.iter() {
                let v: i64 = row
                    .iter()
                    .zip(block.iter())
                    .map(|(a, b)| a * b)
                    .sum::<i64>()
                    .rem_euclid(modulus);
                out.push(alpha[v as usize]);
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(HILL => || Box::new(Hill));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn node() -> &'static dyn Node {
        registry().get(NAME).unwrap()
    }

    #[test]
    fn is_xf_family() {
        assert_eq!(node().family(), Family::Xf);
        assert!(!node().terminal());
    }

    /// The IX author's recorded key is singular, and this is the arithmetic.
    #[test]
    fn ix8_key_is_singular_mod_26() {
        let k = parse_key("2 15 18 22").unwrap();
        assert_eq!(det_mod(&k, 26), 8);
        assert!(mod_inv(8, 26).is_none(), "gcd(8,26)=2, so 8 is not a unit");
        assert!(inv_mod(&k, 26).is_none());
    }

    /// Conformance: key `2 15 18 22`, column convention, `a = 0`, encrypting ix8's
    /// known plaintext reproduces the ciphertext read off the in-game image exactly.
    #[test]
    fn reproduces_ix8() {
        let pt = "AWAVEOFCHANGEISCOMINGYOUWILLBESWEPTUPINITSWAKE";
        let expected = "sqdukqoeowmcyooeawdoimqqiafykccczmacuequwksgci";
        let out = node()
            .apply(
                &Repr::bytes(pt.as_bytes().to_vec()),
                &params! {"key" => "2 15 18 22", "direction" => "encrypt"},
            )
            .unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), expected);
    }

    /// Decryption with that key must fail loudly rather than silently producing
    /// nonsense — the failure mode that makes singular keys invisible to brute force.
    #[test]
    fn singular_key_cannot_decrypt_and_says_why() {
        let e = node()
            .apply(
                &Repr::bytes(b"sqdukqoe".to_vec()),
                &params! {"key" => "2 15 18 22"},
            )
            .unwrap_err();
        let s = format!("{e}");
        assert!(s.contains("not invertible"), "{s}");
        assert!(s.contains("ENCRYPT"), "{s}");
    }

    /// An invertible key round-trips exactly.
    #[test]
    fn invertible_key_round_trips() {
        let n = node();
        // det [[3,3],[2,5]] = 9 mod 26, gcd(9,26)=1
        let enc = n
            .apply(
                &Repr::bytes(b"attackatdawn".to_vec()),
                &params! {"key" => "3 3 2 5", "direction" => "encrypt"},
            )
            .unwrap();
        let back = n
            .apply(&enc, &params! {"key" => "3 3 2 5"})
            .unwrap();
        assert_eq!(back.data, b"attackatdawn");
    }

    /// 3x3 works, and the row convention is the transpose of the column one.
    #[test]
    fn three_by_three_and_row_convention() {
        let n = node();
        let enc_col = n
            .apply(
                &Repr::bytes(b"actbcd".to_vec()),
                &params! {"key" => "6 24 1 13 16 10 20 17 15", "direction" => "encrypt"},
            )
            .unwrap();
        let back = n
            .apply(&enc_col, &params! {"key" => "6 24 1 13 16 10 20 17 15"})
            .unwrap();
        assert_eq!(back.data, b"actbcd");

        let enc_row = n
            .apply(
                &Repr::bytes(b"actbcd".to_vec()),
                &params! {"key" => "6 24 1 13 16 10 20 17 15",
                          "direction" => "encrypt", "convention" => "row"},
            )
            .unwrap();
        assert_ne!(enc_col.data, enc_row.data, "the conventions differ");
    }

    #[test]
    fn ragged_block_and_bad_key_are_rejected() {
        let n = node();
        assert!(n
            .apply(&Repr::bytes(b"abc".to_vec()), &params! {"key" => "3 3 2 5"})
            .is_err());
        assert!(n
            .apply(&Repr::bytes(b"abcd".to_vec()), &params! {"key" => "1 2 3"})
            .is_err());
        assert!(n
            .apply(&Repr::bytes(b"abcd".to_vec()), &params! {"key" => "x y z w"})
            .is_err());
    }
}
