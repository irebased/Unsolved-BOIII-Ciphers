//! Quagmire I–IV, Gromark, Periodic Gromark, Nicodemus, interrupted key, progressive key.
//!
//! # Why these nodes exist
//!
//! Every cipher here has key entropy well below the ~96–131 bits a 30–41 letter
//! ciphertext carries, so all of them are **decidable** at corpus lengths — a
//! recovered key would be uniquely determined rather than one of many. That is the
//! opposite of the multi-square family in [`crate::classical::squares`], and it is why
//! these were the ones worth building.
//!
//! Quagmire in particular is the natural home for a ciphertext whose letter
//! distribution is *flatter* than English (BO4 IX's ix9 shows 19 distinct letters in
//! 30) while its period is short: keyed alphabets flatten unigrams without needing a
//! long key.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: transforms at stated parameters. Solving for the key is a solver's
//! job; these nodes contain no search.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const A26: &str = "abcdefghijklmnopqrstuvwxyz";

fn keyed_alphabet(key: &str) -> Vec<u8> {
    let mut cells = Vec::new();
    let mut seen = std::collections::HashSet::new();
    for c in key.bytes().chain(A26.bytes()) {
        let c = c.to_ascii_lowercase();
        if c.is_ascii_lowercase() && seen.insert(c) {
            cells.push(c);
        }
    }
    cells
}

fn text_letters(data: &[u8]) -> Vec<u8> {
    data.iter()
        .filter(|c| c.is_ascii_alphabetic())
        .map(|c| c.to_ascii_lowercase())
        .collect()
}

// ---------------------------------------------------------------- Quagmire

const QUAG: &str = "quagmire";
const QUAG_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("variant", ParamType::Int, "1, 2, 3 or 4 (Quagmire I..IV)"),
    ParamSpec::req("indicator", ParamType::Str, "the periodic indicator key"),
    ParamSpec::opt("key1", ParamType::Str, "keyword for the plaintext alphabet (I, III, IV)"),
    ParamSpec::opt("key2", ParamType::Str, "keyword for the ciphertext alphabet (II, IV)"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Quagmire I–IV: a periodic polyalphabetic over one or two *keyed* alphabets.
///
/// * **I** — plaintext alphabet keyed, ciphertext alphabet straight
/// * **II** — plaintext straight, ciphertext keyed
/// * **III** — both keyed, with the same keyword
/// * **IV** — both keyed, with different keywords
///
/// Encryption is `c = C[(P.index(p) + s_i) mod 26]`, where `s_i` is the position of
/// the indicator key's i-th letter in the ciphertext alphabet. Writing the shift that
/// way (rather than as a raw A=0 offset) is what makes III and IV differ from a plain
/// Vigenère over a keyed alphabet.
pub struct Quagmire;

impl Node for Quagmire {
    fn name(&self) -> &'static str { QUAG }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/quagmire(I-IV,keyed-alphabets)" }
    fn params_schema(&self) -> &'static [ParamSpec] { QUAG_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let variant = params.req_i64(QUAG, "variant")?;
        let k1 = params.opt_str("key1").unwrap_or("");
        let k2 = params.opt_str("key2").unwrap_or("");
        let (p_alpha, c_alpha) = match variant {
            1 => (keyed_alphabet(k1), A26.bytes().collect::<Vec<u8>>()),
            2 => (A26.bytes().collect::<Vec<u8>>(), keyed_alphabet(k2)),
            3 => (keyed_alphabet(k1), keyed_alphabet(k1)),
            4 => (keyed_alphabet(k1), keyed_alphabet(k2)),
            o => {
                return Err(Error::bad_param(
                    QUAG,
                    "variant",
                    format!("expected 1, 2, 3 or 4, got {o}"),
                ))
            }
        };
        let cidx: std::collections::HashMap<u8, i64> =
            c_alpha.iter().enumerate().map(|(i, &c)| (c, i as i64)).collect();
        let pidx: std::collections::HashMap<u8, i64> =
            p_alpha.iter().enumerate().map(|(i, &c)| (c, i as i64)).collect();
        let shifts: Vec<i64> = params
            .req_str(QUAG, "indicator")?
            .bytes()
            .map(|b| b.to_ascii_lowercase())
            .filter_map(|b| cidx.get(&b).copied())
            .collect();
        if shifts.is_empty() {
            return Err(Error::bad_param(QUAG, "indicator", "no usable indicator letters"));
        }
        let enc = match params.opt_str("direction").unwrap_or("decrypt") {
            "encrypt" => true,
            "decrypt" => false,
            o => return Err(Error::bad_param(QUAG, "direction", format!("got {o:?}"))),
        };
        let t = text_letters(&input.data);
        if t.is_empty() {
            return Err(Error::node_failed(QUAG, "input has no ASCII letters"));
        }
        let mut out = Vec::with_capacity(t.len());
        for (i, &c) in t.iter().enumerate() {
            let s = shifts[i % shifts.len()];
            if enc {
                let p = *pidx.get(&c).ok_or_else(|| miss(QUAG, c))?;
                out.push(c_alpha[((p + s).rem_euclid(26)) as usize]);
            } else {
                let x = *cidx.get(&c).ok_or_else(|| miss(QUAG, c))?;
                out.push(p_alpha[((x - s).rem_euclid(26)) as usize]);
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

fn miss(node: &'static str, c: u8) -> Error {
    Error::node_failed(node, format!("'{}' is not in the alphabet", c as char))
}

// ---------------------------------------------------------------- Gromark

const GROMARK: &str = "gromark";
const GROMARK_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("primer", ParamType::Str, "digit primer, e.g. \"23415\""),
    ParamSpec::opt("period", ParamType::Int, "restart the chain every N letters (0 = never)"),
    ParamSpec::opt("key", ParamType::Str, "keyword for the cipher alphabet (default straight)"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Gromark: a Gronsfeld whose digit stream is a lagged-Fibonacci chain from a primer.
///
/// `k[i] = (k[i-len] + k[i-len+1]) mod 10` once the primer is exhausted. With
/// `period > 0` the chain restarts from the primer every `period` letters, which is
/// the "Periodic Gromark" variant — the same node, because the only difference is
/// whether the running key is allowed to run.
pub struct Gromark;

impl Node for Gromark {
    fn name(&self) -> &'static str { GROMARK }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/gromark(lagged-fibonacci,optional-period)" }
    fn params_schema(&self) -> &'static [ParamSpec] { GROMARK_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        // A digit-only primer is parsed as an Int by the chain spec, so accept both
        // forms: requiring Str alone would make `gromark:primer=23415` unusable from
        // a chain, which is the only way most callers reach this node.
        let primer_src = match params.opt_str("primer") {
            Some(s) => s.to_string(),
            None => params.req_i64(GROMARK, "primer")?.to_string(),
        };
        let primer: Vec<i64> = primer_src
            .bytes()
            .filter(|b| b.is_ascii_digit())
            .map(|b| (b - b'0') as i64)
            .collect();
        if primer.len() < 2 {
            return Err(Error::bad_param(GROMARK, "primer", "needs at least 2 digits"));
        }
        let alpha = match params.opt_str("key") {
            Some(k) => keyed_alphabet(k),
            None => A26.bytes().collect(),
        };
        let idx: std::collections::HashMap<u8, i64> =
            alpha.iter().enumerate().map(|(i, &c)| (c, i as i64)).collect();
        let period = params.opt_i64("period", 0);
        if period < 0 {
            return Err(Error::bad_param(GROMARK, "period", "must not be negative"));
        }
        let enc = match params.opt_str("direction").unwrap_or("decrypt") {
            "encrypt" => true,
            "decrypt" => false,
            o => return Err(Error::bad_param(GROMARK, "direction", format!("got {o:?}"))),
        };
        let t = text_letters(&input.data);
        if t.is_empty() {
            return Err(Error::node_failed(GROMARK, "input has no ASCII letters"));
        }
        let blk = if period == 0 { t.len() } else { period as usize };
        let mut out = Vec::with_capacity(t.len());
        for chunk in t.chunks(blk) {
            let mut ks = primer.clone();
            while ks.len() < chunk.len() {
                let n = ks.len();
                let l = primer.len();
                ks.push((ks[n - l] + ks[n - l + 1]) % 10);
            }
            for (i, &c) in chunk.iter().enumerate() {
                let x = *idx.get(&c).ok_or_else(|| miss(GROMARK, c))?;
                let s = ks[i];
                let v = if enc { x + s } else { x - s };
                out.push(alpha[(v.rem_euclid(26)) as usize]);
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

// ---------------------------------------------------------------- Nicodemus

const NICO: &str = "nicodemus";
const NICO_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "keyword: its length is the period and its \
                                           alphabetical order is the column order"),
    ParamSpec::opt("mode", ParamType::Str, "\"vigenere\" (default), \"beaufort\" or \"variant\""),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Nicodemus: a Vigenère applied down the columns of a block, then a columnar
/// transposition of those columns.
///
/// Encryption writes the text in rows of `key.len()`, enciphers each column with that
/// column's key letter, then reads the columns out in the key's alphabetical order.
/// Both halves use the same key, which is what keeps the entropy at ~50 bits and the
/// cipher decidable at corpus lengths.
pub struct Nicodemus;

fn key_order(key: &[u8]) -> Vec<usize> {
    let mut ix: Vec<usize> = (0..key.len()).collect();
    ix.sort_by_key(|&i| (key[i], i));
    ix
}

impl Node for Nicodemus {
    fn name(&self) -> &'static str { NICO }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/nicodemus(column-vigenere+columnar)" }
    fn params_schema(&self) -> &'static [ParamSpec] { NICO_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key: Vec<u8> = params
            .req_str(NICO, "key")?
            .bytes()
            .filter(|b| b.is_ascii_alphabetic())
            .map(|b| b.to_ascii_lowercase())
            .collect();
        if key.is_empty() {
            return Err(Error::bad_param(NICO, "key", "no ASCII letters in key"));
        }
        let mode = params.opt_str("mode").unwrap_or("vigenere");
        let enc = match params.opt_str("direction").unwrap_or("decrypt") {
            "encrypt" => true,
            "decrypt" => false,
            o => return Err(Error::bad_param(NICO, "direction", format!("got {o:?}"))),
        };
        let t = text_letters(&input.data);
        if t.is_empty() {
            return Err(Error::node_failed(NICO, "input has no ASCII letters"));
        }
        let w = key.len();
        let order = key_order(&key);
        let shift = |x: i64, k: i64, up: bool| -> i64 {
            match mode {
                "beaufort" => (k - x).rem_euclid(26),
                "variant" => if up { (x - k).rem_euclid(26) } else { (x + k).rem_euclid(26) },
                _ => if up { (x + k).rem_euclid(26) } else { (x - k).rem_euclid(26) },
            }
        };
        let rows = t.len().div_ceil(w);
        let mut out = vec![0u8; t.len()];
        if enc {
            // rows -> column-wise Vigenere -> read columns in key order
            let mut cols: Vec<Vec<u8>> = vec![Vec::new(); w];
            for (i, &c) in t.iter().enumerate() {
                let col = i % w;
                let x = (c - b'a') as i64;
                let k = (key[col] - b'a') as i64;
                cols[col].push(b'a' + shift(x, k, true) as u8);
            }
            let mut p = 0;
            for &ci in order.iter() {
                for &c in cols[ci].iter() {
                    out[p] = c;
                    p += 1;
                }
            }
        } else {
            // split by column lengths in key order, un-Vigenere, re-interleave
            let full = t.len() % w;
            let lens: Vec<usize> = (0..w)
                .map(|i| if full == 0 || i < full { rows } else { rows - 1 })
                .collect();
            let mut cols: Vec<Vec<u8>> = vec![Vec::new(); w];
            let mut p = 0;
            for &ci in order.iter() {
                for _ in 0..lens[ci] {
                    cols[ci].push(t[p]);
                    p += 1;
                }
            }
            let mut q = 0;
            for r in 0..rows {
                for col in 0..w {
                    if r < cols[col].len() {
                        let x = (cols[col][r] - b'a') as i64;
                        let k = (key[col] - b'a') as i64;
                        out[q] = b'a' + shift(x, k, false) as u8;
                        q += 1;
                    }
                }
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

// ------------------------------------------------- interrupted / progressive key

const INTERRUPTED: &str = "interrupted_key";
const INT_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "the key word"),
    ParamSpec::req("trigger", ParamType::Str, "single letter; the key restarts after it \
                                               appears in the PLAINTEXT"),
    ParamSpec::opt("mode", ParamType::Str, "\"vigenere\" (default) or \"beaufort\""),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Interrupted key: a Vigenère whose key restarts whenever a trigger letter appears
/// in the *plaintext*.
///
/// Because the trigger is a plaintext condition, decryption has to detect it as it
/// goes — the key position depends on what has already been recovered. That
/// self-referential structure is the whole point of the cipher and is why it resists
/// period-finding: there is no fixed period to find.
pub struct InterruptedKey;

impl Node for InterruptedKey {
    fn name(&self) -> &'static str { INTERRUPTED }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/interrupted_key(plaintext-trigger)" }
    fn params_schema(&self) -> &'static [ParamSpec] { INT_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key: Vec<i64> = params
            .req_str(INTERRUPTED, "key")?
            .bytes()
            .filter(|b| b.is_ascii_alphabetic())
            .map(|b| (b.to_ascii_lowercase() - b'a') as i64)
            .collect();
        if key.is_empty() {
            return Err(Error::bad_param(INTERRUPTED, "key", "no ASCII letters"));
        }
        let tg = params.req_str(INTERRUPTED, "trigger")?;
        let tb = tg.as_bytes();
        if tb.len() != 1 || !tb[0].is_ascii_alphabetic() {
            return Err(Error::bad_param(INTERRUPTED, "trigger", "expected one letter"));
        }
        let trigger = tb[0].to_ascii_lowercase();
        let beaufort = matches!(params.opt_str("mode"), Some("beaufort"));
        let enc = match params.opt_str("direction").unwrap_or("decrypt") {
            "encrypt" => true,
            "decrypt" => false,
            o => return Err(Error::bad_param(INTERRUPTED, "direction", format!("got {o:?}"))),
        };
        let t = text_letters(&input.data);
        if t.is_empty() {
            return Err(Error::node_failed(INTERRUPTED, "input has no ASCII letters"));
        }
        let mut out = Vec::with_capacity(t.len());
        let mut ki = 0usize;
        for &c in t.iter() {
            let x = (c - b'a') as i64;
            let k = key[ki % key.len()];
            let (plain, cipher) = if enc {
                let v = if beaufort { (k - x).rem_euclid(26) } else { (x + k).rem_euclid(26) };
                (x, v)
            } else {
                let v = if beaufort { (k - x).rem_euclid(26) } else { (x - k).rem_euclid(26) };
                (v, x)
            };
            let _ = cipher;
            out.push(b'a' + if enc {
                (if beaufort { (k - x).rem_euclid(26) } else { (x + k).rem_euclid(26) }) as u8
            } else {
                plain as u8
            });
            ki += 1;
            // the trigger is a PLAINTEXT letter in both directions
            let pt_letter = if enc { c } else { b'a' + plain as u8 };
            if pt_letter == trigger {
                ki = 0;
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

const PROGRESSIVE: &str = "progressive_key";
const PROG_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "the key word"),
    ParamSpec::opt("step", ParamType::Int, "extra shift added each time the key recycles (default 1)"),
    ParamSpec::opt("mode", ParamType::Str, "\"vigenere\" (default) or \"beaufort\""),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// Progressive key: a Vigenère whose whole key advances by `step` each cycle.
///
/// After the key has been used once, every letter of it is shifted by `step`, then
/// again the next cycle, and so on. With `step = 0` it degenerates to plain Vigenère,
/// which is a real special case and is asserted as one.
pub struct ProgressiveKey;

impl Node for ProgressiveKey {
    fn name(&self) -> &'static str { PROGRESSIVE }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/progressive_key(cycle-advance)" }
    fn params_schema(&self) -> &'static [ParamSpec] { PROG_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key: Vec<i64> = params
            .req_str(PROGRESSIVE, "key")?
            .bytes()
            .filter(|b| b.is_ascii_alphabetic())
            .map(|b| (b.to_ascii_lowercase() - b'a') as i64)
            .collect();
        if key.is_empty() {
            return Err(Error::bad_param(PROGRESSIVE, "key", "no ASCII letters"));
        }
        let step = params.opt_i64("step", 1);
        let beaufort = matches!(params.opt_str("mode"), Some("beaufort"));
        let enc = match params.opt_str("direction").unwrap_or("decrypt") {
            "encrypt" => true,
            "decrypt" => false,
            o => return Err(Error::bad_param(PROGRESSIVE, "direction", format!("got {o:?}"))),
        };
        let t = text_letters(&input.data);
        if t.is_empty() {
            return Err(Error::node_failed(PROGRESSIVE, "input has no ASCII letters"));
        }
        let p = key.len();
        let mut out = Vec::with_capacity(t.len());
        for (i, &c) in t.iter().enumerate() {
            let cycle = (i / p) as i64;
            let k = (key[i % p] + cycle * step).rem_euclid(26);
            let x = (c - b'a') as i64;
            let v = if beaufort {
                (k - x).rem_euclid(26)
            } else if enc {
                (x + k).rem_euclid(26)
            } else {
                (x - k).rem_euclid(26)
            };
            out.push(b'a' + v as u8);
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(QUAGMIRE => || Box::new(Quagmire));
register_node!(GROMARK_NODE => || Box::new(Gromark));
register_node!(NICODEMUS => || Box::new(Nicodemus));
register_node!(INTERRUPTED_KEY => || Box::new(InterruptedKey));
register_node!(PROGRESSIVE_KEY => || Box::new(ProgressiveKey));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn n(name: &str) -> &'static dyn Node { registry().get(name).unwrap() }

    #[test]
    fn all_are_xf() {
        for name in [QUAG, GROMARK, NICO, INTERRUPTED, PROGRESSIVE] {
            assert_eq!(n(name).family(), Family::Xf);
        }
    }

    #[test]
    fn quagmire_all_four_variants_round_trip() {
        let node = n(QUAG);
        for v in [1i64, 2, 3, 4] {
            let p = params! {
                "variant" => v, "indicator" => "NINE",
                "key1" => "SPRING", "key2" => "AUTUMN"
            };
            let enc = node
                .apply(&Repr::bytes(b"defendtheeastwall".to_vec()), &p.clone().set("direction", "encrypt"))
                .unwrap();
            let back = node.apply(&enc, &p).unwrap();
            assert_eq!(back.data, b"defendtheeastwall", "quagmire {v}");
        }
    }

    /// Quagmire III uses one keyword for both alphabets, IV uses two — so with
    /// different key2 they must diverge. Otherwise IV would be a mislabelled III.
    #[test]
    fn quagmire_three_and_four_differ() {
        let node = n(QUAG);
        let base = params! {"indicator" => "NINE", "key1" => "SPRING", "key2" => "AUTUMN",
                            "direction" => "encrypt"};
        let q3 = node.apply(&Repr::bytes(b"attack".to_vec()), &base.clone().set("variant", 3i64)).unwrap();
        let q4 = node.apply(&Repr::bytes(b"attack".to_vec()), &base.clone().set("variant", 4i64)).unwrap();
        assert_ne!(q3.data, q4.data);
    }

    #[test]
    fn gromark_round_trips_and_period_changes_the_stream() {
        let node = n(GROMARK);
        let p = params! {"primer" => "23415"};
        let enc = node
            .apply(&Repr::bytes(b"attackatdawn".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        assert_eq!(node.apply(&enc, &p).unwrap().data, b"attackatdawn");

        let periodic = node
            .apply(
                &Repr::bytes(b"attackatdawn".to_vec()),
                &params! {"primer" => "23415", "period" => 5i64, "direction" => "encrypt"},
            )
            .unwrap();
        assert_ne!(enc.data, periodic.data, "restarting the chain must matter");
    }

    /// A digit-only primer arrives from the chain spec as an Int, not a Str.
    /// Requiring Str would make `gromark:primer=23415` unusable from a chain — the
    /// only way most callers reach this node.
    #[test]
    fn gromark_accepts_an_integer_primer_from_a_chain_spec() {
        // an Int-valued primer, exactly as the chain spec produces it
        let p = params! {"primer" => 23415i64, "direction" => "encrypt"};
        let out = n(GROMARK)
            .apply(&Repr::bytes(b"defendtheeastwall".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"fhjfsiamkecuuccpo");
        // and the Str form still works and agrees
        let q = params! {"primer" => "23415", "direction" => "encrypt"};
        let out2 = n(GROMARK)
            .apply(&Repr::bytes(b"defendtheeastwall".to_vec()), &q)
            .unwrap();
        assert_eq!(out.data, out2.data);
    }

    #[test]
    fn nicodemus_round_trips_in_all_modes() {
        let node = n(NICO);
        for mode in ["vigenere", "beaufort", "variant"] {
            let p = params! {"key" => "NINE", "mode" => mode};
            let enc = node
                .apply(&Repr::bytes(b"defendtheeastwall".to_vec()), &p.clone().set("direction", "encrypt"))
                .unwrap();
            let back = node.apply(&enc, &p).unwrap();
            assert_eq!(back.data, b"defendtheeastwall", "mode {mode}");
        }
    }

    #[test]
    fn interrupted_key_round_trips() {
        let node = n(INTERRUPTED);
        let p = params! {"key" => "NINE", "trigger" => "e"};
        let enc = node
            .apply(&Repr::bytes(b"defendtheeastwall".to_vec()), &p.clone().set("direction", "encrypt"))
            .unwrap();
        let back = node.apply(&enc, &p).unwrap();
        assert_eq!(back.data, b"defendtheeastwall");
    }

    /// step = 0 must degenerate to plain Vigenère — a real special case, so it is
    /// asserted rather than left to chance.
    #[test]
    fn progressive_key_with_zero_step_is_plain_vigenere() {
        let node = n(PROGRESSIVE);
        let zero = node
            .apply(
                &Repr::bytes(b"attackatdawn".to_vec()),
                &params! {"key" => "nine", "step" => 0i64, "direction" => "encrypt"},
            )
            .unwrap();
        // hand-computed Vigenere("attackatdawn", "nine")
        assert_eq!(zero.data, b"nbgepsnxqijr");

        let one = node
            .apply(
                &Repr::bytes(b"attackatdawn".to_vec()),
                &params! {"key" => "nine", "step" => 1i64, "direction" => "encrypt"},
            )
            .unwrap();
        assert_ne!(zero.data, one.data);
        let back = node
            .apply(&one, &params! {"key" => "nine", "step" => 1i64})
            .unwrap();
        assert_eq!(back.data, b"attackatdawn");
    }

    #[test]
    fn bad_parameters_are_rejected() {
        assert!(n(QUAG)
            .apply(&Repr::bytes(b"abc".to_vec()), &params! {"variant" => 9i64, "indicator" => "A"})
            .is_err());
        assert!(n(GROMARK)
            .apply(&Repr::bytes(b"abc".to_vec()), &params! {"primer" => "7"})
            .is_err());
        assert!(n(INTERRUPTED)
            .apply(&Repr::bytes(b"abc".to_vec()), &params! {"key" => "NINE", "trigger" => "ee"})
            .is_err());
    }
}
