//! rumkin.com's 5x5-grid ciphers: Bifid and Playfair, from the recovered
//! `bifid.js` / `playfair.js`.
//!
//! # The grid is built by a trick worth naming
//!
//! Both call `MakeKeyedAlphabet(skip + key)` and then **slice off the first
//! character**. Prepending the skipped letter forces it to position 0, so removing
//! position 0 leaves exactly the 25 letters that belong in the grid — whichever
//! letter was skipped. That is why `skip` can be any letter, not just `J`.
//!
//! If `skip == skipto` the site advances `skipto` by one letter (wrapping `Z`->`A`)
//! rather than erroring, so the mapping never collapses to a no-op.
//!
//! # Rumkin's Bifid has NO period
//!
//! Unlike the classical description (and unlike [`crate::classical::bifid`], which
//! takes one), this tool fractionates across the **whole message**. There is no
//! period input on the page and none in the source.
//!
//! # Rumkin's Playfair never inserts `X` between doubled letters
//!
//! The textbook cipher splits a doubled pair with a padding letter. This one instead
//! shifts *both* the row and the column of a same-letter pair — a diagonal move —
//! unless the `doubleencode` flag is set, in which case the pair is left alone.
//! A trailing odd letter is paired with `X`, and the site's call for that case
//! **omits the flags argument**, so `flags & 1` evaluates against `undefined` and the
//! shift branch always runs. Reproduced in `playfair_trailing_letter_ignores_the_flag`.
//!
//! # Interleaved non-grid characters come back *inside* the pair
//!
//! If a space or digit falls between the two letters of a Playfair pair, the site
//! buffers it and emits it **between the two output letters** (`out += otemp[0] + bet
//! + otemp[1]`). So `"AB CD"` and `"A BCD"` do not merely differ in spacing — the
//! space lands in a different place relative to the enciphered letters. See
//! `playfair_reinserts_interleaved_characters_inside_the_pair`.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: transforms at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

use super::rumkin_shift::{make_keyed_alphabet, AZ};

const BIFID: &str = "rumkin_bifid";
const PLAYFAIR: &str = "rumkin_playfair";

/// Resolve `skip`/`skipto` and build the 25-letter grid the way both tools do.
fn grid(node: &'static str, params: &Params) -> Result<(Vec<u8>, u8, u8)> {
    let one = |k: &str, d: u8| -> u8 {
        match params.opt_str(k) {
            Some(s) if s.len() == 1 && s.as_bytes()[0].is_ascii_alphabetic() => {
                s.as_bytes()[0].to_ascii_uppercase()
            }
            _ => d,
        }
    };
    let skip = one("skip", b'J');
    let mut skipto = one("skipto", b'I');
    if skip == skipto {
        skipto = if skip == b'Z' { b'A' } else { skip + 1 };
    }
    let key = params.opt_str("key").unwrap_or("");
    let mut seed = String::new();
    seed.push(skip as char);
    seed.push_str(key);
    let full = make_keyed_alphabet(Some(&seed), AZ);
    let cells: Vec<u8> = full[1..].to_vec(); // drop the forced-first skip letter
    if cells.len() != 25 {
        return Err(Error::node_failed(
            node,
            format!("grid should hold 25 letters, got {}", cells.len()),
        ));
    }
    Ok((cells, skip, skipto))
}

const GRID_SCHEMA: &[ParamSpec] = &[
    ParamSpec::opt("key", ParamType::Str, "keyword laying out the 5x5 grid"),
    ParamSpec::opt("skip", ParamType::Str, "letter omitted from the grid (default \"J\")"),
    ParamSpec::opt("skipto", ParamType::Str, "letter the skipped one becomes (default \"I\")"),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

fn ed(node: &'static str, params: &Params) -> Result<i64> {
    match params.opt_str("direction").unwrap_or("decrypt") {
        "encrypt" => Ok(1),
        "decrypt" => Ok(-1),
        o => Err(Error::bad_param(node, "direction", format!("got {o:?}"))),
    }
}

/// `bifid.js`'s `Bifid(encdec, text, skip, skipto, key)` — periodless.
pub struct RumkinBifid;

impl Node for RumkinBifid {
    fn name(&self) -> &'static str { BIFID }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_grid(bifid.js,periodless)" }
    fn params_schema(&self) -> &'static [ParamSpec] { GRID_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let (cells, skip, skipto) = grid(BIFID, params)?;
        let e = ed(BIFID, params)?;
        let pos = |c: u8| cells.iter().position(|&x| x == c);

        // gather the grid-member letters, uppercased with skip folded
        let mut chars = Vec::new();
        for &raw in input.data.iter() {
            let mut c = raw.to_ascii_uppercase();
            if c == skip { c = skipto; }
            if pos(c).is_some() { chars.push(c); }
        }
        // Bifid_Mangle
        let mut line1: Vec<usize> = Vec::new();
        let mut line2: Vec<usize> = Vec::new();
        for &c in chars.iter() {
            let p = pos(c).unwrap();
            let (row, col) = (p / 5, p % 5);
            line1.push(row);
            if e > 0 { line2.push(col); } else { line1.push(col); }
        }
        line1.extend(line2.iter().copied());
        if e < 0 {
            let half = line1.len() / 2;
            let mut de = Vec::with_capacity(line1.len());
            for i in 0..half {
                de.push(line1[i]);
                de.push(line1[half + i]);
            }
            line1 = de;
        }
        let mut enc = Vec::with_capacity(chars.len());
        let mut i = 0;
        while i + 1 < line1.len() {
            enc.push(cells[line1[i] * 5 + line1[i + 1]]);
            i += 2;
        }
        // reassemble preserving case and non-grid characters in place
        let mut out = Vec::with_capacity(input.data.len());
        let mut j = 0usize;
        for &raw in input.data.iter() {
            let mut c = raw.to_ascii_uppercase();
            if c == skip { c = skipto; }
            if pos(c).is_some() && j < enc.len() {
                out.push(if raw.is_ascii_lowercase() { enc[j].to_ascii_lowercase() } else { enc[j] });
                j += 1;
            } else {
                out.push(raw);
            }
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

const PF_SCHEMA: &[ParamSpec] = &[
    ParamSpec::opt("key", ParamType::Str, "keyword laying out the 5x5 grid"),
    ParamSpec::opt("skip", ParamType::Str, "letter omitted from the grid (default \"J\")"),
    ParamSpec::opt("skipto", ParamType::Str, "letter the skipped one becomes (default \"I\")"),
    ParamSpec::opt(
        "doubleencode",
        ParamType::Bool,
        "the site's flag 0x01: when true a same-letter pair is left UNCHANGED instead \
         of being shifted diagonally (default false)",
    ),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// `playfair.js`'s `Playfair(encdec, text, skip, skipto, key, flags)`.
pub struct RumkinPlayfair;

fn pf_lookup(e: i64, a: u8, b: u8, cells: &[u8], leave_doubles: bool) -> (u8, u8) {
    let up = |c: u8| c.to_ascii_uppercase();
    let (lo1, lo2) = (a.is_ascii_lowercase(), b.is_ascii_lowercase());
    let p1 = cells.iter().position(|&x| x == up(a)).unwrap_or(0) as i64;
    let p2 = cells.iter().position(|&x| x == up(b)).unwrap_or(0) as i64;
    let (mut r1, mut c1) = (p1 / 5, p1 % 5);
    let (mut r2, mut c2) = (p2 / 5, p2 % 5);
    if r1 == r2 && c1 == c2 {
        if !leave_doubles {
            r1 += e; r2 += e; c1 += e; c2 += e;
        }
    } else if r1 == r2 {
        c1 += e; c2 += e;
    } else if c1 == c2 {
        r1 += e; r2 += e;
    } else {
        std::mem::swap(&mut c1, &mut c2);
    }
    let f = |r: i64, c: i64| cells[((r.rem_euclid(5)) * 5 + c.rem_euclid(5)) as usize];
    let (mut t1, mut t2) = (f(r1, c1), f(r2, c2));
    if lo1 { t1 = t1.to_ascii_lowercase(); }
    if lo2 { t2 = t2.to_ascii_lowercase(); }
    (t1, t2)
}

impl Node for RumkinPlayfair {
    fn name(&self) -> &'static str { PLAYFAIR }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_grid(playfair.js,no-X-split)" }
    fn params_schema(&self) -> &'static [ParamSpec] { PF_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let (cells, skip, skipto) = grid(PLAYFAIR, params)?;
        let e = ed(PLAYFAIR, params)?;
        let leave = params.opt_bool("doubleencode", false);
        let inside = |c: u8| cells.contains(&c);

        let mut out: Vec<u8> = Vec::with_capacity(input.data.len());
        let mut enc: Vec<u8> = Vec::with_capacity(2);
        let mut bet: Vec<u8> = Vec::new();
        for &raw in input.data.iter() {
            let mut c = raw.to_ascii_uppercase();
            if c == skip { c = skipto; }
            if inside(c) {
                enc.push(if raw.is_ascii_lowercase() { c.to_ascii_lowercase() } else { c });
                if enc.len() == 2 {
                    let (t1, t2) = pf_lookup(e, enc[0], enc[1], &cells, leave);
                    out.push(t1);
                    out.extend(bet.drain(..));
                    out.push(t2);
                    enc.clear();
                }
            } else if !enc.is_empty() {
                bet.push(raw);
            } else {
                out.push(raw);
            }
        }
        if !enc.is_empty() {
            // the site's tail call omits `flags`, so the shift branch always runs
            let (t1, t2) = pf_lookup(e, enc[0], b'X', &cells, false);
            out.push(t1);
            out.extend(bet.drain(..));
            out.push(t2);
        } else {
            out.extend(bet.drain(..));
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(RUMKIN_BIFID => || Box::new(RumkinBifid));
register_node!(RUMKIN_PLAYFAIR => || Box::new(RumkinPlayfair));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn n(name: &str) -> &'static dyn Node { registry().get(name).unwrap() }

    #[test]
    fn both_are_xf() {
        for x in [BIFID, PLAYFAIR] { assert_eq!(n(x).family(), Family::Xf); }
    }

    /// The grid trick: prepend the skip letter, then drop position 0.
    #[test]
    fn grid_omits_the_skip_letter_whichever_it_is() {
        let p = params! {"key" => "ZOMBIES"};
        let (g, skip, skipto) = grid(BIFID, &p).unwrap();
        assert_eq!(g.len(), 25);
        assert!(!g.contains(&b'J'), "default skip J must be absent");
        assert_eq!((skip, skipto), (b'J', b'I'));

        let q = params! {"key" => "ZOMBIES", "skip" => "Q", "skipto" => "K"};
        let (g2, s2, t2) = grid(BIFID, &q).unwrap();
        assert!(!g2.contains(&b'Q'), "a non-default skip must also work");
        assert!(g2.contains(&b'J'));
        assert_eq!((s2, t2), (b'Q', b'K'));
    }

    /// skip == skipto is advanced rather than rejected.
    #[test]
    fn identical_skip_and_skipto_is_advanced() {
        let p = params! {"skip" => "A", "skipto" => "A"};
        let (_, s, t) = grid(BIFID, &p).unwrap();
        assert_eq!((s, t), (b'A', b'B'));
        let q = params! {"skip" => "Z", "skipto" => "Z"};
        let (_, s2, t2) = grid(BIFID, &q).unwrap();
        assert_eq!((s2, t2), (b'Z', b'A'), "Z wraps to A");
    }

    #[test]
    fn bifid_round_trips_and_keeps_layout() {
        let p = params! {"key" => "ZOMBIES"};
        let msg = b"Defend the east wall!".to_vec();
        let e = n(BIFID).apply(&Repr::bytes(msg.clone()), &p.clone().set("direction", "encrypt")).unwrap();
        let d = n(BIFID).apply(&e, &p).unwrap();
        assert_eq!(d.data, msg);
        // spaces and punctuation stay exactly where they were
        assert_eq!(e.data.len(), msg.len());
        assert_eq!(e.data[6], b' ');
        assert_eq!(*e.data.last().unwrap(), b'!');
    }

    #[test]
    fn playfair_round_trips() {
        let p = params! {"key" => "PLAYFAIR EXAMPLE"};
        let msg = b"HIDETHEGOLD".to_vec();
        let e = n(PLAYFAIR).apply(&Repr::bytes(msg.clone()), &p.clone().set("direction","encrypt")).unwrap();
        let d = n(PLAYFAIR).apply(&e, &p).unwrap();
        // odd length: the tail letter was paired with X, so the round trip returns
        // one extra character
        assert!(d.data.starts_with(b"HIDETHEGOLD"), "got {:?}", String::from_utf8_lossy(&d.data));
    }

    /// A non-grid character between a pair's two letters is re-emitted BETWEEN the
    /// two enciphered letters, not before them.
    #[test]
    fn playfair_reinserts_interleaved_characters_inside_the_pair() {
        let p = params! {"key" => "ZOMBIES", "direction" => "encrypt"};
        let out = n(PLAYFAIR).apply(&Repr::bytes(b"A B".to_vec()), &p).unwrap();
        assert_eq!(out.data.len(), 3);
        assert_eq!(out.data[1], b' ', "the space lands between the two output letters");
    }

    /// doubleencode leaves a same-letter pair untouched; without it the pair shifts.
    #[test]
    fn doubleencode_flag_controls_same_letter_pairs() {
        let base = params! {"key" => "ZOMBIES", "direction" => "encrypt"};
        let shifted = n(PLAYFAIR).apply(&Repr::bytes(b"AA".to_vec()), &base).unwrap();
        let left = n(PLAYFAIR)
            .apply(&Repr::bytes(b"AA".to_vec()), &base.clone().set("doubleencode", true))
            .unwrap();
        assert_eq!(left.data, b"AA", "flag set -> unchanged");
        assert_ne!(shifted.data, b"AA", "flag clear -> diagonal shift");
    }

    /// The tail call omits flags, so a trailing letter is shifted even when
    /// doubleencode is set — provided the tail pairs with an identical X.
    #[test]
    fn playfair_trailing_letter_ignores_the_flag() {
        let p = params! {"key" => "ZOMBIES", "doubleencode" => true, "direction" => "encrypt"};
        let out = n(PLAYFAIR).apply(&Repr::bytes(b"X".to_vec()), &p).unwrap();
        // "X"+"X" is a same-letter pair; with flags omitted it must still move
        assert_ne!(out.data, b"XX");
        assert_eq!(out.data.len(), 2);
    }
}
