//! Vanity code (phone-keypad letters-to-numbers), matching
//! geocachingtoolbox.com's implementation — "multiple numbers" mode only.
//!
//! The site has two mutually exclusive `num2char` modes, selected by a
//! checkbox:
//!
//! - **multiple numbers** (each keypress recorded explicitly, e.g. `4` `4`
//!   `4` for a `4` pressed three times as one digit-group, so decoding is
//!   unambiguous — implemented here as [`decode`]);
//! - **single number** (`44` is *one* digit-group meaning "the third letter
//!   on key 4, OR key 4 pressed a different number of times" — genuinely
//!   ambiguous, and the site resolves it by looking a whole word up in a
//!   dictionary variable (`dict[splitChars[i]]`) that is referenced in the
//!   scraped JavaScript but never defined there — it is loaded from a
//!   separate, per-language data file this repo does not have. That mode is
//!   **not implementable as a pure byte transform** and is skipped entirely;
//!   there is no parameter that selects it.
//!
//! `char2num` (letters to digit-groups) needs no dictionary either way and is
//! fully deterministic, but this crate is decrypt-direction, so it is a
//! test-only helper (`encode`) here, used to produce ground-truth ciphertext
//! for [`decode`] to round-trip against — including the trailing `?` the
//! site's own round trip produces (see the module's test for why: the
//! encoder appends a space after every digit-group, including the last,
//! which the decoder's `split(' ')` then reads back as a spurious empty
//! trailing group).
//!
//! # Preprocessing (both directions, verbatim from the site)
//!
//! Before anything else, every run of whitespace (after normalising
//! `\r\n`/`\n`/`\r` to a plain space) collapses to a single space.
//!
//! # Space encoding
//!
//! `vanityCodeSpace` (`"1"` by default) sets which digit-group means a space
//! in the digit alphabet: `"1"` for space and `"0"` for "unrecognised
//! character" (the `char2num` default), or swapped if set to `"0"`.
//!
//! # Artifacts
//!
//! Output is written into `vanityCodeDiv` via `.innerHTML =`
//! (`copy_artifact_risk: HIGH`), so the default [`OutputFmt`] carries a
//! trailing CRLF.

use crate::classical::toolfmt::{read_input_norm, read_output_fmt, InputNorm, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::repr::Repr;
use crate::{artifact_param_specs, register_node};

const VANITY_SCHEMA: &[ParamSpec] = &artifact_param_specs!(ParamSpec::opt(
    "space_value",
    ParamType::Str,
    "which of \"0\"/\"1\" the digit-group for a space is (default \"1\"); the \
     other value means \"unrecognised character\" in char2num",
));

/// `multipleNums[0..26]` from the site, one digit-group per letter a-z. Index
/// 26 (the space's code) is not fixed and is supplied separately.
const MULTI_NUMS: [&str; 26] = [
    "2", "22", "222", "3", "33", "333", "4", "44", "444", "5", "55", "555", "6", "66", "666", "7",
    "77", "777", "7777", "8", "88", "888", "9", "99", "999", "9999",
];

fn default_space_value() -> &'static str {
    "1"
}

/// Collapse `\r\n`/`\n`/`\r` and every run of ASCII whitespace to a single
/// space, exactly like the site's `text.replace(/(\r\n|\n|\r)/gm,' ');
/// text.replace(/\s+/g,' ')`.
fn collapse_whitespace(input: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    let mut in_ws = false;
    for &b in input {
        if b.is_ascii_whitespace() {
            if !in_ws {
                out.push(b' ');
                in_ws = true;
            }
        } else {
            out.push(b);
            in_ws = false;
        }
    }
    out
}

/// Decode digit-groups (space-separated) back to letters/spaces, "multiple
/// numbers" mode. Unmatched groups (including the empty group a trailing
/// separator produces) become `?`, exactly like the site.
pub fn decode(text: &[u8], space_value: &str) -> Vec<u8> {
    let collapsed = collapse_whitespace(text);
    let filtered: Vec<u8> = collapsed
        .iter()
        .copied()
        .filter(|&b| b.is_ascii_digit() || b == b' ')
        .collect();

    let mut out = Vec::new();
    for group in filtered.split(|&b| b == b' ') {
        if group == space_value.as_bytes() {
            out.push(b' ');
        } else if let Some(idx) = MULTI_NUMS.iter().position(|&c| c.as_bytes() == group) {
            out.push(b'a' + idx as u8);
        } else {
            out.push(b'?');
        }
    }
    out
}

/// Encode letters/spaces into digit-groups, "multiple numbers" mode: every
/// token (matched or not) is followed by a single space, including the last.
/// Test-only: this crate is decrypt-direction, so nothing but the test suite
/// (proving [`decode`] agrees with the site's algorithm) needs it.
#[cfg(test)]
fn encode(text: &[u8], space_value: &str, unknown_value: &str) -> Vec<u8> {
    let collapsed = collapse_whitespace(text);
    let mut out = Vec::new();
    for &b in &collapsed {
        let lower = b.to_ascii_lowercase();
        if lower == b' ' {
            out.extend_from_slice(space_value.as_bytes());
        } else if lower.is_ascii_lowercase() {
            out.extend_from_slice(MULTI_NUMS[(lower - b'a') as usize].as_bytes());
        } else {
            out.extend_from_slice(unknown_value.as_bytes());
        }
        out.push(b' ');
    }
    out
}

fn default_input_norm() -> InputNorm {
    InputNorm::default()
}

fn default_output_fmt() -> OutputFmt {
    OutputFmt {
        trailing: Trailing::CrLf,
        ..Default::default()
    }
}

/// Vanity code (phone-keypad), decrypting: digit-groups to letters, "multiple
/// numbers" mode only (see module docs for why "single number" mode is
/// unimplementable).
pub struct Vanity;

impl Node for Vanity {
    fn name(&self) -> &'static str {
        "vanity"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        VANITY_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let space_value = params
            .opt_str("space_value")
            .unwrap_or(default_space_value());
        if space_value != "0" && space_value != "1" {
            return Err(Error::bad_param(
                "vanity",
                "space_value",
                format!("expected \"0\" or \"1\", got {space_value:?}"),
            ));
        }

        let in_norm = read_input_norm("vanity", params, default_input_norm())?;
        let out_fmt = read_output_fmt("vanity", params, default_output_fmt())?;

        let normalised = in_norm.apply(&input.data);
        let transformed = decode(&normalised, space_value);
        let formatted = out_fmt.apply(&transformed);

        Ok(Repr::new(formatted, input.display))
    }
}

register_node!(VANITY => || Box::new(Vanity));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    #[test]
    fn collapse_whitespace_collapses_runs_and_crlf() {
        assert_eq!(collapse_whitespace(b"a  b\t\tc\r\nd"), b"a b c d");
    }

    #[test]
    fn encode_hello_world_default_space_value() {
        let e = encode(b"hello world", "1", "0");
        assert_eq!(e, b"44 33 555 555 666 1 9 666 777 555 3 ");
    }

    #[test]
    fn decode_hello_world_matches_site_ground_truth() {
        // ground truth computed from a direct transliteration of the site's
        // algorithm (see module docs); the trailing '?' is genuine site
        // behaviour, not a bug — the encoder's trailing space becomes an
        // empty final group on decode.
        let decoded = decode(b"44 33 555 555 666 1 9 666 777 555 3 ", "1");
        assert_eq!(decoded, b"hello world?");
    }

    #[test]
    fn decode_matches_encode_modulo_trailing_question_mark() {
        let samples: &[&[u8]] = &[b"hello world", b"the quick brown fox", b"zzz aaa", b"a"];
        for sample in samples {
            let encoded = encode(sample, "1", "0");
            let decoded = decode(&encoded, "1");
            let mut want = sample.to_vec();
            want.push(b'?');
            assert_eq!(decoded, want, "sample={sample:?} encoded={encoded:?}");
        }
    }

    #[test]
    fn decode_without_trailing_separator_round_trips_exactly() {
        // Strip the encoder's trailing space by hand: no spurious empty
        // final group, so the round trip is exact.
        let mut encoded = encode(b"hello", "1", "0");
        encoded.pop(); // trailing space
        assert_eq!(decode(&encoded, "1"), b"hello");
    }

    #[test]
    fn decode_unmatched_group_becomes_question_mark() {
        assert_eq!(decode(b"99999", "1"), b"?");
    }

    #[test]
    fn decode_swapped_space_value() {
        // space_value "0": digit-group "0" means space, "1" means unknown.
        let encoded = encode(b"ab cd", "0", "1");
        assert_eq!(decode(&encoded, "0")[..], b"ab cd?"[..]);
    }

    #[test]
    fn decode_strips_non_digit_non_space_bytes_before_splitting() {
        // "4x4" -> "44" (index 7, 'h'); "3y3" -> "33" (index 4, 'e').
        assert_eq!(decode(b"4x4 3y3", "1"), b"he");
    }

    #[test]
    fn vanity_node_decodes_default_no_params() {
        let n = registry().get("vanity").unwrap();
        let p = params! {};
        let out = n
            .apply(&Repr::bytes(b"44 33 555 555 666".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"hello\r\n");
    }

    #[test]
    fn vanity_default_output_has_trailing_crlf() {
        let n = registry().get("vanity").unwrap();
        let p = params! {};
        let out = n.apply(&Repr::bytes(b"2".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"a\r\n");
    }

    #[test]
    fn vanity_trailing_can_be_disabled_via_param() {
        let n = registry().get("vanity").unwrap();
        let p = params! {"trailing" => "none"};
        let out = n.apply(&Repr::bytes(b"2".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"a");
    }

    #[test]
    fn vanity_node_rejects_invalid_space_value() {
        let n = registry().get("vanity").unwrap();
        let p = params! {"space_value" => "5"};
        let err = n.apply(&Repr::bytes(b"2".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn vanity_preserves_display() {
        let n = registry().get("vanity").unwrap();
        let p = params! {};
        let out = n
            .apply(&Repr::new(b"2".to_vec(), Display::Hex), &p)
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn vanity_is_xf_family_and_not_layer_forming() {
        let n = registry().get("vanity").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
