# Rumkin coverage: 27 of 27 accounted for

Source of truth: `docs/toolsites/rumkin_full.json` — 27 tool pages plus the **15
shared JS libraries** recovered from 2015/2016 Wayback captures. The algorithms are
NOT in each page's inline script (that is UI plumbing only); they live in
`/tools/cipher/js/*.js`, which earlier work did not have. `util.js`'s `Tr` and
`InsertCRLF` had previously to be reconstructed from the pages' prose.

## Implemented as faithful nodes (24 of 27 tools, 19 nodes)

| tool | node |
|---|---|
| Affine | `rumkin_affine` |
| Atbash | `rumkin_atbash` |
| Baconian | `rumkin_baconian` |
| Base64 | `codec:b64encode` / `codec:b64decode` — verified byte-identical to `base64.js` |
| Bifid | `rumkin_bifid` (periodless, as the site is) |
| Caesar / Keyed Caesar / ROT13 | `rumkin_caesar` (`key` optional, `n=13` for ROT13) |
| Column Trans. / Double | `rumkin_coltrans`, `rumkin_coltrans_double` |
| Gronsfeld | `rumkin_gronsfeld` |
| Manipulator | `rumkin_manipulate` |
| Morse | `rumkin_morse` |
| Numbers | `rumkin_numbers` |
| One Time Pad | `rumkin_otp` |
| Playfair | `rumkin_playfair` |
| Railfence | `rumkin_railfence` |
| Rotate | `rotate` (pre-existing; verified line-by-line against `rotate.js`) |
| Skip | `skip` (pre-existing) |
| Substitution | `rumkin_substitution` |
| Übchi | `rumkin_ubchi` |
| Vigenere / Keyed / Autokey | `rumkin_vigenere` (`key`, `autokey`) |

## Deliberately NOT nodes (3 of 27)

These are not ciphers, so they cannot be `Family::Xf` and must never carry coverage:

* **Cryptogram** — a puzzle *generator*. It enciphers with a **random** key, so it is
  non-deterministic and has no inverse to model. A node claiming coverage for it would
  be claiming to have searched a space it cannot reproduce.
* **Cryptogram Solver** — an interactive solving aid (partial-mapping guesswork).
  Would be `Family::Solver` and terminal; the existing sweep machinery already covers
  the search it automates.
* **Frequency** — letter-frequency analysis, i.e. a measurement, not a transform.
  `ra-oracle`'s `ioc-english` and the corpus statistics already provide this.

## Site quirks reproduced, each pinned by a test

| tool | behaviour a clean implementation would get wrong |
|---|---|
| Caesar | **swaps key and alphabet** on decode; keyed decode is not a negative shift |
| Affine | inverse loop hardcodes `% 26` and steps odd-only — wrong over non-26 alphabets, hangs on even multipliers |
| Vigenere | non-alphabetic characters never consume a key position |
| Übchi | pads with `'Z'` by the keyword's **word count** ("ZEBRA CAT" pads 2) |
| coltrans | `ahpla` only flips **tie-breaking**; it is not reverse-alphabetical |
| OTP | refills an exhausted pad with `A`s, emitting the tail **in clear** |
| Railfence | refuses when `rails >= text length` (the site returns the error *as* output) |
| Playfair | **no X-splitting**; doubled pairs shift diagonally, and the tail call drops `flags` |
| Playfair | interleaved non-grid characters re-emitted **between** the output pair |
| Bifid | **periodless** — fractionates the whole message |
| Numbers | greedy 2-digit decode makes unpadded output **lossy** (`AB` -> `12` -> `L`) |
| Morse | `!` appears **twice** with different codes; first match wins |
| Rotate | not self-inverting for a fixed `cols` — decoding needs the *rotated* grid's width |
