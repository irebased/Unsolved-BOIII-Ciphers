//! Ook!/Ook?/Ook. <-> Brainfuck <-> "Ook-short" command substitution, matching
//! geocachingtoolbox.com's `brainfuckOok` tool's non-executing conversions.
//!
//! # Ground truth
//!
//! `docs/toolsites/geocachingtoolbox.json`, tool `"Brainfuck & Ook! code"`
//! (`page_id: "brainfuckOok"`). `ook2bf`/`bf2ook`/`bf2ookshort`/
//! `ookshort2bf`/`ookshort2ook`/`ook2ookShort` were run verbatim under Node
//! (no DOM shim needed -- these six functions are pure string transforms with
//! no `document` access) to produce every vector in the test module below.
//!
//! # Scope: command substitution only, not execution
//!
//! The site's tool has twelve modes; six of them (`bf2ook`, `ook2bf`,
//! `bf2ookshort`, `ookshort2bf`, `ookshort2ook`, `ook2ookshort`) are the pure,
//! deterministic command-substitution ported here. The other six
//! (`bf2txt`/`txt2bf`/`ook2txt`/`txt2ook`/`ookshort2txt`/`txt2ookshort`) round-trip
//! through *executing* Brainfuck via a `doRun` function that is referenced by
//! the tool's `brainfuckOokRun` but is **not present** in the scraped
//! `javascript` field (it is presumably defined in a separate, unscraped
//! script). Reimplementing a Brainfuck interpreter under an assumed-standard
//! semantics (tape size, negative-pointer and `,`/EOF behaviour) without the
//! site's actual `doRun` to check it against would not meet this port's "exactly
//! as the site implements it" bar, so those six modes are cut here rather than
//! guessed at. This is a scope decision made under time pressure, not an
//! oversight — see the task report for the corresponding priority call.
//!
//! # Command mapping
//!
//! | Brainfuck | Ook!/Ook?/Ook.      | Ook-short |
//! |-----------|---------------------|-----------|
//! | `>`       | `Ook. Ook? `        | `.?`      |
//! | `<`       | `Ook? Ook. `        | `?.`      |
//! | `+`       | `Ook. Ook. `        | `..`      |
//! | `-`       | `Ook! Ook! `        | `!!`      |
//! | `.`       | `Ook! Ook. `        | `!.`      |
//! | `,`       | `Ook. Ook! `        | `.!`      |
//! | `[`       | `Ook! Ook? `        | `!?`      |
//! | `]`       | `Ook? Ook! `        | `?!`      |
//!
//! `Bf -> Ook`/`Bf -> OokShort` skip any byte that isn't one of the eight
//! commands above (matching `possibleCommands.indexOf(...)>-1` guarding every
//! append in the site's `bf2ook`/`bf2ookshort`). `Ook -> *`/`OokShort -> *`
//! tokenise on ASCII whitespace first (see [`ook_tokens`]), which is a
//! deliberate simplification of the site's byte-by-byte sliding-window scan —
//! functionally identical for any input that actually consists of
//! space-separated `Ook.`/`Ook!`/`Ook?` words (which is the only input the
//! site's own encoder ever produces), and verified against the site's ground
//! truth below.
//!
//! # Direction
//!
//! Every one of the six supported conversions is its own exact inverse pair
//! (`Ook -> Bf` inverts `Bf -> Ook` losslessly, since the mapping is a
//! bijection on the eight commands with no ambiguity in either alphabet), so
//! — like [`crate::classical::dvorak_keyboard`] — this is a symmetric
//! substitution, not an encrypt/decrypt pair. Both directions are already
//! reachable through the `from`/`to` params; no test-only encode helper is
//! needed.
//!
//! # Artifacts
//!
//! `output_element: "bfookInput"`, `output_method: "value"`
//! (`copy_artifact_risk: "LOW"`): the site writes into an `<input>` via
//! `.value =`, not `.innerHTML`, so — unlike every other node in this module
//! — the default here is a *clean* copy: `Trailing::None`.

use crate::classical::toolfmt::{read_output_fmt, CaseFold, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const NAME: &str = "ook_bf";

const SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "from",
        ParamType::Str,
        "source dialect: bf|ook|ook_short (default: ook, the site's default fromType \
         for this tool group)",
    ),
    ParamSpec::opt(
        "to",
        ParamType::Str,
        "destination dialect: bf|ook|ook_short (default: bf, the site's default toType)",
    ),
);

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Dialect {
    Bf,
    Ook,
    OokShort,
}

impl Dialect {
    fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "bf" => Dialect::Bf,
            "ook" => Dialect::Ook,
            "ook_short" => Dialect::OokShort,
            _ => return None,
        })
    }
}

/// The eight commands in a fixed order, paired with each dialect's spelling.
/// `(bf, ook_word_pair, ook_short)`.
const COMMANDS: &[(u8, (&str, &str), &str)] = &[
    (b'>', ("Ook.", "Ook?"), ".?"),
    (b'<', ("Ook?", "Ook."), "?."),
    (b'+', ("Ook.", "Ook."), ".."),
    (b'-', ("Ook!", "Ook!"), "!!"),
    (b'.', ("Ook!", "Ook."), "!."),
    (b',', ("Ook.", "Ook!"), ".!"),
    (b'[', ("Ook!", "Ook?"), "!?"),
    (b']', ("Ook?", "Ook!"), "?!"),
];

fn bf_to_ook_words(bf: u8) -> Option<(&'static str, &'static str)> {
    COMMANDS.iter().find(|(c, _, _)| *c == bf).map(|(_, w, _)| *w)
}
fn bf_to_short(bf: u8) -> Option<&'static str> {
    COMMANDS.iter().find(|(c, _, _)| *c == bf).map(|(_, _, s)| *s)
}
fn ook_words_to_bf(a: &str, b: &str) -> Option<u8> {
    COMMANDS
        .iter()
        .find(|(_, (w0, w1), _)| *w0 == a && *w1 == b)
        .map(|(c, _, _)| *c)
}
fn short_to_bf(tok: &str) -> Option<u8> {
    COMMANDS.iter().find(|(_, _, s)| *s == tok).map(|(c, _, _)| *c)
}

/// Tokenise on ASCII whitespace and keep only `Ook.`/`Ook!`/`Ook?` words, in
/// order — a simplification of the site's byte-by-byte sliding-window scan
/// (see module doc) that agrees with it for well-formed input.
fn ook_tokens(input: &[u8]) -> Vec<&str> {
    let s = std::str::from_utf8(input).unwrap_or("");
    s.split_ascii_whitespace()
        .filter(|t| *t == "Ook." || *t == "Ook!" || *t == "Ook?")
        .collect()
}

fn bf_to_ook(input: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    for &b in input {
        if let Some((w0, w1)) = bf_to_ook_words(b) {
            out.extend_from_slice(w0.as_bytes());
            out.push(b' ');
            out.extend_from_slice(w1.as_bytes());
            out.push(b' ');
        }
    }
    out
}

fn bf_to_ook_short(input: &[u8]) -> Vec<u8> {
    input.iter().filter_map(|&b| bf_to_short(b)).flat_map(|s| s.bytes()).collect()
}

fn ook_to_bf(input: &[u8]) -> Vec<u8> {
    let tokens = ook_tokens(input);
    tokens
        .chunks_exact(2)
        .filter_map(|pair| ook_words_to_bf(pair[0], pair[1]))
        .collect()
}

fn ook_short_to_bf(input: &[u8]) -> Vec<u8> {
    let s = std::str::from_utf8(input).unwrap_or("");
    let compact: String = s.chars().filter(|c| !c.is_whitespace()).collect();
    let bytes = compact.as_bytes();
    let mut out = Vec::new();
    let mut i = 0;
    while i + 2 <= bytes.len() {
        if let Some(c) = short_to_bf(&compact[i..i + 2]) {
            out.push(c);
        }
        i += 2;
    }
    out
}

fn ook_to_ook_short(input: &[u8]) -> Vec<u8> {
    let tokens = ook_tokens(input);
    let mut out = Vec::new();
    for pair in tokens.chunks_exact(2) {
        if let Some(bf) = ook_words_to_bf(pair[0], pair[1]) {
            if let Some(s) = bf_to_short(bf) {
                out.extend_from_slice(s.as_bytes());
            }
        }
    }
    out
}

fn ook_short_to_ook(input: &[u8]) -> Vec<u8> {
    let bf = ook_short_to_bf(input);
    bf_to_ook(&bf)
}

fn convert(from: Dialect, to: Dialect, input: &[u8]) -> Result<Vec<u8>> {
    Ok(match (from, to) {
        (Dialect::Bf, Dialect::Ook) => bf_to_ook(input),
        (Dialect::Bf, Dialect::OokShort) => bf_to_ook_short(input),
        (Dialect::Ook, Dialect::Bf) => ook_to_bf(input),
        (Dialect::Ook, Dialect::OokShort) => ook_to_ook_short(input),
        (Dialect::OokShort, Dialect::Bf) => ook_short_to_bf(input),
        (Dialect::OokShort, Dialect::Ook) => ook_short_to_ook(input),
        (a, b) if a == b => {
            return Err(Error::node_failed(
                NAME,
                "from and to are the same dialect; nothing to convert",
            ))
        }
        _ => unreachable!("all six from!=to combinations are handled above"),
    })
}

pub struct OokBf;

impl Node for OokBf {
    fn name(&self) -> &'static str {
        NAME
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/ook_bf(geocachingtoolbox.com brainfuckOok tool, \
         command substitution only, not execution)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let from = match params.opt_str("from") {
            Some(s) => Dialect::parse(s).ok_or_else(|| {
                Error::bad_param(NAME, "from", format!("expected bf|ook|ook_short, got {s:?}"))
            })?,
            None => Dialect::Ook,
        };
        let to = match params.opt_str("to") {
            Some(s) => Dialect::parse(s).ok_or_else(|| {
                Error::bad_param(NAME, "to", format!("expected bf|ook|ook_short, got {s:?}"))
            })?,
            None => Dialect::Bf,
        };

        let converted = convert(from, to, &input.data)?;

        let fmt = read_output_fmt(
            NAME,
            params,
            OutputFmt {
                case: CaseFold::Preserve,
                grouping: None,
                trailing: Trailing::None, // .value = write: LOW copy_artifact_risk
            },
        )?;
        Ok(Repr::new(fmt.apply(&converted), Display::Bytes))
    }
}

register_node!(OOK_BF => || Box::new(OokBf));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn node() -> &'static dyn Node {
        registry().get(NAME).unwrap()
    }

    fn run(from: &str, to: &str, text: &[u8]) -> Vec<u8> {
        node()
            .apply(
                &Repr::bytes(text.to_vec()),
                &params! {"from" => from, "to" => to},
            )
            .unwrap()
            .data
    }

    const BF: &[u8] = b"++++++++[>++++++++<-]>+.";

    /// Ground truth: `node run_bfook.js`, calling the site's own
    /// `bf2ook`/`ook2bf`/`bf2ookshort`/`ookshort2bf`/`ookshort2ook`/
    /// `ook2ookShort` directly (pure functions, no DOM needed).
    #[test]
    fn ground_truth_from_site_js() {
        let ook = run("bf", "ook", BF);
        assert_eq!(
            ook,
            b"Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. \
              Ook! Ook? Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. \
              Ook. Ook. Ook. Ook. Ook? Ook. Ook! Ook! Ook? Ook! Ook. Ook? Ook. Ook. Ook! Ook. "
        );
        assert_eq!(run("ook", "bf", &ook), BF);

        let short = run("bf", "ook_short", BF);
        assert_eq!(short, b"................!?.?................?.!!?!.?..!.");
        assert_eq!(run("ook_short", "bf", &short), BF);
        assert_eq!(run("ook_short", "ook", &short), ook);
        assert_eq!(run("ook", "ook_short", &ook), short);

        // all eight commands, both directions
        assert_eq!(
            run("bf", "ook", b"><+-.,[]"),
            "Ook. Ook? Ook? Ook. Ook. Ook. Ook! Ook! Ook! Ook. Ook. Ook! Ook! Ook? Ook? Ook! "
                .as_bytes()
        );
        assert_eq!(run("bf", "ook_short", b"><+-.,[]"), b".??...!!!..!!??!");
    }

    #[test]
    fn bf_to_ook_drops_unrecognised_bytes() {
        assert_eq!(run("bf", "ook", b"+x-"), run("bf", "ook", b"+-"));
    }

    #[test]
    fn round_trip_all_six_pairs() {
        for (from, to) in [
            ("bf", "ook"),
            ("bf", "ook_short"),
            ("ook", "ook_short"),
        ] {
            // Seed `source` in `from`'s own dialect (converting from BF when
            // `from` isn't already `bf`), so the round trip actually starts
            // and ends on the same representation.
            let source = if from == "bf" { BF.to_vec() } else { run("bf", from, BF) };
            let there = run(from, to, &source);
            let back = run(to, from, &there);
            assert_eq!(back, source, "from={from} to={to}");
        }
    }

    #[test]
    fn same_from_and_to_errors() {
        let err = node()
            .apply(
                &Repr::bytes(BF.to_vec()),
                &params! {"from" => "bf", "to" => "bf"},
            )
            .unwrap_err();
        assert!(matches!(err, Error::NodeFailed { .. }), "{err}");
    }

    #[test]
    fn malformed_dialect_is_rejected() {
        let err = node()
            .apply(
                &Repr::bytes(BF.to_vec()),
                &params! {"from" => "sideways", "to" => "bf"},
            )
            .unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    /// `.value =` write: clean by default, unlike the `.innerHTML` tools
    /// elsewhere in this module.
    #[test]
    fn node_default_trailing_is_clean() {
        let out = node()
            .apply(&Repr::bytes(b"+".to_vec()), &params! {"from" => "bf", "to" => "ook"})
            .unwrap();
        assert_eq!(out.data, b"Ook. Ook. ");
    }

    #[test]
    fn is_xf_family_and_not_layer_forming() {
        let n = node();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
