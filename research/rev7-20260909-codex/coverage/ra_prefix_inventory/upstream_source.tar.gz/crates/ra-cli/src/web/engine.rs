//! Generic combinatorial chain-sweep engine for `ra serve`.
//!
//! # Why this is not `crate::sweep`
//!
//! [`crate::sweep`] enumerates a fixed vocabulary of TG4/mcrypt-shaped skeletons
//! (`b64d ∘ dec`, `b64d ∘ xf ∘ dec`, `b64d ∘ dec ∘ xf ∘ codec ∘ dec`) with hardcoded
//! axis domains (primitive list, mode list, IV list, the `0.variant` transcription
//! axis, ...). The web API contract asks for something structurally different: an
//! **arbitrary ordered sequence of named, registered nodes**, each with its own
//! parameter values, exactly as the frontend's chain builder assembles it
//! (`beaufort -> b64decode -> des`, or any other combination the registry allows).
//! `sweep::Plan` has no representation for that — its skeleton vocabulary is closed
//! and its axis set is a fixed, named list of sweep-specific concepts, not "whatever
//! parameters the chosen node happens to declare".
//!
//! So this module is a second, small planner, built directly on the same
//! `ra_core` primitives every other front end uses (`registry`, `Chain`, `Step`,
//! `Params`) rather than on `sweep::Plan`. It keeps the property the spec cares
//! about — **one code path computes the count and enumerates the run** — by making
//! [`Plan::total_ops`] and [`Plan::candidate`] pure functions of the same
//! per-step radix list, decoded with the same mixed-radix scheme.
//!
//! `crate::sweep` itself is untouched: the CLI's `ra sweep` behaviour, including
//! its own `--dry-run` planner, is unchanged by this module's existence.
//!
//! # Slots: a set of candidate nodes per step, optionally skippable
//!
//! A chain step is not just one pinned node with value-set parameters — it is a
//! **slot**: a set of node *alternatives* (each with its own parameter axes), and
//! optionally a "skip this layer entirely" branch. This lets a request express
//! "try beaufort or vigenere here" (an axis over which *node* runs, not just which
//! parameters it runs with) and "optionally reverse here" (a layer that may or may
//! not be present at all) in the same vocabulary.
//!
//! The arithmetic, matched exactly by [`ResolvedStep::radix`] and
//! [`ResolvedStep::decode`] (the same function [`Plan::total_ops`] and
//! [`Plan::candidate`] both drive):
//! - one alternative's `combinations` = the product of its resolved param axis
//!   lengths (a node with no axes at all has `combinations == 1`).
//! - a step's `cardinality` = the **sum** of `combinations` over its alternatives
//!   (different alternatives are different nodes, not different values of the
//!   same axis, so they add rather than multiply).
//! - a step's `radix` (how many index values it consumes in the mixed-radix
//!   decode) = `cardinality + 1` if the step is optional (the `+1` is the "skip
//!   this layer" branch), else just `cardinality`. An optional step with zero
//!   alternatives therefore still has `radix == 1`: a no-op step that is always
//!   skipped, not a step that collapses the whole plan to zero candidates.
//! - `total_ops` = the product of every step's `radix`.

use std::collections::BTreeMap;

use ra_core::node::ParamType;
use ra_core::{registry, Chain, Params, Step, Value};
use serde::Deserialize;
use serde_json::Value as Json;

/// One candidate node for a slot: a node name plus the parameter value-sets the
/// request supplied for it.
#[derive(Clone, Debug, Deserialize)]
pub struct AltSpec {
    pub node: String,
    #[serde(default)]
    pub params: BTreeMap<String, Vec<Json>>,
}

/// One chain slot. Accepts two shapes on the wire:
///
/// - the current, single-node shape `{"node":"x","params":{...}}`, kept
///   unchanged as sugar for a single-alternative, non-optional slot — existing
///   clients and tests must not break.
/// - the new shape `{"optional":bool,"alternatives":[AltSpec, ...]}`, a genuine
///   set of candidate nodes for the slot, optionally skippable.
///
/// `#[serde(untagged)]` tries `Slot` first (it requires the `alternatives` key,
/// which the old shape never has, so the old shape always falls through to
/// `Single`) and `Single` second.
#[derive(Clone, Debug, Deserialize)]
#[serde(untagged)]
pub enum StepSpec {
    Slot {
        #[serde(default)]
        optional: bool,
        alternatives: Vec<AltSpec>,
    },
    Single(AltSpec),
}

impl StepSpec {
    fn optional(&self) -> bool {
        match self {
            StepSpec::Slot { optional, .. } => *optional,
            StepSpec::Single(_) => false,
        }
    }

    fn alternatives(&self) -> &[AltSpec] {
        match self {
            StepSpec::Slot { alternatives, .. } => alternatives,
            StepSpec::Single(a) => std::slice::from_ref(a),
        }
    }
}

#[derive(Clone, Debug, Deserialize)]
pub struct PlanRequest {
    pub target: String,
    pub steps: Vec<StepSpec>,
    #[serde(default)]
    pub oracle: Option<String>,
}

/// One (step, param) axis as resolved against some alternative's schema in that
/// step: the concrete, typed values a request supplied for that slot.
#[derive(Clone, Debug)]
pub struct Axis {
    pub step: usize,
    pub param: String,
    pub values: Vec<Value>,
}

#[derive(Clone, Debug)]
struct ResolvedAlt {
    node: String,
    /// Only params the request actually supplied values for. An optional param the
    /// request omitted contributes no axis at all — the node applies its own
    /// default for every candidate, exactly as `ra run` would with no override.
    axes: Vec<(String, Vec<Value>)>,
}

impl ResolvedAlt {
    fn combinations(&self) -> u64 {
        self.axes.iter().map(|(_, v)| v.len() as u64).product()
    }
}

#[derive(Clone, Debug)]
struct ResolvedStep {
    optional: bool,
    alternatives: Vec<ResolvedAlt>,
}

impl ResolvedStep {
    /// Sum of every alternative's `combinations` — see the module doc for why
    /// alternatives sum rather than multiply.
    fn cardinality(&self) -> u64 {
        self.alternatives.iter().map(ResolvedAlt::combinations).sum()
    }

    /// How many index values this step consumes in the mixed-radix decode:
    /// `cardinality`, plus one more for "skip this layer" when optional.
    fn radix(&self) -> u64 {
        self.cardinality() + u64::from(self.optional)
    }

    /// Decode `sel` (`< radix()`) into the concrete step for that selection, or
    /// `None` if `sel` landed on the "skip this optional layer" branch.
    fn decode(&self, sel: u64) -> Option<Step> {
        let mut rem = sel;
        for alt in &self.alternatives {
            let c = alt.combinations();
            if rem < c {
                let mut idx = rem;
                let mut params = Params::new();
                for (name, values) in &alt.axes {
                    let len = values.len() as u64;
                    let v = idx % len;
                    idx /= len;
                    params = params.set(name, values[v as usize].clone());
                }
                return Some(Step::new(alt.node.clone(), params));
            }
            rem -= c;
        }
        // Only reachable when `optional` and `sel == cardinality()`: the extra
        // "skip this layer" slot `radix()` adds beyond `cardinality()`.
        None
    }
}

#[derive(Debug)]
pub struct Plan {
    steps: Vec<ResolvedStep>,
}

pub struct AltCount {
    pub node: String,
    pub combinations: u64,
}

pub struct PerStep {
    pub step: usize,
    pub optional: bool,
    pub cardinality: u64,
    pub alternatives: Vec<AltCount>,
}

impl Plan {
    pub fn per_step(&self) -> Vec<PerStep> {
        self.steps
            .iter()
            .enumerate()
            .map(|(i, s)| PerStep {
                step: i,
                optional: s.optional,
                cardinality: s.cardinality(),
                alternatives: s
                    .alternatives
                    .iter()
                    .map(|a| AltCount {
                        node: a.node.clone(),
                        combinations: a.combinations(),
                    })
                    .collect(),
            })
            .collect()
    }

    /// Every resolved axis, across every alternative of every step.
    pub fn axes(&self) -> Vec<Axis> {
        let mut out = Vec::new();
        for (i, s) in self.steps.iter().enumerate() {
            for alt in &s.alternatives {
                for (name, values) in &alt.axes {
                    out.push(Axis {
                        step: i,
                        param: name.clone(),
                        values: values.clone(),
                    });
                }
            }
        }
        out
    }

    /// Total candidates. This is the product of every step's `radix` (its
    /// cardinality, plus one for "skip" when optional), computed the exact same
    /// way [`Plan::candidate`] decodes an index into one — so a reported
    /// `total_ops` can never drift from what a run actually enumerates.
    pub fn total_ops(&self) -> u64 {
        self.steps.iter().map(ResolvedStep::radix).product()
    }

    /// Materialise the concrete steps for candidate `idx` (`idx < total_ops()`).
    /// Mixed-radix decode over the same per-step radix [`Plan::total_ops`]
    /// multiplies together. A skipped optional step contributes no [`Step`] at
    /// all, so the returned chain can be shorter than `self.steps.len()`.
    pub fn candidate(&self, mut idx: u64) -> Vec<Step> {
        let mut steps = Vec::with_capacity(self.steps.len());
        for rs in &self.steps {
            let radix = rs.radix();
            let sel = idx % radix;
            idx /= radix;
            if let Some(step) = rs.decode(sel) {
                steps.push(step);
            }
        }
        steps
    }

    /// A validated `Chain` for candidate `idx`.
    pub fn chain(&self, idx: u64) -> Result<Chain, String> {
        Chain::new(self.candidate(idx)).map_err(|e| e.to_string())
    }

    /// A human-readable label naming the slot sequence, e.g.
    /// "beaufort/vigenere | [reverse] | des/blowfish" (`[...]` marks an optional
    /// slot).
    pub fn label(&self) -> String {
        self.steps
            .iter()
            .map(|s| {
                let names: Vec<&str> = s.alternatives.iter().map(|a| a.node.as_str()).collect();
                let joined = if names.is_empty() {
                    "-".to_string()
                } else {
                    names.join("/")
                };
                if s.optional {
                    format!("[{joined}]")
                } else {
                    joined
                }
            })
            .collect::<Vec<_>>()
            .join(" | ")
    }
}

fn coerce(node: &str, spec: &ra_core::ParamSpec, v: &Json) -> Result<Value, String> {
    match spec.ty {
        ParamType::Str | ParamType::Hex => match v.as_str() {
            Some(s) => Ok(Value::Str(s.to_string())),
            None => Err(format!(
                "node '{node}' parameter '{}': expected a string, got {v}",
                spec.name
            )),
        },
        ParamType::Int => match v.as_i64() {
            Some(i) => Ok(Value::Int(i)),
            None => Err(format!(
                "node '{node}' parameter '{}': expected an integer, got {v}",
                spec.name
            )),
        },
        ParamType::Bool => match v.as_bool() {
            Some(b) => Ok(Value::Bool(b)),
            None => Err(format!(
                "node '{node}' parameter '{}': expected a boolean, got {v}",
                spec.name
            )),
        },
    }
}

/// Build and validate a [`Plan`] from a request. Every failure here is meant to
/// become an HTTP 400 with the returned message verbatim.
pub fn build_plan(req: &PlanRequest) -> Result<Plan, String> {
    if req.steps.is_empty() {
        return Err("chain must have at least one step".to_string());
    }
    let reg = registry();
    let last = req.steps.len() - 1;
    let mut steps = Vec::with_capacity(req.steps.len());
    for (i, s) in req.steps.iter().enumerate() {
        let optional = s.optional();
        let alt_specs = s.alternatives();
        if alt_specs.is_empty() && !optional {
            return Err(format!(
                "step {i} has no alternatives and is not optional"
            ));
        }
        let mut alternatives = Vec::with_capacity(alt_specs.len());
        for a in alt_specs {
            let node = reg
                .get(&a.node)
                .ok_or_else(|| format!("unknown node '{}'", a.node))?;
            if node.terminal() && i != last {
                return Err(format!(
                    "terminal node '{}' must be the last step (found at index {i})",
                    a.node
                ));
            }
            let schema = node.params_schema();
            for key in a.params.keys() {
                if !schema.iter().any(|p| p.name == key) {
                    return Err(format!("unknown param '{key}' for node '{}'", a.node));
                }
            }
            let mut axes = Vec::new();
            for spec in schema {
                match a.params.get(spec.name) {
                    Some(vals) => {
                        if vals.is_empty() {
                            return Err(format!(
                                "param '{}' for node '{}' needs at least one value",
                                spec.name, a.node
                            ));
                        }
                        let mut out = Vec::with_capacity(vals.len());
                        for v in vals {
                            out.push(coerce(&a.node, spec, v)?);
                        }
                        axes.push((spec.name.to_string(), out));
                    }
                    None => {
                        if spec.required {
                            return Err(format!(
                                "node '{}' requires parameter '{}'",
                                a.node, spec.name
                            ));
                        }
                        // optional and unset: no axis, the node's own default applies.
                    }
                }
            }
            alternatives.push(ResolvedAlt {
                node: a.node.clone(),
                axes,
            });
        }
        steps.push(ResolvedStep {
            optional,
            alternatives,
        });
    }
    let plan = Plan { steps };
    // Structural validation (terminal placement, chain composition) against a
    // representative candidate (index 0: the first alternative of every step,
    // taken rather than skipped), via the same `Chain::new` every other front
    // end goes through.
    if plan.total_ops() > 0 {
        plan.chain(0)?;
    }
    Ok(plan)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn single(node: &str, params: &[(&str, Vec<Json>)]) -> StepSpec {
        StepSpec::Single(AltSpec {
            node: node.to_string(),
            params: params
                .iter()
                .map(|(k, v)| (k.to_string(), v.clone()))
                .collect(),
        })
    }

    fn alt(node: &str, params: &[(&str, Vec<Json>)]) -> AltSpec {
        AltSpec {
            node: node.to_string(),
            params: params
                .iter()
                .map(|(k, v)| (k.to_string(), v.clone()))
                .collect(),
        }
    }

    fn slot(optional: bool, alternatives: Vec<AltSpec>) -> StepSpec {
        StepSpec::Slot {
            optional,
            alternatives,
        }
    }

    #[test]
    fn total_ops_is_the_product_of_axis_lengths() {
        ra_prim::link();
        let req = PlanRequest {
            target: "tg4".to_string(),
            steps: vec![
                single(
                    "beaufort",
                    &[
                        ("key", vec![json!("TheGiant")]),
                        ("alphabet", vec![json!("ABC"), json!("abc")]),
                    ],
                ),
                single("b64decode", &[]),
                single(
                    "des",
                    &[
                        ("key", vec![json!("Zombies")]),
                        ("mode", vec![json!("cfb"), json!("ecb")]),
                    ],
                ),
            ],
            oracle: None,
        };
        let plan = build_plan(&req).unwrap();
        assert_eq!(plan.total_ops(), 4);
        let sum: u64 = plan.per_step().iter().map(|p| p.cardinality).sum::<u64>();
        // sanity: not literally meaningful to sum, but every step should be >=1
        assert!(sum >= 3);
        for i in 0..plan.total_ops() {
            plan.chain(i).unwrap();
        }
    }

    #[test]
    fn unknown_node_is_rejected() {
        ra_prim::link();
        let req = PlanRequest {
            target: "tg4".to_string(),
            steps: vec![single("no_such_node", &[])],
            oracle: None,
        };
        assert!(build_plan(&req).unwrap_err().contains("unknown node"));
    }

    #[test]
    fn unknown_param_is_rejected() {
        ra_prim::link();
        let req = PlanRequest {
            target: "tg4".to_string(),
            steps: vec![single("b64decode", &[("bogus", vec![json!(1)])])],
            oracle: None,
        };
        assert!(build_plan(&req).unwrap_err().contains("unknown param"));
    }

    #[test]
    fn missing_required_param_is_rejected() {
        ra_prim::link();
        let req = PlanRequest {
            target: "tg4".to_string(),
            steps: vec![single("beaufort", &[])],
            oracle: None,
        };
        let err = build_plan(&req).unwrap_err();
        assert!(err.contains("requires parameter"), "{err}");
    }

    #[test]
    fn bad_value_type_is_rejected() {
        ra_prim::link();
        let req = PlanRequest {
            target: "tg4".to_string(),
            steps: vec![single("rot", &[("n", vec![json!("not-an-int")])])],
            oracle: None,
        };
        let err = build_plan(&req).unwrap_err();
        assert!(err.contains("expected an integer"), "{err}");
    }

    /// The load-bearing arithmetic from the spec: a step with two alternatives of
    /// 2 and 3 combinations has cardinality 5 (a **sum**, since different
    /// alternatives are different nodes, not different values of one axis).
    /// Marking that step optional adds exactly one more branch ("skip"), so its
    /// contribution to `total_ops` becomes 6. Two such optional steps multiply:
    /// 6 * 6 = 36.
    #[test]
    fn alternatives_sum_and_optional_adds_one_skip_branch() {
        ra_prim::link();
        let two_combos = alt(
            "beaufort",
            &[
                ("key", vec![json!("TheGiant")]),
                ("alphabet", vec![json!("ABC"), json!("abc")]),
            ],
        );
        let three_combos = alt(
            "des",
            &[
                ("key", vec![json!("A"), json!("B"), json!("C")]),
                ("mode", vec![json!("cfb")]),
            ],
        );

        // Single non-optional step: cardinality 5.
        let req = PlanRequest {
            target: "tg4".to_string(),
            steps: vec![slot(false, vec![two_combos.clone(), three_combos.clone()])],
            oracle: None,
        };
        let plan = build_plan(&req).unwrap();
        let per_step = plan.per_step();
        assert_eq!(per_step.len(), 1);
        assert_eq!(per_step[0].cardinality, 5);
        assert_eq!(plan.total_ops(), 5);

        // Marking it optional adds one skip branch: 5 + 1 = 6 candidates.
        let req_opt = PlanRequest {
            target: "tg4".to_string(),
            steps: vec![slot(true, vec![two_combos.clone(), three_combos.clone()])],
            oracle: None,
        };
        let plan_opt = build_plan(&req_opt).unwrap();
        assert_eq!(plan_opt.per_step()[0].cardinality, 5);
        assert_eq!(plan_opt.total_ops(), 6);

        // Two such optional steps multiply: 6 * 6 = 36.
        let req_two = PlanRequest {
            target: "tg4".to_string(),
            steps: vec![
                slot(true, vec![two_combos.clone(), three_combos.clone()]),
                slot(true, vec![two_combos, three_combos]),
            ],
            oracle: None,
        };
        let plan_two = build_plan(&req_two).unwrap();
        assert_eq!(plan_two.total_ops(), 36);
        // Every candidate decodes; a chain only fails to construct (empty chain)
        // when *both* optional steps land on their skip branch, which `run_range`
        // (the actual executor) already tolerates the same way it tolerates any
        // other structurally invalid candidate: skip scoring, keep counting.
        let mut any_non_empty = false;
        for i in 0..plan_two.total_ops() {
            let steps = plan_two.candidate(i);
            if !steps.is_empty() {
                any_non_empty = true;
                Chain::new(steps).unwrap();
            }
        }
        assert!(any_non_empty);
    }

    /// An optional step with zero alternatives is a no-op step of radix 1 (always
    /// skipped), not zero — it must not collapse the whole plan's `total_ops` to
    /// zero.
    #[test]
    fn optional_step_with_no_alternatives_is_a_no_op_not_a_zero() {
        ra_prim::link();
        let req = PlanRequest {
            target: "tg4".to_string(),
            steps: vec![slot(true, vec![]), single("reverse", &[])],
            oracle: None,
        };
        let plan = build_plan(&req).unwrap();
        assert_eq!(plan.per_step()[0].cardinality, 0);
        assert_eq!(plan.total_ops(), 1);
        let steps = plan.candidate(0);
        assert_eq!(steps.len(), 1);
        assert_eq!(steps[0].node, "reverse");
    }

    /// A required (non-optional) step with zero alternatives is rejected outright
    /// rather than silently producing a zero-candidate plan.
    #[test]
    fn required_step_with_no_alternatives_is_rejected() {
        ra_prim::link();
        let req = PlanRequest {
            target: "tg4".to_string(),
            steps: vec![slot(false, vec![])],
            oracle: None,
        };
        let err = build_plan(&req).unwrap_err();
        assert!(err.contains("no alternatives"), "{err}");
    }

    /// An optional step genuinely skipped produces a chain without that node, and
    /// the emitted chain spec for such a candidate parses back via
    /// `crate::spec::parse_chain`.
    #[test]
    fn skipped_optional_step_omits_the_node_and_round_trips_through_chain_spec() {
        ra_prim::link();
        let req = PlanRequest {
            target: "tg4".to_string(),
            steps: vec![
                single("beaufort", &[("key", vec![json!("TheGiant")])]),
                slot(true, vec![alt("reverse", &[])]),
            ],
            oracle: None,
        };
        let plan = build_plan(&req).unwrap();
        // step 0: 1 combination (radix 1). step 1: optional, 1 alternative with 1
        // combination -> cardinality 1, radix 2 (take it, or skip it).
        assert_eq!(plan.total_ops(), 2);

        // idx 0 selects sel=0 for step 1 (< cardinality 1): reverse is taken.
        let taken = plan.candidate(0);
        assert_eq!(taken.len(), 2);
        assert_eq!(taken[1].node, "reverse");

        // idx 1 selects sel=1 for step 1 (== cardinality 1): the skip branch.
        let skipped = plan.candidate(1);
        assert_eq!(skipped.len(), 1);
        assert_eq!(skipped[0].node, "beaufort");

        let chain = Chain::new(skipped).unwrap();
        let rendered = crate::spec::render_chain(&chain);
        let reparsed = crate::spec::parse_chain(&rendered).unwrap();
        assert_eq!(reparsed.steps().len(), 1);
        assert_eq!(reparsed.steps()[0].node, "beaufort");
    }
}
