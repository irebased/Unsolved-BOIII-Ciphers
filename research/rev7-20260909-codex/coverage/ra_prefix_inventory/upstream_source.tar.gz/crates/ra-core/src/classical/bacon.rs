//! The Baconian cipher: five binary symbols per letter.
//!
//! # What the corpus documented, and what had to be recovered
//!
//! rev2's recorded solution chain is *"remove the `v` characters, hex decode, decrypt
//! DES/`CFB` key `ZOMBIES`, then `bacon`"*. It records the **name** of this step and
//! nothing else. Baconian has two classical variants and two symbol conventions, and
//! the record fixes neither:
//!
//! | question | classical options | **recovered from rev2** |
//! |---|---|---|
//! | alphabet | 24-letter (I=J, U=V) or 26-letter | **26-letter** |
//! | symbol for bit 0 | `A` or `B` | **`A`** |
//! | symbol for bit 1 | `B` or `A` | **`B`** |
//! | bit order | MSB first or LSB first | **MSB first** |
//!
//! The evidence is direct and does not need a search. rev2's DES layer emits
//! space-separated runs of `A` and `B` whose lengths are all multiples of five — the
//! first run is 40 symbols, and the recorded plaintext's first word is the 8-letter
//! `SAMANTHA`. So the words are delimited and the groups align with letters, which
//! pins the reading of the very first group `BAABA`:
//!
//! - `A`=0, `B`=1, MSB first → `10010` = 18 → 26-letter alphabet gives **`S`** ✅
//! - `A`=0, `B`=1, MSB first → `10010` = 18 → 24-letter alphabet gives `T` ✗
//! - `A`=1, `B`=0, MSB first → `01101` = 13 → 26-letter alphabet gives `N` ✗
//!
//! Carrying the same reading through the whole 2,212-symbol stream reproduces the
//! recorded plaintext, so the finding is confirmed over 425 letters and not just the
//! first one. All four parameters are therefore *reconstructed*, not documented, and
//! each is exposed here as a parameter rather than hardcoded so a caller can state a
//! different reading and have it evaluated rather than silently overridden.
//!
//! A second, unrelated correction to rev2's record: its key is `Zombies`, not the
//! recorded `ZOMBIES`. See the rev2 conformance vector in `ra-cli`'s `corpus.rs`.
//!
//! # `alphabet` is authoritative
//!
//! Baconian is "position `i` of the declared alphabet gets code `i`", and nothing in
//! that scheme is actually about letters -- so `alphabet` is not restricted to ASCII
//! letters. An earlier version of this node hardcoded `is_ascii_alphabetic`, which
//! rejected a coherent, differently-shaped alphabet (e.g. `"0123456789"`) outright;
//! see `digit_alphabet_round_trips` below for one that works. The only restriction
//! left is that a symbol be a distinct, non-whitespace ASCII byte -- whitespace is
//! excluded because `decode` already uses it (and anything else outside the
//! `zero`/`one` pair) as a group separator that passes through verbatim.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: a re-representation of the same text at stated parameters, and
//! therefore exhaustive at those parameters. It is not a solver and does not search.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

/// The 26-letter Baconian alphabet — the variant rev2 actually uses.
pub const BACON_26: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

/// The 24-letter classical Baconian alphabet, with `I`/`J` and `U`/`V` sharing a
/// code. Retained as a selectable value because it is the historically older form
/// and the corpus does not say which was used; rev2 rules it out empirically.
pub const BACON_24: &str = "ABCDEFGHIKLMNOPQRSTUWXYZ";

/// Symbols per letter. Five bits index at most 32 alphabet positions.
const GROUP: usize = 5;

const BACON_SCHEMA: &[ParamSpec] = &[
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "code alphabet, position i receiving code i (default the 26-letter form, \
         which is the one rev2 uses; \"ABCDEFGHIKLMNOPQRSTUWXYZ\" is the 24-letter \
         I=J, U=V variant)",
    ),
    ParamSpec::opt("zero", ParamType::Str, "symbol for bit 0 (default \"A\")"),
    ParamSpec::opt("one", ParamType::Str, "symbol for bit 1 (default \"B\")"),
    ParamSpec::opt(
        "direction",
        ParamType::Str,
        "\"decode\" (default): symbol groups to letters. \"encode\": letters to \
         symbol groups.",
    ),
];

/// Baconian encode/decode over a parameterised alphabet and symbol pair.
pub struct Bacon;

/// Reads and validates the shared parameters: `(alphabet, zero, one)`.
fn resolve(p: &Params) -> Result<(Vec<u8>, u8, u8)> {
    let alphabet = p.opt_str("alphabet").unwrap_or(BACON_26);
    // Baconian is fundamentally "position i of the declared alphabet gets
    // code i"; nothing in `encode`/`decode` below actually depends on the
    // symbols being letters (the only place case mattered, matching input
    // case-insensitively, works identically for any byte since folding a
    // non-letter through `to_ascii_uppercase` is a no-op). Restricting
    // `alphabet` to `is_ascii_alphabetic` was therefore hardcoding an
    // assumption the declared parameter didn't actually need, and it made a
    // non-letter alphabet (e.g. hex digits) rejected outright rather than
    // working -- so the check is dropped in favour of just requiring
    // distinct, non-whitespace ASCII bytes (whitespace is excluded because
    // it would be indistinguishable from `decode`'s own separators).
    let alpha: Vec<u8> = alphabet.as_bytes().to_ascii_uppercase();
    if alpha.is_empty() || alpha.len() > 1 << GROUP {
        return Err(Error::bad_param(
            "bacon",
            "alphabet",
            format!(
                "expected between 1 and {} symbols, got {}",
                1 << GROUP,
                alpha.len()
            ),
        ));
    }
    if !alpha.iter().all(|c| c.is_ascii_graphic()) {
        return Err(Error::bad_param(
            "bacon",
            "alphabet",
            "expected printable, non-whitespace ASCII symbols only",
        ));
    }
    for (i, &c) in alpha.iter().enumerate() {
        if alpha[..i].contains(&c) {
            return Err(Error::bad_param(
                "bacon",
                "alphabet",
                format!("letter {:?} appears twice", c as char),
            ));
        }
    }

    let symbol = |name: &'static str, default: &'static str| -> Result<u8> {
        let s = p.opt_str(name).unwrap_or(default).as_bytes();
        if s.len() != 1 {
            return Err(Error::bad_param(
                "bacon",
                name,
                format!("expected exactly one byte, got {}", s.len()),
            ));
        }
        Ok(s[0])
    };
    let zero = symbol("zero", "A")?;
    let one = symbol("one", "B")?;
    if zero == one {
        return Err(Error::bad_param(
            "bacon",
            "one",
            format!("must differ from `zero` ({:?})", zero as char),
        ));
    }
    Ok((alpha, zero, one))
}

/// Groups of five `zero`/`one` symbols become letters; every other byte is emitted
/// verbatim.
///
/// A byte outside the symbol pair also *flushes* any partial group, which is emitted
/// verbatim rather than dropped or padded — rev2's stream ends in a three-symbol
/// fragment followed by six bytes of noise, because its base64 ciphertext was
/// truncated at the source, and silently discarding a ragged tail would hide exactly
/// the kind of transcription damage this corpus is full of.
fn decode(input: &[u8], alpha: &[u8], zero: u8, one: u8) -> Result<Vec<u8>> {
    let mut out = Vec::with_capacity(input.len() / GROUP + 1);
    let mut pending: Vec<u8> = Vec::with_capacity(GROUP);
    for &b in input {
        if b != zero && b != one {
            out.append(&mut pending);
            out.push(b);
            continue;
        }
        pending.push(b);
        if pending.len() < GROUP {
            continue;
        }
        let value = pending
            .iter()
            .fold(0usize, |acc, &s| acc * 2 + usize::from(s == one));
        match alpha.get(value) {
            Some(&letter) => out.push(letter),
            None => {
                return Err(Error::node_failed(
                    "bacon",
                    format!(
                        "group {:?} denotes code {value}, which is outside the \
                         {}-letter alphabet",
                        String::from_utf8_lossy(&pending),
                        alpha.len()
                    ),
                ))
            }
        }
        pending.clear();
    }
    out.append(&mut pending);
    Ok(out)
}

/// The inverse: each alphabet letter becomes five symbols, case-insensitively. Bytes
/// absent from the alphabet pass through unchanged.
fn encode(input: &[u8], alpha: &[u8], zero: u8, one: u8) -> Vec<u8> {
    let mut out = Vec::with_capacity(input.len() * GROUP);
    for &b in input {
        match alpha.iter().position(|&a| a == b.to_ascii_uppercase()) {
            Some(idx) => {
                for shift in (0..GROUP).rev() {
                    out.push(if (idx >> shift) & 1 == 1 { one } else { zero });
                }
            }
            None => out.push(b),
        }
    }
    out
}

impl Node for Bacon {
    fn name(&self) -> &'static str {
        "bacon"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/bacon"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        BACON_SCHEMA
    }
    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let (alpha, zero, one) = resolve(params)?;
        let out = match params.opt_str("direction").unwrap_or("decode") {
            "decode" => decode(&input.data, &alpha, zero, one)?,
            "encode" => encode(&input.data, &alpha, zero, one),
            other => {
                return Err(Error::bad_param(
                    "bacon",
                    "direction",
                    format!("expected \"decode\" or \"encode\", got {other:?}"),
                ))
            }
        };
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(BACON => || Box::new(Bacon));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn bacon() -> &'static dyn Node {
        registry().get("bacon").unwrap()
    }

    #[test]
    fn bacon_is_xf_family_and_not_layer_forming() {
        let n = bacon();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    /// Hand-computed: `AABAA` is `00100` = 4, and the fifth letter of the default
    /// 26-letter alphabet is `E`. `BAAAB` is `10001` = 17 = `R`.
    #[test]
    fn bacon_decodes_hand_computed_groups() {
        let out = bacon()
            .apply(&Repr::bytes(b"AABAABAAAB".to_vec()), &Params::new())
            .unwrap();
        assert_eq!(out.data, b"ER");
    }

    /// **Recovered parameter, not documented by the corpus.** rev2's record names the
    /// step `bacon` and stops there. This pins all four readings the record omits —
    /// 26-letter alphabet, `A`=0, `B`=1, MSB first — against the first word of rev2's
    /// recorded plaintext, and shows that the two plausible alternatives disagree
    /// with it. See the module docs for the full derivation.
    #[test]
    fn bacon_variant_and_symbols_are_pinned_by_rev2() {
        // The first 40 symbols of rev2's DES output, which the record says decode to
        // the 8-letter word SAMANTHA.
        const REV2_FIRST_WORD: &[u8] = b"BAABAAAAAAABBAAAAAAAABBABBAABBAABBBAAAAA";

        let got = bacon()
            .apply(&Repr::bytes(REV2_FIRST_WORD.to_vec()), &Params::new())
            .unwrap();
        assert_eq!(got.data, b"SAMANTHA", "26-letter, A=0, B=1, MSB first");

        // The 24-letter classical variant is ruled out.
        let two_four = bacon()
            .apply(
                &Repr::bytes(REV2_FIRST_WORD.to_vec()),
                &params! {"alphabet" => BACON_24},
            )
            .unwrap();
        assert_ne!(two_four.data, b"SAMANTHA");

        // So is the opposite symbol convention — emphatically: under it the second
        // group reads 11111 = 31, which no 26-letter alphabet even has a cell for, so
        // it does not merely disagree, it fails to decode at all.
        let swapped = bacon().apply(
            &Repr::bytes(REV2_FIRST_WORD.to_vec()),
            &params! {"zero" => "B", "one" => "A"},
        );
        match swapped {
            Ok(r) => assert_ne!(r.data, b"SAMANTHA"),
            Err(e) => assert!(e.to_string().contains("31"), "{e}"),
        }
    }

    /// Word separators pass through, so the decoded text keeps rev2's spacing.
    #[test]
    fn bacon_passes_non_symbol_bytes_through() {
        let out = bacon()
            .apply(&Repr::bytes(b"AABAA BAAAB!".to_vec()), &Params::new())
            .unwrap();
        assert_eq!(out.data, b"E R!");
    }

    /// A ragged tail is emitted verbatim rather than dropped or padded: rev2's
    /// truncated ciphertext ends in exactly that shape.
    #[test]
    fn bacon_emits_incomplete_groups_verbatim() {
        let mid = bacon()
            .apply(&Repr::bytes(b"AABA BAAAB".to_vec()), &Params::new())
            .unwrap();
        assert_eq!(mid.data, b"AABA R");

        let tail = bacon()
            .apply(&Repr::bytes(b"AABAABB".to_vec()), &Params::new())
            .unwrap();
        assert_eq!(tail.data, b"EBB");
    }

    /// Round trip: encode is the inverse of decode over the alphabet's own letters.
    #[test]
    fn bacon_round_trips_through_encode() {
        let n = bacon();
        let plain = Repr::bytes(b"SAMANTHA FINALLY LEFT".to_vec());
        let coded = n.apply(&plain, &params! {"direction" => "encode"}).unwrap();
        assert!(coded
            .data
            .iter()
            .all(|&c| c == b'A' || c == b'B' || c == b' '));
        let back = n.apply(&coded, &params! {"direction" => "decode"}).unwrap();
        assert_eq!(back.data, plain.data);

        // and with a non-default symbol pair over the 24-letter alphabet
        let p = params! {
            "direction" => "encode", "zero" => ".", "one" => "-", "alphabet" => BACON_24
        };
        let dots = n.apply(&Repr::bytes(b"ZOMBIES".to_vec()), &p).unwrap();
        assert!(dots.data.iter().all(|&c| c == b'.' || c == b'-'));
        let q = params! {
            "direction" => "decode", "zero" => ".", "one" => "-", "alphabet" => BACON_24
        };
        assert_eq!(n.apply(&dots, &q).unwrap().data, b"ZOMBIES");
    }

    /// The declared `alphabet` is authoritative: Baconian's "position i gets
    /// code i" scheme has no actual dependency on the symbols being
    /// letters, so a 10-digit alphabet round trips exactly like the default
    /// 26-letter one, rather than being rejected outright by a hardcoded
    /// `is_ascii_alphabetic` gate.
    #[test]
    fn digit_alphabet_round_trips() {
        let n = bacon();
        let digits = "0123456789";
        let enc = params! {"direction" => "encode", "alphabet" => digits};
        let dec = params! {"direction" => "decode", "alphabet" => digits};
        let coded = n.apply(&Repr::bytes(b"1970".to_vec()), &enc).unwrap();
        assert!(coded.data.iter().all(|&c| c == b'A' || c == b'B'));
        assert_eq!(n.apply(&coded, &dec).unwrap().data, b"1970");
    }

    #[test]
    fn bacon_rejects_malformed_parameters() {
        let n = bacon();
        let d = Repr::bytes(b"AABAA".to_vec());
        for bad in [
            params! {"zero" => "A", "one" => "A"},
            params! {"zero" => "AB"},
            params! {"one" => ""},
            params! {"alphabet" => ""},
            params! {"alphabet" => "A B"}, // whitespace collides with decode's own separators
            params! {"alphabet" => "AA"},
            params! {"direction" => "sideways"},
        ] {
            assert!(
                n.apply(&d, &bad).is_err(),
                "should have rejected {}",
                bad.canonical_json()
            );
        }
        // 52 letters is more than five bits can index
        let too_long: String = BACON_26.repeat(2);
        assert!(n
            .apply(&d, &params! {"alphabet" => too_long.as_str()})
            .is_err());
    }

    /// A code past the end of the alphabet is an error, not a silent `?`: with the
    /// 26-letter alphabet the codes 26..=31 are unassigned.
    #[test]
    fn bacon_rejects_codes_outside_the_alphabet() {
        let e = bacon()
            .apply(&Repr::bytes(b"BBBBB".to_vec()), &Params::new())
            .unwrap_err();
        assert!(e.to_string().contains("31"), "{e}");
    }
}
