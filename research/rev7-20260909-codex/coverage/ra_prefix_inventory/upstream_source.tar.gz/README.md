# ra

A pluggable Rust engine for the two unsolved Black Ops III Zombies ciphers,
**The Giant 4** and **Revelations 7**.

It exists because the interesting problem here is not compute. It is stating precisely
what has been tried, proving the software that tried it was correct, and computing what
remains — so that a negative result means something.

```
crates/     the workspace (see ARCHITECTURE.md)
data/       the corpus: per-cipher records, conformance suite, attestation schema
papers/     the seven dossier documents and their generators
reference/  the original Python, kept as the specification this was built against
```

## Build

```bash
cargo build --release      # no C dependencies; libmcrypt is not required
cargo test --workspace     # 351 tests
```

## Start here

```bash
ra conformance             # does this engine actually reproduce the solved corpus?
```

That is the only question worth asking first. Everything else — every sweep, every
coverage claim, every residual — is worth exactly as much as the answer.

```
[PASS] XTEA            via rev12  hexdecode | xtea:key=Zombies,mode=cfb | reverse | rot:n=20
[PASS] DES             via rev9   b64decode | des:key=Zombies,mode=cfb
[PASS] Twofish         via rev9   … | decimaldecode | reverse | b64decode | twofish:key=Zombies,mode=cfb
[PASS] Serpent         via rev6   decimaldecode | reverse | hexdecode | serpent:key=Zombies,mode=cfb
[PASS] RC4             via rev10  hexdecode | arcfour:key=Zombies
[PASS] Saferplus       via rev10  … | octaldecode | hexdecode | saferplus:key=Zombies,mode=cfb
[PASS] RC2             via rev5   b64decode | rc2:key=Zombies,mode=cfb
[PASS] Blowfish        via rev5   … | reverse | hex_to_base64 | b64decode | blowfish:key=Zombies,mode=cfb
[PASS] Blowfish-compat via rev8   insert:text=63,pos=131,unit=hexpair | … | blowfish-compat:key=Zombies,mode=cfb | b64decode
[PASS] Rijndael-256    via rev1   beaufort:key=ZOMBIES | b64decode | rc2:…,mode=ecb | reverse | b64decode | rijndael-256:…,mode=ecb
[PASS] Loki97          via rev5   … | blowfish:key=Zombies,mode=cfb | b64decode | loki97:key=Zombies,mode=cfb

11 of 11 confirmed primitives reproduced end to end.
```

Every primitive in the vocabulary is backed by a real reproduction of a solved cipher,
so coverage gating no longer voids anything. Had any been unproven it would contribute
**zero coverage** by design: a sweep
over an unproven primitive searches a space that may not be the real one, and admitting
it would let a false negative silently delete a region from the search forever.

That gate is *applied*, not merely defined. `ra residual` executes the conformance
suite and intersects every claim it folds with the primitives that reproduce right
then, reporting claimed against effective coverage for each — so the residual is
computed from what is proven rather than from what is asserted. Each emitted claim also
records the conformance state it ran under, and one that arrives without that block is
announced as not self-describing and gated against current conformance instead of
trusted.

## Run one pipeline

Pipelines are written left to right, `|`-separated, parameters after `:`.

```bash
# recover a solved cipher end to end
ra run --target rev12 "hexdecode | xtea:key=Zombies,mode=cfb | reverse | rot:n=20"
# -> Now that the many worlds are one, it has all reset. There are no Apothicon…

# see which steps actually crossed a layer boundary
ra run --target rev9 --trace --oracle printable-0.75 \
  "b64decode | des:key=Zombies,mode=cfb | decimaldecode | reverse | b64decode | twofish:key=Zombies,mode=cfb"
```

`--trace` distinguishes a real layer from mere re-encoding. `base64 → hex` changes the
display but not the bytes it denotes, so it scores an entropy delta of zero and is not
a layer; a decryption is.

## Sweep, and commit to it

```bash
ra sweep --target tg4 \
  --keys Zombies,TheGiant,ZOMBIES --modes cfb,ecb \
  --ivs ascii0,null --xf identity,reverse \
  --emit-claim tg4-run1.json
```

Outputs a Merkle root over the whole enumeration, any hits above the oracle threshold,
and the claim **as a set with a content digest** rather than a count. Counts do not
compose: two teams each reporting 3.2e8 may have tried the same 3.2e8.

Those two hashes have opposite invariants, and a claim records what each needs. The
coverage digest is **order-independent** — axes are sorted sets, so equal coverage hashes
equally however you spelled the command line. The Merkle root is **order-dependent**,
because it binds the candidate index and the index walks the axes in the order you gave
them. So the claim also records the enumeration order, and:

```bash
ra verify-claim claims/tg4-t3.json              # does the claim regenerate itself?
ra verify-claim claims/tg4-t3.json --recompute  # ... and re-run to match the root exactly
```

Without the recorded order a published root is unverifiable, which would quietly void the
spot audit the whole commitment exists for. A claim that omits it is refused, not trusted.

`--tier` chooses which skeleton to enumerate — `t1` (`b64d ∘ dec`), `t2`
(`b64d ∘ xf ∘ dec`) or `t3` (`b64d ∘ dec ∘ xf ∘ codec ∘ dec`, two modern layers). Each
is swept and committed to separately, because the coverage algebra partitions by
skeleton.

```bash
ra sweep --target tg4 --tier t1,t2,t3 \
  --modes ecb,cbc,cfb,ncfb,ofb,nofb,stream \
  --keys Zombies,TheGiant,ZOMBIES,thegiant,zombies,TheGiant_b64 \
  --kd natural,null-pad-max,null-pad-next-supported,repeat-pad-max \
  --ivs ascii0,null --xf identity,reverse --dry-run
# t1  <b64d o dec>                       3696 candidates
# t2  <b64d o xf o dec>                  7392 candidates
# t3  <b64d o dec o xf o codec o dec>  163.92e6 candidates
```

That `codec` slot is not decoration. Every chain the corpus records **omits an implicit
decode**: the tools4noobs decrypt box base64-decodes its input at each hop, so rev9 does
not reproduce without one and rev1 needs two. A two-layer model read off the recorded
chains therefore has the wrong skeleton — `dec ∘ xf ∘ dec`, which is what the reference
`residual.py` says, and which does not contain the pipelines that actually solved the
corpus. The re-encoding is an enumerable dimension whose domain is read off the solved
corpus rather than invented, and a unit test holds it to that.

`--max-candidates` bounds a run, and the emitted claim then describes the **prefix
actually evaluated** as an exact disjoint union of products, not the whole skeleton. A
sweep asserts `size_exact() == candidates evaluated` before it will emit anything.

## The transcription is an axis too — and the dossier is 8x out

TG4's ciphertext is a *transcription of an image* in a face with two candidate confusions,
`I`/`l` and `0`/`O`. Both members of each pair are valid base64, so on the face of it both
readings are admissible everywhere they occur. Only one pair is actually open:

- **`0`/`O` — resolved.** The project team reviewed the transcript against the font that
  was actually used and confirmed the recorded readings. Seven positions, fixed.
- **`I`/`l` — open.** Seven positions, enumerated.

The sweep derives those positions from the ciphertext at runtime — never a hardcoded list,
which would rot the moment the record was corrected:

```bash
ra sweep --target tg4 --tier t1,t2,t3 --variants all …
# transcription: 7 open ambiguous glyph positions (5xI 2xl) -> 128 admissible readings
#   open       : [3, 15, 31, 36, 39, 90, 160]
#   resolved   : [37, 64, 86, 94, 105, 112, 114]  (0/O, fixed against the source font)
```

**So there are 2^7 = 128 admissible transcriptions, not 16.** `reference/py/space.py` sets
`N_TRANS_TG = 16` and Paper 4's headline figures inherit it as a factor, so each is 8x too
small: the bounded T1–T4 programme is **9.2e9** candidates, not 1.15e9 — **72 minutes**
optimised, not 9. Paper 4's conclusion that the bounded space has very likely been
exhausted already survives at 8x, though it is now unverified rather than obvious. Had
`0`/`O` stayed open the space would have been 16,384 readings and 1.18e12 candidates, and
that conclusion would have been indefensible — which is what the font review bought. Full
arithmetic in `ARCHITECTURE.md`, deviation 6.

Readings are labelled by a bit mask over the open positions, `v00 .. v7f`, with `v00` the
recorded reading. `--variants` takes `all`, `recorded`, or an explicit list. Because 128
readings is cheap at every tier, **all three tiers are swept exhaustively over the whole
space** — no bound, no prioritisation, no partial claim.

An independent corpus measurement corroborates the team's finding: across rev1, rev5 and
rev9, **177 glyph calls are each verified correct with zero errors** by single-flip
perturbation (128/128 on rev5, 45/45 on rev9), 89 of them `0`/`O`. The same method gives
88/88 on `I`/`l`, which is why `v00` is the reading most likely to carry a solve if one
exists — an expectation, not a constraint on what gets enumerated. REV7 is untouched by
any of this: hex excludes `O`, `I` and `l`, so its variant dimension is *computed* to be a
single point and its claim digest is byte-identical before and after.

## What remains

```bash
ra residual --full --claims claims/tg4-t1t2.json,claims/tg4-t3.json,\
claims/tg4-t1t2-all-variants.json,claims/tg4-t3-all-variants.json
```

Computes `UNIVERSE \ CLAIMS` exactly, via orthogonal decomposition rather than
estimation, and shows the double-counting that a count-based report cannot see. The
modelled universe covers tiers T1–T3; `--claims` folds in real sweep output, which is
the point of emitting a set with a digest rather than a count. Its variant dimension is
**derived from the corpus ciphertext**, so the 128-reading correction moves the universe
rather than leaving it stale — the modelled `--full` universe is 2.82e11 candidates, 8x
the 3.52e10 the reference figure implies.

What is covered today, all of it commitment-backed and all of it exhaustive over the
complete admissible variant space:

| skeleton | readings | candidates | hits |
|---|---|---|---|
| T1 `b64d ∘ dec` | **all 128** | 473,088 | 0 |
| T2 `b64d ∘ xf ∘ dec` | **all 128** | 946,176 | 0 |
| T3 `b64d ∘ dec ∘ xf ∘ codec ∘ dec` | **all 128** | 20,982,398,976 | artifacts only |

Nothing is bounded and nothing is dropped: the transcription is no longer what remains
uncovered on TG4. What does remain is the skeletons the model does not contain — any
pipeline with a step *before* the first decryption, and any second inter-layer codec
(`codec ∘ xf ∘ codec`, which rev9 shows).

## Other commands

| | |
|---|---|
| `ra nodes --schema` | every registered plugin, with content-addressed identity |
| `ra target tg4` | what is known about a cipher: entropy, IoC, recorded chain |
| `ra attest <file>` | claimed versus conformance-gated coverage |
| `ra repair --target rev7 --grid` | is the recorded ciphertext even the right bytes? |

## Repair: when the ciphertext itself is the assumption

Every sweep takes the recorded ciphertext as given. The corpus shows that assumption
fails — rev2 needs a character removed, rev8 needs `63` inserted, and rev8 carries a
*second*, undocumented corrupted byte besides. A sweep over the wrong bytes covers
nothing, however large, and reports a clean negative while doing it.

So a transcription repair is not preprocessing; it is a coverage dimension, and the
dossier already has the slot for it (`0.variant`). `ra repair` enumerates it jointly
with the cipher axes and emits the result as a coverage set like any other claim.

```bash
ra repair --target rev7 --grid      # the transcription grid and the repair arithmetic
```

REV7 turns out to be **8 hex characters short in two places**, so its true ciphertext is
**550 bytes, not 546** — confirmed by parity (only the joint repair yields a whole number
of bytes) and, independently, by the final line's width. The search over that repair
space is a **null result**, reported in full in
[`notes/rev7-repair-search.md`](notes/rev7-repair-search.md): 45.4 million candidates,
zero hits, best score 0.474 against a random-byte baseline of 0.371 and a real layer's
0.985.

## The invariants

Confirmed against the corpus, not assumed:

| | |
|---|---|
| Key | `Zombies` |
| IV | `30…30` — ASCII `'0'`×16, **not** a null IV |
| Mode | mcrypt `cfb`, meaning **CFB-8** (8-bit feedback) |
| Key derivation | null-pad to the **smallest supported** key size |
| RC2 effective key bits | **1024**, regardless of key length |

The mode is why a decade of tooling failed: modern libraries use the name `cfb` for
full-block feedback, which mcrypt spells `ncfb`. CyberChef cannot express what these
ciphers are.

The key derivation is a correction to the dossier's own reference tool, which pads to
the *maximum* key size. rev9's Twofish layer recovers its known plaintext only at 16
bytes, not 32 — so any sweep built on the reference used the wrong key for every
multi-key-size primitive while reporting the space as covered.

RC2's effective key bits are the same kind of trap one level down. libmcrypt's `rc2.c`
has RFC 2268's Phase 2 key-size reduction *stripped out*, so `T1` is always 1024 no
matter how long the key is. RustCrypto defaults to `8 × key_len` (56 for `Zombies`) and
OpenSSL to 128; both are different ciphers, and neither reproduces rev5. The three
agree only at a full 128-byte key, which is exactly the length libmcrypt's own
self-test vector uses — so the discrepancy is invisible to the vector most likely to be
consulted.

`ARCHITECTURE.md` documents the plugin boundary, the coverage algebra, all five
deviations from the reference implementation, and the known gaps.
