import time, os
from Crypto.Cipher import DES, ARC2, ARC4, Blowfish, AES

TG4_BYTES = 144
REV7_BYTES = 546
KEY = b"Zombies\x00"      # null-padded to 8
IV8  = b"0"*8
IV16 = b"0"*16

def bench(fn, payload, n=20000):
    t0 = time.perf_counter()
    for _ in range(n): fn(payload)
    return n / (time.perf_counter() - t0)

pay144 = os.urandom(TG4_BYTES)
pay546 = os.urandom(REV7_BYTES)

def des_cfb8(p):
    return DES.new(KEY, DES.MODE_CFB, iv=IV8, segment_size=8).decrypt(p)
def blowfish_cfb8(p):
    return Blowfish.new(b"Zombies", Blowfish.MODE_CFB, iv=IV8, segment_size=8).decrypt(p)
def rc4(p):
    return ARC4.new(b"Zombies").decrypt(p)
def aes_cfb8(p):
    return AES.new(b"Zombies\x00"*2+b"\x00"*0, AES.MODE_CFB, iv=IV16, segment_size=8).decrypt(p)

print("THROUGHPUT (single-core Python, includes cipher-object construction per op)")
print("-"*70)
for name, fn, pay, sz in [
    ("DES CFB-8       144B", des_cfb8, pay144, 144),
    ("DES CFB-8       546B", des_cfb8, pay546, 546),
    ("Blowfish CFB-8  144B", blowfish_cfb8, pay144, 144),
    ("RC4 (stream)    144B", rc4, pay144, 144),
    ("AES CFB-8       144B", aes_cfb8, pay144, 144),
]:
    try:
        r = bench(fn, pay, 8000)
        print(f"{name:<22} {r:>12,.0f} decrypt/sec")
    except Exception as e:
        print(f"{name:<22} ERROR {e}")

# CFB-8 is the slow path: 1 block op per BYTE
print("\nNote: CFB-8 performs one block operation PER BYTE, so it is roughly")
print("blocksize-times slower than full-block modes. This is the dominant cost.")
