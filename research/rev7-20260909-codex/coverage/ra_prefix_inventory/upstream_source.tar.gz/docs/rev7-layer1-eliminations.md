# rev7 layer 1 — what has been eliminated

Goal: find the first decryption layer, i.e. a step yielding a lower-entropy,
more classical-looking intermediate that still needs at least one further step.

## Confirmed prefix (arithmetic, not inference)

- **stripws** — 1310 raw chars contain exactly 218 whitespace (203 spaces,
  15 newlines), stripping to 1092 hex chars = 546 bytes.
- **reverse** — 1092 = 5×218 + 2, and the 2-char partial group sits at the
  START. Group-of-5 formatting always leaves the partial group at the END, so
  the display is the reverse of its natural grouping.

Both steps follow from the formatting alone and do not depend on any solve.

## Payload class

546 bytes at byte entropy 7.6321, IC 0.00379 (random is 1/256 = 0.0039). The
transcription is unambiguous because the display is hex, so unlike TG4 there is
no glyph-variant axis.

## Eliminated

Scored on **structure** rather than plaintext-likeness — entropy drop, charset
purity across seven alphabets (hex, base64, decimal, octal, upper, lower,
letters+space), and repeated-4-gram count. After one layer we should expect
structure, not English, so printability and English fitness are the wrong
instruments.

| search | candidates | result |
|---|---|---|
| 13 primitives × 7 modes × 4 raw-byte kd × 2 IVs × 6 keys × 4 prefixes | 17,472 | zero findings |
| the same, plus md5/sha1/sha256 key derivation | 30,576 | zero findings |

The only "structurally interesting" outputs in either run were **degenerate
OFB-8 fixed points**, where a zero or self-sustaining first keystream byte makes
the layer collapse to identity or a constant XOR. Those are correct cipher
behaviour, not findings.

The narrow IV axis does not weaken this. In CBC and CFB a wrong IV corrupts only
the first block, so roughly 538 of 546 bytes would still decrypt and the entropy
drop would still show.

## Still untested

- hash-derived keys as **hex strings** (hash, render hex, feed the hex *text* as
  the key — a common web-tool pattern, and a different key from the raw digest)
- **EVP_BytesToKey** (OpenSSL's password-to-key, used by many PHP/JS wrappers)
- the **OpenSSL-only cipher menu**: IDEA, Camellia, SEED, ARIA, RC5, CAST-128
- the remaining libmcrypt primitives: cast-256, gost, wake, rijndael-192, and
  libmcrypt's `enigma` (the Unix crypt(1) one-rotor stream cipher)

## Methodological note

`ra run` renders binary output as lossy UTF-8, so each invalid byte becomes a
3-byte replacement sequence. Any harness that analyses its stdout directly is
measuring the rendering, not the plaintext — an early version of this search
reported entropy 3.85 on 546-byte outputs for exactly that reason. Terminate the
chain with `hexencode` and parse the hex to recover true bytes.

## Terminal result for the classical→modern shape (2026-07-31)

`stripws → reverse → classical → hexdecode → modern`, scored on structure
(entropy drop, charset purity across seven alphabets, repeated 4-grams), with a
546-byte output enforced so data loss cannot masquerade as structure.

| axis | saturated at |
|---|---|
| primitives | 15/15 — incl. AES, 3DES, CAST-128, IDEA |
| key derivations | 15/15 — raw, md5/sha1/sha256 digest, hex-string, EVP_BytesToKey |
| classical configs | 192 — columnar (divisor widths x 3 directions), rot/affine over hex, rail fence / Myszkowski / permutation with `strip_non_alphabet=false` |
| modes | 6 — `stream` excluded, inapplicable to block ciphers |
| keys | 6 — Zombies/ZOMBIES/zombies/Zombie/ZOMBIE/zombie |
| IVs | 2 — ascii0, null |

Final run: **3,110,400 candidates, 0 structurally interesting.** The only hits in
any run of this family were degenerate OFB-8 fixed points, where a zero or
self-sustaining first keystream byte collapses the layer to identity or a
constant XOR — correct cipher behaviour, not findings.

**This exhausts the shape within our node vocabulary.** What remains untested is
not more of these parameters:

- **chain depth >= 3** — infeasible by enumeration: 5,400 configs per layer,
  cubed is ~1.6e11. And under an identity codec the intermediates are binary, so
  no structural oracle can prune early; only the final output is scoreable.
- **the ordering itself** — only `stripws` and `reverse` are confirmed, and both
  from formatting arithmetic (218 whitespace chars -> 1092 hex = 546 bytes;
  1092 = 5*218 + 2 with the partial group at the START, where group-of-5
  formatting always leaves it at the END). "Classical then modern" is a
  hypothesis, not a measurement. The classical layer could follow the modern one,
  or there may be none.
- **operations we cannot express** — the vocabulary is 73 nodes, and the ones
  valid on a 16-symbol hex medium remain a small subset.
