const S = require("./style.js");
const { docx, PAGE, numbering, title, subtitle, h1, h2, h3, p, mono, li, numItem, table, callout, spacer, makeHeaderFooter } = S;
const { Document, Packer, Paragraph, TextRun, BorderStyle } = docx;
const fs = require("fs");

const children = [];
const A = (...x) => children.push(...x);

A(title("Coverage Notation and Attestation Specification"));
A(subtitle("A Set Algebra for Search Claims, Bound to Versioned Execution Provenance"));
A(p([
  { t: "Document 5 of 5 (Specification). ", bold: true },
  "This document defines a normative format for stating what portion of a cipher search space has been tried, and for binding that statement to the software that produced it. It exists because the community currently reports coverage informally, and informal reports are neither comparable nor subtractable. The format is designed so that the residual, meaning the part of the space that remains untried, is computed rather than estimated.",
]));

// 1 Motivation
A(h1("1. Why Counts Are Not Claims"));
A(p([
  "A report of the form \"we brute forced every mcrypt combination\" cannot be verified, cannot be composed with another team's report, and cannot be subtracted from the universe. Two groups each reporting three hundred million candidates may have tried the same three hundred million. A count carries no information about which region was covered.",
]));
A(p([
  "Worked against the model in Document 4, the informal claim above resolves, once made precise, to eight candidates out of 76,608 in the single-layer tier alone, because in practice such a run used one transcription, one key, one key-derivation rule, one IV, and the four primitives that exist in stock libraries. The gap between the perceived and actual claim is roughly four orders of magnitude. That gap is the problem this specification addresses.",
]));
A(callout("Design requirement.", [
  "A coverage claim must be a set, expressed in a representation closed under union and difference, so that aggregate coverage and residual are exact. It must also be content-addressed, so that two claims covering the same region are recognisably identical without re-execution.",
], S.ACCENT));

// 2 The algebra
A(h1("2. The Coverage Algebra"));
A(h2("2.1 Pipelines and skeletons"));
A(p([
  "A pipeline is an ordered composition of layers applied left to right. Written with the composition operator, a decode followed by a reversal followed by a modern decryption is:",
]));
A(...mono("V . dcd[hex] . xf[reverse] . dec[prim, mode, key, iv, kd]"));
A(p([
  "The ordered tuple of layer families, ignoring parameter values, is the skeleton. The space of all pipelines partitions by skeleton, and within one skeleton the space is a plain Cartesian product of per-slot parameter domains. Formally, with S the set of skeletons and D the domain of slot j under skeleton s:",
]));
A(...mono("U  =  \u228e   \u220f  D(s, j)\n     s\u2208S  j"));
A(p([
  "The partition matters because it makes variable-length pipelines tractable. Products of different arity are never compared; the disjoint union keeps them separate, and set operations are performed per skeleton.",
]));
A(h2("2.2 Products and covers"));
A(p([
  "A product is a hyperrectangle within one skeleton: an assignment of an explicit value set to each slot parameter. A cover is a union of products within one skeleton. A coverage set is a mapping from skeleton to cover. Products give exponential compression, since a sweep over eleven primitives, two modes, and three IVs is one product of size sixty-six rather than sixty-six enumerated tuples.",
]));
A(p("A claim is written in the notation below. Slot indices prefix each parameter so that position is unambiguous:"));
A(...mono("\u27e8b64d \u2218 dec\u27e9 :  0.variant\u2208{v01} \u00d7 1.key\u2208{TheGiant} \u00d7 1.kd\u2208{nullpad}\n                \u00d7 1.mode\u2208{cfb8,ecb} \u00d7 1.prim\u2208{Blowfish,DES,RC2,RC4}\n                \u00d7 1.iv\u2208{ascii0}"));
A(h2("2.3 Difference by orthogonal decomposition"));
A(p([
  "Closure under difference is what makes the residual computable. For products A and B over the same dimensions, the difference is a disjoint union of at most one product per dimension. Each term fixes the earlier dimensions to the overlap, carves the current dimension, and leaves the later dimensions free:",
]));
A(...mono("A \\ B  =  \u22c3  (A\u2081\u2229B\u2081) \u00d7 \u22ef \u00d7 (A\u2096\u208b\u2081\u2229B\u2096\u208b\u2081) \u00d7 (A\u2096 \\ B\u2096) \u00d7 A\u2096\u208a\u2081 \u00d7 \u22ef \u00d7 A\u2099\n          k"));
A(p([
  "The terms are pairwise disjoint by construction, so sizes add without inclusion and exclusion corrections. Repeated application yields exact aggregate coverage across overlapping claims, and exact residual against the universe. The reference implementation is verified pointwise against brute-force enumeration on small instances.",
]));
A(h2("2.4 Content addressing"));
A(p([
  "A coverage set serialises canonically, with dimensions sorted and value sets sorted, and hashes to a digest. Equal coverage yields an equal digest regardless of how the claim was constructed or in what order products were added. This makes duplicate work detectable across teams without re-running anything.",
]));

// 3 Worked example
A(h1("3. Worked Residual"));
A(p([
  "Three claims are registered against the TG4 universe of 1,467,579,456 candidates spanning tiers T1 through T3 under the full mcrypt menu.",
]));
A(table(
  ["Claim", "Description", "Exact size"],
  [
    ["A", "Single layer, key TheGiant, stock primitives, preferred transcription", "8"],
    ["B", "Single layer, key Zombies, all primitives and IVs, all 16 transcriptions", "2,112"],
    ["C", "Reverse then modern, stock primitives, all keys", "48"],
  ],
  [900, 5600, 2748]
));
A(table(
  ["Skeleton", "Universe", "Remaining after A, B, C"],
  [
    ["b64d o dec", "76,608", "74,496  (14 disjoint blocks)"],
    ["b64d o xf o dec", "306,432", "306,384  (6 disjoint blocks)"],
    ["b64d o dec o xf o dec", "1,467,196,416", "1,467,196,416  (1 block, untouched)"],
    ["TOTAL", "1,467,579,456", "1,467,577,296"],
  ],
  [3400, 2900, 2948]
));
A(callout("Result.", [
  "Aggregate coverage across all three claims is 2,168 candidates, or 0.0001 percent of the modelled universe. Even the single-layer tier, widely believed exhausted, is 97 percent untried once the claim is made precise. The residual is returned as executable disjoint blocks, so a harness can consume it directly as its next work queue rather than re-deriving what to run.",
], S.ACCENT));

// 4 Provenance
A(h1("4. Attestation: Binding a Claim to Its Execution"));
A(p([
  "A coverage set states what was tried. It does not establish whether the result should be believed. Three failure modes void a claim while leaving it superficially intact.",
]));
A(numItem([{ t: "A wrong primitive implementation. ", bold: true }, "Seven of the eleven confirmed primitives have no stock implementation, so each harness supplies its own. A subtly incorrect Twofish sweeps a space that is not the real one. The claim looks complete and covers nothing."], "steps"));
A(numItem([{ t: "A scoring oracle that is too strict. ", bold: true }, "A sweep accepting only fully printable output discards a correct CFB-8 decryption whose first block is corrupt, which is exactly the failure mode the ASCII-zero IV produces. Identical pipelines under a stricter oracle cover strictly less. The oracle is therefore part of the claim, not metadata about it."], "steps"));
A(numItem([{ t: "A different input. ", bold: true }, "TG4 admits up to sixteen transcriptions. A claim over the wrong bytes covers nothing relevant to the target, however large it is."], "steps"));
A(h2("4.1 Envelope contents"));
A(table(
  ["Field group", "Purpose"],
  [
    ["input", "Transcription variant identifier plus ciphertext hash and length"],
    ["coverage_claimed", "The set, in the algebra of Section 2, with canonical digest"],
    ["coverage_effective", "The claim after conformance gating; this is what the residual consumes"],
    ["oracle", "Scoring metric and threshold, treated as part of the claim"],
    ["toolchain.harness", "Name, version, git commit, and content hash of the executing code"],
    ["toolchain.primitives", "Per-primitive implementation, version, hash, and conformance record"],
    ["execution", "Start, finish, candidates evaluated, hardware"],
    ["hits", "Any candidate passing the oracle; empty for a negative result"],
  ],
  [2600, 6648]
));

// 5 Conformance
A(h1("5. Conformance Gating"));
A(p([
  "The solved corpus is a complete conformance suite. Every one of the eleven confirmed primitives is exercised by at least one solved cipher whose plaintext is known, so a harness can prove each implementation by reproducing that cipher's full chain end to end. No external test vectors are required.",
]));
A(table(
  ["Primitive", "Validating cipher(s)", "Primitive", "Validating cipher(s)"],
  [
    ["Blowfish", "rev5 [CFB]", "Saferplus", "rev10 [CFB]"],
    ["Blowfish-compat", "rev8 [CFB]", "Serpent", "rev6 [CFB]"],
    ["DES", "rev2, rev9 [CFB]", "Twofish", "rev9 [CFB]"],
    ["Loki97", "rev5 [CFB]", "XTEA", "rev12 [CFB]"],
    ["RC2", "rev1 [ECB], rev5 [CFB]", "Rijndael-256", "rev1 [ECB]"],
    ["RC4", "rev10 [stream]", "", ""],
  ],
  [2000, 2624, 2000, 2624]
));
A(p([
  "The gating rule is mechanical. Claimed coverage is intersected with the set of primitives whose conformance status is PASS and whose cited vectors actually exercise that primitive. An unproven primitive contributes zero coverage regardless of what the claim asserts. This converts an unfalsifiable assertion into an enforced constraint.",
]));
A(h2("5.1 Validator output on a realistic claim"));
A(p([
  "Applied to a claim asserting a seven-primitive sweep, where Twofish was untested, Serpent failed its vector, and XTEA cited rev2 rather than rev12, the validator reports:",
]));
A(...mono("ERRORS\n  x primitive 'XTEA' cites vectors ['rev2'] which do not validate it;\n    expected one of ['rev12']\n\nWARNINGS\n  ! oracle printable-1.00 is strict; a CFB-8 hit with a corrupt first\n    block would be rejected. Coverage is effectively reduced.\n  ! primitive 'Serpent' conformance=FAIL; its coverage is void\n  ! primitive 'Twofish' conformance=UNTESTED; its coverage is void\n\nclaimed   = 14 candidates\neffective =  8 candidates\nVOIDED    =  6 candidates (43% of the claim)"));
A(callout("Why the wrong-vector check matters.", [
  "The XTEA entry claims PASS and cites a real solved cipher, so it would survive any check that merely required a non-empty vector list. Only cross-referencing against the conformance table catches that rev2 exercises DES rather than XTEA. This class of error is invisible to informal review and silently inflates apparent coverage.",
]));

// 6 Adoption
A(h1("6. Adoption Path"));
A(numItem([{ t: "Freeze the vocabulary. ", bold: true }, "Publish the named domain sets (transcription variants, key candidates, primitive menu, mode menu, IV set, transform families) so that claims from different teams reference identical symbols. Ad hoc names defeat set operations."], "steps2"));
A(numItem([{ t: "Retrofit existing claims. ", bold: true }, "Encode past sweeps in the notation, marking primitives UNTESTED where conformance was never run. Expect aggregate coverage to fall far below intuition; that drop is information, not a setback."], "steps2"));
A(numItem([{ t: "Gate future runs on conformance. ", bold: true }, "Require every harness to reproduce its primitives' validating ciphers before a sweep is admitted. This is cheap, since the vectors are already in the evidence base."], "steps2"));
A(numItem([{ t: "Publish residual, not coverage. ", bold: true }, "The useful artifact for coordination is the remaining space as disjoint executable blocks. Teams claim blocks, execute, and return attestations, which keeps effort non-overlapping by construction."], "steps2"));
A(numItem([{ t: "Version the universe. ", bold: true }, "The universe definition will change as forensics narrows or widens domains. Version it and record which universe digest a residual was computed against, so stale residuals are detectable."], "steps2"));

A(h1("7. Reference Implementation"));
A(table(
  ["File", "Contents"],
  [
    ["tools/covalg.py", "Product, Cover, CoverageSet; exact difference, union, canonical digest"],
    ["tools/residual.py", "Universe definition, example claims, residual calculator"],
    ["tools/attest.py", "Attestation envelope, validator, conformance gating"],
    ["data/coverage-attestation-v1.schema.json", "Normative JSON Schema for the envelope"],
    ["data/conformance_suite.json", "Primitive to validating-cipher vector table"],
    ["data/attestation_example.json", "A validated example, including deliberate defects"],
  ],
  [3400, 5848]
));

A(spacer(60));
A(new Paragraph({
  border: { top: { style: BorderStyle.SINGLE, size: 4, color: "9A9A9A", space: 6 } },
  spacing: { before: 120 },
  children: [new TextRun({ text: "End of Document 5. The reference implementation is self-testing; run python3 covalg.py, residual.py, attest.py.", italics: true, size: 18, color: "6A6A6A", font: S.FONT })],
}));

const doc = new Document({
  numbering,
  styles: { default: { document: { run: { font: S.FONT, size: 21, color: S.INK } } } },
  sections: [{ properties: { page: PAGE }, ...makeHeaderFooter("Coverage Notation and Attestation Specification"), children }],
});
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/claude/BO3_Cipher_Dossier/papers/05_Coverage_Notation_Attestation.docx", buf);
  console.log("wrote 05_Coverage_Notation_Attestation.docx", buf.length, "bytes");
});
