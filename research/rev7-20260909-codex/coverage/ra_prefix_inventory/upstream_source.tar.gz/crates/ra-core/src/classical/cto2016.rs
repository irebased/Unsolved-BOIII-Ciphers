//! CrypTool Online (2016 Wayback snapshot) ciphers not yet covered by other
//! modules: Caesar, Beaufort (alphabet-authoritative variant), Trithemius,
//! Gronsfeld, and the grid-based Rotation transform.
//!
//! Ground truth for every algorithm here is the literal 2016 JS at
//! `docs/toolsites/cryptool2016/js/{caesar,beaufort,trithemius,gronsfeld,
//! rotation}.js`, not the textbook cipher -- see each node's doc comment for
//! the specific divergence(s) found. `ctolib.js`'s shared alphabet-builder
//! semantics (see its own module docs referenced below) are: each checkbox
//! (Uppercase/Lowercase/Digits/Punctuation/Umlauts/Blanks) appends or strips
//! its fixed character block from a running `alphabet` string when toggled;
//! `cleanInputString` deletes every character not literally present in a
//! given alphabet (case-sensitively) except CR/LF/space when `ignore=true`;
//! `inputString` is only used for CSS validity highlighting and has no
//! bearing on the actual `crypt()` output. None of the five tools ported here
//! expose "Five Blocks" style output grouping as anything other than the
//! generic "blocks of 5, spaces stripped first" `clean` checkbox already
//! modelled by [`crate::classical::toolfmt`]'s `group_size` param.
//!
//! # Caesar vs `rot`
//!
//! This crate already has a `rot` node (`crates/ra-core/src/nodes.rs`), but it
//! is a fixed A-Z/a-z-wrap-separately ROT-N -- not CrypTool Online's Caesar.
//! CTO's default alphabet is [`crate::classical::vigenere::CTO_DEFAULT_ALPHABET`],
//! a single **flat** 52-character string (`A`-`Z` then `a`-`z`), so a shift can
//! cross the case boundary exactly like `cto_vigenere`'s alphabet does (see
//! that module's docs) -- `rot`'s per-block wraparound is a different, and for
//! CTO-fidelity purposes wrong, cipher. `caesar.js`'s own "rotation" naming in
//! its GUI functions (`rotateE90`/`increaseKey`/`decreaseKey`) is unrelated to
//! `rotation.js`'s actual "Rotation" tool below -- CTO ships genuinely
//! separate tools named "Caesar" (a keyed shift) and "Rotation" (a grid
//! transposition); the task's "cto_caesar (a.k.a. rotation)" framing conflates
//! them, so both are ported here under their own, non-conflated names.

use crate::classical::toolfmt::{self, CaseFold, InputNorm, OutputFmt};
use crate::classical::vigenere::{cto2016_clean_key, cto2016_crypt, CTO_DEFAULT_ALPHABET};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

// ---------------------------------------------------------------------------
// cto_caesar
// ---------------------------------------------------------------------------

const CTO_CAESAR_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "key",
        ParamType::Int,
        "shift amount (default 0, matching the site's page-load key field); \
         the site clamps this to 0..=alphabet.length-1 client-side, but this \
         node accepts any integer and reduces it mod the alphabet length \
         exactly as caesar.js's own crypt() does",
    ),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "flat, case-sensitive alphabet string (default: 52 chars, A-Z then \
         a-z as distinct blocks -- Caesar.htm's page-load state has both \
         upper/lowercase checked)",
    ),
    ParamSpec::opt(
        "keep_non_alphabet",
        ParamType::Bool,
        "keep text characters outside the alphabet in the output verbatim \
         (default: true, matching the site's default-checked 'Keep \
         non-alphabet characters'); when false, only CR/space/LF survive, \
         matching caesar.js's 'remove' handling",
    ),
);

/// `CTOCaesarAlgorithm.crypt`, transliterated (`caesar.js:31-53`), decrypt
/// direction only (`type == "decrypt"` branch): the site inverts the key
/// itself (`key = alphaLen - key`) before the shared forward-shift loop, so
/// there is no separate decrypt formula to port.
fn cto2016_caesar_decrypt(alphabet: &[char], key: i64, text: &str, keep_non_alphabet: bool) -> String {
    let n = alphabet.len() as i64;
    if n == 0 {
        return String::new();
    }
    // `key = alphaLen - key; key = key % alphaLen;` (caesar.js:38-39).
    let eff = ((n - key.rem_euclid(n)) % n + n) % n;
    let mut out = String::new();
    for c in text.chars() {
        if let Some(idx) = alphabet.iter().position(|&a| a == c) {
            let new_idx = (idx as i64 + eff).rem_euclid(n) as usize;
            out.push(alphabet[new_idx]);
        } else if keep_non_alphabet || matches!(c, '\r' | ' ' | '\n') {
            out.push(c);
        }
    }
    out
}

/// CrypTool Online's Caesar app (`docs/toolsites/cryptool2016/js/caesar.js`,
/// `CTOCaesarAlgorithm.crypt`). See the module docs for why this is not the
/// same cipher as the pre-existing `rot` node.
pub struct CtoCaesar;

impl Node for CtoCaesar {
    fn name(&self) -> &'static str {
        "cto_caesar"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CTO_CAESAR_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let input_norm = toolfmt::read_input_norm("cto_caesar", params, InputNorm::default())?;
        let output_fmt = toolfmt::read_output_fmt("cto_caesar", params, OutputFmt::default())?;

        let key = params.opt_i64("key", 0);
        let alphabet_raw = params.opt_str("alphabet").unwrap_or(CTO_DEFAULT_ALPHABET);
        if alphabet_raw.is_empty() {
            return Err(Error::bad_param("cto_caesar", "alphabet", "must not be empty"));
        }
        let alphabet: Vec<char> = alphabet_raw.chars().collect();
        let keep_non_alphabet = params.opt_bool("keep_non_alphabet", true);

        let data = input_norm.apply(&input.data);
        let text = String::from_utf8(data)
            .map_err(|_| Error::node_failed("cto_caesar", "input is not valid UTF-8"))?;
        let out = cto2016_caesar_decrypt(&alphabet, key, &text, keep_non_alphabet);
        let out = output_fmt.apply(out.as_bytes());

        Ok(Repr::new(out, input.display))
    }
}

register_node!(CTO_CAESAR => || Box::new(CtoCaesar));

// ---------------------------------------------------------------------------
// cto_beaufort (alphabet-authoritative CTO 2016 port)
// ---------------------------------------------------------------------------
//
// A `beaufort` node already exists in `nodes.rs`, cross-checked directly
// against `beaufort.js` and found identical at the site's own default
// parameters (`signs` checked, `casesensitiv` checked) -- see that node's own
// doc comment. This node exists alongside it, in the `cto_vigenere` style,
// specifically to expose the one behaviour the existing node's doc comment
// flags as *not* covered: the `signs`-unchecked ("remove") handling, where
// only CR/space/LF survive instead of every non-alphabet character. Both
// nodes compute byte-identical output whenever `keep_non_alphabet=true`
// (the shared default) -- proven in
// `cto_beaufort_matches_beaufort_node_at_default_params` below.

const CTO_BEAUFORT_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::req(
        "key",
        ParamType::Str,
        "Beaufort key; characters outside the alphabet are always stripped \
         before use (ctolib.js's cleanInputString, unconditional -- 2016 has \
         no toggle to keep them)",
    ),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "flat, case-sensitive alphabet string (default: 52 chars, A-Z then \
         a-z as distinct blocks -- Beaufort.htm's page-load state has both \
         upper/lowercase checked)",
    ),
    ParamSpec::opt(
        "keep_non_alphabet",
        ParamType::Bool,
        "keep text characters outside the alphabet in the output verbatim \
         (default: true, matching the site's default-checked 'Keep \
         non-alphabet characters'); when false, only CR/space/LF survive, \
         matching beaufort.js's 'remove' handling",
    ),
);

/// `CTOBeaufortAlgorithm.crypt`, transliterated (`beaufort.js:26-51`).
/// Beaufort is self-reciprocal -- `type=="encrypt"` and the `else` (decrypt)
/// branch compute the *same* value, `(kp-zp+alphaLen) % alphaLen` (the
/// decrypt branch's `kp-(zp-alphaLen)` is algebraically identical), so there
/// is only one formula to port, unlike Caesar/Vigenere/Trithemius/Gronsfeld.
fn cto2016_beaufort_crypt(alphabet: &[char], key: &[char], text: &str, keep_non_alphabet: bool) -> String {
    if key.is_empty() {
        return String::new();
    }
    let n = alphabet.len() as i64;
    let mut out = String::new();
    let mut j = 0usize;
    for c in text.chars() {
        if let Some(zp) = alphabet.iter().position(|&a| a == c) {
            let kp = alphabet
                .iter()
                .position(|&a| a == key[j % key.len()])
                .unwrap_or(0) as i64;
            let zp = zp as i64;
            let idx = (kp - zp + n).rem_euclid(n);
            out.push(alphabet[idx as usize]);
            j += 1;
        } else if keep_non_alphabet || matches!(c, '\r' | ' ' | '\n') {
            out.push(c);
        }
    }
    out
}

/// CrypTool Online's Beaufort app (`docs/toolsites/cryptool2016/js/beaufort.js`,
/// `CTOBeaufortAlgorithm.crypt`).
pub struct CtoBeaufort;

impl Node for CtoBeaufort {
    fn name(&self) -> &'static str {
        "cto_beaufort"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CTO_BEAUFORT_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let input_norm = toolfmt::read_input_norm("cto_beaufort", params, InputNorm::default())?;
        let output_fmt = toolfmt::read_output_fmt("cto_beaufort", params, OutputFmt::default())?;

        let key_raw = params.req_str("cto_beaufort", "key")?;
        let alphabet_raw = params.opt_str("alphabet").unwrap_or(CTO_DEFAULT_ALPHABET);
        if alphabet_raw.is_empty() {
            return Err(Error::bad_param("cto_beaufort", "alphabet", "must not be empty"));
        }
        let alphabet: Vec<char> = alphabet_raw.chars().collect();
        let keep_non_alphabet = params.opt_bool("keep_non_alphabet", true);

        let key = cto2016_clean_key(&alphabet, key_raw);
        let data = input_norm.apply(&input.data);
        let text = String::from_utf8(data)
            .map_err(|_| Error::node_failed("cto_beaufort", "input is not valid UTF-8"))?;
        let out = cto2016_beaufort_crypt(&alphabet, &key, &text, keep_non_alphabet);
        let out = output_fmt.apply(out.as_bytes());

        Ok(Repr::new(out, input.display))
    }
}

register_node!(CTO_BEAUFORT => || Box::new(CtoBeaufort));

// ---------------------------------------------------------------------------
// cto_trithemius
// ---------------------------------------------------------------------------

const CTO_TRITHEMIUS_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "alphabet string (default: 26-letter A-Z; Trithemius.htm has no \
         alphabet checkboxes at all, unlike Caesar/Beaufort/Vigenere)",
    ),
    ParamSpec::opt(
        "keep_non_alphabet",
        ParamType::Bool,
        "keep text characters outside the alphabet in the output verbatim \
         (default: true, matching the site's default-checked 'Keep \
         non-alphabet characters')",
    ),
);

const TRITHEMIUS_GRONSFELD_ALPHABET: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

/// CrypTool Online's Trithemius app
/// (`docs/toolsites/cryptool2016/js/trithemius.js`,
/// `CTOTrithemiusAlgorithm.crypt`).
///
/// # No `key` parameter -- this is the whole point of the cipher
///
/// Unlike Caesar/Beaufort/Vigenere, `trithemiusCrypt()` never reads a `key`
/// field from the page (`Trithemius.htm` has none) -- it always calls
/// `cryptoclass.crypt("ABCDEFGHIJKLMNOPQRSTUVWXYZ", text, ...)`, i.e. the key
/// IS the alphabet itself. Combined with `cto2016_crypt`'s "advance the key
/// position on every alphabet-member character" loop, this produces the
/// classical Trithemius/"progressive key" cipher: plaintext letter `i`
/// (0-indexed among alphabet members seen so far) shifts by `i mod
/// alphaLen`. Per the "alphabet is authoritative" convention (see
/// `cto_vigenere`), a caller-supplied `alphabet` becomes both the substitution
/// alphabet AND the progressive key, exactly reproducing the site's behaviour
/// when `alphabet` is left at its A-Z default.
///
/// # Forced uppercase, no `casesensitiv` toggle
///
/// `trithemiusCrypt()` unconditionally calls `.toUpperCase()` on both the
/// encode and decode text paths, with no `casesensitiv` checkbox to disable
/// it (unlike Caesar/Beaufort) -- reproduced here as this node's default
/// `input_case`, still overridable via the generic artifact param for
/// exploration.
pub struct CtoTrithemius;

impl Node for CtoTrithemius {
    fn name(&self) -> &'static str {
        "cto_trithemius"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CTO_TRITHEMIUS_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let input_defaults = InputNorm {
            case: CaseFold::Upper,
            ..InputNorm::default()
        };
        let input_norm = toolfmt::read_input_norm("cto_trithemius", params, input_defaults)?;
        let output_fmt = toolfmt::read_output_fmt("cto_trithemius", params, OutputFmt::default())?;

        let alphabet_raw = params.opt_str("alphabet").unwrap_or(TRITHEMIUS_GRONSFELD_ALPHABET);
        if alphabet_raw.is_empty() {
            return Err(Error::bad_param("cto_trithemius", "alphabet", "must not be empty"));
        }
        let alphabet: Vec<char> = alphabet_raw.chars().collect();
        let keep_non_alphabet = params.opt_bool("keep_non_alphabet", true);

        let data = input_norm.apply(&input.data);
        let text = String::from_utf8(data)
            .map_err(|_| Error::node_failed("cto_trithemius", "input is not valid UTF-8"))?;
        let out = cto2016_crypt(&alphabet, &alphabet, &text, keep_non_alphabet, false);
        let out = output_fmt.apply(out.as_bytes());

        Ok(Repr::new(out, input.display))
    }
}

register_node!(CTO_TRITHEMIUS => || Box::new(CtoTrithemius));

// ---------------------------------------------------------------------------
// cto_gronsfeld
// ---------------------------------------------------------------------------

const CTO_GRONSFELD_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "key",
        ParamType::Str,
        "digit-string key (default: \"0157412359\", Gronsfeld.htm's page-load \
         value); each digit 0-9 maps to a Vigenere-style key letter A-J \
         (gronsfeld.js's translate step), non-digit characters are dropped",
    ),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "alphabet string (default: 26-letter A-Z; Gronsfeld.htm has no \
         alphabet checkboxes at all, unlike Caesar/Beaufort/Vigenere)",
    ),
    ParamSpec::opt(
        "keep_non_alphabet",
        ParamType::Bool,
        "keep text characters outside the alphabet in the output verbatim \
         (default: true, matching the site's default-checked 'Keep \
         non-alphabet characters')",
    ),
);

const GRONSFELD_DEFAULT_KEY: &str = "0157412359";

/// `gronsfeld.js`'s digit-to-letter translation (`crypt()`, lines 36-64):
/// `"0"`->`A`, `"1"`->`B`, ... `"9"`->`J`; any other character is dropped
/// silently (the `switch`'s `default:` case does nothing).
fn gronsfeld_translate_key(raw: &str) -> Vec<char> {
    raw.chars()
        .filter_map(|c| c.to_digit(10))
        .map(|d| (b'A' + d as u8) as char)
        .collect()
}

/// CrypTool Online's Gronsfeld app
/// (`docs/toolsites/cryptool2016/js/gronsfeld.js`,
/// `CTOGronsfeldAlgorithm.crypt`). The translated key is then run through the
/// exact same Vigenere-style loop as `cto_vigenere`/`cto_trithemius`
/// (`(zp+kp)%alphaLen` encrypt / `(alphaLen+zp-kp)%alphaLen` decrypt), so
/// [`cto2016_crypt`] is reused directly rather than duplicated.
///
/// # Forced uppercase, no alphabet checkboxes, no `casesensitiv` toggle
///
/// Same as Trithemius: `gronsfeldCrypt()` unconditionally uppercases both
/// text paths and the alphabet is a fixed 26-letter A-Z with no page
/// controls to change it.
pub struct CtoGronsfeld;

impl Node for CtoGronsfeld {
    fn name(&self) -> &'static str {
        "cto_gronsfeld"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CTO_GRONSFELD_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let input_defaults = InputNorm {
            case: CaseFold::Upper,
            ..InputNorm::default()
        };
        let input_norm = toolfmt::read_input_norm("cto_gronsfeld", params, input_defaults)?;
        let output_fmt = toolfmt::read_output_fmt("cto_gronsfeld", params, OutputFmt::default())?;

        // Accepted as either a string or an integer: an all-digit key like
        // `157412359` (no leading zero) is read back by the CLI chain-spec
        // parser as an `Int`, not a `Str` -- see `cto_rotation`'s `rotation`
        // param for the identical reasoning.
        let key_owned: String = match params.get("key") {
            Some(crate::params::Value::Str(s)) => s.clone(),
            Some(crate::params::Value::Int(i)) => i.to_string(),
            Some(other) => {
                return Err(Error::bad_param(
                    "cto_gronsfeld",
                    "key",
                    format!("expected a string or integer, got {other:?}"),
                ));
            }
            None => GRONSFELD_DEFAULT_KEY.to_string(),
        };
        let alphabet_raw = params.opt_str("alphabet").unwrap_or(TRITHEMIUS_GRONSFELD_ALPHABET);
        if alphabet_raw.is_empty() {
            return Err(Error::bad_param("cto_gronsfeld", "alphabet", "must not be empty"));
        }
        let alphabet: Vec<char> = alphabet_raw.chars().collect();
        let keep_non_alphabet = params.opt_bool("keep_non_alphabet", true);

        let key = gronsfeld_translate_key(&key_owned);
        let data = input_norm.apply(&input.data);
        let text = String::from_utf8(data)
            .map_err(|_| Error::node_failed("cto_gronsfeld", "input is not valid UTF-8"))?;
        let out = cto2016_crypt(&alphabet, &key, &text, keep_non_alphabet, false);
        let out = output_fmt.apply(out.as_bytes());

        Ok(Repr::new(out, input.display))
    }
}

register_node!(CTO_GRONSFELD => || Box::new(CtoGronsfeld));

// ---------------------------------------------------------------------------
// cto_rotation
// ---------------------------------------------------------------------------

const CTO_ROTATION_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "blocksize",
        ParamType::Int,
        "grid width (default 5, Rotation.htm's page-load value); must be >= 1",
    ),
    ParamSpec::opt(
        "rotation",
        ParamType::Str,
        "\"90\" (default), \"180\", or \"270\" degrees",
    ),
);

/// `rotateD90`, transliterated verbatim from `rotation.js:44-85` (the
/// decode-direction grid transform). This is not a byte-for-byte-obvious
/// inverse of `rotateE90` -- see the module-level notes above; it is ported
/// as a direct line-by-line transliteration rather than re-derived, because
/// the JS itself is the site's ground truth for what "Decrypt" actually
/// produces, off-by-ones included.
fn rotate_d90(text: &[u8]) -> Vec<u8> {
    text.to_vec()
}

fn rotate_d90_blocksize(text: &[u8], blocksize: usize) -> Vec<u8> {
    if blocksize == 0 || text.is_empty() {
        return rotate_d90(text);
    }
    let textlength = text.len() as i64;
    let bs = blocksize as i64;
    let mut ueber = textlength % bs;
    let arraysize = textlength / bs; // JS parseInt(textlength / blocksize)
    let mut outarray: Vec<Vec<u8>> = vec![Vec::new(); (arraysize + 1) as usize];

    let mut j: i64 = 0;
    while j < textlength {
        let mut i = arraysize;
        while i >= 0 {
            if i == arraysize {
                if ueber > 0 {
                    if let Some(&b) = text.get(j as usize) {
                        outarray[i as usize].push(b);
                    }
                    ueber -= 1;
                } else {
                    j -= 1;
                }
            } else if let Some(&b) = text.get(j as usize) {
                outarray[i as usize].push(b);
            }
            j += 1;
            i -= 1;
        }
    }
    outarray.concat()
}

/// `rotateE90`, transliterated from `rotation.js:22-36` -- only used by the
/// test suite to generate ground-truth ciphertext (this crate is
/// decrypt-direction only), and to prove [`rotate_d90_blocksize`] really is
/// the site's own inverse via the site's own worked shapes.
#[cfg(test)]
fn rotate_e90(text: &[u8], blocksize: usize) -> Vec<u8> {
    if blocksize == 0 {
        return text.to_vec();
    }
    let chunks: Vec<&[u8]> = text.chunks(blocksize).collect();
    let arraylength = chunks.len();
    let mut out = Vec::with_capacity(text.len());
    for j in 0..blocksize {
        for i in (0..arraylength).rev() {
            if let Some(&b) = chunks[i].get(j) {
                out.push(b);
            }
        }
    }
    out
}

/// `rotate180`, transliterated from `rotation.js:93-99`: despite the JS
/// loop's off-by-one start index (`i=textlength`, whose `charAt` is out of
/// range and contributes nothing), the net effect is a literal full reverse.
fn rotate_180(text: &[u8]) -> Vec<u8> {
    let mut out = text.to_vec();
    out.reverse();
    out
}

/// CrypTool Online's Rotation app
/// (`docs/toolsites/cryptool2016/js/rotation.js`). A block-grid
/// transposition, genuinely unrelated to `cto_caesar` despite the site's own
/// GUI-layer function names briefly reusing the word "rotate" for both (see
/// the module docs). Decrypt direction only, matching every other node in
/// this crate: `rotation="90"` runs `rotateD90`, `"180"` runs the
/// self-inverse `rotate180`, `"270"` runs `rotate180` then `rotateD90` (the
/// site's own decode-branch composition order, which is NOT the same order
/// as its encode branch -- see the module docs on `rotationCrypt`).
pub struct CtoRotation;

impl Node for CtoRotation {
    fn name(&self) -> &'static str {
        "cto_rotation"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CTO_ROTATION_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let input_norm = toolfmt::read_input_norm("cto_rotation", params, InputNorm::default())?;
        let output_fmt = toolfmt::read_output_fmt("cto_rotation", params, OutputFmt::default())?;

        let blocksize_raw = params.opt_i64("blocksize", 5);
        if blocksize_raw < 1 {
            return Err(Error::bad_param("cto_rotation", "blocksize", "must be >= 1"));
        }
        let blocksize = blocksize_raw as usize;
        // Accepted as either a string or an integer: the CLI chain-spec
        // parser (`crates/ra-cli/src/spec.rs`) recognises any bare numeral
        // like `90` as an `Int`, not a `Str`, so a purely-digit domain value
        // must not be rejected just because it arrived typed that way --
        // matching the `insert` node's own `text` param precedent.
        let rotation: std::borrow::Cow<'_, str> = match params.get("rotation") {
            Some(crate::params::Value::Str(s)) => std::borrow::Cow::Borrowed(s.as_str()),
            Some(crate::params::Value::Int(i)) => std::borrow::Cow::Owned(i.to_string()),
            Some(other) => {
                return Err(Error::bad_param(
                    "cto_rotation",
                    "rotation",
                    format!("expected a string or integer, got {other:?}"),
                ));
            }
            None => std::borrow::Cow::Borrowed("90"),
        };

        let data = input_norm.apply(&input.data);
        let out = match rotation.as_ref() {
            "90" => rotate_d90_blocksize(&data, blocksize),
            "180" => rotate_180(&data),
            "270" => {
                let step1 = rotate_180(&data);
                rotate_d90_blocksize(&step1, blocksize)
            }
            other => {
                return Err(Error::bad_param(
                    "cto_rotation",
                    "rotation",
                    format!("expected \"90\", \"180\", or \"270\", got {other:?}"),
                ));
            }
        };
        let out = output_fmt.apply(&out);

        Ok(Repr::new(out, input.display))
    }
}

register_node!(CTO_ROTATION => || Box::new(CtoRotation));

// ---------------------------------------------------------------------------
// cto_mono
// ---------------------------------------------------------------------------
//
// Ground truth: `docs/toolsites/cryptool2016/js/mono.js`
// (`CTOMonoAlgorithm.crypt`) plus `docs/toolsites/cryptool2016/Monoalphabetic.htm`
// for the page-load defaults (this tool's alphabets are free-form typed text
// fields, not built from the shared `ctolib.js` checkbox alphabet, so the HTML
// textarea contents -- not a `setAlphabet` call -- are the real default
// source). `casesensitiv` defaults checked=true, `signs` ("Keep non-alphabet
// characters") defaults checked=true, matching every other CTO node's default
// in this module.
//
// # Deviation: the default `ciphertextabc` is ONE character longer than
// `plaintextabc`
//
// `Monoalphabetic.htm`'s page-load `plaintextabc` textarea is the 26-letter
// `"abcdefghijklmnopqrstuvwxyz"`, but `ciphertextabc` is the 27-character
// `"qwertz*/&pas;§$%hjklyxcvbnm"` (the HTML source literally has `&amp;pas;`,
// which decodes to `&pas;` -- an extra `;` the mono.js *file's own* fallback
// JS-literal default (`"qwertz*/&pas§$%hjklyxcvbnm"`, 26 chars, no `;`) does
// not have; the HTML textarea's rendered contents are what a page-load
// `crypt()` call actually reads, per `checkAlphabet()`, so the HTML is
// authoritative here). This length mismatch means: on **encrypt**,
// `ciphertextabc`'s final character (`'m'`, index 26) is simply unreachable
// (only indices `0..=25` are ever produced, since `n = plaintextabc.indexOf(...)`
// tops out at 25); on **decrypt**, decoding the ciphertext character `'m'`
// looks it up at `ciphertextabc` index 26, then reads `plaintextabc.charAt(26)`
// -- one past `plaintextabc`'s last valid index -- which JS returns as `""`
// (empty string, not an error), so **that one ciphertext character silently
// vanishes from the decoded output**. [`cto_mono_default_alphabet_drops_the_dangling_ciphertext_symbol_m`]
// pins this exact behaviour.
//
// # Deviation: `casesensitiv=false` preserves input case rather than folding it
//
// Unlike Trithemius/Gronsfeld (which force-uppercase unconditionally) or
// Caesar/Beaufort (whose flat alphabet spans both cases as literal distinct
// members), `mono.js`'s `sensetiv==false` branch does something more
// deliberate: `plaintextabc = plaintextabc.toLowerCase() +
// plaintextabc.toUpperCase()`. This does **not** fold input case away -- it
// doubles both alphabets into a lower-block-then-upper-block pair with
// matching offsets (`ciphertextabc` gets the identical treatment), so an
// uppercase input character is found at `plaintextabc`'s position
// `alphaLen_of_original + i` and maps through `ciphertextabc`'s *uppercase*
// block at that same offset -- producing case-preserved output through a
// case-folded key comparison, not case-destroyed output. This node reproduces
// that doubling exactly rather than the simpler (and wrong) "just fold
// everything to one case" shortcut a naive transliteration would reach for.
// See [`cto_mono_case_insensitive_preserves_input_case_via_doubled_alphabet`].

const CTO_MONO_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "plaintextabc",
        ParamType::Str,
        "plaintext alphabet (default: \"abcdefghijklmnopqrstuvwxyz\", \
         Monoalphabetic.htm's page-load textarea contents)",
    ),
    ParamSpec::opt(
        "ciphertextabc",
        ParamType::Str,
        "ciphertext alphabet, paired positionally with plaintextabc (default: \
         the site's own 27-character \"qwertz*/&pas;§$%hjklyxcvbnm\" -- one \
         character LONGER than the 26-character plaintextabc default; see \
         the module docs for the resulting dangling-symbol deviation)",
    ),
    ParamSpec::opt(
        "casesensitiv",
        ParamType::Bool,
        "case-sensitive alphabet matching (default: true, Monoalphabetic.htm's \
         page-load checked state); when false, both alphabets are doubled \
         into lower+upper blocks so input case is PRESERVED through a \
         case-folded lookup, not destroyed -- see the module docs",
    ),
    ParamSpec::opt(
        "keep_non_alphabet",
        ParamType::Bool,
        "keep text characters outside the active alphabet in the output \
         verbatim (default: true, matching the site's default-checked 'Keep \
         non-alphabet characters'); when false, only CR/space/LF survive",
    ),
);

const MONO_DEFAULT_PLAINTEXTABC: &str = "abcdefghijklmnopqrstuvwxyz";
/// `Monoalphabetic.htm`'s page-load `ciphertextabc` textarea, HTML-entity
/// decoded (`&amp;` -> `&`) -- 27 characters, one longer than
/// [`MONO_DEFAULT_PLAINTEXTABC`]. See the module docs.
const MONO_DEFAULT_CIPHERTEXTABC: &str = "qwertz*/&pas;§$%hjklyxcvbnm";

/// `CTOMonoAlgorithm.crypt`, transliterated (`mono.js:23-72`), decrypt
/// direction only (the `else` branch, `type != "encrypt"`).
fn cto2016_mono_decrypt(
    plaintextabc_raw: &str,
    ciphertextabc_raw: &str,
    casesensitiv: bool,
    text: &str,
    keep_non_alphabet: bool,
) -> String {
    // `sensetiv==false`: `plaintextabc=plaintextabc.toLowerCase();
    // plaintextabc+=plaintextabc.toUpperCase();` (and the same for
    // ciphertextabc) -- see the module docs for why this preserves case
    // rather than folding it away.
    let (plaintextabc, ciphertextabc): (Vec<char>, Vec<char>) = if casesensitiv {
        (plaintextabc_raw.chars().collect(), ciphertextabc_raw.chars().collect())
    } else {
        let pt_lower = plaintextabc_raw.to_lowercase();
        let ct_lower = ciphertextabc_raw.to_lowercase();
        let mut pt: Vec<char> = pt_lower.chars().collect();
        pt.extend(pt_lower.to_uppercase().chars());
        let mut ct: Vec<char> = ct_lower.chars().collect();
        ct.extend(ct_lower.to_uppercase().chars());
        (pt, ct)
    };

    let mut out = String::new();
    for c in text.chars() {
        // `n = ciphertextabc.indexOf(text.charAt(i));` then
        // `chiffre += plaintextabc.charAt(n);` -- `charAt` on an
        // out-of-range index returns `""` in JS (see the module docs' mono
        // dangling-symbol deviation), reproduced here via `.get()`.
        if let Some(n) = ciphertextabc.iter().position(|&a| a == c) {
            if let Some(&p) = plaintextabc.get(n) {
                out.push(p);
            }
            // else: `plaintextabc.charAt(n)` was `""` -- nothing appended,
            // the character silently vanishes from the output.
        } else if keep_non_alphabet || matches!(c, '\r' | ' ' | '\n') {
            out.push(c);
        }
    }
    out
}

/// CrypTool Online's Monoalphabetic Substitution app
/// (`docs/toolsites/cryptool2016/js/mono.js`, `CTOMonoAlgorithm.crypt`).
pub struct CtoMono;

impl Node for CtoMono {
    fn name(&self) -> &'static str {
        "cto_mono"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CTO_MONO_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let input_norm = toolfmt::read_input_norm("cto_mono", params, InputNorm::default())?;
        let output_fmt = toolfmt::read_output_fmt("cto_mono", params, OutputFmt::default())?;

        let plaintextabc = params.opt_str("plaintextabc").unwrap_or(MONO_DEFAULT_PLAINTEXTABC);
        let ciphertextabc = params.opt_str("ciphertextabc").unwrap_or(MONO_DEFAULT_CIPHERTEXTABC);
        if plaintextabc.is_empty() || ciphertextabc.is_empty() {
            return Err(Error::bad_param("cto_mono", "plaintextabc/ciphertextabc", "must not be empty"));
        }
        let casesensitiv = params.opt_bool("casesensitiv", true);
        let keep_non_alphabet = params.opt_bool("keep_non_alphabet", true);

        let data = input_norm.apply(&input.data);
        let text = String::from_utf8(data)
            .map_err(|_| Error::node_failed("cto_mono", "input is not valid UTF-8"))?;
        let out = cto2016_mono_decrypt(plaintextabc, ciphertextabc, casesensitiv, &text, keep_non_alphabet);
        let out = output_fmt.apply(out.as_bytes());

        Ok(Repr::new(out, input.display))
    }
}

register_node!(CTO_MONO => || Box::new(CtoMono));

// ---------------------------------------------------------------------------
// cto_multiplicative
// ---------------------------------------------------------------------------
//
// Ground truth: `docs/toolsites/cryptool2016/js/multiplikative.js`
// (`CTOMultiplikativeAlgorithm.crypt` and `parseAlphabet`), plus
// `Multiplicative.htm` for defaults: `alphabet` defaults to
// [`CTO_DEFAULT_ALPHABET`] (uppercase+lowercase checked, the div's rendered
// default text), and `key` defaults to `3` (the `<option ... selected>` in
// the key dropdown). `casesensitiv` and `signs` both default checked=true.
//
// # Deviation: `pos = n*key; while (pos>alphaLen) pos -= alphaLen;` is not `%`
//
// The textbook multiplicative cipher computes `(n*key) mod alphaLen`, which
// always lands in `0..alphaLen-1`. The site's own loop only subtracts
// `alphaLen` while `pos` is STRICTLY greater than `alphaLen` -- so for a
// coprime key (the only kind the site's own dropdown ever offers, since it's
// populated by a GCD sieve) this is provably identical to `%` for every `n in
// 1..alphaLen-1` (a coprime `key` makes `n*key` a nonzero multiple of
// `alphaLen` only when `n==0`, which never enters the loop and stays `0`).
// But for a **non-coprime or negative key** -- reachable only by calling this
// node directly, bypassing the site's own dropdown -- the divergence is real
// and severe:
//   - A **negative key** makes `n*key <= 0` for every `n >= 0`, so the while
//     loop (which only ever subtracts, never adds) never fires; every `n > 0`
//     produces a negative `pos`, and `alphabet.charAt(negative)` is `""` in
//     JS -- the character silently vanishes. Only `n == 0` (`pos == 0`)
//     survives. See [`cto_multiplicative_negative_key_collapses_output_to_the_first_alphabet_symbol_only`].
//   - A **key that shares a factor with `alphaLen`** collapses distinct
//     plaintext symbols onto the same ciphertext symbol (the textbook
//     multiplicative cipher's own well-known weakness), reproduced here
//     as-is rather than rejected, matching the site (which prevents this only
//     via its dropdown's UI-layer sieve, not inside `crypt()` itself).
// This node accepts any `i64` key, exactly like the site's `crypt()` would if
// called with one bypassing the dropdown, and documents rather than guards
// against the two failure modes above.
//
// # `alphabet` is authoritative; `cipheralpha` is always derived, never typed
//
// Unlike `cto_mono`'s two independently-typed alphabets, `multiplikative.js`
// only ever lets the user type ONE alphabet (built from the same checkbox
// machinery as Caesar/Beaufort) and always DERIVES `ciphertextabc` from it via
// `parseAlphabet`'s `pos = i*key; while(pos>alphaLen) pos-=alphaLen;` loop --
// so this node exposes only `alphabet` and `key`, deriving the ciphertext
// alphabet internally rather than accepting it as a separate param.

const CTO_MULTIPLICATIVE_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "key",
        ParamType::Int,
        "multiplicative key (default 3, Multiplicative.htm's page-load \
         selected dropdown value); the site's dropdown only ever offers keys \
         coprime with alphabet.length, but this node accepts any integer -- \
         see the module docs for what a non-coprime or negative key literally \
         does per multiplikative.js's own (non-modulo) reduction loop",
    ),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "flat, case-sensitive alphabet string (default: 52 chars, A-Z then \
         a-z as distinct blocks -- Multiplicative.htm's page-load state has \
         both upper/lowercase checked); the ciphertext alphabet is always \
         DERIVED from this one, never typed separately (see module docs)",
    ),
    ParamSpec::opt(
        "keep_non_alphabet",
        ParamType::Bool,
        "keep text characters outside the alphabet in the output verbatim \
         (default: true, matching the site's default-checked 'Keep \
         non-alphabet characters'); when false, only CR/space/LF survive",
    ),
);

/// `pos = n*key; while (pos > alphaLen) pos -= alphaLen;`, transliterated
/// literally (`multiplikative.js:68-69`/`259-260`) -- NOT `%`, see the module
/// docs for exactly where this diverges from the textbook formula.
fn cto2016_multiplicative_pos(n: i64, key: i64, alpha_len: i64) -> i64 {
    let mut pos = n * key;
    while pos > alpha_len {
        pos -= alpha_len;
    }
    pos
}

/// `String.charAt`'s exact out-of-range behaviour: `None` (JS `""`) for any
/// negative or `>= len` index, never a panic and never wraparound.
fn js_char_at(alphabet: &[char], idx: i64) -> Option<char> {
    if idx < 0 {
        return None;
    }
    alphabet.get(idx as usize).copied()
}

/// `parseAlphabet`'s `out2` derivation (`multiplikative.js:257-262`): the
/// ciphertext alphabet, built by applying [`cto2016_multiplicative_pos`] to
/// every alphabet position in turn. Shorter than `alphabet` whenever a
/// position's `pos` falls out of range (see the module docs) -- entries are
/// simply skipped, exactly matching `out2 = out2 + alphabet.charAt(pos)`
/// appending `""` for an out-of-range `pos`.
fn cto2016_multiplicative_cipheralpha(alphabet: &[char], key: i64) -> Vec<char> {
    let alpha_len = alphabet.len() as i64;
    (0..alpha_len)
        .filter_map(|i| js_char_at(alphabet, cto2016_multiplicative_pos(i, key, alpha_len)))
        .collect()
}

/// `CTOMultiplikativeAlgorithm.crypt`, transliterated (`multiplikative.js:32-82`),
/// decrypt direction only (the `type=="decrypt"` branch, a direct lookup
/// through the derived `cipheralpha`).
fn cto2016_multiplicative_decrypt(alphabet: &[char], cipheralpha: &[char], text: &str, keep_non_alphabet: bool) -> String {
    let mut out = String::new();
    for c in text.chars() {
        if let Some(n) = cipheralpha.iter().position(|&a| a == c) {
            if let Some(&p) = alphabet.get(n) {
                out.push(p);
            }
        } else if keep_non_alphabet || matches!(c, '\r' | ' ' | '\n') {
            out.push(c);
        }
    }
    out
}

/// CrypTool Online's Multiplicative app
/// (`docs/toolsites/cryptool2016/js/multiplikative.js`).
pub struct CtoMultiplicative;

impl Node for CtoMultiplicative {
    fn name(&self) -> &'static str {
        "cto_multiplicative"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CTO_MULTIPLICATIVE_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let input_norm = toolfmt::read_input_norm("cto_multiplicative", params, InputNorm::default())?;
        let output_fmt = toolfmt::read_output_fmt("cto_multiplicative", params, OutputFmt::default())?;

        let key = params.opt_i64("key", 3);
        let alphabet_raw = params.opt_str("alphabet").unwrap_or(CTO_DEFAULT_ALPHABET);
        if alphabet_raw.is_empty() {
            return Err(Error::bad_param("cto_multiplicative", "alphabet", "must not be empty"));
        }
        let alphabet: Vec<char> = alphabet_raw.chars().collect();
        let keep_non_alphabet = params.opt_bool("keep_non_alphabet", true);

        let cipheralpha = cto2016_multiplicative_cipheralpha(&alphabet, key);
        let data = input_norm.apply(&input.data);
        let text = String::from_utf8(data)
            .map_err(|_| Error::node_failed("cto_multiplicative", "input is not valid UTF-8"))?;
        let out = cto2016_multiplicative_decrypt(&alphabet, &cipheralpha, &text, keep_non_alphabet);
        let out = output_fmt.apply(out.as_bytes());

        Ok(Repr::new(out, input.display))
    }
}

register_node!(CTO_MULTIPLICATIVE => || Box::new(CtoMultiplicative));

// ---------------------------------------------------------------------------
// cto_transposition
// ---------------------------------------------------------------------------
//
// Ground truth: `docs/toolsites/cryptool2016/js/transposition.js`
// (`CTOTranspositionAlgorithm.decodePartA`/`encodePartB`), plus
// `Transposition.htm` for defaults: `alphabet` defaults to the 26-letter
// A-Z-only [`TRITHEMIUS_GRONSFELD_ALPHABET`] (only "Upper case" is checked by
// default, unlike Caesar/Beaufort/Multiplicative's 52-char default -- this
// tool's alphabet options table has no page-load state matching those other
// tools'), and `key` defaults to `"CODE"` (the `<input>`'s literal value
// attribute).
//
// # Column order comes from the ALPHABET, not string comparison
//
// This is a standard columnar transposition, but the "alphabetical rank" that
// decides read/write column order is computed by scanning the declared
// `alphabet` string left to right and recording, for each of its characters
// that appears (once) in `key`, that key position's rank -- NOT by sorting the
// key's characters with a generic string comparator. This makes a
// non-standard `alphabet` (already this crate's established
// alphabet-authoritative convention) a real, cheap way to reorder columns
// without changing the key text itself.
//
// # The key is cleaned to the alphabet before use, unconditionally
//
// `transpositionCrypt()` always runs `key =
// ctolib.cleanInputString(key, allowedkeys=alphabet, false)` before calling
// either `encodePartB`/`decodePartA`, for BOTH directions, with no site
// toggle to skip it -- reproduced here via [`cto2016_clean_key`]. A `key` that
// cleans down to `""` makes the site's own `transpositionCrypt` return with
// no output at all (`if(key.length<=0){return;}` on decode; encode explicitly
// blanks `codtxt`); this node surfaces that as a `BadParam` error instead of a
// silent no-op, since "produce nothing" isn't a meaningful `Repr` for a
// pipeline stage.
//
// # No alphabet-membership filtering of the TEXT at all
//
// Unlike every substitution/polyalphabetic node in this module,
// `decodePartA`/`encodePartB` never test the ciphertext/plaintext TEXT against
// `alphabet` -- they operate on `ciphertext.length`/`substr` directly, so
// every byte of the input, alphabet member or not, participates in the
// transposition. There is consequently no `keep_non_alphabet` param here: the
// concept doesn't apply.

const CTO_TRANSPOSITION_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::req(
        "key",
        ParamType::Str,
        "transposition key; cleaned to the characters literally present in \
         alphabet before use (ctolib.js's cleanInputString, unconditional -- \
         no site toggle to keep foreign characters); a key that cleans down \
         to empty is rejected (the site itself produces no output for it)",
    ),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "alphabet used ONLY to rank the key's characters into a column order \
         (default: 26-letter A-Z; Transposition.htm's page-load state has \
         only 'Upper case' checked, unlike Caesar/Beaufort/Multiplicative)",
    ),
);

/// The site's own column-ranking scan (`transposition.js:40-60` in
/// `decodePartA`, and the equivalent inline loop in `encodePartB:152-171`):
/// walk `alphabet` left to right; each time an alphabet character is found
/// (once) in the still-unconsumed `key`, record that key position's rank
/// (0-indexed, in scan order) and blank that key position out so a repeated
/// letter isn't matched twice. Returns one rank per `key` character, i.e.
/// `transparray` — `rank_of_column[i]` is which `key` position has rank `i`.
fn cto2016_transposition_ranks(alphabet: &[char], key: &[char]) -> Vec<usize> {
    let klen = key.len();
    let mut remaining = key.to_vec();
    let mut ranks = Vec::with_capacity(klen);
    let mut i = 0usize;
    while ranks.len() < klen && i < alphabet.len() {
        if let Some(t) = remaining.iter().position(|&k| k == alphabet[i]) {
            ranks.push(t);
            remaining[t] = '\0'; // "_" sentinel in the JS; any never-matched char works
        } else {
            i += 1;
        }
    }
    ranks
}

/// `decodePartA`, transliterated (`transposition.js:26-136`), the plaintext
/// string only (`outputarray[0]`) -- the "row sequence" display string
/// (`outputarray[1]`) is cosmetic GUI feedback with no bearing on decrypted
/// output and is not reproduced.
fn cto2016_transposition_decrypt(alphabet: &[char], key: &[char], ciphertext: &str) -> String {
    let klen = key.len();
    if klen == 0 {
        return String::new();
    }
    let transparray = cto2016_transposition_ranks(alphabet, key);
    let ciphertext: Vec<char> = ciphertext.chars().collect();
    let chars = ciphertext.len();
    let extracols = chars % klen;
    // `indizesarray[o] = transparray.indexOf(o)` for `o in 0..extracols`.
    let indizesarray: Vec<usize> = (0..extracols)
        .filter_map(|o| transparray.iter().position(|&t| t == o))
        .collect();

    let col_length = chars / klen; // `parseInt(ciphertext.length / klen)`
    let mut cols: Vec<Vec<char>> = vec![Vec::new(); klen];
    // `cursor` plays the role of the JS loop's `(i*colLength)+extra`: it
    // accumulates every previous column's actual length (colLength, or
    // colLength+1 for a rank that got the extra character), so it always
    // points at the right offset without a separate `extra` counter.
    let mut cursor = 0usize;
    for i in 0..klen {
        let len = if indizesarray.contains(&i) {
            col_length + 1
        } else {
            col_length
        };
        let end = (cursor + len).min(ciphertext.len());
        cols[i] = ciphertext[cursor.min(ciphertext.len())..end].to_vec();
        cursor += len;
    }

    // `outputarray[i] = cols[transparray.indexOf(i)]` -- reindex from rank
    // order to original column order.
    let mut outputarray: Vec<Vec<char>> = Vec::with_capacity(klen);
    for i in 0..klen {
        let rank = transparray.iter().position(|&t| t == i).unwrap_or(0);
        outputarray.push(cols[rank].clone());
    }

    let mut tmp_col_length = col_length;
    if extracols > 0 {
        tmp_col_length += 1;
    }
    let mut plaintext = String::new();
    for row in 0..tmp_col_length {
        for col in outputarray.iter() {
            if let Some(&c) = col.get(row) {
                plaintext.push(c);
            }
        }
    }
    plaintext
}

/// CrypTool Online's Transposition app
/// (`docs/toolsites/cryptool2016/js/transposition.js`).
pub struct CtoTransposition;

impl Node for CtoTransposition {
    fn name(&self) -> &'static str {
        "cto_transposition"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CTO_TRANSPOSITION_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let input_norm = toolfmt::read_input_norm("cto_transposition", params, InputNorm::default())?;
        let output_fmt = toolfmt::read_output_fmt("cto_transposition", params, OutputFmt::default())?;

        let key_raw = params.req_str("cto_transposition", "key")?;
        let alphabet_raw = params.opt_str("alphabet").unwrap_or(TRITHEMIUS_GRONSFELD_ALPHABET);
        if alphabet_raw.is_empty() {
            return Err(Error::bad_param("cto_transposition", "alphabet", "must not be empty"));
        }
        let alphabet: Vec<char> = alphabet_raw.chars().collect();
        let key = crate::classical::vigenere::cto2016_clean_key(&alphabet, key_raw);
        if key.is_empty() {
            return Err(Error::bad_param(
                "cto_transposition",
                "key",
                "cleaned to empty against alphabet -- the site itself produces no output for this",
            ));
        }

        let data = input_norm.apply(&input.data);
        let text = String::from_utf8(data)
            .map_err(|_| Error::node_failed("cto_transposition", "input is not valid UTF-8"))?;
        let out = cto2016_transposition_decrypt(&alphabet, &key, &text);
        let out = output_fmt.apply(out.as_bytes());

        Ok(Repr::new(out, input.display))
    }
}

register_node!(CTO_TRANSPOSITION => || Box::new(CtoTransposition));

// ---------------------------------------------------------------------------
// cto_kamasutra
// ---------------------------------------------------------------------------
//
// Ground truth: `docs/toolsites/cryptool2016/js/kamasutra.js`
// (`CTOKamasutraAlgorithm.crypt`), plus `Kamasutra.htm` for defaults: `key`
// defaults to the site's own `"kjzqiglxubyfhvpnwreamscdot"` (26 characters,
// its own two 13-character halves are shown as separate "plaintext"/
// "ciphertext" alphabets in the GUI, but `crypt()` only ever consumes the one
// concatenated `key` string). `signs` ("keep non-alphabet characters")
// defaults checked=true.
//
// # Self-reciprocal by construction, `type` is dead code
//
// `crypt(key, text, type, handle)`'s body never reads `type` -- swapping
// index `n` with `n +/- half` is its own inverse regardless of direction, so
// encrypt and decrypt are the SAME formula. This node is consequently
// idempotent-pair (`apply(apply(x)) == x`), proven directly rather than
// inferred, in [`cto_kamasutra_is_self_reciprocal`].
//
// # Odd-length key silently produces empty output, not an error
//
// `if (key.length % 2 != 0) return "";` -- the site's own `uniqueTest` in the
// GUI layer would flag an odd-length key as invalid before this is ever
// reached in practice, but `crypt()` itself has no guard beyond returning
// `""`. This node treats that the same way `cto_beaufort`'s empty-key case is
// treated: a `BadParam` rejection rather than a silent empty `Repr`, since (as
// with transposition's empty-key case) "produce nothing" is not a meaningful
// pipeline output. See [`cto_kamasutra_rejects_odd_length_key`].

const CTO_KAMASUTRA_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::opt(
        "key",
        ParamType::Str,
        "even-length key string whose two halves are paired positionally \
         (default: \"kjzqiglxubyfhvpnwreamscdot\", Kamasutra.htm's page-load \
         value); an odd-length key is rejected -- see the module docs",
    ),
    ParamSpec::opt(
        "keep_non_alphabet",
        ParamType::Bool,
        "keep text characters outside the key's alphabet in the output \
         verbatim (default: true, matching the site's default-checked 'Keep \
         non-alphabet characters'); when false, only CR/space/LF survive",
    ),
);

const KAMASUTRA_DEFAULT_KEY: &str = "kjzqiglxubyfhvpnwreamscdot";

/// `CTOKamasutraAlgorithm.crypt`, transliterated (`kamasutra.js:26-52`). Both
/// directions compute the identical formula (`type` is unused in the JS body
/// -- see the module docs), so there is only one function to port.
fn cto2016_kamasutra_crypt(key: &[char], text: &str, keep_non_alphabet: bool) -> String {
    let half = key.len() / 2;
    let mut out = String::new();
    for c in text.chars() {
        if let Some(n) = key.iter().position(|&k| k == c) {
            let m = if n < half { n + half } else { n - half };
            out.push(key[m]);
        } else if keep_non_alphabet || matches!(c, '\r' | ' ' | '\n') {
            out.push(c);
        }
    }
    out
}

/// CrypTool Online's Kamasutra app
/// (`docs/toolsites/cryptool2016/js/kamasutra.js`).
pub struct CtoKamasutra;

impl Node for CtoKamasutra {
    fn name(&self) -> &'static str {
        "cto_kamasutra"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CTO_KAMASUTRA_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let input_norm = toolfmt::read_input_norm("cto_kamasutra", params, InputNorm::default())?;
        let output_fmt = toolfmt::read_output_fmt("cto_kamasutra", params, OutputFmt::default())?;

        let key_raw = params.opt_str("key").unwrap_or(KAMASUTRA_DEFAULT_KEY);
        if key_raw.chars().count() % 2 != 0 {
            return Err(Error::bad_param(
                "cto_kamasutra",
                "key",
                "must have even length (kamasutra.js's own crypt() returns \"\" for an odd-length key)",
            ));
        }
        let key: Vec<char> = key_raw.chars().collect();
        let keep_non_alphabet = params.opt_bool("keep_non_alphabet", true);

        let data = input_norm.apply(&input.data);
        let text = String::from_utf8(data)
            .map_err(|_| Error::node_failed("cto_kamasutra", "input is not valid UTF-8"))?;
        let out = cto2016_kamasutra_crypt(&key, &text, keep_non_alphabet);
        let out = output_fmt.apply(out.as_bytes());

        Ok(Repr::new(out, input.display))
    }
}

register_node!(CTO_KAMASUTRA => || Box::new(CtoKamasutra));

// ---------------------------------------------------------------------------
// cto_jaeger
// ---------------------------------------------------------------------------
//
// Ground truth: `docs/toolsites/cryptool2016/js/jaeger.js`
// (`CTOJaegerAlgorithm.crypt`). Despite the site's own filename/tool grouping
// alongside the substitution ciphers, this is a rail-fence/zigzag
// TRANSPOSITION keyed by a rail `depth` and a phase `offset` -- confirmed by
// reading the JS directly, per this task's brief: `crypt()` never looks up any
// alphabet or key string at all, it only ever indexes `text.charAt(j)` by
// position. No `Jaeger.htm` capture exists in this repo's snapshot (unlike
// every other tool in this module), so **`depth` has no site-verified
// default** -- it is a required param here rather than an invented one.
// `offset` defaults to `0` (a genuinely neutral "no phase shift" value, not a
// site-observed default either, since the same capture gap applies).
//
// # Unconditional `\W` stripping -- no `keep_non_alphabet` toggle exists
//
// Both directions open with `text.replace(/\W/g, "")` (`\w` in a JS regex
// without the `u` flag is ASCII-only: `[A-Za-z0-9_]`), stripping every
// non-word character UNCONDITIONALLY before any rail-fence math runs, with no
// site checkbox to keep them. This is a harder-edged version of every other
// node's `keep_non_alphabet=false` path (CR/space/LF get no exemption here
// either) and is why hex survives this cipher but base64 does not -- see the
// medium-compatibility tests below.
//
// # `offset` shifts the fence's phase via literal `#`/`X` placeholder chars
//
// `n = 2*depth - 2` is the zigzag's period; `offset` (reduced into `0..n`)
// prepends that many placeholder characters before running the rail-fence
// pass, then strips them back out of the ciphertext -- but their PRESENCE
// still shifted how many real characters land in each rail, so decrypt must
// reconstruct the same placeholder-padded row lengths to invert it. This node
// transliterates `crypt()`'s decrypt branch (`jaeger.js:63-120`) literally,
// including its `Math.ceil`/`Math.floor` integer-division arithmetic (ported
// via `i64::div_euclid`/`rem_euclid`-based exact ceiling/floor division,
// matching JS's own rounding for the negative operands `offset - i` can
// produce mid-computation).
//
// # Depth must be >= 2 -- unverifiable against a site default, verified structurally
// `n = 2*depth - 2` must be a positive, even period for the rail-index maths
// below to be well-defined (`depth=1` gives `n=0`, a division by zero in the
// site's own JS); `checkKey()`'s own clamp (`if (key<2) key=2`) confirms `2`
// is the site's own established floor, reproduced here as a hard `BadParam`
// rejection below it.

const CTO_JAEGER_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::req(
        "depth",
        ParamType::Int,
        "rail-fence depth (number of rails), must be >= 2 -- matches \
         jaeger.js's own checkKey() floor; no site-verified default exists \
         (see the module docs), so this param is required rather than \
         defaulted",
    ),
    ParamSpec::opt(
        "offset",
        ParamType::Int,
        "phase offset for the zigzag pattern (default 0, a neutral \
         assumption -- see the module docs); reduced into 0..2*(depth-1) \
         exactly as jaeger.js's own crypt() does",
    ),
);

fn ceil_div(a: i64, b: i64) -> i64 {
    let q = a.div_euclid(b);
    let r = a.rem_euclid(b);
    if r == 0 {
        q
    } else {
        q + 1
    }
}

fn floor_div(a: i64, b: i64) -> i64 {
    a.div_euclid(b)
}

/// `\w` in a JS regex without the `u` flag: ASCII `[A-Za-z0-9_]` only.
fn is_js_word_char(c: char) -> bool {
    c.is_ascii_alphanumeric() || c == '_'
}

/// `CTOJaegerAlgorithm.crypt`'s `type=="encrypt"` branch (`jaeger.js:27-61`),
/// only used by the test suite to generate ground-truth ciphertext (this
/// crate is decrypt-direction only), mirroring `cto_rotation`'s
/// `rotate_e90` precedent.
#[cfg(test)]
fn jaeger_encrypt(text: &str, depth: i64, offset: i64) -> String {
    let plaintext: Vec<char> = text.chars().filter(|&c| is_js_word_char(c)).collect();
    let n = 2 * depth - 2;
    let offset = offset.rem_euclid(n);
    let mut padded: Vec<char> = vec!['#'; offset as usize];
    padded.extend(plaintext);

    let mut ciphertext = String::new();
    let half = n / 2;
    for d in 0..=half {
        for (j, &c) in padded.iter().enumerate() {
            let jm = j as i64 % n;
            if jm == d || jm == n - d {
                ciphertext.push(c);
            }
        }
    }
    ciphertext.chars().filter(|&c| c != '#').collect()
}

/// `CTOJaegerAlgorithm.crypt`'s `else` (decrypt) branch, transliterated
/// (`jaeger.js:63-120`); see the module docs for the ceil/floor-division and
/// placeholder-padding notes.
fn cto2016_jaeger_decrypt(text: &str, depth: i64, offset: i64) -> String {
    let n = 2 * depth - 2;
    let half = n / 2;
    let ciphertext: Vec<char> = text.chars().filter(|&c| is_js_word_char(c)).collect();
    let offset = offset.rem_euclid(n);
    let k = ciphertext.len() as i64 + offset;

    let mut off = vec![0i64; (half + 1) as usize];
    off[0] = ceil_div(offset, n);
    for i in 1..half {
        off[i as usize] = ceil_div(offset - i, n) + floor_div(offset + i - 1, n);
    }
    off[half as usize] = ceil_div(offset - half, n);

    let xs: Vec<String> = off
        .iter()
        .map(|&o| match o {
            0 => String::new(),
            1 => "X".to_string(),
            2 => "XX".to_string(),
            // Not reachable for any `offset in 0..n` and `depth >= 2` (see the
            // module docs' bound argument) -- treated as "no placeholder"
            // rather than reproducing JS's `undefined` string-coercion
            // artifact, which has no sensible Rust analogue.
            _ => String::new(),
        })
        .collect();

    let mut remaining: String = xs[0].clone();
    remaining.extend(ciphertext.iter());
    let mut a: Vec<Vec<char>> = vec![Vec::new(); (half + 1) as usize];

    let len0 = ceil_div(k, n).max(0) as usize;
    let remaining_chars: Vec<char> = remaining.chars().collect();
    let split0 = len0.min(remaining_chars.len());
    a[0] = remaining_chars[..split0].to_vec();
    let mut rest: Vec<char> = remaining_chars[split0..].to_vec();

    for i in 1..half {
        let mut next: Vec<char> = xs[i as usize].chars().collect();
        next.extend(rest.iter());
        let blocklen = (ceil_div(k - i, n) + floor_div(k + i - 1, n)).max(0) as usize;
        let split = blocklen.min(next.len());
        a[i as usize] = next[..split].to_vec();
        rest = next[split..].to_vec();
    }
    let mut last: Vec<char> = xs[half as usize].chars().collect();
    last.extend(rest.iter());
    a[half as usize] = last;

    let mut cursors = vec![0usize; (half + 1) as usize];
    let mut i: i64 = 0;
    let mut increment: i64 = 1;
    let mut plaintext = String::new();
    while cursors[i as usize] < a[i as usize].len() {
        plaintext.push(a[i as usize][cursors[i as usize]]);
        cursors[i as usize] += 1;
        if i == 0 {
            increment = 1;
        }
        if i == half {
            increment = -1;
        }
        i += increment;
    }

    plaintext.chars().filter(|&c| c != 'X').collect()
}

/// CrypTool Online's Jaeger app (`docs/toolsites/cryptool2016/js/jaeger.js`).
/// See the module docs for why this is a transposition, not a substitution
/// cipher, despite its GUI-layer grouping alongside Mono/Kamasutra.
pub struct CtoJaeger;

impl Node for CtoJaeger {
    fn name(&self) -> &'static str {
        "cto_jaeger"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CTO_JAEGER_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let input_norm = toolfmt::read_input_norm("cto_jaeger", params, InputNorm::default())?;
        let output_fmt = toolfmt::read_output_fmt("cto_jaeger", params, OutputFmt::default())?;

        let depth = params.req_i64("cto_jaeger", "depth")?;
        if depth < 2 {
            return Err(Error::bad_param("cto_jaeger", "depth", "must be >= 2"));
        }
        let offset = params.opt_i64("offset", 0);

        let data = input_norm.apply(&input.data);
        let text = String::from_utf8(data)
            .map_err(|_| Error::node_failed("cto_jaeger", "input is not valid UTF-8"))?;
        let out = cto2016_jaeger_decrypt(&text, depth, offset);
        let out = output_fmt.apply(out.as_bytes());

        Ok(Repr::new(out, input.display))
    }
}

register_node!(CTO_JAEGER => || Box::new(CtoJaeger));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    // -- cto_caesar ----------------------------------------------------------

    /// Ground truth: transliteration of `caesar.js:31-53`'s decrypt branch,
    /// hand-computed over the 52-char default alphabet. Decrypt inverts the
    /// key first (`eff = alphaLen - key = 52-5 = 47`), then shifts forward:
    /// "abc" sits at flat-alphabet positions 26,27,28; `(26+47)%52=21`,
    /// `(27+47)%52=22`, `(28+47)%52=23` land on positions 21,22,23 -- back in
    /// the UPPERCASE block ("VWX") -- crossing the case boundary exactly like
    /// `cto_vigenere`'s flat alphabet (see the module docs).
    #[test]
    fn cto_caesar_matches_2016_default_alphabet_shift() {
        let n = registry().get("cto_caesar").unwrap();
        let p = params! {"key" => 5i64};
        let out = n.apply(&Repr::bytes(b"abc".to_vec()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "VWX");
    }

    /// Divergence pin vs `rot`: on the flat 52-char alphabet a shift can
    /// cross the case boundary, unlike `rot`'s per-block wraparound. Position
    /// of 'A' is 0; decrypting with key=1 means eff = 52-1 = 51, so 'A' (idx
    /// 0) maps to idx 51 = 'z' -- crossing into the lowercase block.
    #[test]
    fn cto_caesar_can_cross_case_boundary_unlike_rot() {
        let n = registry().get("cto_caesar").unwrap();
        let p = params! {"key" => 1i64};
        let out = n.apply(&Repr::bytes(b"A".to_vec()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "z");

        let rot = registry().get("rot").unwrap();
        let rot_out = rot.apply(&Repr::bytes(b"A".to_vec()), &params! {"n" => -1i64}).unwrap();
        assert_eq!(rot_out.data, b"Z"); // rot never leaves the uppercase block
    }

    #[test]
    fn cto_caesar_default_key_zero_is_identity() {
        let n = registry().get("cto_caesar").unwrap();
        let out = n.apply(&Repr::bytes(b"Hello, World!".to_vec()), &Params::new()).unwrap();
        assert_eq!(out.data, b"Hello, World!");
    }

    #[test]
    fn cto_caesar_keep_non_alphabet_false_drops_punctuation() {
        let n = registry().get("cto_caesar").unwrap();
        let p = params! {"key" => 0i64, "keep_non_alphabet" => false};
        let out = n.apply(&Repr::bytes(b"Hi, Bob!".to_vec()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "Hi Bob");
    }

    #[test]
    fn cto_caesar_is_xf_family_and_not_layer_forming() {
        let n = registry().get("cto_caesar").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    #[test]
    fn cto_caesar_preserves_display() {
        let n = registry().get("cto_caesar").unwrap();
        let out = n
            .apply(&Repr::new(b"abc".to_vec(), Display::Hex), &Params::new())
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    // -- cto_beaufort ----------------------------------------------------------

    /// Ground truth: transliteration of `beaufort.js:26-51`. Key "key" over
    /// alphabet position math: 'A'(0),'B'(1),'C'(2) as plaintext with key
    /// "key" ('k'=36,'e'=30,'y'=50 in the 52-char flat alphabet) -- hand
    /// verified: idx=(kp-zp+52)%52.
    #[test]
    fn cto_beaufort_matches_hand_computed_vector() {
        let n = registry().get("cto_beaufort").unwrap();
        let p = params! {"key" => "key"};
        // Encrypt-by-hand (self-reciprocal, so encrypt==decrypt here):
        // 'A' idx0, 'k' idx 36 -> (36-0+52)%52=36 -> 'k'
        // 'B' idx1, 'e' idx 30 -> (30-1+52)%52=81%52=29 -> 'd'
        // 'C' idx2, 'y' idx 50 -> (50-2+52)%52=100%52=48 -> 'w'
        let out = n.apply(&Repr::bytes(b"ABC".to_vec()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "kdw");
    }

    /// Beaufort is self-reciprocal: applying it twice with the same key
    /// recovers the original text.
    #[test]
    fn cto_beaufort_is_self_reciprocal() {
        let n = registry().get("cto_beaufort").unwrap();
        let p = params! {"key" => "SECRETKEY"};
        let text = b"TheQuickBrownFoxJumpsOverTheLazyDog".to_vec();
        let once = n.apply(&Repr::bytes(text.clone()), &p).unwrap();
        let twice = n.apply(&once, &p).unwrap();
        assert_eq!(twice.data, text);
    }

    /// Matches the existing (already-verified-against-beaufort.js) `beaufort`
    /// node at default parameters (`keep_non_alphabet=true`), proving this
    /// alphabet-authoritative port didn't regress that established fidelity.
    #[test]
    fn cto_beaufort_matches_beaufort_node_at_default_params() {
        let cto = registry().get("cto_beaufort").unwrap();
        let plain = registry().get("beaufort").unwrap();
        let p = params! {"key" => "CODE"};
        let text = b"Attack at Dawn, 5 units!".to_vec();
        let a = cto.apply(&Repr::bytes(text.clone()), &p).unwrap();
        let b = plain.apply(&Repr::bytes(text), &p).unwrap();
        assert_eq!(a.data, b.data);
    }

    #[test]
    fn cto_beaufort_empty_key_yields_empty_output() {
        let n = registry().get("cto_beaufort").unwrap();
        let p = params! {"key" => "123"}; // no alphabet members survive cleaning
        let out = n.apply(&Repr::bytes(b"Hello".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"".to_vec());
    }

    #[test]
    fn cto_beaufort_keep_non_alphabet_false_drops_punctuation() {
        let n = registry().get("cto_beaufort").unwrap();
        let p = params! {"key" => "CODE", "keep_non_alphabet" => false};
        let ct = n.apply(&Repr::bytes(b"Hi, Bob!".to_vec()), &p).unwrap();
        assert!(!ct.data.contains(&b','));
        assert!(!ct.data.contains(&b'!'));
    }

    #[test]
    fn cto_beaufort_is_xf_family_and_not_layer_forming() {
        let n = registry().get("cto_beaufort").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    /// ARCHITECTURE.md pin (rev1 Beaufort): the key phase must SKIP
    /// characters outside the alphabet, not advance over them, or the layer
    /// does not invert. `beaufort.js:35-48`: `j = (j+1) % key.length` sits
    /// INSIDE the `if (zp >= 0)` branch -- it only executes for an
    /// alphabet-member text character, never for a passed-through
    /// non-alphabet one. Proven here directly: inserting punctuation into the
    /// ciphertext must not shift which key character subsequent letters use.
    #[test]
    fn cto_beaufort_key_phase_skips_non_alphabet_characters() {
        let n = registry().get("cto_beaufort").unwrap();
        let p = params! {"key" => "key"};
        let plain = n.apply(&Repr::bytes(b"AAAAA".to_vec()), &p).unwrap();
        let with_junk = n.apply(&Repr::bytes(b"A, A, A, A, A".to_vec()), &p).unwrap();
        let letters_only: Vec<u8> = with_junk.data.iter().filter(|b| b.is_ascii_alphabetic()).copied().collect();
        assert_eq!(letters_only, plain.data, "punctuation must not advance the key phase");
    }

    // -- cto_trithemius ----------------------------------------------------------

    /// Ground truth: hand-worked Trithemius over the default A-Z alphabet.
    /// Decrypt formula `(26+zp-kp)%26` with `kp` = position `i` in the
    /// alphabet-as-key (progressive: 0,1,2,...). "BBB" decrypts: pos0 kp=0 ->
    /// 'B'-0='B'; pos1 kp=1 -> 'B'-1='A'; pos2 kp=2 -> 'B'-2='Z'.
    #[test]
    fn cto_trithemius_matches_hand_computed_progressive_shift() {
        let n = registry().get("cto_trithemius").unwrap();
        let out = n.apply(&Repr::bytes(b"BBB".to_vec()), &Params::new()).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "BAZ");
    }

    /// No `key` param exists; the alphabet is authoritative and IS the key
    /// (see the module docs). A custom alphabet changes the progression base.
    #[test]
    fn cto_trithemius_alphabet_is_authoritative_and_is_the_key() {
        let n = registry().get("cto_trithemius").unwrap();
        let p = params! {"alphabet" => "ABC"};
        // alphaLen=3, key=alphabet itself ("ABC"). "AAA": pos0 kp=0->'A';
        // pos1 kp=1->(3+0-1)%3=2->'C'; pos2 kp=2->(3+0-2)%3=1->'B'.
        let out = n.apply(&Repr::bytes(b"AAA".to_vec()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "ACB");
    }

    /// Divergence pin: the site forces uppercase unconditionally, with no
    /// `casesensitiv` toggle (unlike Caesar/Beaufort/Vigenere).
    #[test]
    fn cto_trithemius_forces_uppercase_input_by_default() {
        let n = registry().get("cto_trithemius").unwrap();
        let lower = n.apply(&Repr::bytes(b"bbb".to_vec()), &Params::new()).unwrap();
        let upper = n.apply(&Repr::bytes(b"BBB".to_vec()), &Params::new()).unwrap();
        assert_eq!(lower.data, upper.data);
    }

    #[test]
    fn cto_trithemius_is_xf_family_and_not_layer_forming() {
        let n = registry().get("cto_trithemius").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    /// ARCHITECTURE.md pin, applied to Trithemius: `trithemius.js` reuses the
    /// exact same shared `crypt()` shape as Beaufort/Vigenere/Gronsfeld
    /// (`trithemius.js:35-48`, `j = (j+1) % key.length` inside `if (zp >= 0)`)
    /// -- the progressive shift only advances on alphabet-member characters,
    /// so inserted punctuation must not shift the progression.
    #[test]
    fn cto_trithemius_key_phase_skips_non_alphabet_characters() {
        let n = registry().get("cto_trithemius").unwrap();
        let plain = n.apply(&Repr::bytes(b"BBBB".to_vec()), &Params::new()).unwrap();
        let with_junk = n.apply(&Repr::bytes(b"B, B, B, B".to_vec()), &Params::new()).unwrap();
        let letters_only: Vec<u8> = with_junk.data.iter().filter(|b| b.is_ascii_alphabetic()).copied().collect();
        assert_eq!(letters_only, plain.data, "punctuation must not advance the progressive shift");
    }

    // -- cto_gronsfeld ----------------------------------------------------------

    /// Ground truth: hand-worked. Key "12" translates to "BC" (digit d ->
    /// 'A'+d). Decrypt formula `(26+zp-kp)%26`. "BD": pos1('B') kp='B'->1 ->
    /// (26+1-1)%26=0->'A'; pos3('D') kp='C'->2 -> (26+3-2)%26=1->'B'.
    #[test]
    fn cto_gronsfeld_translates_digit_key_and_matches_hand_computed_vector() {
        let n = registry().get("cto_gronsfeld").unwrap();
        let p = params! {"key" => "12"};
        let out = n.apply(&Repr::bytes(b"BD".to_vec()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "AB");
    }

    /// Divergence pin: non-digit characters in the key are dropped, matching
    /// gronsfeld.js's switch statement having no default-case action.
    #[test]
    fn cto_gronsfeld_drops_non_digit_key_characters() {
        assert_eq!(gronsfeld_translate_key("1x2"), vec!['B', 'C']);
        assert_eq!(gronsfeld_translate_key(""), Vec::<char>::new());
    }

    #[test]
    fn cto_gronsfeld_default_key_matches_site_page_load_value() {
        let n = registry().get("cto_gronsfeld").unwrap();
        // Just prove the default key round-trips through the digit
        // translation without erroring, over both cases (forced uppercase).
        let out = n.apply(&Repr::bytes(b"hello".to_vec()), &Params::new()).unwrap();
        assert!(!out.data.is_empty());
    }

    #[test]
    fn cto_gronsfeld_is_xf_family_and_not_layer_forming() {
        let n = registry().get("cto_gronsfeld").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    /// ARCHITECTURE.md pin, applied to Gronsfeld: `gronsfeld.js:68-81`'s
    /// `j = (j+1) % key.length` is likewise inside `if (zp >= 0)` -- the
    /// digit-key phase only advances on alphabet-member characters.
    #[test]
    fn cto_gronsfeld_key_phase_skips_non_alphabet_characters() {
        let n = registry().get("cto_gronsfeld").unwrap();
        let p = params! {"key" => "12"};
        let plain = n.apply(&Repr::bytes(b"BBBB".to_vec()), &p).unwrap();
        let with_junk = n.apply(&Repr::bytes(b"B, B, B, B".to_vec()), &p).unwrap();
        let letters_only: Vec<u8> = with_junk.data.iter().filter(|b| b.is_ascii_alphabetic()).copied().collect();
        assert_eq!(letters_only, plain.data, "punctuation must not advance the key phase");
    }

    // -- cto_rotation ----------------------------------------------------------

    /// Hand-worked from `rotation.js`'s own `rotateE90` (`str_split` into
    /// 3-char chunks "HEL","LOW","ORL","D", then for each column j in
    /// 0..blocksize, read chunk[i] at column j for i counting DOWN from the
    /// last chunk, empty `charAt` results dropped): col0 -> D,O,L,H; col1 ->
    /// (D has none),R,O,E; col2 -> (D has none),L,W,L.
    #[test]
    fn rotate_e90_matches_hand_worked_ground_truth() {
        assert_eq!(rotate_e90(b"HELLOWORLD", 3), b"DOLHROELWL");
    }

    /// `rotateD90` inverts `rotateE90` for input lengths that are already an
    /// exact multiple of blocksize (no padding ambiguity).
    #[test]
    fn cto_rotation_90_round_trips_when_length_is_exact_multiple() {
        let pt = b"HELLOWORLDXX".to_vec(); // 12 chars, blocksize 3 -> exact
        let ct = rotate_e90(&pt, 3);
        let n = registry().get("cto_rotation").unwrap();
        let p = params! {"blocksize" => 3i64, "rotation" => "90"};
        let out = n.apply(&Repr::bytes(ct), &p).unwrap();
        assert_eq!(out.data, pt);
    }

    #[test]
    fn cto_rotation_180_is_self_inverse_and_matches_reverse() {
        let n = registry().get("cto_rotation").unwrap();
        let p = params! {"rotation" => "180"};
        let out = n.apply(&Repr::bytes(b"HELLO".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"OLLEH");
        let twice = n.apply(&Repr::bytes(out.data), &p).unwrap();
        assert_eq!(twice.data, b"HELLO");
    }

    #[test]
    fn cto_rotation_270_round_trips_when_length_is_exact_multiple() {
        let pt = b"HELLOWORLDXX".to_vec();
        let step1 = rotate_e90(&pt, 3);
        let ct = rotate_180(&step1);
        let n = registry().get("cto_rotation").unwrap();
        let p = params! {"blocksize" => 3i64, "rotation" => "270"};
        let out = n.apply(&Repr::bytes(ct), &p).unwrap();
        assert_eq!(out.data, pt);
    }

    #[test]
    fn cto_rotation_default_blocksize_is_five_and_default_rotation_is_90() {
        let n = registry().get("cto_rotation").unwrap();
        let pt = b"ABCDEFGHIJ".to_vec(); // 10 chars, exact multiple of 5
        let ct = rotate_e90(&pt, 5);
        let out = n.apply(&Repr::bytes(ct), &Params::new()).unwrap();
        assert_eq!(out.data, pt);
    }

    #[test]
    fn cto_rotation_rejects_blocksize_below_one() {
        let n = registry().get("cto_rotation").unwrap();
        let p = params! {"blocksize" => 0i64};
        let err = n.apply(&Repr::bytes(b"HELLO".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn cto_rotation_rejects_unknown_rotation_value() {
        let n = registry().get("cto_rotation").unwrap();
        let p = params! {"rotation" => "45"};
        let err = n.apply(&Repr::bytes(b"HELLO".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn cto_rotation_preserves_display() {
        let n = registry().get("cto_rotation").unwrap();
        let out = n
            .apply(&Repr::new(b"HELLO".to_vec(), Display::Hex), &params! {"rotation" => "180"})
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn cto_rotation_is_xf_family_and_not_layer_forming() {
        let n = registry().get("cto_rotation").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    // -- hex/base64 medium compatibility --------------------------------------
    //
    // rev7 is a HEX medium (16 symbols) and TG4 is BASE64 -- a leading
    // classical layer is only usable there if its output stays IN that
    // medium. Every ported cipher below is proven to preserve a hex or
    // base64 alphabet when given that alphabet explicitly (declared alphabet
    // is authoritative, per this crate's alphabet-authority convention) --
    // see this task's final report for the summary of which of the five
    // ported ciphers can/cannot run over each medium.

    const HEX_ALPHABET: &str = "0123456789ABCDEF";
    const BASE64_ALPHABET: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    #[test]
    fn cto_caesar_operates_over_a_hex_alphabet_and_stays_in_medium() {
        let n = registry().get("cto_caesar").unwrap();
        let p = params! {"key" => 3i64, "alphabet" => HEX_ALPHABET};
        let out = n.apply(&Repr::bytes(b"DEADBEEF".to_vec()), &p).unwrap();
        assert!(out.data.iter().all(|b| HEX_ALPHABET.as_bytes().contains(b)));
    }

    #[test]
    fn cto_caesar_operates_over_a_base64_alphabet_and_stays_in_medium() {
        let n = registry().get("cto_caesar").unwrap();
        let p = params! {"key" => 5i64, "alphabet" => BASE64_ALPHABET};
        let out = n.apply(&Repr::bytes(b"SGVsbG8=".to_vec()), &p).unwrap();
        // '=' padding is outside every declared alphabet (hex and base64
        // both), so it passes through under the default keep_non_alphabet=true.
        assert!(out.data.iter().all(|b| BASE64_ALPHABET.as_bytes().contains(b) || *b == b'='));
    }

    #[test]
    fn cto_beaufort_operates_over_a_hex_alphabet_and_stays_in_medium() {
        let n = registry().get("cto_beaufort").unwrap();
        let p = params! {"key" => "FEED", "alphabet" => HEX_ALPHABET};
        let out = n.apply(&Repr::bytes(b"DEADBEEF".to_vec()), &p).unwrap();
        assert!(out.data.iter().all(|b| HEX_ALPHABET.as_bytes().contains(b)));
    }

    #[test]
    fn cto_beaufort_operates_over_a_base64_alphabet_and_stays_in_medium() {
        let n = registry().get("cto_beaufort").unwrap();
        let p = params! {"key" => "Zm9v", "alphabet" => BASE64_ALPHABET};
        let out = n.apply(&Repr::bytes(b"SGVsbG8".to_vec()), &p).unwrap();
        assert!(out.data.iter().all(|b| BASE64_ALPHABET.as_bytes().contains(b)));
    }

    /// `cto_trithemius`'s alphabet is authoritative (see its module docs) and
    /// IS the progressive key, so overriding it to hex genuinely runs the
    /// cipher over 16 symbols instead of the site's own fixed A-Z -- a
    /// deliberate generalisation beyond literal 2016 behaviour, since the
    /// site itself offers no alphabet control for this tool at all.
    #[test]
    fn cto_trithemius_operates_over_a_hex_alphabet_and_stays_in_medium() {
        let n = registry().get("cto_trithemius").unwrap();
        let p = params! {"alphabet" => HEX_ALPHABET};
        let out = n.apply(&Repr::bytes(b"DEADBEEF".to_vec()), &p).unwrap();
        assert!(out.data.iter().all(|b| HEX_ALPHABET.as_bytes().contains(b)));
    }

    #[test]
    fn cto_trithemius_operates_over_a_base64_alphabet_and_stays_in_medium() {
        let n = registry().get("cto_trithemius").unwrap();
        let p = params! {"alphabet" => BASE64_ALPHABET};
        let out = n.apply(&Repr::bytes(b"SGVsbG8".to_vec()), &p).unwrap();
        assert!(out.data.iter().all(|b| BASE64_ALPHABET.as_bytes().contains(b)));
    }

    /// `cto_gronsfeld`'s digit key translates to letters 'A'-'J'
    /// (`gronsfeld_translate_key`), which are then looked up as MEMBERS of
    /// whatever alphabet `cto2016_crypt` is given -- not as raw positions
    /// 0-9. Overriding `alphabet` to the natural hex ordering
    /// `"0123456789ABCDEF"` still resolves every translated key letter (`A`
    /// through `J` all literally appear in that string, at positions 10-15
    /// for A-F and nowhere for G-J since hex has no G/H/I/J) -- so a key
    /// digit whose translated letter falls outside G-J stays fully within
    /// the medium; see the report's discussion of this alphabet's shape for
    /// why digits 6-9 (letters G-J) are the sharp edge here.
    #[test]
    fn cto_gronsfeld_operates_over_a_hex_alphabet_for_digits_that_resolve() {
        let n = registry().get("cto_gronsfeld").unwrap();
        // Digits 0-5 translate to 'A'-'F', all present in the natural hex
        // alphabet -- exercise exactly that subset.
        let p = params! {"key" => "012345", "alphabet" => HEX_ALPHABET};
        let out = n.apply(&Repr::bytes(b"DEADBEEF".to_vec()), &p).unwrap();
        assert!(out.data.iter().all(|b| HEX_ALPHABET.as_bytes().contains(b)));
    }

    #[test]
    fn cto_rotation_over_hex_bytes_stays_in_medium_trivially() {
        // cto_rotation is a pure byte permutation with no alphabet concept at
        // all, so it trivially preserves ANY medium, including hex/base64.
        let n = registry().get("cto_rotation").unwrap();
        let hex_ct = b"DEADBEEFCAFEBABE0123456789ABCDEF".to_vec();
        for rotation in ["90", "180", "270"] {
            let p = params! {"blocksize" => 4i64, "rotation" => rotation};
            let out = n.apply(&Repr::bytes(hex_ct.clone()), &p).unwrap();
            assert!(out.data.iter().all(|b| HEX_ALPHABET.as_bytes().contains(b)));
        }
    }

    // -- the five ciphers added in the second porting pass ------------------
    //
    // Medium compatibility is the property that decides whether any of these
    // is usable as a LEADING layer against the unsolved targets, so it is
    // tested rather than asserted in prose. REV7's medium is hex
    // (`0-9A-F`) and TG4's is base64; a leading classical layer whose output
    // leaves that alphabet destroys the medium and the next layer's decode
    // fails. Values below were cross-checked against the release binary via
    // `ra run` before being pinned here.

    fn apply_with(name: &str, p: &Params, input: &[u8]) -> Vec<u8> {
        let n = registry().get(name).unwrap_or_else(|| panic!("{name} not registered"));
        n.apply(&Repr::bytes(input.to_vec()), p).unwrap().data
    }

    /// All five are registered, are `Xf`, and are therefore NOT layer-forming --
    /// a classical step must never be counted as a decryption in the coverage
    /// algebra.
    #[test]
    fn the_second_pass_ciphers_are_all_registered_non_layer_forming_xf_nodes() {
        for name in [
            "cto_mono",
            "cto_multiplicative",
            "cto_transposition",
            "cto_kamasutra",
            "cto_jaeger",
        ] {
            let n = registry().get(name).unwrap_or_else(|| panic!("{name} not registered"));
            assert_eq!(n.family(), Family::Xf, "{name} must be Xf");
        }
    }

    /// The two TRANSPOSITION-family ports stay inside a hex alphabet, because a
    /// transposition only permutes the bytes it was given. That makes them the
    /// two members of this batch usable as a leading layer on REV7.
    #[test]
    fn the_transposition_ports_stay_in_the_hex_medium() {
        const HEX: &[u8] = b"0123456789ABCDEF";

        let t = apply_with(
            "cto_transposition",
            &params! {"key" => "ZOMBIES", "alphabet" => "0123456789ABCDEF"},
            HEX,
        );
        assert_eq!(t, b"08192A3B4C5D6E7F".to_vec(), "cto_transposition ground truth");
        assert!(t.iter().all(|b| HEX.contains(b)), "must stay in the hex medium");

        let j = apply_with("cto_jaeger", &params! {"depth" => 3i64}, HEX);
        assert_eq!(j, b"04C516D728E93AFB".to_vec(), "cto_jaeger ground truth");
        assert!(j.iter().all(|b| HEX.contains(b)), "must stay in the hex medium");

        // A permutation preserves the byte multiset exactly -- the property that
        // makes "stays in medium" true for ANY input, not just this one.
        let mut a = t.clone();
        let mut b = HEX.to_vec();
        a.sort_unstable();
        b.sort_unstable();
        assert_eq!(a, b, "a transposition must preserve the byte multiset");
    }

    /// The three SUBSTITUTION-family ports are each USELESS as a leading layer
    /// on REV7, but for two different reasons, and the distinction matters more
    /// than a bare "stays in medium" check would show.
    ///
    /// `cto_mono` and `cto_kamasutra` return hex input **completely unchanged**.
    /// Their site-default alphabets are lowercase `a-z`; hex's digits and its
    /// uppercase `A-F` are outside that alphabet, and the site's default is to
    /// keep non-alphabet characters verbatim, so every byte passes through. That
    /// is not a safe transform, it is the IDENTITY -- enumerating it as a leading
    /// layer would add a duplicate axis point that silently does nothing while
    /// multiplying the candidate count.
    ///
    /// `cto_multiplicative` genuinely leaves the medium: it maps the `A-F` range
    /// into a mixed-case alphabet, so hex-ness is destroyed and the next layer's
    /// hexdecode fails.
    ///
    /// Either way none of the three is usable on REV7 under site defaults, which
    /// is the operational conclusion; it is recorded here so a future sweep does
    /// not enumerate them expecting a real transform.
    #[test]
    fn no_substitution_port_is_a_usable_leading_layer_on_hex() {
        const HEX: &[u8] = b"0123456789ABCDEF";

        // Identity, not safety.
        for name in ["cto_mono", "cto_kamasutra"] {
            let out = apply_with(name, &Params::new(), HEX);
            assert_eq!(
                out,
                HEX.to_vec(),
                "{name} is expected to be the IDENTITY on hex under its site defaults \
                 (lowercase a-z alphabet, keep-non-alphabet on). If this changed, the \
                 leading-layer guidance for REV7 needs revisiting."
            );
        }

        // Genuinely leaves the medium.
        let out = apply_with("cto_multiplicative", &params! {"key" => 3i64}, HEX);
        assert_ne!(out, HEX.to_vec(), "cto_multiplicative must actually transform");
        assert!(
            !out.iter().all(|b| HEX.contains(b)),
            "cto_multiplicative maps A-F into a mixed-case alphabet, so it must leave \
             the hex medium and break a following hexdecode"
        );
    }

    /// Determinism: the same input and params must give the same output. A
    /// sweep's whole audit story rests on candidate `i` being a pure function of
    /// `i`, which fails if any node is nondeterministic.
    #[test]
    fn the_second_pass_ciphers_are_deterministic() {
        let cases: Vec<(&str, Params)> = vec![
            ("cto_mono", Params::new()),
            ("cto_multiplicative", params! {"key" => 3i64}),
            ("cto_transposition", params! {"key" => "ZOMBIES"}),
            ("cto_kamasutra", Params::new()),
            ("cto_jaeger", params! {"depth" => 3i64}),
        ];
        for (name, p) in cases {
            let a = apply_with(name, &p, b"attackatdawn");
            let b = apply_with(name, &p, b"attackatdawn");
            assert_eq!(a, b, "{name} must be deterministic");
            assert!(!a.is_empty(), "{name} produced no output");
        }
    }
}
