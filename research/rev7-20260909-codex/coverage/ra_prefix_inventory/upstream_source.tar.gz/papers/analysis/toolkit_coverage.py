#!/usr/bin/env python3
"""Toolkit menu coverage against the corpus's distinct cipher methods.

The question is NOT "which single tool" -- that is settled, there is no single
source.  It is: do the candidate toolkits, taken together, explain the corpus
at all, and which ciphers remain without any identified source?

TWO RULES THIS SCRIPT ENFORCES
------------------------------
1.  A menu obtained by SEARCH or by spot-checking is not COMPLETE.  For those,
    "not in covers" means "not known to be covered", NOT "verified absent".
    Only toolkits with complete=True may have absence inferred from silence.
    Without this rule the uncovered set is an artefact of what we happened to
    fetch rather than a fact about the corpus.
2.  Verified absences are recorded separately in `absent` and are stronger
    evidence than silence, whatever the completeness flag.

ALL MENUS ARE 2026 MENUS.  No toolkit's 2016 state was verifiable (archive.org
unreachable, Braingle HTTP 403, practicalcryptography refused).  Removing
dcode.fr leaves the result resting on narrower menus, so this caveat now
matters more, not less.

REVISION 4 ADDS A SECOND, BETTER KIND OF EVIDENCE.  Ten of the toolkits below
are now present because a human who worked the problem NAMED them, in the
community "Zombies Sources" sheet, as the source of a specific cipher, with a
confidence figure attached.  Community attribution and menu inference are kept
apart in the `status` string of every entry and must not be blended: a menu
containing a cipher is weak evidence that a tool was used, whereas a solver
saying "this tool, because it uses the site's default key" is direct testimony.
Where the two agree, say so; where they conflict -- and Cryptool Online's row
does conflict -- say that too rather than quietly preferring one.

Run: python3 papers/analysis/toolkit_coverage.py
     python3 papers/analysis/community_sources.py     (the sheet reconciliation)
"""
import os
import sys
import collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reuse_matrix import load, CIPHER_TYPES  # noqa: E402

TOOLKITS = {
    "CacheSleuth": dict(
        url="https://www.cachesleuth.com/multidecoder/",
        status="VERIFIED LIVE 2026; ~37 entries spot-checked against a claimed '250+ ciphers and codes'",
        complete=False,
        covers={
            "straddling_checkerboard", "navajo_code_talker", "trifid", "bifid",
            "beaufort", "adfgx", "porta", "four_square", "trithemius", "ubchi",
            "2_1_amsco", "autokey", "book", "baudot_code", "leet_speak", "t_9",
            "bacon", "playfair", "enigma_m3", "affine", "atbash", "vigenere",
            "keyed_caesar", "rail_fence", "columnar_transposition",
            "double_columnar_transposition", "tupper_s_self_referential_formula",
        },
        absent={
            "keyed_vigenere_quagmire_iii", "purple", "skip", "flag_semaphore",
            "simplified_lorenz", "homophonic_substitution",
        },
        notes="Also carries Variant Beaufort, ADFGVX, Hill and VIC, none of "
              "which the corpus uses. Homophonic is listed only as 'Numeric "
              "Homophonic', which may or may not match de6; counted as absent.",
    ),
    "rumkin.com": dict(
        url="https://rumkin.com/tools/cipher/",
        status="VERIFIED LIVE 2026, complete menu enumerated. Also the "
               "most-attributed identified tool in the community sheet, "
               "11 of 83 rows",
        complete=True,
        covers={
            "ubchi", "skip", "bacon", "affine", "playfair", "bifid",
            "columnar_transposition", "double_columnar_transposition",
            "rail_fence", "rotate", "vigenere", "atbash", "flag_semaphore",
            "numbers_to_letters", "pigpen", "base64", "rot",
            # Added in revision 4 on the sheet's testimony, NOT on the menu.
            "keyed_caesar", "keyed_vigenere_quagmire_iii",
        },
        absent=set(),
        notes="Menu fully enumerated, so silence IS absence here -- and that "
              "turned out to be the wrong unit. A MENU ENUMERATION COUNTS "
              "PAGES, NOT CAPABILITIES. The sheet attributes zns7 (keyed "
              "Caesar, 95%) and zns12 (Quagmire III, 99%) to rumkin's "
              "'keymaker' alphabet generator, a SETTING on pages this table "
              "had recorded only as 'Caesar' and 'Vigenere': 'Keyed alphabet "
              "is generated using Rumkin's keymaker settings. There aren't "
              "really other sites with settings as convenient as these for "
              "generating an alphabet based on keyword Shinonuma that look "
              "like our provided alphabet.' Both are added on that testimony. "
              "This is the single largest correction the sheet makes to the "
              "method of this table, and it means every `complete=True` flag "
              "here should be read as complete-at-page-level. 'Rotate' is "
              "matched to gk7's grid rotation, a judgement call the sheet "
              "independently endorses at 100%.",
    ),
    "crypto.interactive-maths (Crypto Corner)": dict(
        url="https://crypto.interactive-maths.com/",
        status="VERIFIED LIVE 2026, ~22 entries spot-checked",
        complete=False,
        covers={
            "straddling_checkerboard", "autokey", "playfair", "four_square",
            "vigenere", "affine", "atbash", "rail_fence",
            "columnar_transposition", "double_columnar_transposition",
            "homophonic_substitution", "substitution",
        },
        absent={
            "beaufort", "trifid", "bifid", "adfgx", "porta", "trithemius",
            "bacon", "enigma_m3", "navajo_code_talker",
        },
        notes="A teaching site with an activity per cipher rather than a "
              "general-purpose decoder. Carries the straddling checkerboard, "
              "which is one of only three sources found that does.",
    ),
    "cryptii (v3)": dict(
        url="https://cryptii.com/",
        status="NOT VERIFIED. Menu could not be enumerated; the homepage does "
               "not list it. Encoded from the research report only.",
        complete=False,
        covers={"trifid", "bifid", "beaufort", "enigma_m3", "bacon"},
        absent=set(),
        notes="Weakest entry in this table. Contributes nothing not already "
              "covered by CacheSleuth, so its uncertainty does not affect any "
              "conclusion below.",
    ),
    "CIMT / MEP Codes and Ciphers": dict(
        url="https://www.cimt.org.uk/resources/codes/index.htm",
        status="VERIFIED LIVE 2026, complete 20-unit menu enumerated",
        complete=True,
        covers={
            "simplified_lorenz", "enigma_m3", "substitution", "atbash",
            "keyed_caesar", "columnar_transposition",
            "double_columnar_transposition",
        },
        absent=set(),
        notes="A 20-unit teaching curriculum. The ONLY source found for "
              "simplified_lorenz, and confirmed for tg3 by reproduction.",
    ),
    "tools4noobs.com": dict(
        url="https://www.tools4noobs.com/online_tools/encrypt/",
        status="ESTABLISHED by this project via 11 of 11 end-to-end reproductions",
        complete=True,
        covers={
            "blowfish", "blowfish_compat", "des", "loki97", "rc2", "rc4",
            "rijndael_256", "saferplus", "serpent", "twofish", "xtea",
        },
        absent=set(),
        notes="An mcrypt front end. Carries no classical cipher at all.",
    ),
    # ---------------------------------------------------------------------
    # Added in revision 4, from the community "Zombies Sources" sheet.  Every
    # one of these is a tool a human who worked the problem NAMED as the
    # source of a specific cipher.  That is a different and better class of
    # evidence than the menu inference the rest of this table runs on, and
    # several of them turn out to be why a method looked uncovered.
    # ---------------------------------------------------------------------
    "Practical Cryptography": dict(
        url="http://practicalcryptography.com/ciphers/",
        status="ATTRIBUTED by the sheet for 5 rows (soe1, soe3, soe5, tg5, rev3), "
               "two at 100%. The site STILL refuses the connection; the menu "
               "below is from search snapshots and from a.tools, which "
               "reproduces its straddling-checkerboard defaults",
        complete=False,
        covers={
            "porta", "four_square", "straddling_checkerboard", "enigma_m3",
            "affine", "beaufort", "bifid", "trifid", "adfgx", "playfair",
            "vigenere", "autokey", "trithemius", "homophonic_substitution",
            "substitution", "columnar_transposition",
            "double_columnar_transposition", "bacon",
        },
        absent=set(),
        notes="The single biggest change this revision makes. It carries the "
              "straddling checkerboard, Porta and Four-square, and the sheet "
              "attributes all three to it on DEFAULT-VALUE and page-formatting "
              "grounds rather than on menu presence. It also carries Trifid as "
              "a page but, per the sheet, WITHOUT AN IMPLEMENTATION, which is "
              "why soe2 went to Braingle.",
    ),
    "Cryptool Online": dict(
        url="https://www.cryptool.org/en/cto/",
        status="VERIFIED LIVE 2026, 29 applications enumerated but not "
               "trusted as exhaustive after the rumkin keymaker lesson, so "
               "complete=False. ATTRIBUTED by the sheet for 8 corpus rows",
        complete=False,
        covers={
            "atbash", "vigenere", "columnar_transposition",
            "double_columnar_transposition", "substitution", "rail_fence",
            "enigma_m3", "bacon", "homophonic_substitution",
        },
        absent={"beaufort", "adfgx", "purple", "simplified_lorenz"},
        notes="A live tension, recorded rather than smoothed. The sheet "
              "attributes de4 (Bifid, 90%), de5 (Navajo, 75%), de7 (AMSCO, "
              "80%), de9 (Trithemius, 75%) and de3 (Playfair, 85%) to this "
              "site, and the 2026 enumeration found none of those five. The "
              "covers set above is written to the MENU, not to the sheet, so "
              "that the disagreement stays visible in "
              "community_sources.py rather than being encoded away. It is a "
              "disagreement and not a refutation: the menu is not complete, so "
              "'not found' means 'not known to be covered'. The sheet's own "
              "reasoning for de4 is specific enough to be checkable if the "
              "2016 site is ever reachable -- it says the site's Bifid had a "
              "setting substituting W as VV, which is exactly what de4's "
              "ciphertext shows.",
    ),
    "cryptii v2": dict(
        url="https://v2.cryptii.com/",
        status="VERIFIED LIVE 2026 at the v2 archive URL, complete 22-format "
               "menu enumerated. ATTRIBUTED by the sheet for 8 corpus rows",
        complete=True,
        covers={"leet_speak", "navajo_code_talker", "pigpen", "baudot_code",
                "atbash", "enigma_m3", "vigenere"},
        absent={"trifid", "bifid", "beaufort", "adfgx", "purple",
                "straddling_checkerboard", "simplified_lorenz"},
        notes="NOT the same object as the 'cryptii (v3)' row above, and the "
              "distinction matters: v2 is the 2013 build the author could "
              "actually have used in 2016, v3 is the rewrite. The sheet "
              "attributes six Gorod Krovi ciphers to it. Its octal, decimal, "
              "hexadecimal and Roman numeral formats also cover the structural "
              "steps this table does not count.",
    ),
    "geocachingtoolbox.com": dict(
        url="https://www.geocachingtoolbox.com/",
        status="VERIFIED LIVE 2026, complete menu enumerated. NOT named as a "
               "source in any of the sheet's 83 rows; runner-up in two "
               "Explanations; the owner's working hypotheses call it the "
               "'geo toolbox' for six Revelations ciphers",
        complete=True,
        covers={"adfgx", "affine", "atbash", "bacon", "bifid", "four_square",
                "playfair", "rail_fence", "substitution", "trifid", "vigenere",
                "keyed_caesar"},
        absent={"straddling_checkerboard", "porta", "beaufort", "purple",
                "navajo_code_talker", "simplified_lorenz",
                "keyed_vigenere_quagmire_iii", "skip", "flag_semaphore"},
        notes="Tested at the owner's request. It DOES carry the reverse, the "
              "ASCII conversion, the affine and the ADFGX the hypotheses want. "
              "It does NOT carry an arbitrary ROT-N: only ROT13 is offered, "
              "which refutes the rev12 ROT-6 hypothesis for this site "
              "specifically. It also has no hex conversion and no zero-padded "
              "decimal output.",
    ),
    "Braingle": dict(
        url="https://www.braingle.com/brainteasers/codes/",
        status="Direct fetch still HTTP 403. Menu obtained from search "
               "snapshots of its per-cipher pages, so SPOT-CHECKED, not "
               "enumerated. ATTRIBUTED by the sheet for soe2 and rev4",
        complete=False,
        covers={"trifid", "bifid", "playfair", "four_square", "beaufort",
                "autokey", "vigenere", "atbash", "keyed_caesar", "pigpen",
                "rail_fence", "columnar_transposition", "book", "substitution",
                "flag_semaphore"},
        absent=set(),
        notes="Promoted from UNKNOWN to a spot-checked menu. The sheet "
              "independently reaches this project's suspicion that Braingle is "
              "soe2's Trifid source, and gives the reason this project could "
              "not: Braingle's Trifid needs the non-standard "
              "square-row-column read, which is 'treated as a variant on most "
              "platforms but is the only option here'. Whether its 27-cell "
              "square fills down the columns is still not established.",
    ),
    "Brian Neal PURPLE": dict(
        url="https://github.com/gremmie/purple",
        status="NAMED by the sheet for de11 at 30%, the sheet's lowest "
               "confidence on any named tool, and named together with a "
               "REPRODUCTION FAILURE. Verified to exist: a Python library and "
               "command-line tool, first released ~2013",
        complete=True,
        covers={"purple"},
        absent=set(),
        notes="READ THE CONFIDENCE. The sheet's own words are 'Does not match "
              "outputting at all, does however match with the default key. "
              "However, the default keys here are much more standard than the "
              "other default keys we have used to identify other sites... I "
              "will be returning to this to see if I can find a tool with "
              "better output.' So de11's ATTRIBUTION is not settled; what is "
              "settled is that a tool implementing Purple exists and is "
              "period-plausible, which answers explicability and not "
              "authorship. It is entered in `covers` on that basis alone. The "
              "genuinely useful part is that it is NOT A WEB PAGE: this "
              "document's search was scoped to web toolkits throughout, and "
              "Purple is the cipher least likely to sit on one.",
    ),
    "PMacg": dict(
        url="unresolved",
        status="ATTRIBUTED by the sheet for soe4 at 90%. This project could "
               "not identify the site; searches return the PMAC algorithm and "
               "an unrelated GitHub user",
        complete=False,
        covers={"tupper_s_self_referential_formula"},
        absent=set(),
        notes="Recorded because the sheet's reasoning is specific and "
              "checkable in principle: it prefers this site over Keely Hill "
              "on page formatting and 'the lack of a comma delimiter as is "
              "standard'. The site itself remains unlocated.",
    ),
    "Woodmann": dict(
        url="http://www.woodmann.com/",
        status="ATTRIBUTED by the sheet for zns11 at 95%. Reachable but its "
               "pages returned no content; a reverse-engineering archive "
               "rather than a cipher toolkit",
        complete=False,
        covers={"rail_fence"},
        absent=set(),
        notes="One cipher, one map. Listed for completeness. The 95% is the "
              "community's and is not reproduced here.",
    ),
    "Limfinity": dict(
        url="massey.limfinity.com/207/hillcipher.php",
        status="ATTRIBUTED by the sheet for four Mob of the Dead rows at 99%. "
               "HTTP 403",
        complete=True,
        covers=set(),
        absent=set(),
        notes="Covers nothing in this corpus: all four attributions are Hill "
              "ciphers in Mob of the Dead, a BO2 map outside the six analysed "
              "here. Entered so the sheet's tool list is represented in full "
              "and so its zero contribution is a stated fact rather than an "
              "omission.",
    ),
    "Google Translate": dict(
        url="https://translate.google.com/",
        status="ATTRIBUTED by the sheet for gk5 at 90%",
        complete=True,
        covers=set(),
        absent=set(),
        notes="gk5 is recorded in this corpus as a puzzle ('This message "
              "translates from Zulu'), not a cipher method, so it contributes "
              "nothing to the classical count. A useful reminder that some "
              "corpus entries need a translator rather than a cipher tool.",
    ),
}

EXCLUDED = {
    "dcode.fr": "EXCLUDED ON OWNER GROUND TRUTH, and now CORROBORATED by the "
                "community sheet. The owner states with high confidence that "
                "dcode.fr was not used. The sheet names it in none of its 83 "
                "Encoding Source cells, and its Explanations reach for it four "
                "times and put it down every time: for zns1 'the outputs do "
                "not match when I try to encipher the known plaintext', for "
                "gk4 it 'handles the numbers in a way' where cryptii handles "
                "them correctly, for soe1 the Porta table is present but "
                "'labelled a variant'. Two independent routes, one attributed "
                "and one evidential, same exclusion.",
    "Boxentriq": "EXCLUDED: launched 2018, four years after authorship. The "
                 "sheet never names it either.",
}

UNKNOWN = {
    "CacheSleuth": "Never named in any of the sheet's 83 rows, and never "
                   "discussed in any Explanation. Not evidence of absence, but "
                   "worth recording: the toolkit that leads this table on "
                   "coverage is one the people who worked the problem never "
                   "reached for.",
}

# Implementation tells we hold, which are what will eventually identify a tool.
TELLS = {
    "straddling_checkerboard": "rev3's row selectors are {1,3}, against the "
                               "usual 2/6 or 3/7. Reconstructed.",
    "trifid": "rev11's 27-symbol alphabet is filled DOWN THE COLUMNS, and its "
              "period is the whole message. Reconstructed.",
    "beaufort": "rev1's alphabet is 52 characters, mixed case A-Za-z, case "
                "significant. RECORDED, not reconstructed.",
    "playfair": "rev11 key ZOMBIES; de3 key testsubject. Merge and padding ours.",
    "bifid": "de4 period 99 = whole ciphertext length. RECORDED.",
    "keyed_vigenere_quagmire_iii": "zns12 alphabet key AMUNOIHSZYXWVTRQPLKJGFEDCB, "
                                   "a reversed keyed alphabet. RECORDED.",
    "2_1_amsco": "de7 key 198346572. RECORDED.",
    "adfgx": "rev4's square is unkeyed and its five letters are themselves "
             "Polybius-encoded as 11/14/21/22/53. Reconstructed.",
    "autokey": "gk12 key TRYTHIS over alphabet ZOMBIESAREEVERYWHERE. RECORDED.",
    "simplified_lorenz": "tg3 K wheel 14 cams start 9, S wheel 4 cams start 4. "
                         "CONFIRMED by 48/48 reproduction.",
}


def main():
    _, steps, _ = load()
    named = [s for s in steps if s["method"]]
    kind = {s["method"]: s["type"] for s in named}
    maps_of = collections.defaultdict(set)
    for s in named:
        maps_of[s["method"]].add(s["map"])

    methods = sorted(set(s["method"] for s in named))
    ciphers = [m for m in methods if kind[m] in CIPHER_TYPES]
    mcrypt = [m for m in ciphers if kind[m] == "decrypt"]
    classical = [m for m in ciphers if kind[m] != "decrypt"]

    print(f"corpus distinct methods      : {len(methods)}")
    print(f"  cipher-role                : {len(ciphers)}")
    print(f"    mcrypt (tools4noobs)     : {len(mcrypt)}")
    print(f"    classical / formula      : {len(classical)}")
    print()
    print("The toolkit question lives in the classical set: the 11 mcrypt")
    print("primitives are already attributed to tools4noobs by reproduction.")
    print()

    print("=" * 76)
    print("EXCLUDED AND UNKNOWN")
    print("=" * 76)
    for k, v in EXCLUDED.items():
        print(f"  [EXCLUDED] {k}\n      {v}")
    for k, v in UNKNOWN.items():
        print(f"  [UNKNOWN ] {k}\n      {v}")
    print()

    print("=" * 76)
    print("COVERAGE OF THE 39 CLASSICAL / FORMULA METHODS")
    print("=" * 76)
    print(f"{'toolkit':<44}{'covers':>10}{'complete?':>12}")
    for name, tk in TOOLKITS.items():
        hit = sum(1 for m in classical if m in tk["covers"])
        print(f"{name:<44}{f'{hit}/{len(classical)}={hit / len(classical):.0%}':>10}"
              f"{str(tk['complete']):>12}")
    print()

    # --------------------------------------------------------------- union
    union = set().union(*(tk["covers"] for tk in TOOLKITS.values()))
    covered = [m for m in classical if m in union]
    uncovered = [m for m in classical if m not in union]
    print("=" * 76)
    print("DO THEY EXPLAIN THE CORPUS, TAKEN TOGETHER?")
    print("=" * 76)
    print(f"  classical methods covered by at least one toolkit : "
          f"{len(covered)}/{len(classical)} = {len(covered) / len(classical):.0%}")
    print(f"  not covered by any                               : {len(uncovered)}")
    print()
    print("  With the 11 mcrypt primitives folded back in, the whole cipher set:")
    unionall = union | set(mcrypt)
    cov_all = sum(1 for m in ciphers if m in unionall)
    print(f"    {cov_all}/{len(ciphers)} = {cov_all / len(ciphers):.0%}")
    print()

    # ------------------------------------------------- was the gap an artefact?
    print("=" * 76)
    print("WAS THE 'UNEXPLAINED' GAP AN ARTEFACT OF WHAT WE ENCODED?")
    print("=" * 76)
    SHEET = {"Practical Cryptography", "Cryptool Online", "cryptii v2",
             "geocachingtoolbox.com", "Braingle", "Brian Neal PURPLE", "PMacg",
             "Woodmann", "Limfinity", "Google Translate"}
    old = {"rumkin.com", "CIMT / MEP Codes and Ciphers", "tools4noobs.com"}

    def cov(names):
        u = set().union(*(TOOLKITS[n]["covers"] for n in names))
        return sum(1 for m in classical if m in u)

    r2, r3 = cov(old), cov(set(TOOLKITS) - SHEET)
    print(f"  rev 2 table, dcode removed  : {r2}/{len(classical)} covered, "
          f"{len(classical) - r2} uncovered.")
    print(f"  + the 4 researched toolkits : {r3}/{len(classical)} covered, "
          f"{len(classical) - r3} uncovered.")
    print(f"  + the 10 the sheet names    : {len(covered)}/{len(classical)} "
          f"covered, {len(uncovered)} uncovered.")
    print()
    print("  >>> The gap was overwhelmingly an encoding artefact. Removing")
    print("      dcode did not create 21 unexplained ciphers; it exposed that")
    print("      four researched toolkits had never been entered. The sheet's")
    print("      ten then close Purple, which had been one of only two real")
    print("      ciphers in the corpus with no identified source, and it does")
    print("      it with a tool that is not a web page at all.")
    print()

    # ------------------------------------------------------- minimal cover
    print("=" * 76)
    print("SMALLEST SET OF TOOLKITS THAT EXPLAINS THE CLASSICAL CORPUS")
    print("=" * 76)
    import itertools
    names_all = list(TOOLKITS)
    best = None
    for r in range(1, len(names_all) + 1):
        for combo in itertools.combinations(names_all, r):
            u = set().union(*(TOOLKITS[n]["covers"] for n in combo))
            hit = sum(1 for m in classical if m in u)
            if best is None or hit > best[0] or (hit == best[0] and r < len(best[1])):
                best = (hit, combo)
        if best and best[0] == len(covered):
            break
    print(f"  {len(best[1])} toolkits reach the maximum {best[0]}/{len(classical)}:")
    for n in best[1]:
        print(f"      {n}")
    print()
    for r in range(1, 4):
        rows = []
        for combo in itertools.combinations(names_all, r):
            u = set().union(*(TOOLKITS[n]["covers"] for n in combo))
            rows.append((sum(1 for m in classical if m in u), combo))
        rows.sort(reverse=True)
        top = rows[0]
        print(f"  best {r}-toolkit set : {top[0]}/{len(classical)} = "
              f"{top[0] / len(classical):.0%}   {' + '.join(top[1])}")
    print()

    # ---------------------------------------------------- unique contributions
    print("=" * 76)
    print("UNIQUE CONTRIBUTIONS: methods only ONE toolkit covers")
    print("=" * 76)
    print("  These are the entries that carry real attribution weight. A method")
    print("  many toolkits carry cannot discriminate between them.")
    for name, tk in TOOLKITS.items():
        uniq = [m for m in classical if m in tk["covers"]
                and sum(1 for t in TOOLKITS.values() if m in t["covers"]) == 1]
        if uniq:
            print(f"  {name}:")
            for m in uniq:
                mm = ",".join(sorted(maps_of[m]))
                print(f"      {m:<34}{mm}")
    print()

    # ------------------------------------------------------------- uncovered
    print("=" * 76)
    print("THE UNCOVERED SET, RANKED BY DISCRIMINATING POWER")
    print("=" * 76)
    print("  Rank key: a cipher used in TWO maps is far likelier to come from a")
    print("  tool the author actually had than a one-off, so cross-map ciphers")
    print("  rank highest. Then real named ciphers over bespoke one-offs. Then")
    print("  whether we hold an implementation tell to match a candidate against.")
    print()

    def rank(m):
        return (-len(maps_of[m]), 0 if m in TELLS else 1, m)

    for m in sorted(uncovered, key=rank):
        nmaps = len(maps_of[m])
        mm = ",".join(sorted(maps_of[m]))
        flag = "CROSS-MAP" if nmaps > 1 else "one map "
        verified_absent = [n for n, tk in TOOLKITS.items() if m in tk["absent"]]
        print(f"  [{flag}] {m}")
        print(f"      maps            : {mm}")
        if verified_absent:
            print(f"      VERIFIED absent : {', '.join(verified_absent)}")
        else:
            print(f"      status          : not listed by any encoded toolkit; "
                  f"no verified absence")
        if m in TELLS:
            print(f"      tell            : {TELLS[m]}")
    print()

    print("=" * 76)
    print("THE THREE CROSS-MAP CIPHERS, WHICH THE BRIEF WEIGHTS HIGHEST")
    print("=" * 76)
    for m in ["straddling_checkerboard", "navajo_code_talker", "trifid"]:
        src = [n for n, tk in TOOLKITS.items() if m in tk["covers"]]
        print(f"  {m:<28} maps={','.join(sorted(maps_of[m]))}")
        print(f"      covered by: {src if src else 'NOTHING'}")
        if m in TELLS:
            print(f"      tell      : {TELLS[m]}")
    print()

    print("=" * 76)
    print("PER-MAP: classical cipher methods each toolkit's menu contains")
    print("=" * 76)
    by_map = collections.defaultdict(set)
    for s in named:
        if kind[s["method"]] in CIPHER_TYPES and kind[s["method"]] != "decrypt":
            by_map[s["map"]].add(s["method"])
    names = list(TOOLKITS)
    print(f"{'map':<20}{'n':>3}" + "".join(f"{n[:11]:>13}" for n in names)
          + f"{'union':>8}")
    for m, ms in sorted(by_map.items()):
        row = f"{m:<20}{len(ms):>3}"
        for n in names:
            row += f"{sum(1 for x in ms if x in TOOLKITS[n]['covers']):>13}"
        row += f"{sum(1 for x in ms if x in union):>8}"
        print(row)


if __name__ == "__main__":
    main()
