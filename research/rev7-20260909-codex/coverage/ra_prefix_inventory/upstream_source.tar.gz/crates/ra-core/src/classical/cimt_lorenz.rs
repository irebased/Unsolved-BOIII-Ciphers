//! CIMT/MEP "Simplified Lorenz Cipher Toolkit", matching
//! <https://www.cimt.org.uk/resources/codes/lorenz/index.htm> (produced by the
//! Centre for Innovation in Mathematics Teaching with Bletchley Park National
//! Codes Centre, part of MEP "Codes and Ciphers" Unit 19).
//!
//! # The model
//!
//! Two cipher wheels, each a fixed cyclic pattern of Baudot/ITA2 letters, both
//! stepping once per character:
//!
//! - a **K wheel** with 14 positions, whose cam pattern is the literal 14
//!   letters `A..N` in order — pinned by the page's own worked example
//!   ("If the K-wheel start-position is 7 i.e. letter 'G', K =
//!   GHIJKLMNABCDEFGHIJKLMNABCDEF...");
//! - an **S wheel** with 4 positions, whose cam pattern the page's own script
//!   hard-codes as `slets[1]='A'; slets[2]='A'; slets[3]='B'; slets[4]='B';`
//!   — i.e. `AABB`, read from position 1. This is fixed by the toolkit, not a
//!   per-message key; it was independently recovered from TG3's known
//!   plaintext before this node existed (`papers/analysis/tg3_cimt.py`) and
//!   the page's own source confirms it exactly.
//!
//! Enciphering (`encodeText()` in the page's script) is: add the K-wheel
//! letter to the plaintext letter, then add the S-wheel letter to that result
//! — "add" meaning XOR of the two letters' five-bit ITA2 codes (teleprinter
//! addition) — then rotate both wheels one place. The page states plainly
//! that deciphering uses "identically" the same process, which is obviously
//! true of XOR: this node performs the one formula both ways, matching the
//! page's own single `encodeText()` doing double duty for both directions.
//!
//! The alphabet (`lcodes[0..32]` in the page's script) is ITA2 in Bletchley
//! Park "General Report on Tunny" notation: 26 letters plus `/` (null),
//! `9` (space), `3` (carriage return), `4` (line feed), `+` (figure shift)
//! and `8` (letter shift) — see [`ITA2`]. The page forces its plaintext input
//! to upper case before enciphering (`pts=pts.toUpperCase()`); a character
//! outside this 32-glyph alphabet enciphers to a literal `?` and the page
//! alerts the user rather than refusing to run, which this node reproduces
//! (no error; `?` at that position) since the corpus's own ciphertext never
//! needs it and there's nothing to gain from a stricter refusal here.
//!
//! # TG3 (`data/the_giant.json`)
//!
//! TG3's recorded solution reads "K-wheel = 9 and S-wheel = 4". Those are
//! **1-indexed start positions**, not wheel lengths (both wheel lengths, 14
//! and 4, are fixed by the toolkit itself; "K-wheel = 9" cannot mean length 9
//! without contradicting the page's own model) — a correction already made
//! and recorded in `papers/analysis/tg3_cimt.py` before this node existed,
//! reproduced here as `k_start=9, s_start=4`. See the conformance vector in
//! `ra-cli`'s `corpus.rs` and the test below.

use crate::classical::toolfmt::{self, CaseFold, InputNorm, OutputFmt};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

/// ITA2 five-bit codes in numeric order 0..31, in the Bletchley Park notation
/// the toolkit's own `lcodes` array uses: `lcodes[31]` is letter-shift,
/// written `8` (the General Report on Tunny writes it `-`); `lcodes[27]` is
/// figure-shift, written `+` by both.
pub const ITA2: &[u8; 32] = b"/T3O9HNM4LRGIPCVEZDBSYFXAWJ+UQK8";

/// The K wheel's fixed 14-letter cam pattern (`klets[1..14]` on the page):
/// the literal alphabet `A..N`, pinned by the page's worked example.
const K_WHEEL: &[u8; 14] = b"ABCDEFGHIJKLMN";

/// The S wheel's fixed 4-letter cam pattern (`slets[1..4]` on the page's own
/// script: `slets[1]='A'; slets[2]='A'; slets[3]='B'; slets[4]='B';`).
const S_WHEEL: &[u8; 4] = b"AABB";

fn ita2_code(b: u8) -> Option<u8> {
    ITA2.iter().position(|&c| c == b).map(|i| i as u8)
}

const CIMT_LORENZ_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::req(
        "k_start",
        ParamType::Int,
        "K-wheel start position, 1..=14 (1-indexed, matching the page's own \
         'K-wheel start position' field)",
    ),
    ParamSpec::req(
        "s_start",
        ParamType::Int,
        "S-wheel start position, 1..=4 (1-indexed, matching the page's own \
         'S-wheel start position' field)",
    ),
);

/// The page's `encodeText()`, applied one direction at a time: this node
/// performs it in the decrypt direction (ciphertext in, plaintext out), which
/// is byte-for-byte the same formula the page uses for the encrypt direction
/// too, since XOR is its own inverse. [`cimt_lorenz_transform`] is exposed so
/// the test module's encryption helper below is *literally the same code
/// path*, not a second reimplementation that could silently drift from it.
pub fn cimt_lorenz_transform(data: &[u8], k_start: i64, s_start: i64) -> Vec<u8> {
    let mut out = Vec::with_capacity(data.len());
    for (i, &b) in data.iter().enumerate() {
        let k_letter = K_WHEEL[(k_start as usize - 1 + i) % K_WHEEL.len()];
        let s_letter = S_WHEEL[(s_start as usize - 1 + i) % S_WHEEL.len()];
        // Both wheel letters are always members of the fixed cam patterns
        // above, so their codes always resolve.
        let k_code = ita2_code(k_letter).expect("K wheel cams are all valid ITA2 glyphs");
        let s_code = ita2_code(s_letter).expect("S wheel cams are all valid ITA2 glyphs");
        let out_byte = match ita2_code(b) {
            Some(code) => ITA2[(code ^ k_code ^ s_code) as usize],
            // The page's own behaviour: an out-of-alphabet character enciphers
            // to a literal '?' rather than aborting the whole message.
            None => b'?',
        };
        out.push(out_byte);
    }
    out
}

/// CIMT/MEP Simplified Lorenz Cipher Toolkit, decrypting.
pub struct CimtLorenz;

impl Node for CimtLorenz {
    fn name(&self) -> &'static str {
        "cimt_lorenz"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CIMT_LORENZ_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let k_start = params.req_i64("cimt_lorenz", "k_start")?;
        if !(1..=14).contains(&k_start) {
            return Err(Error::bad_param(
                "cimt_lorenz",
                "k_start",
                format!("must be 1..=14, got {k_start}"),
            ));
        }
        let s_start = params.req_i64("cimt_lorenz", "s_start")?;
        if !(1..=4).contains(&s_start) {
            return Err(Error::bad_param(
                "cimt_lorenz",
                "s_start",
                format!("must be 1..=4, got {s_start}"),
            ));
        }

        // The page forces its plaintext/ciphertext input to upper case before
        // running the wheels (`pts=pts.toUpperCase()`); there is no grouping
        // and the result is written via `.value =`, so no CRLF copy artifact.
        let input_norm = toolfmt::read_input_norm(
            "cimt_lorenz",
            params,
            InputNorm {
                case: CaseFold::Upper,
                ..InputNorm::default()
            },
        )?;
        let output_fmt = toolfmt::read_output_fmt("cimt_lorenz", params, OutputFmt::default())?;

        let data = input_norm.apply(&input.data);
        let out = cimt_lorenz_transform(&data, k_start, s_start);
        let out = output_fmt.apply(&out);

        Ok(Repr::new(out, input.display))
    }
}

register_node!(CIMT_LORENZ => || Box::new(CimtLorenz));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    /// Test-only "encryption": literally [`cimt_lorenz_transform`] again,
    /// since the page's own `encodeText()` is the same formula both ways (XOR
    /// is an involution). Kept as a separate name only so round-trip tests
    /// below read naturally; it is not a second implementation.
    fn encrypt_for_test(data: &[u8], k_start: i64, s_start: i64) -> Vec<u8> {
        cimt_lorenz_transform(data, k_start, s_start)
    }

    /// The page's own worked example: "Encipher the word 'HELLO' with the
    /// starting position K=7, S=2 ... enciphers to 'FNFGH'."
    #[test]
    fn matches_pages_own_worked_example() {
        let n = registry().get("cimt_lorenz").unwrap();
        let p = params! {"k_start" => 7i64, "s_start" => 2i64};
        let out = n
            .apply(&Repr::bytes(b"FNFGH".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"HELLO");
    }

    /// TG3 end to end: the recorded ciphertext, at the recorded (corrected)
    /// start positions, reproduces the recorded plaintext exactly.
    #[test]
    fn reproduces_tg3_end_to_end() {
        let n = registry().get("cimt_lorenz").unwrap();
        let p = params! {"k_start" => 9i64, "s_start" => 4i64};
        let ct = b"NMFU3DNILVAXTPPH9AYHRXUM3PDBVMHN/CANVGPYS+3HGQKH";
        let out = n.apply(&Repr::bytes(ct.to_vec()), &p).unwrap();
        assert_eq!(
            String::from_utf8(out.data).unwrap(),
            "WHENFINISHEDWEWILLRETURNTOTHEHOUSEANDTHEINFINITE"
        );
    }

    #[test]
    fn round_trips_arbitrary_alphabet_text_at_any_start() {
        for k_start in 1..=14i64 {
            for s_start in 1..=4i64 {
                let pt = b"THEQUICKBROWNFOXJUMPS9OVERTHELAZYDOG";
                let ct = encrypt_for_test(pt, k_start, s_start);
                let n = registry().get("cimt_lorenz").unwrap();
                let p = params! {"k_start" => k_start, "s_start" => s_start};
                let out = n.apply(&Repr::bytes(ct), &p).unwrap();
                assert_eq!(out.data, pt, "k_start={k_start} s_start={s_start}");
            }
        }
    }

    #[test]
    fn out_of_alphabet_character_becomes_question_mark() {
        let n = registry().get("cimt_lorenz").unwrap();
        let p = params! {"k_start" => 1i64, "s_start" => 1i64};
        // '1' is not in the 32-glyph ITA2 alphabet.
        let out = n.apply(&Repr::bytes(b"A1B".to_vec()), &p).unwrap();
        assert_eq!(out.data[1], b'?');
    }

    #[test]
    fn input_is_upper_cased_before_transforming() {
        let n = registry().get("cimt_lorenz").unwrap();
        let p = params! {"k_start" => 7i64, "s_start" => 2i64};
        let out = n.apply(&Repr::bytes(b"fnfgh".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"HELLO");
    }

    #[test]
    fn rejects_k_start_out_of_range() {
        let n = registry().get("cimt_lorenz").unwrap();
        let p = params! {"k_start" => 15i64, "s_start" => 1i64};
        let err = n.apply(&Repr::bytes(b"A".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");

        let p = params! {"k_start" => 0i64, "s_start" => 1i64};
        let err = n.apply(&Repr::bytes(b"A".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn rejects_s_start_out_of_range() {
        let n = registry().get("cimt_lorenz").unwrap();
        let p = params! {"k_start" => 1i64, "s_start" => 5i64};
        let err = n.apply(&Repr::bytes(b"A".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");

        let p = params! {"k_start" => 1i64, "s_start" => 0i64};
        let err = n.apply(&Repr::bytes(b"A".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn missing_required_params_error() {
        let n = registry().get("cimt_lorenz").unwrap();
        let err = n.apply(&Repr::bytes(b"A".to_vec()), &params! {}).unwrap_err();
        assert!(matches!(err, Error::MissingParam { .. }), "{err}");
    }

    #[test]
    fn preserves_display() {
        let n = registry().get("cimt_lorenz").unwrap();
        let p = params! {"k_start" => 7i64, "s_start" => 2i64};
        let out = n
            .apply(&Repr::new(b"FNFGH".to_vec(), Display::Hex), &p)
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn is_xf_family_and_not_layer_forming() {
        let n = registry().get("cimt_lorenz").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
