# Architecture

A Rust workspace implementing the engine, coverage algebra and attestation model
specified in the dossier's papers 5–7. The Python in `reference/py/` is the
specification this was built against; it is retained for comparison, not used at
runtime.

## Crate graph

```
ra-core ──────────┬──> ra-prim ────┐
  Repr, Node,     │     modes,     │
  registry,       │     primitives │
  Chain, layers   │                │
                  └──> ra-oracle ──┤
                        scoring    │
                                   ├──> ra-cli  (the `ra` binary)
ra-covalg ────────┬──> ra-attest ──┤
  Product/Cover   │     gating     │
  exact residual  │                │
                  │                │
ra-toolreg ───────┘   ra-merkle ───┘
  tool identity,       streaming commit,
  selective            audit paths
  invalidation
```

Nothing depends on `ra-cli`; every capability is a library first.

## The plugin boundary

A plugin is a type implementing `ra_core::Node`:

```rust
pub trait Node: Send + Sync + 'static {
    fn name(&self) -> &'static str;
    fn version(&self) -> &'static str;
    fn family(&self) -> Family;              // Xf | Codec | Dec | Solver
    fn source_digest(&self) -> &'static str; // provenance of the backing impl
    fn params_schema(&self) -> &'static [ParamSpec];
    fn block_size(&self, p: &Params) -> Option<usize>;
    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr>;
}
```

Registration is link-time, via a `linkme` distributed slice:

```rust
ra_core::register_node!(MY_NODE => || Box::new(MyNode));
```

**Why link-time rather than runtime-loadable.** The binary's hash must cover every
primitive it can execute, so a reproducible build maps verifiably back to audited
source. Document 6 argues that compilation is not an integrity mechanism and that
reproducible builds plus independent auditability are what actually work; a
`dlopen`-style plugin would break exactly that property, and conformance gating
depends on it. The set of nodes is therefore fixed when the binary is linked, and
resolved by name at runtime.

`Family` carries coverage semantics, not just taxonomy:

| Family | Meaning | Coverage semantics |
|---|---|---|
| `Xf` | representation-preserving transform | not layer-forming |
| `Codec` | display change | not layer-forming — canonical bytes are unchanged |
| `Dec` | keyed decryption | layer-forming |
| `Solver` | automated classical solver | **terminal**, and its coverage is *heuristic* |

The solver distinction is load-bearing. An exhaustive sweep returning nothing proves
its region is empty. A solver returning nothing proves only that its heuristic missed
within budget. `Chain::new` refuses to place a terminal node anywhere but last, and
heuristic claims must never subtract from the exhaustive residual.

### One node per primitive

`engine.py` exposes a single `mcrypt` node parameterised by `prim`. This workspace
registers **eleven separate `dec` nodes** instead. A shared node would give all
primitives one `node_id`, which destroys Document 6's central payoff: revoking a
defective Twofish build must void *only* Twofish coverage. Per-primitive identity
makes selective invalidation exact — `ra-toolreg`'s test reproduces the documented
figure of 215M candidates voided and 158M retained (42% preserved) where
platform-level versioning would void all 373M.

## Layer detection

`Repr` carries bytes plus how they are *displayed*. `canonical_bytes()` normalises the
display away, which makes the semantic definition of a layer computable: pure
re-encoding preserves canonical bytes, so `base64 → hex` registers an entropy delta of
exactly zero and is not a layer, while a decryption rewrites the byte sequence.

`ra_core::layer::layer_delta` reports entropy before/after, representation class
before/after, and whether a layer boundary was actually crossed. `classify` checks
text-likeness *first*, because uppercase prose also matches the base64 character
class and would otherwise be mislabelled.

## The block-aware oracle

Under CFB-8 a wrong IV corrupts exactly `block_size` bytes, then the stream
self-synchronises. This is verified byte for byte against real corpus data in
`ra-prim/tests/corpus.rs`, not asserted.

The consequence: a correct Rijndael-256 hit on a 144-byte TG4 candidate presents as
only 112/144 = 77.8% printable, so a fixed 0.80 threshold silently discards the
answer. `Chain::terminal_block_size()` reports the relevant block size and the oracle
skips that prefix. The fix is exact rather than heuristic, and it lowers the false
positive rate too, because the scored region is pure signal.

Because a stricter oracle covers strictly less, the oracle id is part of the claim.
`printable-1.00` is retained and flagged as not block-aware, so an attestation citing
it produces a warning rather than silently over-claiming.

## Coverage algebra

The space of pipelines partitions by **skeleton** (the ordered tuple of layer
families). Within a skeleton it is a Cartesian product of per-slot parameter domains,
so a claim is a union of hyperrectangles. Union-of-products is closed under difference
via orthogonal decomposition, which makes

```
RESIDUAL = UNIVERSE \ (claim₁ ∪ claim₂ ∪ … ∪ claimₙ)
```

**exact rather than estimated**. `Product::difference` emits at most `|dims|` pairwise
disjoint products; the disjointness is what makes summing their sizes exact, and it is
verified pointwise in tests rather than assumed.

Sizes are `u128` because realistic multi-layer universes exceed `u64`.

Coverage sets are content-addressed over a canonical (`BTreeMap`-ordered) JSON view, so
equal coverage yields an equal digest and duplicate work is detectable across teams
without re-running anything.

## Conformance gating

`ra_attest::gate_coverage` intersects each `*.prim` dimension of a coverage set with
the primitives that are **proven**, and drops any product whose primitive set becomes
empty. A primitive proven under neither class below contributes zero coverage
regardless of what the claim asserts.

### Two proof classes, and why the second one had to exist

Proof used to mean exactly one thing: reproducing a *solved* corpus cipher end to end
with known plaintext. That is a genuine proof of correctness, but it conflates two
different questions:

1. **Is this implementation correct?** — answerable by the algorithm's own
   published/normative test vectors.
2. **Did the puzzle author use this primitive?** — a *prior about the puzzle*, not a
   property of the code.

The gate's purpose is to stop a **defective implementation** manufacturing a false
negative that silently deletes a region of the search forever. That purpose is served
by (1) alone. Using (2) as a proxy is **circular for the two unsolved ciphers**: TG4 and
REV7 may well use a primitive that appears nowhere in the solved corpus, and a gate that
can only certify what has already been witnessed structurally prevents crediting any
search of genuinely new space. AES is the sharp case — it is the default algorithm on
the tools4noobs successor form, and no solved cipher uses it, so under the old rule its
coverage was zero permanently no matter how much compute was spent. Salsa20 is sharper
still: it comes from a tool site only identified in 2026, so no corpus chain could ever
have used it.

| class | meaning | carries coverage |
|---|---|---|
| `CorpusProven` | reproduces a solved corpus chain end to end with known plaintext | yes |
| `VectorProven` | matches the algorithm's own published/normative test vectors | yes, **tagged distinctly** |
| unproven | neither | **no — exactly zero** |

The two proven classes are **never silently merged**. The precedent is this workspace's
existing separation of heuristic `Solver` coverage from exhaustive coverage: visible,
not conflated. `ra conformance` reports each class separately with its citation, and an
auditor can see at a glance how much of a negative rests on the weaker proof.
`PrimInfo::vector_proof` carries the citation, so "vector-proven" is never an assertion —
it names the document it rests on.

The safety property is unchanged: an implementation validated by nothing still carries
nothing, and `is_vacuous()` still reports a gate that examined zero `*.prim` dimensions
as a *failure to gate* rather than a pass.

`ra conformance` runs the suite for real, and reports **11 of 16 CorpusProven**, **4
additionally VectorProven** (AES via FIPS-197 C.1 plus libmcrypt's own `rijndael-128.c`
self-test; 3DES via libmcrypt's `tripledes.c` self-test; CAST-128 via RFC 2144 Appendix
B.1; Salsa20 via Bernstein's reference vectors), and **1 unproven under either class** —
IDEA, which has no corpus chain and no cited normative vector, and therefore still
contributes zero. Admitting the second class moved the worked-example residual union
from 100 to 116: four primitives × 4 candidates each, which
`gating_is_the_identity_and_the_residual_is_unmoved_except_for_unproven_primitives`
pins along with the arithmetic.

Historically, every primitive in the vocabulary was backed by a reproduction, so gating
voids nothing — but the mechanism is what makes that statement checkable rather than
asserted, and it will void a primitive again the moment one regresses.

### Where the gate is applied

`gate_coverage` is the **only** implementation of the intersection in the workspace,
and it has exactly two callers:

| caller | gates | against |
|---|---|---|
| `Attestation::effective_coverage()` | a hand-written attestation document | the conformance evidence that document declares |
| `cmd_residual` (`crates/ra-cli/src/gate.rs`) | every claim folded by `ra residual --claims`, worked example or sweep output alike | `corpus::conformance_state`, executed at the moment the residual is computed |

The second did not exist for a long time, and its absence is the failure this section
is really about. `ra-attest` implemented and tested the gate; `ra attest <file>`
displayed it; the pipeline a user actually runs —

```
ra sweep --emit-claim <file>   ->   ra residual --claims <file>
```

— never called it. `cmd_residual` unioned each loaded claim straight into the
aggregate. Because all eleven primitives are conformance-PASS, gating would have been
the identity, so nothing was ever wrong *numerically* and nothing failed. The property
held **coincidentally rather than by enforcement**, which is the worst state for a
safety property to be in: a regressed primitive, or an unproven twelfth, would have had
its void coverage absorbed silently and permanently deleted a region from the search on
the strength of a fabricated negative. `ra residual` now executes conformance and gates
every claim before folding it, and reports claimed versus effective size per claim with
each void attributed to its own reason.

The aggregate and the residual are computed from **effective** coverage. `GatedClaim`
is the only thing `gate_claims` hands back and it exposes the effective set alone as
foldable, so there is no route from a loaded claim to the aggregate that skips the gate.

### The gate cannot pass vacuously

Deviation 3 below records a case mismatch — `Rijndael-256` against a table keyed
`rijndael-256` — that once made a conformance check pass **vacuously**: the check ran,
found nothing to compare, and reported success. The general form of that hazard is a
gate with nothing to bite on, so `GatedCoverage` counts the `*.prim` dimensions it
actually examined and `is_vacuous()` reports zero as a *failure to gate*, not a pass. A
claim spelling its dimension `1.primitive`, or omitting it, is refused by `ra residual`
rather than folded. Matching is case-insensitive across the two spellings this
workspace uses, and tested to be case-insensitive without being name-blind: an
unrecognised primitive is voided whatever its case.

### A claim carries its own conformance provenance

`ra sweep --emit-claim` records the conformance state it ran under — which primitives
were proven, which were not, which the run itself swept, and the digest of the
conformance suite:

```json
"conformance": {
  "suite_digest": "sha256:…",
  "proven_primitives": ["Blowfish", …],
  "unproven_primitives": [],
  "swept_primitives": ["DES", …],
  "all_swept_primitives_proven": true
}
```

The precedent is `enumeration_order`: a claim must carry what is needed to check it. A
published Merkle root nobody can regenerate is not a commitment, and coverage over
primitives nobody can tell were proven is not coverage. `ra verify-claim` reports the
block, flags drift against the suite digest, and names any primitive that was proven at
emission and is not proven now.

Loading stays **backward compatible**: the five committed claims predate the block, one
of them a five-hour run, and invalidating them to add a field would be a worse outcome
than the defect. A claim with no block still loads and still verifies; it is announced
as not self-describing and gated against *current* conformance rather than trusted.

## Sweep execution

`ra sweep` enumerates a bounded space with `rayon`. Three properties the design
requires:

- **Deterministic enumeration.** Candidate `i` is a pure function of `i` and the axis
  lists (`sweep::decode_index`, tested as a bijection), so a challenged candidate is
  regenerable without replaying the sweep. That is what makes a spot audit cheap.
- **Outputs are discarded.** Each candidate folds into a `StreamingMerkle` and is
  dropped; only above-threshold hits are retained. Resident cost is well under a byte
  per candidate.
- **The result is a coverage set, not a count.** A count neither composes nor
  differences. The emitted claim is directly usable in a residual calculation.

### Two hashes, and only one of them is order-independent

A claim carries two commitments, and they have *opposite* invariants. Conflating them
cost this workspace a real property, so both are now stated and both are emitted:

| | coverage digest | Merkle root |
|---|---|---|
| commits to | *which* candidates are covered | *that this computation ran* |
| axis order | **irrelevant by design** — axes are stored as sorted sets, so equal coverage hashes equally however the command line was spelled | **load-bearing by necessity** — `leaf_hash` binds the candidate index, and the index is assigned by mixed-radix enumeration over the axis lists *as resolved* |
| recorded as | `coverage_claimed` (sorted `BTree*`) | `enumeration_order` per tier (ordered, least significant digit first) |

The order-independence of the coverage digest is the whole point of it: it is what lets
two teams detect duplicate work without re-running anything. But the same axis *sets* in a
different *order* enumerate a different index assignment and therefore commit to a
different root — three orders of the same 3,696-candidate T1 space give three roots.

A claim that recorded only the sorted cover therefore published a root **nobody could
regenerate**, which silently voids Document 6's spot audit: its premise is that a
challenged leaf is cheaply regenerable from deterministic enumeration, and a verifier
holding the claim had the coverage but not the order. The coverage claims and the residual
were unaffected — only the computation commitment was unverifiable — but "unverifiable
commitment" is precisely the failure this apparatus exists to prevent.

The fix is to record the order, **not** to sort the enumeration: a commitment describes a
computation, and the computation had an order. `ra verify-claim` rebuilds the axes from the
recorded order and checks that the claim regenerates itself — structurally for free, or
against the root byte for byte with `--recompute`. `a_claim_round_trips_to_the_same_merkle_root`
holds that for all three tiers, `the_merkle_root_depends_on_the_enumeration_order` pins why
it is needed, and a claim with no recorded order is *refused* rather than half-honoured.

Leaves are collected with their indices and folded in index order, so the commitment
does not depend on thread scheduling. For a 1e8-candidate sweep, holding every leaf at
once would cost gigabytes, so chunks are processed in *ordered batches* and each
batch's leaves are folded and dropped — the fold order, and therefore the root, is
identical to the single-batch case.

### Tiers, and the inter-layer codec

`--tier` selects which skeleton to enumerate, and each is swept and committed to
separately because the coverage algebra partitions by skeleton:

| Tier | Skeleton |
|---|---|
| T1 | `b64d ∘ dec` |
| T2 | `b64d ∘ xf ∘ dec` |
| T3 | `b64d ∘ dec ∘ xf ∘ codec ∘ dec` |

T3's `codec` slot is the structural correction. Because every recorded chain omits the
implicit decode the tools4noobs box performs on its input, a multi-layer model built
from the recorded chains has the **wrong skeleton vocabulary**: it enumerates
`dec ∘ xf ∘ dec`, which is literally what `reference/py/residual.py`'s `SK_T3` says,
and that skeleton does not contain the pipelines that actually solved the corpus.
The re-encoding is therefore an enumerable dimension, and its domain is *read off the
solved corpus* — the `codec`-family nodes appearing between two consecutive
layer-forming steps in the chains this engine reproduces, which is
`{identity, b64decode, hexdecode, hex_to_base64|b64decode, decimaldecode, octaldecode}`.
A unit test asserts that equality against `corpus::VECTORS`, so inventing a value or
dropping an observed one fails the build rather than quietly changing what a claim means.

Two honest limits of that model, both visible in the claim rather than assumed away:

- `hexdecode` and `hex_to_base64|b64decode` denote the same bytes. They are distinct
  *pipelines*, both spelled out in the corpus, so both are evaluated — collapsing them
  would evaluate one point and claim two.
- The fullest arrangement the corpus shows is `codec ∘ xf ∘ codec` (rev9's
  `decimaldecode | reverse | b64decode`). T3 covers the `xf ∘ codec` sub-form; the
  leading codec makes a *different skeleton*, which the algebra keeps separate, so its
  absence is legible in the claim instead of being papered over.

### The transcription is an axis, not a constant

A recorded ciphertext is a **transcription of an image**, and TG4's is rendered in an
Oswald-derived face with two candidate confusions: `I`/`l` and `0`/`O`. Both members of
each pair are valid base64, so on the face of it both readings are admissible everywhere
they occur. Only one pair is actually open:

| pair | occurrences in TG4 | offsets | status |
|---|---|---|---|
| `I`/`l` | 7 | 3, 15, 31, 36, 39, 90, 160 | **open** — enumerated |
| `0`/`O` | 7 | 37, 64, 86, 94, 105, 112, 114 | **resolved** — fixed to the recorded reading |

so the admissible space is **2^7 = 128 readings**, and every tier is swept exhaustively
over all of it.

The `0`/`O` resolution and the evidence for the rest are three different kinds of claim,
and are kept apart on purpose:

1. **`0`/`O` is resolved by the project team's direct review of the transcript against
   the font that was actually used.** That is *external ground truth about the artefact* —
   a human reading of the source — not something derivable from the corpus, and it is
   what turns an infeasible 2^14 space into a fully enumerable 2^7 one. It is recorded in
   `crate::variants::RESOLVED_PAIRS` as a stated fact rather than an absence, so
   `no_resolved_glyph_is_ever_enumerated` can check that no `0`/`O` position re-enters the
   space and that no variant alters one of those seven bytes at any mask. Re-opening the
   pair has to be a deliberate edit, not a regression.
2. **A corpus measurement corroborates it independently** — see below.
3. **REV7 is unaffected**, and that is *computed*: see the display-awareness point below.

Three engineering properties are load-bearing:

- **Derived, never written down.** Hardcoding the 7 offsets would rot silently the moment
  the corpus record were corrected — the sweep would enumerate a space the ciphertext no
  longer has while the claim went on asserting the old one. The offsets are scanned at
  runtime, and `tg4_derives_the_seven_open_ambiguous_positions` pins the result against
  the record so a re-transcription fails the build.
- **Display-aware, which is what settles REV7.** A glyph is ambiguous only if its partner
  is admissible in that display's alphabet. Hex excludes `O`, `I` and `l`, so REV7's
  transcription carries no glyph ambiguity of this kind at all — not even a *resolved*
  one. The dossier's "REV7 is unambiguous" is therefore confirmed rather than assumed,
  and REV7's claim digest is byte-identical before and after this work.
- **Labels are the mask, so claims compose.** A reading is named `v` + the bit mask over
  the *open* positions in ascending offset order, lower-case hex, zero-padded: `v00 ..
  v7f`. Bit `i` clear means the recorded glyph, so **`v00` is exactly the corpus reading**
  and is the pre-correction `v01` under a new name. The label depends only on the mask and
  the open-position count, so two runs' claims are directly comparable.

The variant is the **most significant** digit of the candidate index. Nothing needs a
bound at 128 readings, but the property is what would make one safe: a `--max-candidates`
prefix covers *whole readings*, and the emitted cover is a single product naming exactly
those readings rather than a prefix smear across the cipher axes.
`the_transcription_is_the_most_significant_axis_and_multiplies_the_product` and
`a_variant_bounded_run_claims_whole_readings` hold that.

#### Glyph reliability: the corroborating measurement

The transcriber's per-glyph calls were measured on exactly these two pairs, using the
solved base64 ciphers whose chains this engine reproduces, by **perturbation**: flip one
glyph call and check whether the reproduction still holds.

| vector | ambiguous positions | flips that break the reproduction | what breaks |
|---|---|---|---|
| rev5 | 128 | 128 / 128 | the RC2 layer stops classifying as hex |
| rev9 | 45 | 45 / 45 | the DES layer stops classifying as decimal |
| rev1 | 4 | 4 / 4 | exact plaintext recovery fails |
| **total** | **177** | **177 / 177**, i.e. **0 errors** | |

Every one of the 177 calls is *independently* verified — the perturbation shows each is
load-bearing rather than incidentally right — and 89 of them are `0`/`O` calls against 88
`I`/`l`. This is **corroboration of the team's font review, not the basis for the
decision**: the decision rests on the direct reading of the source, and the measurement
is an independent line of evidence pointing the same way. The rule of three puts a 95%
upper bound of `3/177 = 1.69%` on the per-call error rate.

Its one consequence for the engine is an *expectation*, never a constraint: the same
method gives 88/88 on `I`/`l`, so if TG4 has a solve, `v00` — the recorded reading — is
the one most likely to carry it. The enumeration covers the other 127 regardless, and the
claim does not privilege any of them.

#### What was run

Over the observed menu (11 primitives, 7 modes, 6 keys, 4 key-derivations, 2 IVs =
3,696 per modern layer), with the block-aware `printable-0.75` oracle. **Every tier is
exhaustive over the complete 128-reading variant space** — there is no bound to log and no
partial claim to describe:

| region | candidates | hits | verdict |
|---|---|---|---|
| T1 x all 128 readings | 473,088 | **0** | exhaustive. Scored region 112–144 B, chance budget `5.5e-12` |
| T2 x all 128 readings | 946,176 | **0** | exhaustive. Scored region 112–144 B, chance budget `1.1e-11` |
| T3 x all 128 readings | 20,982,398,976 | artifacts only | exhaustive. Passes below the chance budget, longest passing scored region a handful of bytes |

The T1/T2 rows are unambiguous negatives: those skeletons are empty **for every admissible
transcription**, with a 112-to-144-byte scored region, so a single hit would have been
decisive. T3's passes are matcher artifacts over short inter-layer decodes and are
reported as such, against the chance expectation rather than in isolation.

For scale, the pre-resolution worst case over both glyph pairs was 2,685,747,068,928 T3
candidates — about 27 days at the measured throughput. The font review is worth a factor
of 128, and it is the reason this is a complete result rather than a bounded one. Two
techniques that were on the table for making a 2^14 T3 tractable — probability-weighted
Hamming ordering of the variant axis, and an exact per-cluster decomposition of the score
over disjoint output windows — are therefore **both absent**, deliberately. Neither is
needed, and an unproven decomposition manufactures exactly the false negatives this
project exists to prevent.

The variant axis is **provably additive**: for a recorded-reading run, the same invocation
produces an identical Merkle root on the pre-variant-axis binary and on this one, and the
same 1,820,718 T3 passes. (Roots are quoted nowhere here on purpose — a root is only
meaningful beside the enumeration order that produced it, which is why claims now record
that order and `ra verify-claim` regenerates from it.)

### Bounding is explicit, never silent

`--max-candidates N` truncates the index space, and the emitted cover is the **prefix
decomposition** of `[0, N)` in the mixed radix of the axes: for each digit position
with a non-zero digit, one product fixes the axes above it, restricts that axis to its
first `d` values, and leaves the axes below it free. Those blocks are pairwise disjoint
and their sizes sum to exactly `N`, so `size_exact()` equals the candidates actually
evaluated even for an `N` that is not a multiple of any radix. A run asserts that
equality before emitting, and logs what it dropped. A truncated sweep therefore cannot
produce a claim larger than its work — which is the failure mode the whole coverage
apparatus exists to prevent.

### The false-positive budget is reported, not assumed

Document 4's "expected false positives ≈ 0" is computed for a 144- or 546-byte payload.
An inter-layer `hexdecode` of high-entropy bytes keeps only the ASCII hex digits, so the
second modern layer can receive a dozen bytes, and a printable-ratio oracle over a
dozen bytes is nearly uninformative. Each run therefore accumulates the distribution of
*actual* scored lengths and reports `Σ count(n) · P(≥threshold printable | n)` beside
the hit count. On TG4's exhaustive T3 that budget is 2.36e6 against 1.82e6 observed
passes — the observed rate is *below* chance, and the longest scored region among all
of them is a handful of bytes. Saying so is the difference between a negative result
and a false alarm, and the run reports the longest passing scored region precisely so
that "these are all artifacts" is checkable rather than asserted.

Extending T1 and T2 across all 128 admissible readings sharpens the contrast from the
other direction. There the scored region is 112–144 bytes (the block-aware oracle skipping
the CFB-8 corruption prefix), so the budget is `5.5e-12` over T1's 473,088 candidates and
`1.1e-11` over T2's 946,176 — and the observed pass count is **zero**. A single hit in
either would have been decisive rather than ambiguous, which is what makes those two
negatives worth having and T3's passes worth discounting.

For the same reason, hit retention is ranked by scored length before score. A first-N
policy would let a million three-byte artifacts displace a genuine full-length hit
found later in the index space — the sweep would find the answer and throw it away.
Hits also carry the transcription they were found against, and — for any reading other
than the recorded one — the exact ciphertext bytes, since a hit on a corrected reading is
not reproducible from the corpus record alone. Making that actually work exposed a defect
in the chain-spec parser: it typed parameters by shape, so a null IV's thirty-two zeros
became the integer `0` and the one chain an auditor most wants to paste into `ra run` was
the only one that would not parse (the ASCII-zero invariant, `iv=3030…`, parsed fine, so
the failure hid behind the *other* IV in the domain). A zero-padded fixed-width field is
now a string; `n=0` is still an integer.

## Repair execution

`ra repair` searches the one dimension a sweep silently fixes: the *transcription*. It
enumerates unknown display characters at a named site jointly with the cipher axes,
scores a byte range of the output, and emits the result as a coverage set whose
`0.variant` dimension lists the repaired variants explicitly.

Three properties differ from `ra sweep` and are load-bearing:

- **The scored window is part of the claim.** Scoring bytes `[a, b)` eliminates a
  combination only under the assumption that a correct first layer is recognisable
  *there*. The emitted JSON records `scored_window_bytes` so the assumption is
  checkable rather than implicit.
- **Leaves are batched.** `ra sweep` collects every Merkle leaf before folding, which is
  fine at 10^4 candidates and 1.2 GB at 10^8. `repair` folds batches of 2^18 in index
  order, so the commitment is the same construction at bounded memory — 0.012 bytes per
  candidate over a 45-million-candidate run.
- **The report is a distribution, not a verdict.** A null result is only interpretable
  as a distance from the random-byte baseline of 95/256 = 0.371, so the score histogram
  and the best score are always printed, whether or not anything passed.

The two commands must also agree about what is *ambiguous*, not only about key bytes, or
each would name the same region differently and the digests would stop detecting
duplicate work. Both derive the glyph space with `crate::variants`; `repair`'s
`0.variant` values then additionally name the repair word. What `repair` does **not** do
is enumerate glyph readings jointly with repair words — for REV7 that costs nothing,
because its hex transcription is computed to have no glyph ambiguity at all, and for a
target that has both the command says so and records the uncovered readings in the
emitted claim rather than omitting them. (`repair`'s *repair alphabet* is deliberately a
different set from `variants`' *admissible* alphabet: the former is what to enumerate, so
including both cases of hex would double REV7's 45.4M-candidate space while evaluating
each byte twice.)

`--grid` reports the transcription grid and the repair arithmetic without searching:
group census, anomalies against the modal grid, and the parity of every candidate
repair. That is how REV7's reconstruction was *tested* rather than assumed — see
`notes/rev7-repair-search.md`.

One negative property is worth knowing before reaching for this command. Enumerating two
gaps in *sequence* rather than as a product depends on the first repair byte-aligning a
prefix long enough to identify a layer. A `reverse` transform destroys that: it puts the
stream's tail at the front, and the tail is exactly what is still unknown. The reverse
skeleton therefore cannot be covered by the sequential decomposition at all, and the
command warns rather than quietly scoring a different hypothesis.

`StreamingMerkle` and the batch `merkle_root` use the same RFC 6962-style left-heavy
split, so the two agree by construction for every leaf count. The alternative —
padding each level by duplicating the last leaf — builds a different tree for any
non-power-of-two count and admits the duplicate-leaf root ambiguity.

## Deviations from the reference implementation

| # | Reference behaviour | Here | Why |
|---|---|---|---|
| 1 | `mcrypt_node.py` pads keys to `mcrypt_enc_get_key_size` (the **maximum**) | pads to the **smallest supported** size | rev9's Twofish layer only recovers its known plaintext at 16 bytes, not 32. See below. |
| 2 | one `mcrypt` node parameterised by `prim` | one node per primitive | shared identity breaks selective invalidation |
| 3 | conformance table keyed literally, so `Rijndael-256` missed `rijndael-256` and passed **vacuously** | case-insensitive lookup, a missing entry is an error, and the gate now counts the dimensions it examined so "nothing to check" cannot read as a pass | the vacuous pass admitted unproven coverage |
| 4 | `merkle_root` pads by duplicating the last leaf; streaming folds a frontier | both use the RFC 6962 split | the two constructions otherwise disagree |
| 5 | oracle block-awareness implicit | `block_aware` is a declared field of the oracle spec | a non-block-aware oracle must be visible in the attestation |
| 6 | `space.py` sets `N_TRANS_TG = 16` transcription variants | derived from the ciphertext: **128** | an 8x understatement of the dimension, and it propagates into every feasibility figure. See below. |

### On deviation 6: the transcription dimension is 8x larger than modelled

`reference/py/space.py` models TG4's glyph ambiguity as `N_TRANS_TG = 16`, and Paper 2
says "as many as sixteen transcription variants are admissible". Sixteen is roughly the
count of *ambiguous glyphs one might list*, not the count of readings, and the two are not
the same thing: `n` independently ambiguous positions admit `2^n` readings. TG4 has 7 open
`I`/`l` positions, so the admissible count is **128**. The figure is derived from the
ciphertext rather than transcribed, and asserted in
`variants::tests::the_variant_count_corrects_the_dossier_by_8x`.

The correction propagates straight into Paper 4, whose headline is that the bounded
programme (tiers T1–T4) costs **1.15e9** candidates for TG4 — "12 hours single-core
Python, 9 minutes optimised" — and is therefore "very probably been exhausted already by
prior community effort, which is consistent with the reported negative results". Every one
of those figures carries `N_TRANS_TG` as a factor, so each is 8x too small:

| Paper 4 says | actually |
|---|---|
| bounded programme T1–T4 = 1.15e9 candidates | **9.2e9** |
| 12 hours single-core Python | **4 days** |
| 9 minutes optimised | **72 minutes** |
| "very likely already spent" | **still plausible, but no longer cheap enough to assume** |

The conclusion survives at 8x where it would not have at 1024x, which is precisely why
the `0`/`O` resolution matters: had both pairs stayed open, the admissible space would
have been 16,384 readings, the bounded programme 1.18e12 candidates and 6.4 days of
optimised compute, and "very likely already spent" would have been indefensible. As it
stands the claim is merely unverified rather than wrong — and this workspace's coverage
figures are the way to find out which parts of that space genuinely have been spent.

Paper 4's other recommendation is sharpened and half-collected: "resolving the TG4
transcription to a single confirmed variant cuts its search space sixteenfold" is really
128-fold, obtainable for zero compute spend. The team's font review has already collected
a factor of 128 of the original 16,384 by closing `0`/`O`; resolving the remaining seven
`I`/`l` calls is worth the last factor of 128.

The reference Python is left untouched: it is the specification this workspace was built
against, and silently editing it would destroy the comparison. The correction lives here,
in the test suite, and in the derived universe model `ra residual` computes against.

### On deviation 1

This is the substantive one. Padding to the maximum rather than the smallest supported
key size means the wrong key for every multi-key-size primitive — Twofish, Serpent,
Loki97, Saferplus, Rijndael-256. A sweep built on the reference tool would have used
the wrong key throughout and reported the space as covered. That is precisely the
silent-void failure the coverage papers warn about, sitting inside the reference
implementation.

All four policies are retained as an enumerable coverage dimension, because
"confirmed for Twofish and Serpent" is not "confirmed for every primitive", and a
claim should be able to state which policy it swept.

Loki97 turns out to be the exception that proves the point from the other side: its
libmcrypt key schedule is the 256-bit one for *every* key size and reads a buffer
`internal_init_mcrypt` allocated with `mxcalloc(1, 32)`, so the two null-padding
policies collapse onto the same 32-byte zero-extended key. rev5's Loki97 layer
therefore cannot discriminate between them — the dimension is real but degenerate
here, and a claim that cited rev5 as evidence for null-pad-next-supported *in
general* would be over-reading it. The two repeat-padding policies still differ.
See `crates/ra-prim/src/loki97.rs`.

### RC2's effective key bits: the same trap one level down

RC2 has a second key parameter beside length — RFC 2268's effective key bits `T1`,
which Phase 2 of the key schedule uses to collapse the expanded 128-byte key buffer
back to `T1` bits. libmcrypt's `modules/algorithms/rc2.c` has that phase *stripped*
(its own comment: the parameter "looks like an export control hack. For normal use, it
should always be set to 1024"), so mcrypt behaves as `T1 = 1024` for every key length.

Defaults disagree: RustCrypto's `Rc2::new_from_slice` picks `8 * key_len`, OpenSSL
picks 128, PyCryptodome's `ARC2` picks 1024. The three coincide **only** at a full
128-byte key — which is precisely the length libmcrypt's own self-test vector uses, so
the vector one would naturally reach for cannot detect the difference. This engine
originally built RC2 through `new_from_slice`, got `T1 = 56` for the 7-byte passphrase,
and rev5 was recorded as an unexplained gap for it.

rev5 settles it: its third recorded step is `hex_to_base64`, so the first layer must
emit hex, and exactly one `T1` in `{8, 16, …, 1024}` does — 1024, over 1650 of 1650
characters. PyCryptodome's `ARC2` at its own default agrees byte for byte, which is an
independent implementation rather than a second reading of the same code.

The value is a compiled-in constant, not a swept dimension: it is a property of mcrypt,
not a choice the 2016 author made, and `ra_prim::rc2` records why.

## Corpus caveats worth knowing before writing a conformance check

- **Recorded plaintexts are transcriptions, not bytes.** rev12's is 207 UTF-8 bytes
  against a 211-byte ciphertext: three leading newlines trimmed, one byte rendered as
  a multi-byte en-dash. Compare on normalised substrings, never exact equality.
- **A recorded `rot` shift is the encryption shift.** Decryption applies the inverse:
  rev12's documented "shift 6" is a ROT-20 outbound.
- **Recorded chains omit an implicit `b64decode`.** The tools4noobs decrypt box
  base64-decodes its input, so between "reverse" and the next decrypt there is a
  base64 decode that no recorded chain mentions. rev9 does not reproduce without it.
- **rev6's recorded substitution alphabet is slightly defective.** Applying it yields
  "your cone live" where the record says "your gone life" — a handful of letters out
  of 127. The Serpent layer beneath it is unambiguous.
- **rev8's "insert" repair step is counted in hex bigrams, not bytes.** "Insert
  missing '63' between the 131st and 132nd bigram" means a hex-digit pair in the
  raw hex display text, ignoring the space separators the corpus's own
  transcription uses — see `insert`'s `unit=hexpair` mode.

## Known gaps

- **Loki97 is implemented and proven**, via rev5, as a port of libmcrypt's own
  `loki97.c`. Its S-boxes are generated by cubing in GF(2^13)/GF(2^11) rather than
  transcribed. Recovering rev5's plaintext also retroactively upgrades rev5's RC2 and
  Blowfish vectors from shape-based to plaintext-backed, since a wrong RC2 or Blowfish
  layer cannot terminate in correct prose.
  One property of that C is worth knowing before citing rev5 as evidence for anything
  else: its key schedule is the 256-bit one for *every* key size and reads a zeroed
  32-byte buffer, so this vector **cannot** discriminate between null-pad-next-supported
  and null-pad-max — both derive the same key. rev9's Twofish layer remains the only
  vector that settles the key-derivation policy.
- **Rijndael-256 is implemented and proven**, via rev1 — the one primitive no AES
  implementation can provide, since AES standardised only the 128-bit block. rev1's
  chain opens with a classical Beaufort layer (key `ZOMBIES`, the 52-character
  mixed-case alphabet), which needed the `beaufort` node (`crates/ra-core/src/nodes.rs`,
  family `Xf`, reciprocal). Two corrections to the recorded chain: it omits *two*
  implicit base64 decodes rather than the usual one, since the tools4noobs decrypt
  box base64-decodes its input on both the RC2 and the Rijndael-256 hop; and the
  Beaufort key phase must skip characters outside the alphabet rather than
  advancing over them, or the layer does not invert. The final layer receives exactly
  one 32-byte block, which is itself corroboration of the wide block: under AES's
  128-bit block that would be two independently-decrypted ECB blocks.
- **Saferplus is implemented and proven**, as a direct port of libmcrypt's own
  `saferplus.c` (the reference behaviour the ciphertexts were produced against — the
  textbook SAFER K-64/SK-128 description alone does not reproduce it). It is checked
  against libmcrypt's compiled-in self-test vector and reproduces rev10 end to end.
  See `crates/ra-prim/src/saferplus.rs` for the structural notes an auditor comparing
  it against the C source will want: word-order reversal on both block and key, and
  tables derived rather than transcribed.
- **Loki97 is implemented and proven, via rev5** — the last entry to leave
  `Declared`. Also a direct port of libmcrypt's own `loki97.c`, checked against that
  file's compiled-in self-test vector and reproducing rev5's recorded plaintext
  ("August, 1946. OSS report final T-7…") through all five recorded layers. Its
  arrival retroactively upgrades rev5's RC2 and Blowfish vectors from shape-based to
  plaintext-backed: those two layers are now pinned by a chain that terminates in
  known text rather than only by the shape of an intermediate. The 8192- and
  2048-entry S-boxes are generated by cubing in GF(2^13)/GF(2^11) rather than
  transcribed. Structural quirks worth knowing are in
  `crates/ra-prim/src/loki97.rs`: word-order reversal on load, reversal *plus* the
  Feistel half-swap on store, a pairwise-swapped key load, and the 256-bit-only key
  schedule discussed above.
- **Blowfish-compat is proven, via rev8.** The corpus's note — "insert missing '63'
  between the 131st and 132nd bigram" — is exact once counted as a hex-digit pair
  rather than a raw byte offset; see the `insert` node (`unit=hexpair`). Two caveats
  recorded at the vector itself: the check does not pin `pos` (the insert lands near
  the end of the *reversed* stream, so neighbouring positions leave the checked
  prefix equally clean), and rev8's ciphertext carries a second, undocumented
  transcription defect showing the CFB-8 single-byte corruption signature.
- **TG4's transcription dimension is 128 readings, not 16**, and that is now an enumerated
  axis rather than a fixed assumption. All three tiers are swept **exhaustively over every
  admissible reading** — 473,088, 946,176 and 20,982,398,976 candidates. T1 and T2 return
  zero hits against a false-positive budget of `~1e-11` over a 112-to-144-byte scored
  region, so those skeletons are genuinely empty for every transcription; T3's passes are
  matcher artifacts over short inter-layer decodes, below the chance expectation and a few
  bytes long. Nothing here is bounded and nothing is dropped. What remains uncovered on
  TG4 is not the transcription any more: it is the skeletons the model does not contain —
  in particular any pipeline with a step *before* the first decryption, and any second
  inter-layer codec (`codec ∘ xf ∘ codec`, which rev9 shows). The 7 open `I`/`l` calls
  remain the cheapest available reduction of the whole space: resolving them is worth a
  factor of 128 for zero compute.
- **REV7's recorded ciphertext is 8 hex characters short**, and the repair space over it
  is a **rigorous negative**. The transcription is on a 14x5 grid; line 0's first group
  holds 2 characters and line 11 holds 13 groups, so the true stream is 220 groups =
  1100 characters = **550 bytes, not the 546 the corpus records**. Parity confirms it
  (only the joint repair yields a whole number of bytes) and so, independently, does the
  final line's width, which refutes the alternative reading that the leading `83` is a
  right-aligned remainder. Searching that repair space jointly with the single-layer
  cipher axes found **nothing**: 45.4M candidates, 0 hits, best score 0.474 against a
  0.371 random baseline and a real layer's 0.985. The negative extends beyond the space
  enumerated, because REV7's first group can only perturb the first three bytes of the
  stream and every mcrypt mode confines the damage to at most 64 of 384 scored bytes.
  Full statement of what is and is not eliminated in `notes/rev7-repair-search.md`; the
  largest uncovered region is any skeleton with a step *before* the first decryption,
  which rev1 and rev8 both have.
- **No distributed ledger.** `ra-toolreg` and `ra-merkle` provide the primitives
  (claims, selective invalidation, commitments, audit paths, detection probabilities);
  the coordinator, HTTP API and worker trust model from Document 6 are not built.
