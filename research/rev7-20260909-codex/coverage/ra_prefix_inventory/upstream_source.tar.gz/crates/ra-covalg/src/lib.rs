//! Coverage algebra: what was tried, stated so that what *remains* is computable.
//!
//! # Why not just count
//!
//! "We tried 3.2e8 candidates" is not falsifiable and does not compose. Two teams
//! each reporting 3.2e8 may have tried the same 3.2e8. Set notation makes the
//! overlap explicit and makes the residual computable.
//!
//! # Representation
//!
//! A pipeline is an ordered composition of layers. The space of all pipelines
//! partitions by **skeleton** — the ordered tuple of layer families, ignoring
//! parameter values. Within one skeleton the space is a plain Cartesian product of
//! per-slot parameter domains. So
//!
//! ```text
//! Space = disjoint-union over skeletons of (product of domains)
//! ```
//!
//! A claim is therefore a map from skeleton to a union of sub-products (a "cover").
//! Union-of-products is closed under union (concatenate) and under difference
//! (orthogonal decomposition, see [`Product::difference`]), which is what makes
//!
//! ```text
//! RESIDUAL = UNIVERSE \ (claim_1 u claim_2 u ... u claim_n)
//! ```
//!
//! **exact rather than estimated**.

use std::collections::{BTreeMap, BTreeSet};

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

/// A dimension key: `"<slot_index>.<param>"`, e.g. `"1.prim"`.
pub type Dim = String;

/// One hyperrectangle within a fixed skeleton: each dimension independently
/// enumerated.
#[derive(Clone, PartialEq, Eq, PartialOrd, Ord, Debug, Default, Serialize, Deserialize)]
#[serde(transparent)]
pub struct Product {
    pub dims: BTreeMap<Dim, BTreeSet<String>>,
}

impl Product {
    pub fn new<K, V, I, J>(dims: I) -> Self
    where
        I: IntoIterator<Item = (K, J)>,
        J: IntoIterator<Item = V>,
        K: Into<Dim>,
        V: Into<String>,
    {
        let dims: BTreeMap<Dim, BTreeSet<String>> = dims
            .into_iter()
            .map(|(k, vs)| (k.into(), vs.into_iter().map(Into::into).collect()))
            .collect();
        // canonical empty: if any dimension is empty the product is empty, and all
        // such products must compare equal so that digests agree
        if dims.values().any(|v| v.is_empty()) {
            return Product {
                dims: dims.into_keys().map(|k| (k, BTreeSet::new())).collect(),
            };
        }
        Product { dims }
    }

    pub fn is_empty(&self) -> bool {
        self.dims.is_empty() || self.dims.values().any(|v| v.is_empty())
    }

    pub fn size(&self) -> u128 {
        if self.is_empty() {
            return 0;
        }
        self.dims.values().map(|v| v.len() as u128).product()
    }

    pub fn keys(&self) -> Vec<&Dim> {
        self.dims.keys().collect()
    }

    fn same_shape(&self, other: &Product) -> bool {
        self.dims.len() == other.dims.len() && self.dims.keys().eq(other.dims.keys())
    }

    pub fn intersect(&self, other: &Product) -> Product {
        debug_assert!(self.same_shape(other), "skeleton/dimension mismatch");
        Product::new(self.dims.iter().map(|(k, v)| {
            let empty = BTreeSet::new();
            let o = other.dims.get(k).unwrap_or(&empty);
            (k.clone(), v.intersection(o).cloned().collect::<Vec<_>>())
        }))
    }

    pub fn contains(&self, point: &BTreeMap<Dim, String>) -> bool {
        self.dims
            .iter()
            .all(|(k, v)| point.get(k).is_some_and(|p| v.contains(p)))
    }

    /// `self \ other`, as a **disjoint** union of at most `|dims|` products.
    ///
    /// ```text
    /// A \ B = U_d [ (A_1^B_1) x .. x (A_{d-1}^B_{d-1}) x (A_d \ B_d) x A_{d+1} x .. x A_n ]
    /// ```
    ///
    /// where `^` is intersection. Each term fixes the first `d-1` dimensions to the
    /// overlap and carves the `d`-th, so the terms are pairwise disjoint by
    /// construction. Disjointness is what makes summing their sizes exact.
    pub fn difference(&self, other: &Product) -> Vec<Product> {
        if self.is_empty() {
            return vec![];
        }
        if self.intersect(other).is_empty() {
            return vec![self.clone()]; // no overlap, nothing removed
        }
        let keys: Vec<Dim> = self.dims.keys().cloned().collect();
        let empty = BTreeSet::new();
        let mut out = Vec::new();
        for (d, kd) in keys.iter().enumerate() {
            let ob = other.dims.get(kd).unwrap_or(&empty);
            let carved: BTreeSet<String> = self.dims[kd].difference(ob).cloned().collect();
            if carved.is_empty() {
                continue;
            }
            let mut nd: BTreeMap<Dim, BTreeSet<String>> = BTreeMap::new();
            for (i, k) in keys.iter().enumerate() {
                let mine = &self.dims[k];
                let theirs = other.dims.get(k).unwrap_or(&empty);
                let set = match i.cmp(&d) {
                    std::cmp::Ordering::Less => mine.intersection(theirs).cloned().collect(),
                    std::cmp::Ordering::Equal => carved.clone(),
                    std::cmp::Ordering::Greater => mine.clone(),
                };
                nd.insert(k.clone(), set);
            }
            let p = Product { dims: nd };
            if !p.is_empty() {
                out.push(p);
            }
        }
        out
    }

    /// Human-readable set notation, abbreviating large domains.
    pub fn notation(&self) -> String {
        self.dims
            .iter()
            .map(|(k, v)| {
                let vals: Vec<&str> = v.iter().map(String::as_str).collect();
                let inner = if vals.len() <= 4 {
                    format!("{{{}}}", vals.join(","))
                } else {
                    format!("{{{},...|{}|}}", vals[..3].join(","), vals.len())
                };
                format!("{k}\u{2208}{inner}")
            })
            .collect::<Vec<_>>()
            .join(" \u{00d7} ")
    }
}

/// A union of products within **one** skeleton.
#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub struct Cover {
    pub skeleton: Vec<String>,
    pub products: Vec<Product>,
}

impl Cover {
    pub fn new<S: Into<String>>(skeleton: Vec<S>, products: Vec<Product>) -> Self {
        Self {
            skeleton: skeleton.into_iter().map(Into::into).collect(),
            products: products.into_iter().filter(|p| !p.is_empty()).collect(),
        }
    }

    /// Sum of product sizes. Equals the exact size only if the products are
    /// disjoint, so it is an upper bound in general.
    pub fn size_upper(&self) -> u128 {
        self.products.iter().map(Product::size).sum()
    }

    /// Exact size, via successive disjointification. Cost grows with overlap.
    pub fn size_exact(&self) -> u128 {
        let mut disjoint: Vec<Product> = Vec::new();
        for p in &self.products {
            let mut pieces = vec![p.clone()];
            for d in &disjoint {
                let mut next = Vec::new();
                for piece in &pieces {
                    next.extend(piece.difference(d));
                }
                pieces = next;
                if pieces.is_empty() {
                    break;
                }
            }
            disjoint.extend(pieces);
        }
        disjoint.iter().map(Product::size).sum()
    }

    pub fn union(&self, other: &Cover) -> Cover {
        assert_eq!(self.skeleton, other.skeleton, "skeleton mismatch in union");
        let mut products = self.products.clone();
        products.extend(other.products.clone());
        Cover {
            skeleton: self.skeleton.clone(),
            products,
        }
    }

    pub fn difference(&self, other: &Cover) -> Cover {
        assert_eq!(
            self.skeleton, other.skeleton,
            "skeleton mismatch in difference"
        );
        let mut cur = self.products.clone();
        for b in &other.products {
            let mut next = Vec::new();
            for a in &cur {
                next.extend(a.difference(b));
            }
            cur = next;
            if cur.is_empty() {
                break;
            }
        }
        Cover {
            skeleton: self.skeleton.clone(),
            products: cur,
        }
    }

    pub fn notation(&self) -> String {
        let sk = self.skeleton.join(" \u{2218} ");
        if self.products.is_empty() {
            return format!("\u{2205}  [skeleton {sk}]");
        }
        let body = self
            .products
            .iter()
            .map(Product::notation)
            .collect::<Vec<_>>()
            .join("\n      \u{222a} ");
        format!("\u{27e8}{sk}\u{27e9} :  {body}")
    }
}

/// A full claim: skeleton -> cover.
#[derive(Clone, PartialEq, Eq, Debug, Default, Serialize, Deserialize)]
#[serde(transparent)]
pub struct CoverageSet {
    pub covers: BTreeMap<Vec<String>, Cover>,
}

impl CoverageSet {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn add(&mut self, cover: Cover) -> &mut Self {
        self.covers
            .entry(cover.skeleton.clone())
            .and_modify(|c| *c = c.union(&cover))
            .or_insert(cover);
        self
    }

    pub fn size_exact(&self) -> u128 {
        self.covers.values().map(Cover::size_exact).sum()
    }

    pub fn union(&self, other: &CoverageSet) -> CoverageSet {
        let mut out = self.clone();
        for cover in other.covers.values() {
            out.add(cover.clone());
        }
        out
    }

    pub fn difference(&self, other: &CoverageSet) -> CoverageSet {
        let mut out = CoverageSet::new();
        for (sk, cov) in &self.covers {
            match other.covers.get(sk) {
                Some(o) => {
                    let d = cov.difference(o);
                    if !d.products.is_empty() {
                        out.covers.insert(sk.clone(), d);
                    }
                }
                None => {
                    out.covers.insert(sk.clone(), cov.clone());
                }
            }
        }
        out
    }

    pub fn notation(&self) -> String {
        self.covers
            .values()
            .map(Cover::notation)
            .collect::<Vec<_>>()
            .join("\n\n")
    }

    /// Canonical, order-independent JSON view. Content addressing depends on this
    /// being stable, which is why every collection here is a `BTree*`.
    pub fn to_json(&self) -> serde_json::Value {
        serde_json::json!({
            "skeletons": self.covers.iter().map(|(sk, cov)| serde_json::json!({
                "skeleton": sk,
                "products": cov.products,
                "size_exact": cov.size_exact().to_string(),
            })).collect::<Vec<_>>(),
            "size_exact_total": self.size_exact().to_string(),
        })
    }

    /// Content hash. Equal coverage yields an equal digest, so duplicate work is
    /// detectable across teams without re-running anything.
    pub fn digest(&self) -> String {
        let canon = serde_json::to_string(&self.to_json()).unwrap_or_default();
        format!("sha256:{}", hex::encode(Sha256::digest(canon.as_bytes())))
    }
}

/// Convenience: `product!{"1.prim" => ["DES","RC2"], "1.mode" => ["cfb"]}`
#[macro_export]
macro_rules! product {
    ($($k:expr => $v:expr),+ $(,)?) => {
        $crate::Product::new(vec![ $( ($k, $v.iter().map(|s| s.to_string()).collect::<Vec<_>>()) ),+ ])
    };
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pt(pairs: &[(&str, &str)]) -> BTreeMap<Dim, String> {
        pairs
            .iter()
            .map(|(k, v)| (k.to_string(), v.to_string()))
            .collect()
    }

    /// The Python reference self-test: 6 - 1 = 5, and the pieces are disjoint.
    #[test]
    fn difference_is_exact_and_disjoint() {
        let a = product! {"a" => ["1","2","3"], "b" => ["x","y"]};
        let b = product! {"a" => ["2"], "b" => ["x"]};
        assert_eq!(a.size(), 6);
        assert_eq!(b.size(), 1);

        let diff = a.difference(&b);
        assert_eq!(diff.iter().map(Product::size).sum::<u128>(), 5);

        // verify pointwise: every original point except (2,x), each covered once
        let mut seen: BTreeSet<(String, String)> = BTreeSet::new();
        for p in &diff {
            for i in &p.dims["a"] {
                for j in &p.dims["b"] {
                    assert!(
                        seen.insert((i.clone(), j.clone())),
                        "products overlap at ({i},{j})"
                    );
                }
            }
        }
        let expected: BTreeSet<(String, String)> = ["1", "2", "3"]
            .iter()
            .flat_map(|i| ["x", "y"].iter().map(move |j| (i.to_string(), j.to_string())))
            .filter(|p| p != &("2".to_string(), "x".to_string()))
            .collect();
        assert_eq!(seen, expected);
    }

    #[test]
    fn difference_with_no_overlap_returns_self() {
        let a = product! {"a" => ["1","2"], "b" => ["x"]};
        let b = product! {"a" => ["9"], "b" => ["z"]};
        assert_eq!(a.difference(&b), vec![a.clone()]);
    }

    #[test]
    fn self_difference_is_empty() {
        let a = product! {"a" => ["1","2","3"], "b" => ["x","y"]};
        assert!(a.difference(&a).is_empty());
    }

    /// Overlapping claims must not be double counted. This is the failure mode that
    /// pure counting cannot even detect.
    #[test]
    fn overlapping_claims_are_deduplicated_exactly() {
        let sk = vec!["b64d", "dec"];
        let c1 = Cover::new(
            sk.clone(),
            vec![product! {"1.prim" => ["DES","RC2","RC4"], "1.mode" => ["cfb"]}],
        );
        let c2 = Cover::new(
            sk.clone(),
            vec![product! {"1.prim" => ["RC2","RC4","Twofish"], "1.mode" => ["cfb"]}],
        );
        let u = c1.union(&c2);
        assert_eq!(u.size_upper(), 6, "naive sum double counts RC2 and RC4");
        assert_eq!(u.size_exact(), 4, "exact union is DES,RC2,RC4,Twofish");
    }

    #[test]
    fn residual_is_universe_minus_claims() {
        let sk: Vec<String> = vec!["b64d".to_string(), "dec".to_string()];
        let mut universe = CoverageSet::new();
        universe.add(Cover::new(
            sk.clone(),
            vec![product! {
                "1.prim" => ["DES","RC2","RC4","Blowfish","Twofish","Serpent"],
                "1.mode" => ["cfb","ecb"],
                "1.iv"   => ["ascii0","null"],
            }],
        ));
        assert_eq!(universe.size_exact(), 6 * 2 * 2);

        let mut claim = CoverageSet::new();
        claim.add(Cover::new(
            sk.clone(),
            vec![product! {
                "1.prim" => ["DES","RC2"],
                "1.mode" => ["cfb"],
                "1.iv"   => ["ascii0"],
            }],
        ));
        assert_eq!(claim.size_exact(), 2);

        let residual = universe.difference(&claim);
        assert_eq!(residual.size_exact(), 24 - 2);

        // and the residual really excludes the claimed points
        let claimed_point = pt(&[("1.prim", "DES"), ("1.mode", "cfb"), ("1.iv", "ascii0")]);
        let still_open = pt(&[("1.prim", "DES"), ("1.mode", "ecb"), ("1.iv", "ascii0")]);
        let r = &residual.covers[&sk];
        assert!(!r.products.iter().any(|p| p.contains(&claimed_point)));
        assert!(r.products.iter().any(|p| p.contains(&still_open)));
    }

    /// Claims in different skeletons never interact: a single-layer sweep says
    /// nothing about a two-layer pipeline.
    #[test]
    fn skeletons_are_independent() {
        let mut universe = CoverageSet::new();
        universe.add(Cover::new(
            vec!["b64d", "dec"],
            vec![product! {"1.prim" => ["DES","RC2"]}],
        ));
        universe.add(Cover::new(
            vec!["b64d", "xf", "dec"],
            vec![product! {"2.prim" => ["DES","RC2"]}],
        ));
        assert_eq!(universe.size_exact(), 4);

        let mut claim = CoverageSet::new();
        claim.add(Cover::new(
            vec!["b64d", "dec"],
            vec![product! {"1.prim" => ["DES","RC2"]}],
        ));

        let residual = universe.difference(&claim);
        assert_eq!(residual.size_exact(), 2, "the two-layer skeleton is untouched");
        assert_eq!(residual.covers.len(), 1);
    }

    #[test]
    fn digest_is_order_independent_and_content_addressed() {
        let sk = vec!["b64d", "dec"];
        let mut a = CoverageSet::new();
        a.add(Cover::new(
            sk.clone(),
            vec![product! {"1.prim" => ["RC2","DES"], "1.mode" => ["ecb","cfb"]}],
        ));
        let mut b = CoverageSet::new();
        b.add(Cover::new(
            sk.clone(),
            vec![product! {"1.prim" => ["DES","RC2"], "1.mode" => ["cfb","ecb"]}],
        ));
        assert_eq!(a.digest(), b.digest(), "equal coverage must hash equally");

        let mut c = CoverageSet::new();
        c.add(Cover::new(
            sk,
            vec![product! {"1.prim" => ["DES"], "1.mode" => ["cfb"]}],
        ));
        assert_ne!(a.digest(), c.digest());
    }

    #[test]
    fn empty_dimension_makes_the_product_empty() {
        let p = product! {"a" => ["1","2"], "b" => Vec::<String>::new()};
        assert!(p.is_empty());
        assert_eq!(p.size(), 0);
    }

    /// Sizes exceed u64 for realistic multi-layer universes, hence u128.
    #[test]
    fn large_universes_do_not_overflow() {
        let p = product! {
            "0.variant" => (1..=16).map(|i| format!("v{i:02}")).collect::<Vec<_>>(),
            "1.key"     => ["TheGiant","Zombies","ZOMBIES","thegiant","TheGiant_b64","zombies"],
            "1.kd"      => ["nullpad","repeatpad"],
            "1.prim"    => (0..19).map(|i| format!("p{i}")).collect::<Vec<_>>(),
            "1.mode"    => ["ecb","cbc","cfb","ofb","nofb","ncfb","stream"],
            "1.iv"      => ["ascii0","null","other"],
        };
        assert_eq!(p.size(), 16 * 6 * 2 * 19 * 7 * 3);
    }
}
