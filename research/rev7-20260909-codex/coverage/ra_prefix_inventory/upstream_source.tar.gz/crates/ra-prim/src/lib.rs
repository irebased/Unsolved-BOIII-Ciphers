//! mcrypt-faithful primitives and mode engine, exposed as `ra-core` plugins.
//!
//! # What is confirmed, and how
//!
//! - **`cfb` means CFB-8.** mcrypt's `cfb` is 8-bit feedback; modern libraries use
//!   that name for full-block feedback, which mcrypt spells `ncfb`. Confirmed
//!   against rev9, whose first layer is DES/`cfb` over its base64 ciphertext and
//!   must yield whitespace-separated decimal groups because the next documented
//!   step is a decimal decode. CFB-8 produces exactly that; nCFB, OFB, CBC and ECB
//!   produce noise.
//! - **The IV is ASCII `'0'` x16, not a null IV.** The two differ in the first block
//!   and nowhere else, which is itself the confirmation: substituting a null IV
//!   corrupts exactly `block_size` bytes and the stream then recovers byte for byte.
//! - **DES pins the mode with minimal confounding.** DES has one key size, which
//!   collapses the two null-padding policies onto each other, leaving the mode as
//!   effectively the only free variable. Note that repeat-padding still differs even
//!   at a fixed key size (`Zombies\0` versus `ZombiesZ`), so a fixed key size
//!   narrows the derivation question to two candidates rather than eliminating it.
//!
//! - **XTEA reproduces rev12 end to end**, against known plaintext. This is the
//!   strongest single result available from the corpus: one vector simultaneously
//!   pins the round function, CFB-8, the ASCII-zero IV, and
//!   [`KeyDerivation::NullPadMax`] as the authentic key-derivation policy. See the
//!   [`xtea`] module docs.
//! - **SAFER+ reproduces rev10 end to end**, against known plaintext, at
//!   [`KeyDerivation::NullPadNextSupported`] (16 bytes). See the [`saferplus`]
//!   module docs.
//! - **LOKI97 reproduces rev5 end to end**, against known plaintext, which also
//!   turns rev5's RC2 and Blowfish checks from shape-based into plaintext-backed:
//!   a wrong effective-key-bits value or a wrong Blowfish word order cannot
//!   terminate in 615 bytes of the recorded OSS report. Like SAFER+ it is a port
//!   of libmcrypt's own C rather than a reading of the paper. See the [`loki97`]
//!   module docs.
//!
//! - **RC2's effective key bits are 1024, not `8 * key_len`.** mcrypt ships RFC
//!   2268's Phase 2 key-size reduction *stripped out*, so the parameter is fixed
//!   regardless of key length. Confirmed against rev5, whose third documented step is
//!   `hex_to_base64` and therefore demands a hex first layer: exactly one value in
//!   `{8, 16, …, 1024}` delivers it. This was the whole reason RC2 did not reproduce.
//!   See the [`rc2`] module docs.
//!
//! # What is not confirmed
//!
//! - **Key derivation** for algorithms with *several* supported key sizes.
//!   Null-pad-max is confirmed for XTEA, whose only supported size is 16, so
//!   null-pad-max and null-pad-next-supported coincide there. Twofish, Serpent,
//!   Loki97, Saferplus and Rijndael-256 accept 16/24/32, where the two policies
//!   diverge in general; SAFER+ is now pinned to null-pad-next-supported by rev10,
//!   joining Twofish. Hence [`KeyDerivation`] stays an enumerable coverage
//!   dimension for the primitives that remain unpinned.
//!
//!   **LOKI97 is a special case and cannot be pinned at all**: libmcrypt's key
//!   schedule is the 256-bit one for every key size and reads a zeroed 32-byte
//!   buffer, so both null-padding policies derive the same key. rev5's pass is
//!   therefore not evidence for either one. See the [`loki97`] module docs.
//!
//! # A corpus caveat that affects any conformance runner
//!
//! Recorded plaintexts are human transcriptions, not bytes. rev12's is 207 UTF-8
//! bytes against a 211-byte ciphertext: three leading newlines were trimmed and one
//! byte became a multi-byte en-dash. Conformance checks must compare on normalised
//! substrings, never exact equality, or the whole corpus reports false failures.
//! Relatedly, a recorded `rot` shift is the *encryption* shift; decryption applies
//! its inverse.

pub mod gf;
pub mod keyderiv;
pub mod loki97;
pub mod mode;
pub mod nodes;
pub mod prim;
pub mod rc2;
pub mod rc4;
pub mod rijndael;
pub mod saferplus;
pub mod salsa20;
pub mod xtea;

pub use keyderiv::KeyDerivation;
pub use mode::Mode;
pub use nodes::{link, CORPUS_IV};
pub use prim::{
    implemented, instantiate_block, instantiate_stream, prim_info, vector_proven, BlockPrim,
    ImplStatus, PrimError, PrimInfo, PrimKind, StreamPrim, PRIMS,
};
pub use rc2::MCRYPT_RC2_EFF_KEY_BITS;

/// Derive a key, build the primitive, and decrypt in one call.
pub fn decrypt(
    prim: &str,
    mode: Mode,
    key: &[u8],
    iv: &[u8],
    kd: KeyDerivation,
    data: &[u8],
) -> Result<Vec<u8>, PrimError> {
    let info = prim_info(prim).ok_or_else(|| PrimError::Unknown(prim.to_string()))?;
    let derived = kd.derive(key, info);
    match info.kind {
        PrimKind::Stream => {
            let p = instantiate_stream(prim, &derived, iv)?;
            let mut buf = data.to_vec();
            p.apply_keystream(&mut buf);
            Ok(buf)
        }
        PrimKind::Block => {
            let p = instantiate_block(prim, &derived)?;
            mode::decrypt(&*p, mode, data, iv).map_err(|source| PrimError::ModeInapplicable {
                prim: info.display_name,
                mode: mode.as_str(),
                source,
            })
        }
    }
}

/// The encrypting counterpart, used to build conformance fixtures.
pub fn encrypt(
    prim: &str,
    mode: Mode,
    key: &[u8],
    iv: &[u8],
    kd: KeyDerivation,
    data: &[u8],
) -> Result<Vec<u8>, PrimError> {
    let info = prim_info(prim).ok_or_else(|| PrimError::Unknown(prim.to_string()))?;
    let derived = kd.derive(key, info);
    match info.kind {
        PrimKind::Stream => {
            let p = instantiate_stream(prim, &derived, iv)?;
            let mut buf = data.to_vec();
            p.apply_keystream(&mut buf);
            Ok(buf)
        }
        PrimKind::Block => {
            let p = instantiate_block(prim, &derived)?;
            mode::encrypt(&*p, mode, data, iv).map_err(|source| PrimError::ModeInapplicable {
                prim: info.display_name,
                mode: mode.as_str(),
                source,
            })
        }
    }
}
