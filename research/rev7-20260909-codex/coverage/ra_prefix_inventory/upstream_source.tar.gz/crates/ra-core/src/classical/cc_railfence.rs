//! Crypto Corner's ("crypto.interactive-maths.com") Rail Fence Cipher tool.
//!
//! Source: the page's own JavaScript, fetched directly (task scratchpad
//! `pages/cc_rail_fence_js.txt`; the site has no vendored copy in this repo).
//! `railfenceEncrypt2`/`railfenceDecrypt2` are transliterated verbatim below.
//!
//! # The algorithm
//!
//! This is the *ordinary* zigzag rail fence, always starting at rail 0 going
//! down — there is no offset/starting-rail parameter like CrypTool's Rail
//! Fence tool (`cryptool_railfence.rs`); the only parameter is `key`, the
//! number of rails. This is a genuinely different, simpler tool from
//! CrypTool's, so it is a separate node rather than a `variant` of it, per the
//! task spec's instruction not to merge differing implementations.
//!
//! Encrypt fills a `key`-row grid in zigzag order (down to row `key-1`, back
//! up to row 0, repeat) and reads rows out top to bottom, concatenated.
//! Decrypt is the direct inverse: replay the same zigzag path to work out how
//! many ciphertext characters belong to each row, slice the ciphertext into
//! those rows in row order, then walk the zigzag path again reading one
//! character off the correct row at each step.
//!
//! # Case and alphabet
//!
//! The site always upper-cases for encryption internals and lower-cases the
//! decrypted result (`ctext.toUpperCase()` / `ptext.toLowerCase()`) — that is
//! reproduced here via the shared [`crate::classical::toolfmt`] `output_case`
//! default (`Lower`), matching the site's own default behaviour exactly. The
//! site also strips characters outside its selected alphabet before running
//! the cipher (`remove()`/`belongsTo()`); the default alphabet toggle is the
//! full 26-letter Latin alphabet.
//!
//! # Stripping is the page's input normalisation, not the cipher
//!
//! A rail fence is a permutation of *positions* — it does not need an
//! alphabet at all, only a length. The A-Z filtering above is a property of
//! this specific web page (it only ever expected letters), not of the
//! transposition itself, so it is reproduced by default (for site fidelity)
//! via [`crate::classical::toolfmt`]'s `strip_non_alphabet` param rather than
//! hardcoded — set `strip_non_alphabet=false` to run the same permutation
//! over any medium (e.g. hex ciphertext from an earlier layer), verified in
//! `cc_railfence_preserves_hex_medium_when_stripping_disabled` below.
//!
//! # Engine direction
//!
//! Decrypt-direction: [`CcRailfence::apply`] runs [`decrypt`]. [`encrypt`] is
//! reproduced test-only (`#[cfg(test)]`), to prove the round trip.

use crate::classical::toolfmt::{read_output_fmt, CaseFold, InputNorm, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

const CC_RAILFENCE_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(ParamSpec::req(
    "key",
    ParamType::Int,
    "number of rails, minimum 2 (the site's default is 3)"
),);

/// `railfenceDecrypt2`, transliterated from `pages/cc_rail_fence_js.txt`.
/// Operates on already-uppercased characters; case handling lives in the
/// node's `apply`/[`crate::classical::toolfmt`] layer, matching the site's
/// own `cipher.toUpperCase()` / `.toLowerCase()` bracketing.
#[allow(clippy::needless_range_loop)] // faithful index-walk transliteration of the site's JS
pub fn decrypt(ctext: &[char], key: usize) -> Result<Vec<char>> {
    if key < 2 {
        return Err(Error::bad_param("cc_railfence", "key", "must be at least 2"));
    }
    let n = ctext.len();
    let mut main_array: Vec<Vec<Option<char>>> = vec![vec![None; n]; key];

    let mut q = 0usize;
    for t in 0..key {
        let mut j = 0i64;
        let mut r = 0;
        for i in 0..n {
            if j as usize == t {
                main_array[j as usize][i] = Some(ctext[q]);
                q += 1;
            }
            if r == 0 {
                j += 1;
            } else {
                j -= 1;
            }
            if j as usize == key - 1 {
                r = 1;
            } else if j == 0 {
                r = 0;
            }
        }
    }

    let mut j = 0i64;
    let mut r = 0;
    let mut out = Vec::with_capacity(n);
    for i in 0..n {
        if let Some(c) = main_array[j as usize][i] {
            out.push(c);
        }
        if r == 0 {
            j += 1;
        } else {
            j -= 1;
        }
        if j as usize == key - 1 {
            r = 1;
        } else if j == 0 {
            r = 0;
        }
    }
    Ok(out)
}

/// `railfenceEncrypt2`, transliterated the same way. Test-only.
#[cfg(test)]
fn encrypt(ptext: &[char], key: usize) -> Vec<char> {
    let n = ptext.len();
    let mut main_array: Vec<Vec<char>> = vec![Vec::new(); key];
    let mut j = 0i64;
    let mut r = 0;
    for &c in ptext.iter().take(n) {
        main_array[j as usize].push(c);
        if r == 0 {
            j += 1;
        } else {
            j -= 1;
        }
        if j as usize == key - 1 {
            r = 1;
        } else if j == 0 {
            r = 0;
        }
    }
    main_array.concat()
}

/// Crypto Corner's Rail Fence Cipher tool, decrypting.
pub struct CcRailfence;

impl Node for CcRailfence {
    fn name(&self) -> &'static str {
        "cc_railfence"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CC_RAILFENCE_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = params.req_i64("cc_railfence", "key")?;
        if key < 2 {
            return Err(Error::bad_param("cc_railfence", "key", "must be at least 2"));
        }

        // Site default alphabet: A-Z only, upper-cased before decrypting.
        let in_norm = crate::classical::toolfmt::read_input_norm(
            "cc_railfence",
            params,
            InputNorm {
                case: CaseFold::Upper,
                strip_outside_alphabet: Some("ABCDEFGHIJKLMNOPQRSTUVWXYZ".to_string()),
                ..InputNorm::default()
            },
        )?;
        let normalized = in_norm.apply(&input.data);
        let text = String::from_utf8(normalized)
            .map_err(|_| Error::node_failed("cc_railfence", "input is not valid UTF-8"))?;
        let chars: Vec<char> = text.chars().collect();

        let plain = decrypt(&chars, key as usize)?;
        let plain: String = plain.into_iter().collect();

        // Site writes into an <input>/<textarea> via .value = with the
        // decrypted text already lower-cased by the algorithm itself.
        let out_fmt: OutputFmt = read_output_fmt(
            "cc_railfence",
            params,
            OutputFmt {
                case: CaseFold::Lower,
                grouping: None,
                trailing: Trailing::None,
            },
        )?;
        let out = out_fmt.apply(plain.as_bytes());
        Ok(Repr::new(out, input.display))
    }
}

register_node!(CC_RAILFENCE => || Box::new(CcRailfence));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    fn chars(s: &str) -> Vec<char> {
        s.chars().collect()
    }

    /// Ground truth: direct Python transliteration of the fetched JS (task
    /// scratchpad `cc_oracle.py`), run and cross-checked here.
    #[test]
    fn cc_railfence_hand_and_oracle_vector() {
        let ct = encrypt(&chars("HELLOWORLD"), 3);
        assert_eq!(ct.iter().collect::<String>(), "HOLELWRDLO");
        let pt = decrypt(&ct, 3).unwrap();
        assert_eq!(pt.iter().collect::<String>(), "HELLOWORLD");
    }

    #[test]
    fn cc_railfence_round_trips_varied_keys_and_lengths() {
        let samples = ["A", "AB", "ATTACKATDAWN", "THEQUICKBROWNFOXJUMPSOVERTHELAZYDOG"];
        for s in samples {
            for key in 2usize..=7 {
                let pt = chars(s);
                let ct = encrypt(&pt, key);
                let back = decrypt(&ct, key).unwrap();
                assert_eq!(back, pt, "s={s:?} key={key}");
            }
        }
    }

    #[test]
    fn cc_railfence_node_decrypts_lowercasing_output() {
        let ct = encrypt(&chars("HELLOWORLD"), 3);
        let n = registry().get("cc_railfence").unwrap();
        let p = params! {"key" => 3i64};
        let out = n
            .apply(&Repr::bytes(ct.into_iter().collect::<String>().into_bytes()), &p)
            .unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "helloworld");
    }

    #[test]
    fn cc_railfence_node_strips_non_alphabet_and_upcases_input() {
        // lowercase input with punctuation and digits, matching the site's
        // remove()/belongsTo() filtering before the algorithm runs.
        let ct_clean = encrypt(&chars("HELLOWORLD"), 3);
        let ct_dirty: String = "he1ll-o,wo!rld"
            .chars()
            .collect::<String>()
            .to_uppercase();
        // Filtering "HE1LL-O,WO!RLD" to A-Z gives "HELLOWORLD" before encrypt,
        // so encrypting the dirty text through the site's own pipeline
        // (upcase + filter, THEN cipher) must equal ct_clean.
        let filtered: String = ct_dirty.chars().filter(|c| c.is_ascii_alphabetic()).collect();
        assert_eq!(filtered, "HELLOWORLD");

        let n = registry().get("cc_railfence").unwrap();
        let p = params! {"key" => 3i64};
        let out = n
            .apply(&Repr::bytes(ct_clean.into_iter().collect::<String>().into_bytes()), &p)
            .unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "helloworld");
    }

    #[test]
    fn cc_railfence_rejects_key_below_two() {
        let n = registry().get("cc_railfence").unwrap();
        let p = params! {"key" => 1i64};
        assert!(n.apply(&Repr::bytes(b"X".to_vec()), &p).is_err());
    }

    #[test]
    fn cc_railfence_preserves_display() {
        let ct = encrypt(&chars("HELLOWORLD"), 3);
        let n = registry().get("cc_railfence").unwrap();
        let p = params! {"key" => 3i64};
        let out = n
            .apply(
                &Repr::new(ct.into_iter().collect::<String>().into_bytes(), Display::Hex),
                &p,
            )
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    /// The payoff: with `strip_non_alphabet` explicitly disabled, this
    /// transposition operates on any medium, not just A-Z text -- proven here
    /// against a 1092-character hex string, the length of rev7's ciphertext.
    /// A transposition is a permutation of positions; it needs no alphabet at
    /// all, and the site's A-Z filtering is the *tool's* input normalisation
    /// (reproduced by default for site fidelity), not part of the cipher.
    #[test]
    fn cc_railfence_preserves_hex_medium_when_stripping_disabled() {
        let hex: String = (0..1092).map(|i| "0123456789ABCDEF".as_bytes()[i % 16] as char).collect();
        let n = registry().get("cc_railfence").unwrap();
        let p = params! {"key" => 3i64, "strip_non_alphabet" => false, "output_case" => "preserve"};
        let out = n.apply(&Repr::bytes(hex.clone().into_bytes()), &p).unwrap();
        assert_eq!(out.data.len(), 1092);
        let mut want: Vec<u8> = hex.into_bytes();
        want.sort();
        let mut got = out.data.clone();
        got.sort();
        assert_eq!(got, want, "must be a pure permutation: same multiset of bytes");
    }

    #[test]
    fn cc_railfence_is_xf_family_and_not_layer_forming() {
        let n = registry().get("cc_railfence").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
