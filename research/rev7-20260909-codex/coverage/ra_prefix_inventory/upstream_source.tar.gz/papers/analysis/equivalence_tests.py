#!/usr/bin/env python3
"""Are our reconstructed parameterisations genuinely unusual, or merely an
equivalent re-description of a standard operation?

A "novel tool feature" claim is worse than no claim if the operation is really
a standard one wearing different parameter names, because it sends the reader
hunting for a tool that need not exist.  Two claims are tested here, both
arithmetically and without reference to any web tool:

  1. rev14's columnar transposition -- "width 6, rotate columns by 3, read
     bottom to top" -- against the whole family of standard keyed columnar
     transpositions on a complete rectangle.
  2. gk12's autokey over the keyed alphabet built from ZOMBIESAREEVERYWHERE,
     against a plain-alphabet autokey (i.e. is the keyed alphabet absorbable
     into a different key?).

Stdlib only.  Run: python3 papers/analysis/equivalence_tests.py
"""

N = 162          # rev14 body length, = 6 x 27, after removing the "-M" trailer
WIDTH = 6
ROTATE = 3


def rev14_permutation():
    """pi[j] = index in the INPUT that supplies output position j.

    Mirrors crates/ra-core/src/classical/columnar.rs at
    width=6, rotate=3, direction=btt.
    """
    rows = N // WIDTH
    pi = []
    for r_out in range(rows):
        r = rows - 1 - r_out                      # bottom-to-top
        for c in range(WIDTH):
            pi.append(r * WIDTH + (c + ROTATE) % WIDTH)
    return pi


def divisors(n):
    return [d for d in range(2, n) if n % d == 0]


def test_columnar():
    print("=" * 72)
    print("1. rev14 columnar vs the standard keyed columnar family")
    print("=" * 72)
    pi = rev14_permutation()
    assert sorted(pi) == list(range(N)), "not a permutation"
    print(f"  our permutation on {N} positions, first 18 outputs:")
    print(f"    {pi[:18]}")
    print()
    print("  Structure of a STANDARD columnar transposition on a complete")
    print("  W x R rectangle: the text splits into W contiguous blocks of R")
    print("  characters, and inside each block consecutive positions are")
    print("  exactly W apart in the other text.  The column key only decides")
    print("  which block is which -- it cannot change that within-block step.")
    print("  So testing the step is a test of the WHOLE family at that width,")
    print("  all W! key orders at once.")
    print()
    print(f"  {'W':>4} {'R':>4}   within-block step is constant W?")
    any_fit = False
    for w in divisors(N):
        r = N // w
        ok = True
        for b in range(w):
            blk = pi[b * r:(b + 1) * r]
            if any(blk[i + 1] - blk[i] != w for i in range(len(blk) - 1)):
                ok = False
                break
        if ok:
            any_fit = True
        print(f"  {w:>4} {r:>4}   {'YES -- equivalent!' if ok else 'no'}")
    print()
    if any_fit:
        print("  >>> rev14 IS a standard keyed columnar. Fingerprint claim dies.")
    else:
        print("  >>> No width fits. rev14's permutation is NOT any standard")
        print("      complete-rectangle keyed columnar transposition.")
    print()
    print("  Why, structurally: our map sends each contiguous run of 6 output")
    print("  positions to 6 CONSECUTIVE input positions (a cyclic rotation")
    print("  within one row). A standard columnar sends a contiguous run to an")
    print("  arithmetic progression of step W. Those two sets coincide only")
    print("  when W = 1 or R = 1, i.e. only in the degenerate cases.")
    steps = [pi[i + 1] - pi[i] for i in range(len(pi) - 1)]
    plus1 = sum(1 for s in steps if s == 1)
    print(f"  measured: step == +1 at {plus1} of {len(steps)} consecutive pairs")
    print("  A standard columnar of width W>1 has step +1 nowhere inside a")
    print("  block; it steps by W.")
    print()
    print("  VERDICT: the parameterisation is genuinely non-standard as a")
    print("  permutation, so 'no tool documents it' is not explained away by")
    print("  re-description.  It remains true, separately, that rev14's")
    print("  parameters were RECOVERED by search over readings of the recorded")
    print("  note, not read off a tool -- see columnar.rs.")


# ---------------------------------------------------------------------------

ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def keyed_alphabet(src):
    """Keep first occurrence of each letter, then append the missing A-Z."""
    out = []
    for c in src.upper():
        if c.isalpha() and c not in out:
            out.append(c)
    for c in ALPHA:
        if c not in out:
            out.append(c)
    return "".join(out)


def is_affine(perm):
    """Is the permutation of Z26 given by `perm` of the form x -> a*x + b?"""
    idx = {c: i for i, c in enumerate(ALPHA)}
    p = [idx[c] for c in perm]
    for a in range(1, 26):
        if any(a * k % 26 == 0 for k in range(1, 26) if 26 % k == 0):
            pass
        for b in range(26):
            if all(p[x] == (a * x + b) % 26 for x in range(26)):
                return (a, b)
    return None


def autokey_decrypt(ct, key, alphabet):
    idx = {c: i for i, c in enumerate(alphabet)}
    ks = list(key)
    out = []
    for i, c in enumerate(ct):
        if c not in idx:
            out.append(c)
            continue
        k = ks[len(out) if False else 0]
        k = ks[len([o for o in out if o in idx])]
        p = alphabet[(idx[c] - idx[k]) % len(alphabet)]
        out.append(p)
        ks.append(p)
    return "".join(out)


def test_autokey():
    print()
    print("=" * 72)
    print("2. gk12 autokey: is the keyed alphabet absorbable into the key?")
    print("=" * 72)
    ka = keyed_alphabet("ZOMBIESAREEVERYWHERE")
    print(f"  keyed alphabet : {ka}")
    print(f"  length {len(ka)}, is a permutation of A-Z: {sorted(ka) == list(ALPHA)}")
    aff = is_affine(ka)
    print(f"  is it AFFINE (x -> a*x+b mod 26)? {aff if aff else 'NO'}")
    print()
    print("  Why affineness is the right test: an autokey over a mixed alphabet")
    print("  A is A o autokey o A^-1.  It collapses to a plain-alphabet autokey")
    print("  with a different key exactly when A commutes with the additive")
    print("  structure, i.e. when A is affine.  For a general permutation it")
    print("  does not, so no plain-alphabet key can reproduce it.")
    print()
    if aff:
        print("  >>> absorbable: gk12 is a plain autokey in disguise.")
    else:
        print("  >>> NOT absorbable into a plain-alphabet autokey.")
    print()
    print("  BUT: 'keyed-alphabet autokey' is itself a textbook construction,")
    print("  and the dedup policy used here -- keep first occurrence, then")
    print("  append the unused letters in A-Z order -- is the standard way every")
    print("  textbook turns a keyword into a mixed alphabet.  So the two-input")
    print("  shape (key + alphabet keyword) discriminates between TOOLS that")
    print("  offer it and tools that do not, but the POLICY does not")
    print("  discriminate between tools that offer it.  Weak fingerprint.")


if __name__ == "__main__":
    test_columnar()
    test_autokey()
