//! Crypto Corner's Permutation Cipher tool.
//!
//! Source: the page's own JavaScript, fetched directly (task scratchpad
//! `pages/cc_permutation_js.txt`). `permuteEncrypt`/`permuteDecrypt` (plus the
//! shared `keyNumbers`, identical to `cc_columnar.rs`'s) are transliterated
//! verbatim below.
//!
//! # How this differs from `cc_columnar`
//!
//! Columnar transposition reorders whole *columns* end to end (every cell of
//! rank-1's column, then every cell of rank-2's column, ...). The Permutation
//! Cipher instead permutes column **positions within each row**, keeping rows
//! intact and reading the grid out row by row:
//!
//! ```js
//! for (i = 0; i < m; i++)
//!   for (j = 0; j < keyn.length; j++)
//!     cArray[i][keyn[j] - 1] = mainArray[i][j];   // move column j to slot keyn[j]-1
//! ctext = cArray.flat-per-row-joined;
//! ```
//!
//! So a block of `key.length` plaintext characters becomes a block of
//! `key.length` ciphertext characters with the *same* permutation applied
//! independently to every block — this is the cipher usually called
//! "columnar transposition with row-wise reading" or, per this site's naming,
//! "Permutation Cipher". It uses the same alphabetical-with-stable-ties
//! `keyNumbers` ranking as `cc_columnar.rs`.
//!
//! # Decrypt
//!
//! `permuteDecrypt` marks the short last block's missing *permuted* slots as
//! blank (via `keyn[keyn.length - j]`, working backwards from the end of the
//! rank list — the inverse permutation's tail), fills every non-blank cell of
//! every row in plaintext left-to-right order from the ciphertext, then
//! un-permutes row by row using the same `keyn` mapping run in reverse
//! (`pArray[i][j] = mainArray[i][k]` wherever `keyn[j] == k+1`).
//!
//! # Case, nulls, engine direction
//!
//! Same conventions as `cc_columnar.rs`.
//!
//! # Stripping is the page's input normalisation, not the cipher
//!
//! Like `cc_columnar.rs`, this permutes grid positions and needs no alphabet
//! for the message; the site's A-Z filtering is reproduced by default (site
//! fidelity) via [`crate::classical::toolfmt`]'s `strip_non_alphabet` param —
//! set it `false` to run the same permutation over any medium, verified in
//! `cc_permutation_preserves_hex_medium_when_stripping_disabled` below.

use crate::classical::toolfmt::{read_output_fmt, CaseFold, InputNorm, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

const CC_PERMUTATION_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(ParamSpec::req(
    "key",
    ParamType::Str,
    "transposition keyword (letters A-Z only; non-letter characters are dropped)"
),);

const ALPHABET: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZ";

/// `keyNumbers`, identical to `cc_columnar.rs`'s.
fn key_numbers(key: &[u8]) -> Vec<usize> {
    let mut ranks = vec![0usize; key.len()];
    let mut a = 1usize;
    for &alpha_c in ALPHABET {
        for (j, &kc) in key.iter().enumerate() {
            if kc == alpha_c {
                ranks[j] = a;
                a += 1;
            }
        }
    }
    ranks
}

/// `permuteDecrypt`, transliterated from `pages/cc_permutation_js.txt`.
pub fn decrypt(ctext: &[u8], key: &[u8]) -> Result<Vec<u8>> {
    if key.is_empty() {
        return Err(Error::bad_param("cc_permutation", "key", "must not be empty"));
    }
    let klen = key.len();
    let m = ctext.len().div_ceil(klen);
    let mut count = ctext.len();
    while count % klen != 0 {
        count += 1;
    }
    let count = count - ctext.len() + 1;

    #[derive(Clone, Copy, PartialEq)]
    enum Cell {
        Empty,
        Blank,
        Char(u8),
    }
    let mut grid = vec![vec![Cell::Empty; klen]; m];

    let keyn = key_numbers(key);
    for j in 1..count {
        if j <= keyn.len() {
            let idx = keyn[keyn.len() - j].wrapping_sub(1);
            if idx < klen {
                grid[m - 1][idx] = Cell::Blank;
            }
        }
    }

    let mut q = 0usize;
    for row in grid.iter_mut().take(m) {
        for cell in row.iter_mut().take(klen) {
            if *cell == Cell::Empty {
                if q == ctext.len() {
                    continue;
                }
                *cell = Cell::Char(ctext[q]);
                q += 1;
            }
        }
    }

    // Un-permute: pArray[i][j] = grid[i][k] wherever keyn[j] == k+1.
    let mut p_grid = vec![vec![Cell::Empty; klen]; m];
    for i in 0..m {
        for (j, &rank_j) in keyn.iter().enumerate() {
            for (k, &rank_k) in keyn.iter().enumerate() {
                if rank_j == k + 1 {
                    let _ = rank_k;
                    p_grid[i][j] = grid[i][k];
                }
            }
        }
    }
    for cell in p_grid[m - 1].iter_mut().take(klen) {
        if *cell == Cell::Blank {
            *cell = Cell::Empty;
        }
    }

    let mut out = Vec::with_capacity(ctext.len());
    for row in &p_grid {
        for cell in row.iter().take(klen) {
            if let Cell::Char(c) = cell {
                out.push(*c);
            }
        }
    }
    Ok(out)
}

/// `permuteEncrypt`, transliterated the same way. Test-only.
#[cfg(test)]
fn encrypt(ptext: &[u8], key: &[u8]) -> Vec<u8> {
    let klen = key.len();
    let m = ptext.len().div_ceil(klen);
    let mut grid = vec![vec![None::<u8>; klen]; m];
    let mut q = 0usize;
    for row in grid.iter_mut().take(m) {
        for cell in row.iter_mut().take(klen) {
            if q < ptext.len() {
                *cell = Some(ptext[q]);
            }
            q += 1;
        }
    }
    let keyn = key_numbers(key);
    let mut c_grid = vec![vec![None::<u8>; klen]; m];
    for i in 0..m {
        for (j, &rank) in keyn.iter().enumerate() {
            c_grid[i][rank - 1] = grid[i][j];
        }
    }
    let mut out = Vec::with_capacity(ptext.len());
    for row in &c_grid {
        for cell in row.iter().take(klen).flatten() {
            out.push(*cell);
        }
    }
    out
}

/// Crypto Corner's Permutation Cipher tool, decrypting.
pub struct CcPermutation;

impl Node for CcPermutation {
    fn name(&self) -> &'static str {
        "cc_permutation"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CC_PERMUTATION_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = params.req_str("cc_permutation", "key")?;
        let key: Vec<u8> = key
            .to_uppercase()
            .bytes()
            .filter(|b| ALPHABET.contains(b))
            .collect();
        if key.is_empty() {
            return Err(Error::bad_param(
                "cc_permutation",
                "key",
                "no letters remain in the key after filtering to A-Z",
            ));
        }

        let in_norm = crate::classical::toolfmt::read_input_norm(
            "cc_permutation",
            params,
            InputNorm {
                case: CaseFold::Upper,
                strip_outside_alphabet: Some("ABCDEFGHIJKLMNOPQRSTUVWXYZ".to_string()),
                ..InputNorm::default()
            },
        )?;
        let text = in_norm.apply(&input.data);

        let plain = decrypt(&text, &key)?;

        let out_fmt: OutputFmt = read_output_fmt(
            "cc_permutation",
            params,
            OutputFmt {
                case: CaseFold::Lower,
                grouping: None,
                trailing: Trailing::None,
            },
        )?;
        let out = out_fmt.apply(&plain);
        Ok(Repr::new(out, input.display))
    }
}

register_node!(CC_PERMUTATION => || Box::new(CcPermutation));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    /// Ground truth: direct Python transliteration of the fetched JS (task
    /// scratchpad `cc_oracle.py`), run and cross-checked here.
    #[test]
    fn cc_permutation_oracle_vector() {
        let pt = b"HELLOWORLD";
        let key = b"KEY";
        let ct = encrypt(pt, key);
        assert_eq!(ct, b"EHLOLWROLD");
        let back = decrypt(&ct, key).unwrap();
        assert_eq!(back, pt);
    }

    #[test]
    fn cc_permutation_round_trips_varied_keys_and_lengths() {
        let samples: &[&[u8]] = &[
            b"A",
            b"AB",
            b"ATTACKATDAWN",
            b"THEQUICKBROWNFOXJUMPSOVERTHELAZYDOGTWICE",
        ];
        let keys: &[&[u8]] = &[b"ZEBRA", b"KEY", b"A", b"ABCDEFGHIJ", b"BAB"];
        for pt in samples {
            for key in keys {
                let ct = encrypt(pt, key);
                let back = decrypt(&ct, key).unwrap();
                assert_eq!(&back, pt, "pt={pt:?} key={key:?}");
            }
        }
    }

    #[test]
    fn cc_permutation_node_decrypts_lowercasing_output() {
        let pt = b"HELLOWORLD";
        let ct = encrypt(pt, b"KEY");
        let n = registry().get("cc_permutation").unwrap();
        let p = params! {"key" => "KEY"};
        let out = n.apply(&Repr::bytes(ct), &p).unwrap();
        assert_eq!(
            String::from_utf8(out.data).unwrap(),
            String::from_utf8(pt.to_ascii_lowercase()).unwrap()
        );
    }

    #[test]
    fn cc_permutation_rejects_key_with_no_letters() {
        let n = registry().get("cc_permutation").unwrap();
        let p = params! {"key" => "123"};
        assert!(n.apply(&Repr::bytes(b"XYZ".to_vec()), &p).is_err());
    }

    #[test]
    fn cc_permutation_preserves_display() {
        let ct = encrypt(b"HELLOWORLD", b"KEY");
        let n = registry().get("cc_permutation").unwrap();
        let p = params! {"key" => "KEY"};
        let out = n.apply(&Repr::new(ct, Display::Hex), &p).unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    /// The payoff: with `strip_non_alphabet` explicitly disabled, this
    /// transposition operates on any medium, not just A-Z text -- proven here
    /// against a 1092-character hex string, the length of rev7's ciphertext.
    #[test]
    fn cc_permutation_preserves_hex_medium_when_stripping_disabled() {
        let hex: String = (0..1092).map(|i| "0123456789ABCDEF".as_bytes()[i % 16] as char).collect();
        let n = registry().get("cc_permutation").unwrap();
        let p = params! {
            "key" => "ZOMBIES",
            "strip_non_alphabet" => false,
            "output_case" => "preserve",
        };
        let out = n.apply(&Repr::bytes(hex.clone().into_bytes()), &p).unwrap();
        assert_eq!(out.data.len(), 1092);
        let mut want: Vec<u8> = hex.into_bytes();
        want.sort();
        let mut got = out.data.clone();
        got.sort();
        assert_eq!(got, want, "must be a pure permutation: same multiset of bytes");
    }

    #[test]
    fn cc_permutation_is_xf_family_and_not_layer_forming() {
        let n = registry().get("cc_permutation").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
