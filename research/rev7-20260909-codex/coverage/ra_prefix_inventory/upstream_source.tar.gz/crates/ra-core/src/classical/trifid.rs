//! Trifid: Delastelle's 27-symbol fractionating cipher over a 3×3×3 cube.
//!
//! # The transform
//!
//! Each of 27 symbols has a three-digit base-3 coordinate `(layer, row, col)`, read
//! off a 27-symbol alphabet laid into three 3×3 squares. The alphabet parameter
//! gives those symbols in **cube order**: the symbol at linear index `i` has
//! coordinates `layer = i / 9`, `row = (i / 3) % 3`, `col = i % 3`.
//!
//! Encryption writes a block of `period` plaintext coordinates as three rows —
//! all the layers, then all the rows, then all the columns — concatenates those
//! `3·N` digits and re-reads them as consecutive triples, one per ciphertext
//! symbol. Decryption inverts that exactly. Fractionation is what makes it strong
//! for its age: one plaintext symbol's digits end up spread across three
//! ciphertext symbols.
//!
//! This implementation is checked against the standard published vector (key
//! alphabet `FELIXMARDSTBCGHJKNOPQUVWYZ+`, period 5,
//! `AIDETOILECIELTAIDERA` → `FMJFVOISSUFTFPUFEQQC`) in
//! `standard_published_vector`, so the convention here is the textbook one and not
//! a local invention.
//!
//! # rev11's parameters are RECOVERED, not documented
//!
//! This matters for how much they may be trusted. rev11's record names the step
//! "Trifid" and gives its output, but records **neither the alphabet nor the
//! period**. Both were recovered here from the corpus, by solving the known
//! plaintext/ciphertext pair the record supplies:
//!
//! - **alphabet** = [`REV11_ALPHABET`], `adgbehcfijmpknqlorsvytwzux.`
//! - **period** = the whole message as a single block ([`PERIOD_WHOLE_INPUT`], i.e.
//!   `0`; rev11's text is 462 symbols, so `period=462` is the same thing)
//!
//! The alphabet looks arbitrary written out flat, but it is not: it is the plain
//! 27-symbol alphabet `a`…`z` followed by `.`, laid into the three squares **down
//! the columns** rather than across the rows.
//!
//! ```text
//!   a d g     j m p     s v y
//!   b e h     k n q     t w z
//!   c f i     l o r     u x .
//! ```
//!
//! Equivalently: a tool that fills its squares column-wise, or that reads the row
//! and column coordinates in the opposite order to the textbook. Either way the
//! recovered value is a *tool fingerprint*, and it is consistent with the dossier's
//! note that the Braingle Trifid — the corpus's suspected Trifid tool — implements
//! a non-standard ruleset.
//!
//! ## How the recovery was done
//!
//! Not by search over alphabets: 27! is far too large, and a search would make this
//! node a solver. It was solved as a constraint system. For a candidate period the
//! transform is a fixed permutation of digit slots, so every ciphertext/plaintext
//! position pair asserts an *equality between two base-3 digits* of two alphabet
//! symbols. Union-find over the 81 digit slots (27 symbols × 3 digits) collapses
//! those equalities; a correct period leaves exactly 3 classes of exactly 27 slots
//! each, and the 27 symbols then carry 27 distinct coordinate triples, which is the
//! alphabet up to the 3! relabellings of the digit values. Only one period in
//! 2..=462 produced that structure, and it reproduces the recorded plaintext at
//! 462 of 462 symbols — an exact match, not a similarity score.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]. The node itself performs no search whatsoever: the alphabet and
//! period are parameters and the transform is exhaustive at them. The recovery
//! described above happened offline, once, and its result is pinned in a test.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

const NAME: &str = "trifid";

/// The neutral default: `a`…`z` then `.`, laid into the squares row-wise. Chosen as
/// the default precisely *because* it is not rev11's alphabet — nothing recovered is
/// baked into a default.
pub const DEFAULT_ALPHABET: &str = "abcdefghijklmnopqrstuvwxyz.";

/// rev11's **recovered** cube alphabet: `a`…`z` then `.`, laid into the three 3×3
/// squares down the columns. Not recorded anywhere in the corpus; see the module
/// documentation for how it was established.
pub const REV11_ALPHABET: &str = "adgbehcfijmpknqlorsvytwzux.";

/// `period = 0` means "treat the whole input as one block", which is rev11's
/// **recovered** period.
pub const PERIOD_WHOLE_INPUT: i64 = 0;

const SCHEMA: &[ParamSpec] = &[
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "27 distinct single-byte symbols in cube order (index i -> layer i/9, row \
         (i/3)%3, col i%3); default \"abcdefghijklmnopqrstuvwxyz.\"",
    ),
    ParamSpec::opt(
        "period",
        ParamType::Int,
        "block length in symbols; 0 (the default) or any value at or above the input \
         length means the whole input is one block",
    ),
    ParamSpec::opt(
        "direction",
        ParamType::Str,
        "\"decrypt\" (default) or \"encrypt\"",
    ),
];

/// A validated 27-symbol cube alphabet.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Cube {
    symbols: [u8; 27],
    /// byte value -> linear cube index, or 27 when the byte is not a symbol
    index: [u8; 256],
}

impl Cube {
    pub fn build(alphabet: &str) -> Result<Self> {
        let b = alphabet.as_bytes();
        if b.len() != 27 {
            return Err(Error::bad_param(
                NAME,
                "alphabet",
                format!(
                    "expected 27 single-byte symbols, got {} bytes ({alphabet:?})",
                    b.len()
                ),
            ));
        }
        let mut index = [27u8; 256];
        for (i, &c) in b.iter().enumerate() {
            if index[c as usize] != 27 {
                return Err(Error::bad_param(
                    NAME,
                    "alphabet",
                    format!("symbol '{}' appears twice", c as char),
                ));
            }
            index[c as usize] = i as u8;
        }
        let symbols: [u8; 27] = b.try_into().expect("length checked above");
        Ok(Self { symbols, index })
    }

    fn code(&self, c: u8) -> Result<usize> {
        let i = self.index[c as usize];
        if i == 27 {
            Err(Error::node_failed(
                NAME,
                format!(
                    "symbol {:?} is not in the 27-symbol alphabet, so it has no cube \
                     coordinate",
                    c as char
                ),
            ))
        } else {
            Ok(i as usize)
        }
    }

    fn symbol(&self, code: usize) -> u8 {
        self.symbols[code]
    }
}

/// Resolve the effective block length: `period <= 0` or `period >= len` both mean
/// one block covering the whole input.
fn block_len(period: i64, len: usize) -> Result<usize> {
    if period < 0 {
        return Err(Error::bad_param(
            NAME,
            "period",
            format!("must not be negative, got {period}"),
        ));
    }
    let p = period as usize;
    Ok(if p == 0 || p > len { len } else { p })
}

/// Encrypt: coordinates written as three rows per block, read back as triples.
pub fn encrypt(text: &[u8], cube: &Cube, period: i64) -> Result<Vec<u8>> {
    let p = block_len(period, text.len())?;
    let mut out = Vec::with_capacity(text.len());
    for block in text.chunks(p) {
        let n = block.len();
        let mut digits = vec![0u8; 3 * n];
        for (k, &c) in block.iter().enumerate() {
            let v = cube.code(c)?;
            digits[k] = (v / 9) as u8;
            digits[n + k] = ((v / 3) % 3) as u8;
            digits[2 * n + k] = (v % 3) as u8;
        }
        for triple in digits.chunks_exact(3) {
            let code = triple[0] as usize * 9 + triple[1] as usize * 3 + triple[2] as usize;
            out.push(cube.symbol(code));
        }
    }
    Ok(out)
}

/// Decrypt: the exact inverse of [`encrypt`] at the same parameters.
pub fn decrypt(text: &[u8], cube: &Cube, period: i64) -> Result<Vec<u8>> {
    let p = block_len(period, text.len())?;
    let mut out = Vec::with_capacity(text.len());
    for block in text.chunks(p) {
        let n = block.len();
        let mut digits = Vec::with_capacity(3 * n);
        for &c in block {
            let v = cube.code(c)?;
            digits.push((v / 9) as u8);
            digits.push(((v / 3) % 3) as u8);
            digits.push((v % 3) as u8);
        }
        for k in 0..n {
            let code = digits[k] as usize * 9
                + digits[n + k] as usize * 3
                + digits[2 * n + k] as usize;
            out.push(cube.symbol(code));
        }
    }
    Ok(out)
}

pub struct Trifid;

impl Node for Trifid {
    fn name(&self) -> &'static str {
        NAME
    }

    fn version(&self) -> &'static str {
        "1.0.0"
    }

    fn family(&self) -> Family {
        Family::Xf
    }

    fn source_digest(&self) -> &'static str {
        "ra-core/classical/trifid(delastelle-3x3x3,alphabet+period-parameterised)"
    }

    fn params_schema(&self) -> &'static [ParamSpec] {
        SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let cube = Cube::build(params.opt_str("alphabet").unwrap_or(DEFAULT_ALPHABET))?;
        let period = params.opt_i64("period", PERIOD_WHOLE_INPUT);
        if input.data.is_empty() {
            return Err(Error::node_failed(NAME, "input is empty"));
        }
        let out = match params.opt_str("direction").unwrap_or("decrypt") {
            "decrypt" => decrypt(&input.data, &cube, period)?,
            "encrypt" => encrypt(&input.data, &cube, period)?,
            other => {
                return Err(Error::bad_param(
                    NAME,
                    "direction",
                    format!("expected \"decrypt\" or \"encrypt\", got {other:?}"),
                ))
            }
        };
        // Trifid emits a symbol stream over its own alphabet, which is text rather
        // than an encoded display.
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(TRIFID => || Box::new(Trifid));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn node() -> &'static dyn Node {
        registry().get(NAME).unwrap()
    }

    #[test]
    fn is_xf_family_and_not_layer_forming() {
        let n = node();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    /// The standard published Trifid vector. Alphabet `FELIXMARDSTBCGHJKNOPQUVWYZ+`
    /// as three squares
    ///
    /// ```text
    ///   F E L    S T B    O P Q
    ///   I X M    C G H    U V W
    ///   A R D    J K N    Y Z +
    /// ```
    ///
    /// period 5, `AIDETOILECIELTAIDERA` encrypts to `FMJFVOISSUFTFPUFEQQC`.
    ///
    /// Worked by hand for the first block: `A I D E T` have coordinates
    /// (1,3,1) (1,2,1) (1,3,3) (1,1,2) (2,1,2) in 1-based cube notation, so the
    /// three rows are `1 1 1 1 2` / `3 2 3 1 1` / `1 1 3 2 2`, concatenating to
    /// `111 123 231 111 322` = `F M J F V`.
    #[test]
    fn standard_published_vector() {
        let n = node();
        let p = params! {
            "alphabet" => "FELIXMARDSTBCGHJKNOPQUVWYZ+",
            "period" => 5i64,
            "direction" => "encrypt",
        };
        let ct = n
            .apply(&Repr::bytes(b"AIDETOILECIELTAIDERA".to_vec()), &p)
            .unwrap();
        assert_eq!(ct.data, b"FMJFVOISSUFTFPUFEQQC");
    }

    /// Encryption and decryption are exact inverses at equal parameters — unlike
    /// Playfair, Trifid loses nothing, so the honest round-trip property here is
    /// full equality.
    #[test]
    fn round_trip_is_exact_in_both_directions() {
        let n = node();
        for period in [PERIOD_WHOLE_INPUT, 1, 2, 3, 5, 7, 11, 40] {
            for alphabet in [DEFAULT_ALPHABET, REV11_ALPHABET] {
                let base = params! {"alphabet" => alphabet, "period" => period};
                let plain = Repr::bytes(b"attack.at.dawn.with.the.zombies.".to_vec());
                let ct = n
                    .apply(
                        &plain,
                        &base.clone().set("direction", "encrypt"),
                    )
                    .unwrap();
                let back = n.apply(&ct, &base).unwrap();
                assert_eq!(back.data, plain.data, "period {period}, alphabet {alphabet}");
            }
        }
    }

    /// A period of 1 fractionates nothing: each block is a single symbol whose
    /// three digits are read straight back, so the transform is the identity.
    /// Worth pinning because it is the degenerate case a period sweep would hit
    /// first and could easily mistake for a hit.
    #[test]
    fn period_one_is_the_identity() {
        let n = node();
        let input = Repr::bytes(b"zombies.".to_vec());
        let out = n.apply(&input, &params! {"period" => 1i64}).unwrap();
        assert_eq!(out.data, input.data);
    }

    /// `period = 0`, `period = len` and any `period > len` all mean one block.
    #[test]
    fn whole_input_periods_agree() {
        let n = node();
        let input = Repr::bytes(b"abcdefgh.".to_vec());
        let a = n.apply(&input, &params! {"period" => 0i64}).unwrap();
        let b = n.apply(&input, &params! {"period" => 9i64}).unwrap();
        let c = n.apply(&input, &params! {"period" => 1000i64}).unwrap();
        assert_eq!(a.data, b.data);
        assert_eq!(a.data, c.data);
    }

    /// A short final block is handled at its own length rather than padded, which
    /// is what makes rev11's 462-symbol text work at all: no length is a multiple
    /// of every period.
    #[test]
    fn a_short_final_block_round_trips() {
        let n = node();
        let plain = Repr::bytes(b"abcdefghij".to_vec()); // 10 symbols, period 4
        let base = params! {"period" => 4i64};
        let ct = n
            .apply(&plain, &base.clone().set("direction", "encrypt"))
            .unwrap();
        let back = n.apply(&ct, &base).unwrap();
        assert_eq!(back.data, plain.data);
    }

    #[test]
    fn malformed_alphabets_and_periods_are_rejected() {
        let n = node();
        let d = Repr::bytes(b"abc".to_vec());
        for bad in [
            params! {"alphabet" => "tooshort"},
            params! {"alphabet" => "aabcdefghijklmnopqrstuvwxy"},
            params! {"alphabet" => "aabcdefghijklmnopqrstuvwxyz"},
            params! {"alphabet" => "abcdefghijklmnopqrstuvwxyz.."},
            params! {"period" => -1i64},
            params! {"direction" => "sideways"},
        ] {
            assert!(n.apply(&d, &bad).is_err(), "{bad:?} should be rejected");
        }
    }

    #[test]
    fn a_symbol_outside_the_alphabet_is_an_error_not_a_passthrough() {
        let n = node();
        let e = n
            .apply(&Repr::bytes(b"abc!".to_vec()), &Params::new())
            .unwrap_err();
        assert!(format!("{e}").contains("not in the 27-symbol alphabet"), "{e}");
    }

    #[test]
    fn empty_input_is_an_error() {
        assert!(node().apply(&Repr::bytes(Vec::new()), &Params::new()).is_err());
    }

    /// The two **recovered** rev11 parameters, pinned.
    ///
    /// Neither is documented anywhere in the corpus: the record names the step
    /// "Trifid" and nothing else. Both were recovered from rev11's own recorded
    /// step-6 output and plaintext by the union-find construction described in the
    /// module documentation. This test pins their *values* and the structural claim
    /// about the alphabet; `reproduces_rev11_step_seven_exactly` is the one that
    /// pins the reproduction.
    ///
    /// Note that a truncated pair would not do: because the recovered period is
    /// the whole message, the first 154 ciphertext symbols draw on the layer digits
    /// of all 462 plaintext symbols, so any prefix of the pair is not itself a
    /// valid Trifid pair. Every rev11 vector here uses the full 462 symbols.
    #[test]
    fn rev11_recovered_parameters_are_pinned() {
        // recovered, not recorded: a-z then '.', filled down the columns of the
        // three 3x3 squares
        assert_eq!(REV11_ALPHABET, "adgbehcfijmpknqlorsvytwzux.");
        assert_eq!(PERIOD_WHOLE_INPUT, 0);

        // the recovered alphabet really is the column-wise reading of a..z + '.'
        let plain: Vec<u8> = (b'a'..=b'z').chain([b'.']).collect();
        let mut column_wise = Vec::with_capacity(27);
        for layer in 0..3 {
            for row in 0..3 {
                for col in 0..3 {
                    // column-wise fill: the square's (row, col) cell holds the
                    // symbol at offset col*3 + row within the square
                    column_wise.push(plain[layer * 9 + col * 3 + row]);
                }
            }
        }
        assert_eq!(column_wise, REV11_ALPHABET.as_bytes());

        // and it is a valid cube containing exactly the 26 letters plus '.'
        let cube = Cube::build(REV11_ALPHABET).unwrap();
        let mut got = cube.symbols.to_vec();
        got.sort_unstable();
        let mut want = plain.clone();
        want.sort_unstable();
        assert_eq!(got, want);
    }

    /// rev11's step 7 end to end, on the corpus's own recorded step-6 output.
    ///
    /// This is the full 462-symbol pair, inlined so the assertion is exact rather
    /// than a substring or a score. The expected output is byte-identical to the
    /// record's step-7 output.
    #[test]
    fn reproduces_rev11_step_seven_exactly() {
        const STEP6: &str = "cubeuvridxjledluvebmdjxcdtedmxggarcvtwmgbdgbps.ntdzedrsogshtbxbsjkajesgtagbgbsaehcu.mkuhmreyfhxbfktudmcyarbipgobestsechhabmacvpmiexgzggahgwcbmdvldeacbigyiteotgiptkgt.ahueqpjxitqnr.ijuycmqvdfzfzjtgmnskp.tpxrpgqxaskurhkkpzvo.nmoegsbuee.jmizzsh.vwrubbhbquadrtqkjtxhtb.tikle.npwqtudspzdtxcpolaxomcntxhfdogfeomkjptgowzfpsndtihaleqrlxwsapncaqxgckzsefhetjzijn.caxenftprnmjekingqcknwmqfadfhttjfmqqofawugbejjuehghnvcanwqcvqfatnpzacavqpqtwtffsjcmyedqbupwjsepzfzfloudpoctdp";
        const STEP7: &str = "iwasthereinmyvisions.itseemssoreal.iampablo.aswewerepreparingforbattlethefourcalledprimusraisedtheirstavesinunisonreleasingagreatenergythatsurroundedourwholearmy.wefoundasuddensurgeofstrengthandconfidenceforthebattleahead.imagesflashedbeforemyeyes.futureorpasticouldnottell.isawmanystrangeworldspassbeforemewithshadowycreaturesdevouringallthatlaybeforethem.inthefinalimageisawallhumanityconsumed.tothisdayifeelthatsomethinglingersinmybeingplacedtherebythestaves.";
        assert_eq!(STEP6.len(), 462);
        assert_eq!(STEP7.len(), 462);

        let out = node()
            .apply(
                &Repr::bytes(STEP6.as_bytes().to_vec()),
                &params! {"alphabet" => REV11_ALPHABET, "period" => PERIOD_WHOLE_INPUT},
            )
            .unwrap();
        assert_eq!(String::from_utf8_lossy(&out.data), STEP7);

        // and the inverse direction regenerates the recorded step-6 output, which
        // is a genuinely independent check: it exercises the encryption path
        let re = node()
            .apply(
                &Repr::bytes(STEP7.as_bytes().to_vec()),
                &params! {
                    "alphabet" => REV11_ALPHABET,
                    "period" => PERIOD_WHOLE_INPUT,
                    "direction" => "encrypt",
                },
            )
            .unwrap();
        assert_eq!(String::from_utf8_lossy(&re.data), STEP6);
    }

    /// The recovered period is unique, not merely sufficient: no other period
    /// reproduces the recorded plaintext from the recorded step-6 output under the
    /// recovered alphabet. Cheap to assert and it is what stops "one block" being
    /// mistaken for an arbitrary choice that happened to work.
    #[test]
    fn no_other_period_reproduces_rev11_under_the_recovered_alphabet() {
        const STEP6: &str = "cubeuvridxjledluvebmdjxcdtedmxggarcvtwmgbdgbps.ntdzedrsogshtbxbsjkajesgtagbgbsaehcu.mkuhmreyfhxbfktudmcyarbipgobestsechhabmacvpmiexgzggahgwcbmdvldeacbigyiteotgiptkgt.ahueqpjxitqnr.ijuycmqvdfzfzjtgmnskp.tpxrpgqxaskurhkkpzvo.nmoegsbuee.jmizzsh.vwrubbhbquadrtqkjtxhtb.tikle.npwqtudspzdtxcpolaxomcntxhfdogfeomkjptgowzfpsndtihaleqrlxwsapncaqxgckzsefhetjzijn.caxenftprnmjekingqcknwmqfadfhttjfmqqofawugbejjuehghnvcanwqcvqfatnpzacavqpqtwtffsjcmyedqbupwjsepzfzfloudpoctdp";
        const STEP7: &str = "iwasthereinmyvisions.itseemssoreal.iampablo.aswewerepreparingforbattlethefourcalledprimusraisedtheirstavesinunisonreleasingagreatenergythatsurroundedourwholearmy.wefoundasuddensurgeofstrengthandconfidenceforthebattleahead.imagesflashedbeforemyeyes.futureorpasticouldnottell.isawmanystrangeworldspassbeforemewithshadowycreaturesdevouringallthatlaybeforethem.inthefinalimageisawallhumanityconsumed.tothisdayifeelthatsomethinglingersinmybeingplacedtherebythestaves.";
        let cube = Cube::build(REV11_ALPHABET).unwrap();
        let mut reproducing: Vec<usize> = Vec::new();
        for period in 2..=462i64 {
            let got = decrypt(STEP6.as_bytes(), &cube, period).unwrap();
            if got == STEP7.as_bytes() {
                reproducing.push(period as usize);
            }
        }
        assert_eq!(
            reproducing,
            vec![462],
            "only the whole-input period may reproduce rev11"
        );
    }
}
