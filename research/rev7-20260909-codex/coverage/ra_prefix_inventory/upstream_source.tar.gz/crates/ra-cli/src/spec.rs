//! Textual chain specification.
//!
//! ```text
//! hexdecode | xtea:key=Zombies,mode=cfb | reverse | rot:n=20
//! ```
//!
//! Steps are separated by `|`, parameters by `,` after a `:`. Integers and booleans
//! are recognised by shape so `n=20` binds an int and `uppercase=true` a bool; all
//! else is a string.

use anyhow::{bail, Context, Result};
use ra_core::{Chain, Params, Step};

pub fn parse_chain(spec: &str) -> Result<Chain> {
    let mut steps = Vec::new();
    for raw in spec.split('|') {
        let seg = raw.trim();
        if seg.is_empty() {
            bail!("empty step in chain spec: {spec:?}");
        }
        let (name, rest) = match seg.split_once(':') {
            Some((n, r)) => (n.trim(), Some(r)),
            None => (seg, None),
        };
        let mut params = Params::new();
        if let Some(rest) = rest {
            for kv in rest.split(',') {
                let kv = kv.trim();
                if kv.is_empty() {
                    continue;
                }
                let (k, v) = kv
                    .split_once('=')
                    .with_context(|| format!("parameter {kv:?} is not key=value"))?;
                let k = k.trim();
                let v = v.trim();
                // A leading zero followed by more digits is not an integer literal in
                // any spelling that appears here; it is a fixed-width field. This
                // matters for auditability rather than taste: a sweep hit's chain is
                // emitted with `iv=<hex>`, and a null IV renders as thirty-two zeros —
                // which shape-guessing turned into `Int(0)`, so the one chain an
                // auditor most wants to paste into `ra run` was the one that would not
                // parse. `n=0` is still an int; `n=00` was never meant to be.
                let looks_like_a_field = v.len() > 1 && v.starts_with('0');
                params = if let (false, Ok(i)) = (looks_like_a_field, v.parse::<i64>()) {
                    params.set(k, i)
                } else if v == "true" || v == "false" {
                    params.set(k, v == "true")
                } else {
                    params.set(k, v)
                };
            }
        }
        steps.push(Step::new(name, params));
    }
    Chain::new(steps).map_err(Into::into)
}

/// Render a chain back to the spec syntax, for echoing what was actually run.
pub fn render_chain(chain: &Chain) -> String {
    chain
        .steps()
        .iter()
        .map(|s| {
            if s.params.is_empty() {
                s.node.clone()
            } else {
                let kvs: Vec<String> = s
                    .params
                    .0
                    .iter()
                    .map(|(k, v)| {
                        let vs = match v {
                            ra_core::Value::Str(x) => x.clone(),
                            ra_core::Value::Int(i) => i.to_string(),
                            ra_core::Value::Bool(b) => b.to_string(),
                        };
                        format!("{k}={vs}")
                    })
                    .collect();
                format!("{}:{}", s.node, kvs.join(","))
            }
        })
        .collect::<Vec<_>>()
        .join(" | ")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_a_multi_step_chain_with_typed_params() {
        let c = parse_chain("hexdecode | xtea:key=Zombies,mode=cfb | reverse | rot:n=20").unwrap();
        assert_eq!(c.len(), 4);
        assert_eq!(c.steps()[1].node, "xtea");
        assert_eq!(
            c.steps()[1].params.get("key"),
            Some(&ra_core::Value::Str("Zombies".into()))
        );
        assert_eq!(
            c.steps()[3].params.get("n"),
            Some(&ra_core::Value::Int(20))
        );
    }

    #[test]
    fn round_trips_through_render() {
        let spec = "hexdecode | rot:n=20";
        let c = parse_chain(spec).unwrap();
        assert_eq!(render_chain(&c), spec);
    }

    #[test]
    fn negative_shifts_and_booleans_are_typed() {
        let c = parse_chain("rot:n=-6 | hexencode:uppercase=false").unwrap();
        assert_eq!(c.steps()[0].params.get("n"), Some(&ra_core::Value::Int(-6)));
        assert_eq!(
            c.steps()[1].params.get("uppercase"),
            Some(&ra_core::Value::Bool(false))
        );
    }

    /// A sweep hit's chain is meant to paste straight into `ra run`; that is the whole
    /// mechanism by which a challenged candidate is re-checked. The null IV renders as
    /// thirty-two zeros, and shape-guessing an integer out of it made exactly that
    /// chain unparseable — while `iv=3030…` (the ASCII-zero invariant) parsed fine, so
    /// the failure only showed up on the other IV in the domain.
    #[test]
    fn a_fixed_width_zero_padded_field_stays_a_string() {
        let c = parse_chain(
            "b64decode | des:key=Zombies,mode=cfb,iv=00000000000000000000000000000000",
        )
        .unwrap();
        assert_eq!(
            c.steps()[1].params.get("iv"),
            Some(&ra_core::Value::Str("00000000000000000000000000000000".into())),
            "a 32-zero IV is a field, not the integer zero"
        );
        // the ASCII-zero invariant was never affected, and must not change
        let c = parse_chain(
            "b64decode | des:key=Zombies,mode=cfb,iv=30303030303030303030303030303030",
        )
        .unwrap();
        assert_eq!(
            c.steps()[1].params.get("iv"),
            Some(&ra_core::Value::Str("30303030303030303030303030303030".into()))
        );
        // genuine integers, including a bare zero, are still integers
        for (spec, want) in [("rot:n=0", 0i64), ("rot:n=20", 20), ("rot:n=-6", -6)] {
            let c = parse_chain(spec).unwrap();
            assert_eq!(
                c.steps()[0].params.get("n"),
                Some(&ra_core::Value::Int(want)),
                "{spec}"
            );
        }
    }

    #[test]
    fn rejects_unknown_nodes_and_malformed_params() {
        assert!(parse_chain("no_such_node").is_err());
        assert!(parse_chain("rot:justakey").is_err());
        assert!(parse_chain("reverse || rot").is_err());
    }

    /// A solver would be terminal; decryption is not, so this must be accepted.
    #[test]
    fn decryption_may_be_followed_by_more_steps() {
        assert!(parse_chain("des:key=Zombies | reverse").is_ok());
    }
}
