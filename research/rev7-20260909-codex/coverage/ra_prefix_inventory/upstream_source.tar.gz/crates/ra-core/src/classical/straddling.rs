//! The straddling checkerboard, plus the `base10` relabelling rev3 needs to feed it.
//!
//! # What the corpus documented, and what had to be recovered
//!
//! rev3's recorded chain is three steps: `base10` (*"convert symbols to digits by
//! order of appearance"*), `straddling_checkerboard`, then a `substitution` chosen
//! because its *"IOC [is] closest to English"*. The record gives the checkerboard
//! neither a layout nor its straddling digits, and gives the substitution no
//! alphabet. Three findings, in increasing order of consequence:
//!
//! ## 1. The digit stream is **reversed** before the checkerboard (undocumented step)
//!
//! Straddling is a prefix code: a digit either stands for a letter on its own or
//! selects a row and consumes the next digit. Read left to right, rev3's digit stream
//! admits **no** parse consistent with the recorded plaintext — the second `O` of
//! `OCTOBER` cannot land on the same code as the first, whichever code `O`, `C` and
//! `T` are given, because no `0`-initial code occurs 3–7 digits in. Read **right to
//! left** it parses perfectly and uniquely. So the chain needs a `reverse` between
//! `base10` and the checkerboard which the record does not mention. That is the same
//! class of omission as the corpus-wide implicit `b64decode`, and `reverse` appears
//! explicitly in four other recorded chains, so it is an unremarkable step to have
//! been dropped from a written-up solution.
//!
//! ## 2. The straddling digits are `1` and `3`, and the layout is as pinned below
//!
//! Recovered by exhaustive alignment against the recorded plaintext, not by search
//! over plausible boards: enumerate every parse of the reversed digit stream into 61
//! codes that (a) assigns each plaintext letter one fixed code, (b) is injective, and
//! (c) is prefix-free — i.e. no single-digit code is the first digit of a two-digit
//! code, which is exactly what makes a checkerboard decodable. **Exactly one parse
//! exists**, and it recovers rev3's recorded plaintext byte for byte, all 61
//! characters. It reads:
//!
//! ```text
//!        0  1  2  3  4  5  6  7  8  9
//!        C  .  D  .  .  Y  F  E  .  W      <- single-digit row
//!   1x   N  X  M  .  T  .  .  .  U  .
//!   3x   .  S  O  G  I  A  R  .  B  H
//! ```
//!
//! Eight single-digit cells and two ten-cell rows: 28 cells, textbook shape. Cells
//! shown `.` are simply unattested — their letters do not occur in a 61-character
//! message — except at digits `1` and `3` of the top row, which are structurally
//! empty because those digits are the row selectors.
//!
//! ## 3. The recorded `substitution` step is **not separately identifiable**
//!
//! A monoalphabetic substitution applied after a checkerboard is the same function as
//! a differently-labelled checkerboard: the composite of the two recorded steps has
//! exactly the freedom of one checkerboard, so the ciphertext cannot say where the
//! board stops and the substitution starts. Rather than invent a split — pick some
//! "natural" board and let the substitution absorb the difference — this node states
//! the **composite** as its `layout`. That is the honest form: the layout above is a
//! recovered parameter with a unique solution, whereas any decomposition of it into
//! board + alphabet would be a choice presented as a finding.
//!
//! Consequently there is deliberately **no IoC-maximising substitution search** here.
//! The mapping is derived from the known plaintext by alignment and stated as a
//! parameter, which makes this a *reproduction* at stated parameters — exhaustive at
//! those parameters, like any `xf` — rather than a heuristic solve whose coverage
//! could never be subtracted from the residual.
//!
//! # `layout` audited: already authoritative, no fix needed
//!
//! Unlike `xf:adfgx`'s square (which hardcoded a letters-only gate on its declared
//! alphabet), `Board::parse` never restricts a `layout` cell's content to
//! `is_ascii_alphabetic` at all -- any distinct byte, letters or otherwise, is a
//! legal cell (the sole reserved byte is `.` itself, [`EMPTY`], marking an unused
//! cell). The two `to_ascii_uppercase` calls (parsing `layout`, and folding
//! `encode`'s input before lookup) only normalise letter case for matching; they
//! are a no-op on a non-letter symbol, so a checkerboard built entirely from
//! punctuation already round-trips correctly. `layout` was therefore already
//! end-to-end authoritative before this audit; see
//! `punctuation_alphabet_round_trips` below for the differential proof.
//!
//! # Coverage semantics
//!
//! Both nodes are [`Family::Xf`]. `base10` is a relabelling (like `rot`) and the
//! checkerboard is a keyed re-representation; neither is a solver and neither
//! searches.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

// ---------------------------------------------------------------------------
// base10: symbols to digits by order of first appearance
// ---------------------------------------------------------------------------

/// Digits, in the order `base10` hands them out.
const DIGITS: &[u8; 10] = b"0123456789";

/// rev3's `base10` step: relabel an at-most-ten-symbol alphabet as decimal digits,
/// assigning `0` to the first distinct symbol seen, `1` to the second, and so on.
///
/// This is *not* [`crate::nodes::DecimalDecode`], which reads whitespace-separated
/// decimal byte values, nor any other codec already in the vocabulary: those decode a
/// number into bytes, whereas this one renames an arbitrary symbol set. rev3's
/// ciphertext is drawn from `@CB?>FAG=<` — ten glyphs with no numeric meaning at all
/// — so the digit each one denotes comes from its position in the text and from
/// nowhere else.
///
/// ASCII whitespace is skipped: it is neither assigned a digit nor emitted, so a
/// wrapped or grouped transcription relabels identically to a flat one. Every other
/// byte counts, and an eleventh distinct symbol is an error rather than a silent
/// wrap-around.
pub struct Base10;

impl Node for Base10 {
    fn name(&self) -> &'static str {
        "base10"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/straddling(base10)"
    }
    fn apply(&self, input: &Repr, _params: &Params) -> Result<Repr> {
        let mut seen: Vec<u8> = Vec::with_capacity(10);
        let mut out = Vec::with_capacity(input.data.len());
        for &b in &input.data {
            if b.is_ascii_whitespace() {
                continue;
            }
            let idx = match seen.iter().position(|&s| s == b) {
                Some(i) => i,
                None => {
                    if seen.len() == DIGITS.len() {
                        return Err(Error::node_failed(
                            "base10",
                            format!(
                                "more than {} distinct symbols: {:?} is the {}th",
                                DIGITS.len(),
                                b as char,
                                seen.len() + 1
                            ),
                        ));
                    }
                    seen.push(b);
                    seen.len() - 1
                }
            };
            out.push(DIGITS[idx]);
        }
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(BASE10 => || Box::new(Base10));

// ---------------------------------------------------------------------------
// straddling: the checkerboard itself
// ---------------------------------------------------------------------------

/// Cells per row, and the number of digits.
const RADIX: usize = 10;

/// Marks a checkerboard cell with no letter in it.
const EMPTY: u8 = b'.';

/// rev3's recovered straddling digits. See the module docs: **reconstructed** by
/// alignment against the recorded plaintext, not recorded by the corpus.
pub const REV3_STRADDLE: &str = "13";

/// rev3's recovered layout, in this node's `layout` syntax. See the module docs:
/// **reconstructed**, unique, and the composite of the recorded checkerboard and the
/// recorded final substitution, which are not separately identifiable.
pub const REV3_LAYOUT: &str = "C.D..YFE.W/NXM.T...U./.SOGIAR.BH";

const STRADDLING_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req(
        "straddle",
        ParamType::Str,
        "the digits that select a row instead of standing for a letter, in row order \
         (rev3: \"13\"). Accepts an integer too, because the CLI's chain-spec parser \
         reads a bare numeral as one; a set beginning with 0 therefore loses its \
         leading digit that way, but the layout's row count then disagrees and the \
         node errors rather than decoding something wrong.",
    ),
    ParamSpec::req(
        "layout",
        ParamType::Str,
        "'/'-separated rows of exactly 10 cells each: first the single-digit row \
         indexed by digit 0..9, then one row per straddling digit indexed by the \
         following digit. '.' marks an empty cell, and is required at the straddling \
         digits' own positions in the first row.",
    ),
    ParamSpec::opt(
        "direction",
        ParamType::Str,
        "\"decode\" (default): digits to letters. \"encode\": letters to digits.",
    ),
];

/// A parsed checkerboard: the single-digit row plus one row per straddling digit.
struct Board {
    /// `straddle[r]` is the digit that selects `rows[r]`.
    straddle: Vec<u8>,
    /// Cells of the single-digit row, indexed by digit value.
    top: Vec<u8>,
    /// `rows[r][d]` is the cell selected by `straddle[r]` then digit `d`.
    rows: Vec<Vec<u8>>,
}

impl Board {
    fn parse(p: &Params) -> Result<Self> {
        let straddle: Vec<u8> = match p.get("straddle") {
            Some(crate::params::Value::Str(s)) => s.as_bytes().to_vec(),
            Some(crate::params::Value::Int(i)) => i.to_string().into_bytes(),
            Some(other) => {
                return Err(Error::bad_param(
                    "straddling",
                    "straddle",
                    format!("expected a string or integer, got {other:?}"),
                ))
            }
            None => {
                return Err(Error::MissingParam {
                    node: "straddling".to_string(),
                    param: "straddle".to_string(),
                })
            }
        };
        if straddle.is_empty() || straddle.len() >= RADIX {
            return Err(Error::bad_param(
                "straddling",
                "straddle",
                format!(
                    "expected between 1 and {} digits, got {}",
                    RADIX - 1,
                    straddle.len()
                ),
            ));
        }
        for (i, &d) in straddle.iter().enumerate() {
            if !d.is_ascii_digit() {
                return Err(Error::bad_param(
                    "straddling",
                    "straddle",
                    format!("{:?} is not a decimal digit", d as char),
                ));
            }
            if straddle[..i].contains(&d) {
                return Err(Error::bad_param(
                    "straddling",
                    "straddle",
                    format!("digit {:?} appears twice", d as char),
                ));
            }
        }

        let layout = p.req_str("straddling", "layout")?;
        let rows: Vec<Vec<u8>> = layout
            .split('/')
            .map(|r| r.as_bytes().to_ascii_uppercase())
            .collect();
        let want = straddle.len() + 1;
        if rows.len() != want {
            return Err(Error::bad_param(
                "straddling",
                "layout",
                format!(
                    "expected {want} '/'-separated rows (one single-digit row plus \
                     one per straddling digit), got {}",
                    rows.len()
                ),
            ));
        }
        for (i, r) in rows.iter().enumerate() {
            if r.len() != RADIX {
                return Err(Error::bad_param(
                    "straddling",
                    "layout",
                    format!("row {i} has {} cells, expected {RADIX}", r.len()),
                ));
            }
        }

        let top = rows[0].clone();
        for &d in &straddle {
            let idx = usize::from(d - b'0');
            if top[idx] != EMPTY {
                return Err(Error::bad_param(
                    "straddling",
                    "layout",
                    format!(
                        "digit {:?} is a row selector, so its cell in the first row \
                         must be '{}', not {:?}",
                        d as char, EMPTY as char, top[idx] as char
                    ),
                ));
            }
        }
        Ok(Board {
            straddle,
            top,
            rows: rows[1..].to_vec(),
        })
    }

    /// Digits to letters. ASCII whitespace is skipped; any other non-digit is an
    /// error, since a checkerboard has no reading for it.
    fn decode(&self, input: &[u8]) -> Result<Vec<u8>> {
        let digits: Vec<u8> = input
            .iter()
            .copied()
            .filter(|b| !b.is_ascii_whitespace())
            .collect();
        let mut out = Vec::with_capacity(digits.len());
        let mut i = 0usize;
        while i < digits.len() {
            let d = digits[i];
            if !d.is_ascii_digit() {
                return Err(Error::node_failed(
                    "straddling",
                    format!("byte {i} is {:?}, not a decimal digit", d as char),
                ));
            }
            let (cell, width) = match self.straddle.iter().position(|&s| s == d) {
                Some(r) => {
                    let next = *digits.get(i + 1).ok_or_else(|| {
                        Error::node_failed(
                            "straddling",
                            format!(
                                "input ends with row selector {:?} and no cell digit \
                                 after it",
                                d as char
                            ),
                        )
                    })?;
                    if !next.is_ascii_digit() {
                        return Err(Error::node_failed(
                            "straddling",
                            format!("byte {} is {:?}, not a decimal digit", i + 1, next as char),
                        ));
                    }
                    (self.rows[r][usize::from(next - b'0')], 2)
                }
                None => (self.top[usize::from(d - b'0')], 1),
            };
            if cell == EMPTY {
                return Err(Error::node_failed(
                    "straddling",
                    format!(
                        "code {:?} at byte {i} selects an empty cell",
                        String::from_utf8_lossy(&digits[i..i + width])
                    ),
                ));
            }
            out.push(cell);
            i += width;
        }
        Ok(out)
    }

    /// Letters to digits. A byte with no cell is an error rather than a passthrough:
    /// silently emitting it would produce a digit stream that does not decode back.
    fn encode(&self, input: &[u8]) -> Result<Vec<u8>> {
        let mut out = Vec::with_capacity(input.len() * 2);
        for &b in input {
            let c = b.to_ascii_uppercase();
            if let Some(i) = self.top.iter().position(|&t| t == c && t != EMPTY) {
                out.push(DIGITS[i]);
                continue;
            }
            let found = self.rows.iter().enumerate().find_map(|(r, row)| {
                row.iter()
                    .position(|&t| t == c && t != EMPTY)
                    .map(|i| (r, i))
            });
            match found {
                Some((r, i)) => {
                    out.push(self.straddle[r]);
                    out.push(DIGITS[i]);
                }
                None => {
                    return Err(Error::node_failed(
                        "straddling",
                        format!("{:?} has no cell in this checkerboard", b as char),
                    ))
                }
            }
        }
        Ok(out)
    }
}

/// The straddling checkerboard: a prefix code over the ten digits.
pub struct Straddling;

impl Node for Straddling {
    fn name(&self) -> &'static str {
        "straddling"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/straddling"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        STRADDLING_SCHEMA
    }
    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let board = Board::parse(params)?;
        let out = match params.opt_str("direction").unwrap_or("decode") {
            "decode" => board.decode(&input.data)?,
            "encode" => board.encode(&input.data)?,
            other => {
                return Err(Error::bad_param(
                    "straddling",
                    "direction",
                    format!("expected \"decode\" or \"encode\", got {other:?}"),
                ))
            }
        };
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(STRADDLING => || Box::new(Straddling));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn base10() -> &'static dyn Node {
        registry().get("base10").unwrap()
    }
    fn straddling() -> &'static dyn Node {
        registry().get("straddling").unwrap()
    }

    /// rev3's ciphertext, verbatim from `data/revelations.json`.
    const REV3_CIPHERTEXT: &[u8] =
        b"@CB?>?>C@F?A?>CCCG??@C>?@C@C>???G=?C?=C@CGBC@CB?G@A?=CB?C?G<?>CB@C=CB?<FG<?>C>C>CA?B?AGA?F?C?@CA?G=?B?>C@B?";

    /// rev3's recorded plaintext, verbatim from `data/revelations.json`.
    const REV3_PLAINTEXT: &[u8] = b"OCTOBERNSAREFORTTTHEYWOUNDTHESOURCEONMENUSBEGINNINGEXTRACTION";

    #[test]
    fn both_nodes_are_xf_family_and_not_layer_forming() {
        for n in [base10(), straddling()] {
            assert_eq!(n.family(), Family::Xf);
            assert!(!n.layer_forming());
            assert!(!n.terminal());
        }
    }

    /// Hand-computed: `@` is first seen so it is `0`, `C` second so `1`, `B` third so
    /// `2`; the repeat of `@` reuses `0` rather than taking a fresh digit.
    #[test]
    fn base10_assigns_digits_by_first_appearance() {
        let out = base10()
            .apply(&Repr::bytes(b"@CB@?C".to_vec()), &Params::new())
            .unwrap();
        assert_eq!(out.data, b"012031");
    }

    #[test]
    fn base10_skips_whitespace_so_grouping_does_not_change_the_labels() {
        let flat = base10()
            .apply(&Repr::bytes(b"@CB@?C".to_vec()), &Params::new())
            .unwrap();
        let grouped = base10()
            .apply(&Repr::bytes(b"@CB\n @?C\r\n".to_vec()), &Params::new())
            .unwrap();
        assert_eq!(flat.data, grouped.data);
    }

    #[test]
    fn base10_rejects_an_eleventh_symbol() {
        let e = base10()
            .apply(&Repr::bytes(b"abcdefghijk".to_vec()), &Params::new())
            .unwrap_err();
        assert!(e.to_string().contains("11th"), "{e}");
    }

    /// Hand-computed over a two-cell toy board. Straddling digit `1` selects the
    /// second row; `0` and `2` stand alone. `0` -> `A`, `2` -> `B`, `13` -> `C`.
    #[test]
    fn straddling_decodes_a_hand_computed_board() {
        let p = params! {
            "straddle" => "1",
            "layout" => "A.B......./...C......",
        };
        let out = straddling()
            .apply(&Repr::bytes(b"0213".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"ABC");
    }

    /// The declared `layout` is already authoritative for a non-letter
    /// alphabet, with no fix needed (see the module docs): the same toy
    /// board as `straddling_decodes_a_hand_computed_board`, but with `A`,
    /// `B`, `C` replaced by punctuation, round trips identically -- proving
    /// `Board::parse` never actually gated cell content to
    /// `is_ascii_alphabetic`.
    #[test]
    fn punctuation_alphabet_round_trips() {
        let n = straddling();
        let dec = params! {
            "straddle" => "1",
            "layout" => "!.@......./...#......",
        };
        let enc = params! {
            "straddle" => "1",
            "layout" => "!.@......./...#......",
            "direction" => "encode",
        };
        let out = n.apply(&Repr::bytes(b"0213".to_vec()), &dec).unwrap();
        assert_eq!(out.data, b"!@#");

        let back = n.apply(&out, &enc).unwrap();
        assert_eq!(back.data, b"0213");
    }

    /// **Recovered parameters, not documented by the corpus.** rev3's record gives the
    /// checkerboard no layout and no straddling digits, and its final substitution no
    /// alphabet. These values are the unique solution of the alignment described in
    /// the module docs, and this test decodes rev3 end to end from the raw ciphertext
    /// to prove it — including the `reverse` the record omits.
    #[test]
    fn rev3_layout_and_straddle_digits_are_pinned_by_the_recorded_plaintext() {
        let reg = registry();
        let digits = base10()
            .apply(&Repr::bytes(REV3_CIPHERTEXT.to_vec()), &Params::new())
            .unwrap();
        let reversed = reg
            .get("reverse")
            .unwrap()
            .apply(&digits, &Params::new())
            .unwrap();
        let p = params! {"straddle" => REV3_STRADDLE, "layout" => REV3_LAYOUT};
        let out = straddling().apply(&reversed, &p).unwrap();
        assert_eq!(out.data, REV3_PLAINTEXT);

        // Without the undocumented reverse the same board cannot decode the stream at
        // all: it runs onto an empty cell a few codes in.
        assert!(straddling().apply(&digits, &p).is_err());
    }

    /// The prefix property, stated as a test: the leading `1` of `14` must not be read
    /// as the single-digit cell for `1`.
    #[test]
    fn straddling_two_digit_codes_take_precedence_over_single_digits() {
        let p = params! {"straddle" => REV3_STRADDLE, "layout" => REV3_LAYOUT};
        // 14 -> T, 0 -> C, 32 -> O
        let out = straddling()
            .apply(&Repr::bytes(b"14032".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"TCO");
    }

    #[test]
    fn straddling_round_trips_through_encode() {
        let n = straddling();
        let dec = params! {"straddle" => REV3_STRADDLE, "layout" => REV3_LAYOUT};
        let enc = params! {
            "straddle" => REV3_STRADDLE, "layout" => REV3_LAYOUT, "direction" => "encode"
        };

        let plain = Repr::bytes(REV3_PLAINTEXT.to_vec());
        let coded = n.apply(&plain, &enc).unwrap();
        assert!(coded.data.iter().all(|b| b.is_ascii_digit()));
        assert_eq!(n.apply(&coded, &dec).unwrap().data, plain.data);
    }

    #[test]
    fn straddling_rejects_malformed_boards() {
        let n = straddling();
        let d = Repr::bytes(b"0".to_vec());
        for bad in [
            // no straddle digits
            params! {"straddle" => "", "layout" => "ABCDEFGHIJ"},
            // straddle digit is not a digit
            params! {"straddle" => "X", "layout" => "ABCDEFGHIJ/ABCDEFGHIJ"},
            // duplicate straddle digit
            params! {"straddle" => "11", "layout" => "AB.D.FGHIJ/ABCDEFGHIJ/ABCDEFGHIJ"},
            // wrong number of rows
            params! {"straddle" => "13", "layout" => "A.C.EFGHIJ/ABCDEFGHIJ"},
            // wrong row width
            params! {"straddle" => "1", "layout" => "A.CDEFGHIJ/ABCDEFGHI"},
            // the straddling digit's own cell in the top row is not empty
            params! {"straddle" => "1", "layout" => "ABCDEFGHIJ/ABCDEFGHIJ"},
            // unknown direction
            params! {"straddle" => "1", "layout" => "A.CDEFGHIJ/ABCDEFGHIJ", "direction" => "up"},
        ] {
            assert!(
                n.apply(&d, &bad).is_err(),
                "should have rejected {}",
                bad.canonical_json()
            );
        }
        // both parameters are required
        assert!(n.apply(&d, &params! {"straddle" => "1"}).is_err());
        assert!(n
            .apply(&d, &params! {"layout" => "A.CDEFGHIJ/ABCDEFGHIJ"})
            .is_err());
    }

    #[test]
    fn straddling_rejects_malformed_input() {
        let n = straddling();
        let p = params! {"straddle" => "1", "layout" => "A.B......./...C......"};

        // a non-digit byte has no reading
        assert!(n.apply(&Repr::bytes(b"0Z".to_vec()), &p).is_err());
        // a dangling row selector
        let e = n.apply(&Repr::bytes(b"01".to_vec()), &p).unwrap_err();
        assert!(e.to_string().contains("ends with row selector"), "{e}");
        // an empty cell is reported rather than emitted as '.'
        let e = n.apply(&Repr::bytes(b"9".to_vec()), &p).unwrap_err();
        assert!(e.to_string().contains("empty cell"), "{e}");
    }

    /// Whitespace in the digit stream is ignored, so a grouped transcription decodes
    /// identically to a flat one.
    #[test]
    fn straddling_skips_whitespace() {
        let p = params! {"straddle" => "1", "layout" => "A.B......./...C......"};
        let out = straddling()
            .apply(&Repr::bytes(b"02 13\n".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"ABC");
    }
}
