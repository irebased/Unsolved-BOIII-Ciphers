//! One-time pad (letter-keyed Vigenère-style shift), matching
//! geocachingtoolbox.com's implementation.
//!
//! The key is filtered down to just its letters (case-insensitive), in order,
//! each contributing a shift value 0-25. Plaintext bytes that aren't letters
//! pass through unchanged *and do not consume a key letter* — the key
//! position only advances on an actual substitution. Output case follows the
//! input character's case, letter by letter. Decrypting subtracts the key
//! shift (`(charVal - keyVal + 26) % 26`); encrypting (test-only here, since
//! this crate is decrypt-direction) adds it.
//!
//! # Key shorter than the text
//!
//! If the key runs out before the text does, every remaining character is
//! copied through unchanged, and the site appends a literal warning line
//! *inside the result textarea* — i.e. into the copyable text itself, not
//! just the page:
//! `"\n\nPlease note: The key is shorter than the text, not everything might be substituted."`
//! [`decode`] reproduces this exactly (`with_note: true`); node behaviour
//! matches the site's default (the note is unconditional whenever this
//! happens, there is no toggle for it on the page).
//!
//! # No valid key
//!
//! If the key contains no letters at all, the site short-circuits to "No
//! valid key found" and performs no substitution whatsoever — modelled here
//! as a rejected `key` parameter, since there is nothing to decrypt with.
//!
//! # `strip_non_alphabet` audited: already available, no fix needed
//!
//! This node already runs the standard [`crate::classical::toolfmt`] pipeline
//! (`OTP_SCHEMA` already splices in `artifact_param_specs!()`, and `apply`
//! already calls `read_input_norm`/`read_output_fmt`), so `strip_non_alphabet`
//! and `input_alphabet` were already present in the schema and already
//! functional -- `default_input_norm()` returning `InputNorm::default()` means
//! the toggle defaults off (matching the site-faithful passthrough described
//! above), and a caller who sets it must also give `input_alphabet`, since
//! (like `xf:autokey`) there is no baked-in default alphabet to fall back to
//! for a node whose site never strips on its own. See
//! `strip_non_alphabet_is_off_by_default_and_removes_digits_when_enabled`
//! below for the differential proof.
//!
//! # Artifacts
//!
//! Output is written into `oneTimePadDiv` via `.innerHTML =`
//! (`copy_artifact_risk: HIGH`), so the default [`OutputFmt`] carries a
//! trailing CRLF.

use crate::classical::toolfmt::{read_input_norm, read_output_fmt, InputNorm, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::repr::Repr;
use crate::{artifact_param_specs, register_node};

const OTP_SCHEMA: &[ParamSpec] = &artifact_param_specs!(ParamSpec::req(
    "key",
    ParamType::Str,
    "one-time pad key; only its letters (case-insensitive) are used, in order",
));

const SHORT_KEY_NOTE: &str =
    "\n\nPlease note: The key is shorter than the text, not everything might be substituted.";

/// Extract the key's letters, in order, as shift values 0-25 (`'a'`/`'A'` = 0).
fn key_values(key: &str) -> Vec<u8> {
    key.bytes()
        .filter(|b| b.is_ascii_alphabetic())
        .map(|b| b.to_ascii_lowercase() - b'a')
        .collect()
}

/// Decrypt `text` with `key_values` (see [`key_values`]), appending the
/// site's "key too short" note verbatim if the key ran out before the text
/// did. `key_values` must be non-empty (checked by the caller).
pub fn decode(text: &[u8], key_values: &[u8]) -> Vec<u8> {
    apply_shift(text, key_values, false)
}

/// Encrypt `text` with `key_values`. Test-only: this crate is
/// decrypt-direction, so nothing but the test suite (proving [`decode`]
/// agrees with the site's algorithm) needs it.
#[cfg(test)]
fn encode(text: &[u8], key_values: &[u8]) -> Vec<u8> {
    apply_shift(text, key_values, true)
}

fn apply_shift(text: &[u8], key_values: &[u8], encrypt: bool) -> Vec<u8> {
    let mut out = Vec::new();
    let mut key_pos = 0usize;
    let mut noted = false;
    for &b in text {
        if key_pos == key_values.len() {
            if !noted {
                out.extend_from_slice(SHORT_KEY_NOTE.as_bytes());
                noted = true;
            }
            out.push(b);
            continue;
        }
        if !b.is_ascii_alphabetic() {
            out.push(b);
            continue;
        }
        let char_val = b.to_ascii_lowercase() - b'a';
        let shift = key_values[key_pos];
        let new_val = if encrypt {
            (char_val + shift) % 26
        } else {
            (char_val + 26 - shift) % 26
        };
        let new_char = b'a' + new_val;
        out.push(if b.is_ascii_uppercase() {
            new_char.to_ascii_uppercase()
        } else {
            new_char
        });
        key_pos += 1;
    }
    out
}

fn default_input_norm() -> InputNorm {
    InputNorm::default()
}

fn default_output_fmt() -> OutputFmt {
    OutputFmt {
        trailing: Trailing::CrLf,
        ..Default::default()
    }
}

/// One-time pad, decrypting: a letter-keyed Vigenère-style shift.
pub struct Otp;

impl Node for Otp {
    fn name(&self) -> &'static str {
        "otp"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        OTP_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = params.req_str("otp", "key")?;
        let key_vals = key_values(key);
        if key_vals.is_empty() {
            return Err(Error::bad_param("otp", "key", "no valid (letter) key found"));
        }

        let in_norm = read_input_norm("otp", params, default_input_norm())?;
        let out_fmt = read_output_fmt("otp", params, default_output_fmt())?;

        let normalised = in_norm.apply(&input.data);
        let transformed = decode(&normalised, &key_vals);
        let formatted = out_fmt.apply(&transformed);

        Ok(Repr::new(formatted, input.display))
    }
}

register_node!(OTP => || Box::new(Otp));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    #[test]
    fn key_values_filters_and_lowercases() {
        assert_eq!(key_values("Ab3c!"), vec![0, 1, 2]);
    }

    #[test]
    fn key_values_empty_when_no_letters() {
        assert_eq!(key_values("123!"), Vec::<u8>::new());
    }

    #[test]
    fn encode_then_decode_round_trips() {
        let samples: &[&[u8]] = &[
            b"hello world",
            b"The Quick Brown Fox 123!",
            b"zzz aaa",
            b"a",
        ];
        // Long enough to cover every sample's letter count, so the "key too
        // short" note never triggers here; that path is covered separately.
        let key = key_values(&"zombiesarecool".repeat(4));
        for sample in samples {
            let encoded = encode(sample, &key);
            let decoded = decode(&encoded, &key);
            assert_eq!(&decoded, sample, "sample={sample:?} encoded={encoded:?}");
        }
    }

    #[test]
    fn decode_preserves_case_per_character() {
        let key = key_values("b"); // shift of 1
        // Encrypt 'A' with shift 1 -> 'B'; decrypting 'B' recovers 'A'.
        assert_eq!(decode(b"B", &key), b"A");
        assert_eq!(decode(b"b", &key), b"a");
    }

    #[test]
    fn decode_passes_non_letters_through_without_consuming_key() {
        let key = key_values("ab"); // shifts [0, 1]
        // '!' passes through, doesn't consume a key letter, so both 'a's use
        // key positions 0 and 1 respectively (shift 0, then shift 1).
        let out = decode(b"a!a", &key);
        // key[0]=0 -> 'a'-0='a'; key[1]=1 -> 'a'-1='z' (wrapping)
        assert_eq!(out, b"a!z");
    }

    #[test]
    fn decode_appends_note_once_when_key_shorter_than_text() {
        let key = key_values("a"); // single shift-0 key letter
        let out = decode(b"ab", &key);
        let mut want = vec![b'a'];
        want.extend_from_slice(SHORT_KEY_NOTE.as_bytes());
        want.push(b'b');
        assert_eq!(out, want);
    }

    #[test]
    fn decode_note_not_appended_when_key_covers_the_whole_text() {
        let key = key_values("ab");
        let out = decode(b"ab", &key);
        assert!(!out.ends_with(SHORT_KEY_NOTE.as_bytes()));
        assert_eq!(std::str::from_utf8(&out).unwrap().find("Please note"), None);
    }

    #[test]
    fn otp_node_decodes_with_key() {
        let n = registry().get("otp").unwrap();
        let p = params! {"key" => "b"};
        let out = n.apply(&Repr::bytes(b"B".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"A\r\n");
    }

    #[test]
    fn otp_node_missing_key_errors() {
        let n = registry().get("otp").unwrap();
        let p = params! {};
        let err = n.apply(&Repr::bytes(b"B".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::MissingParam { .. }), "{err}");
    }

    #[test]
    fn otp_node_key_with_no_letters_errors() {
        let n = registry().get("otp").unwrap();
        let p = params! {"key" => "123!"};
        let err = n.apply(&Repr::bytes(b"B".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    /// `strip_non_alphabet` was already wired up via the shared toolfmt
    /// plumbing; this is the differential proof (see the module docs), not a
    /// fix. Off by default, matching `otp_node_decodes_with_key`'s
    /// passthrough behaviour; on, a non-letter byte is removed from the
    /// medium entirely rather than merely skipped in place.
    #[test]
    fn strip_non_alphabet_is_off_by_default_and_removes_digits_when_enabled() {
        let n = registry().get("otp").unwrap();
        let ct = b"B9B".to_vec();
        // two shift-1 letters so both 'B's are decrypted (a shorter key would
        // trigger the unrelated "key too short" note instead)
        let key = "bb";

        let default = n
            .apply(&Repr::bytes(ct.clone()), &params! {"key" => key})
            .unwrap();
        assert_eq!(default.data, b"A9A\r\n", "default: passthrough, unchanged");

        let stripped = n
            .apply(
                &Repr::bytes(ct),
                &params! {
                    "key" => key,
                    "strip_non_alphabet" => true,
                    "input_alphabet" => "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",
                    "trailing" => "none",
                },
            )
            .unwrap();
        assert_eq!(stripped.data, b"AA", "'9' removed from the medium entirely");
    }

    #[test]
    fn otp_trailing_can_be_disabled_via_param() {
        let n = registry().get("otp").unwrap();
        let p = params! {"key" => "b", "trailing" => "none"};
        let out = n.apply(&Repr::bytes(b"B".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"A");
    }

    #[test]
    fn otp_preserves_display() {
        let n = registry().get("otp").unwrap();
        let p = params! {"key" => "b"};
        let out = n
            .apply(&Repr::new(b"B".to_vec(), Display::Hex), &p)
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn otp_is_xf_family_and_not_layer_forming() {
        let n = registry().get("otp").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
