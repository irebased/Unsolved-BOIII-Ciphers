var _____WB$wombat$assign$function_____=function(name){return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name))||self[name];};if(!self.__WB_pmw){self.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opens = _____WB$wombat$assign$function_____("opens");
//*******************************(service-layer)
//*******************************
//*******************************

function CTOTrithemiusAlgorithm(alpha)
{

    var alphabet=alpha;

    this.getAlphabet=getAlphabet;
    function getAlphabet()
    {
    	return alphabet;
    }

	this.crypt = crypt;
	function crypt (key, text, type, handle)
	{
		var alphaLen = alphabet.length;
    	var i, j = 0;
    	var zp, kp  = 0;
    	var chiffre = "";

    	if (key != "")
    	{
     	  for (i=0; i < text.length; i++)
     	  {
          	 zp = alphabet.indexOf(text.charAt(i));
          	 if (zp >= 0)
          	 {
             	 kp      = alphabet.indexOf(key.charAt(j));
                 if (type=="encrypt") chiffre = chiffre + alphabet.charAt((zp+kp) % alphaLen);
                 else                 chiffre = chiffre + alphabet.charAt((alphaLen+(zp-kp)) % alphaLen);
                 j = (j+1) % key.length;
             }
             else
			 	if (handle == "ignore" || text.charCodeAt(i) == 13 || text.charCodeAt(i) == 32 || text.charCodeAt(i) == 10)
					 chiffre = chiffre + text.charAt(i);
          }
         }
         return chiffre;
    }
}


//*******************************(gui-access-layer)
//*******************************
//*******************************

function CTOTrithemiusGuiAccess ()
{
	var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var cryptoclass = new CTOTrithemiusAlgorithm(alphabet);
	var ctolib = new CTOLib();





	//@author Christian Sieche
	//@version 23.12.2008
	//@params:
	// type = "encode" or "decode"

    this.trithemiusCrypt = trithemiusCrypt;
    function trithemiusCrypt(type) //starts encryption
    {

        //set value to radiogroup
        if (type == "encode")
        {
            document.CTOTrithemiusForm1.code[0].checked = true;
            document.CTOTrithemiusForm1.code[1].checked = false;
        }

        if (type == "decode")
        {
            document.CTOTrithemiusForm1.code[0].checked = false;
            document.CTOTrithemiusForm1.code[1].checked = true;
        }
        //get value of radiogroup
        var type;
        for (var i = 0; i < document.CTOTrithemiusForm1.code.length; i++)

            if (document.CTOTrithemiusForm1.code[i].checked)
                type = document.CTOTrithemiusForm1.code[i].value;
        var codtxtlayout = $('codtxt')
        var orgtxtlayout = $('orgtxt')

        if (type == "encode")
        {
			document.getElementById('codtxt').className = 'ctoformcss-txtinput-style ctoformcss-default-input-size';
            var orgtext = document.getElementById("orgtxt").value;
            orgtext = orgtext.toUpperCase();
            var isInputOK = ctolib.inputString(orgtext, alphabet);

            if (isInputOK == false)
            {
                document.getElementById('orgtxt').className = 'ctoformcss-invalid-style ctoformcss-default-input-size';
            }
            else
            {
                document.getElementById('orgtxt').className = 'ctoformcss-txtinput-style ctoformcss-default-input-size';
            }
            var output;

            if (document.getElementById('signs').checked == true)
            {
                output = cryptoclass.crypt("ABCDEFGHIJKLMNOPQRSTUVWXYZ", orgtext, "encrypt", "ignore");
            }
            else
                output = cryptoclass.crypt("ABCDEFGHIJKLMNOPQRSTUVWXYZ", orgtext, "encrypt", "remove");

            if (document.getElementById("clean").checked == true)
            {
                output = output.replace(/ /g, "");
                var tmp = ctolib.str_split(output, 5);
                output = tmp.join(" ");
            }
            document.getElementById("codtxt").value = output;
        }

        if (type == "decode")
        {
			document.getElementById('orgtxt').className = 'ctoformcss-txtinput-style ctoformcss-default-input-size';
            var codtext = document.getElementById("codtxt").value;

                codtext = codtext.toUpperCase();

            var isInputOK = ctolib.inputString(codtext, alphabet);

            if (isInputOK == false)
            {
                document.getElementById('codtxt').className = 'ctoformcss-invalid-style ctoformcss-default-input-size';
            }
            else
            {
                document.getElementById('codtxt').className = 'ctoformcss-txtinput-style ctoformcss-default-input-size';
            }
            var output;

            if (document.getElementById('signs').checked == true)
            {
                output = cryptoclass.crypt("ABCDEFGHIJKLMNOPQRSTUVWXYZ", codtext, "decrypt", "ignore");
            }
            else
                output = cryptoclass.crypt("ABCDEFGHIJKLMNOPQRSTUVWXYZ", codtext, "decrypt", "remove");
            document.getElementById("orgtxt").value = output;
     }   
    }


}





//create trithemius object with alphabet and start necessary scripts
var CTOTrithemiusScripts = new CTOTrithemiusGuiAccess();
}

/*
     FILE ARCHIVED ON 10:10:47 Apr 09, 2015 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 07:19:59 Mar 29, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 0.651
  exclusion.robots: 0.024
  exclusion.robots.policy: 0.011
  esindex: 0.011
  cdx.remote: 13.998
  LoadShardBlock: 131.843 (3)
  PetaboxLoader3.datanode: 142.06 (5)
  load_resource: 941.334 (2)
  PetaboxLoader3.resolve: 862.83 (2)
*/