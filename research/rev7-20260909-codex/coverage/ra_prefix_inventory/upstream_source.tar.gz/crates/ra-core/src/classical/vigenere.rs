//! Vigenère cipher, one node per site emulated.
//!
//! We had no Vigenère node at all before this file. Three sites are ported
//! here, each its own [`Node`] because their conventions genuinely diverge
//! (see "Cross-site divergences" below) — merging them would corrupt the
//! content-addressed node identity a sweep relies on for selective
//! invalidation.
//!
//! - [`CtoVigenere`] emulates CrypTool Online's Vigenère app (vendored,
//!   Apache-2.0, at `.claude/vendor/cto/_ctoApps/vigenere/src/vigenere/` and
//!   `src/common/{vigenere,crypt,base}.js`). Pure JS, not Pyodide/Python —
//!   `common/vigenere.js`'s `Vigenere.encrypt`/`decrypt` is a five-line
//!   integer add/subtract; no Python is loaded by this particular app.
//! - [`GeocachingVigenere`] emulates geocachingtoolbox.com's `vigenereCipher()`
//!   (verbatim JS in `docs/toolsites/geocachingtoolbox.json`, tool "Vigenère
//!   cipher"). The sibling tool "Vigenère cipher decoder" (`page=
//!   vigenereCipherSolve`) is **not** ported: its extracted JS is only the
//!   page's shared login-dialog boilerplate, its page has no key input and no
//!   result element, and its `page_id` (`...Solve`) together with the single
//!   `bericht` textarea is consistent only with a Kasiski/frequency
//!   cryptanalysis form — i.e. a solver, out of scope per the task ("we are
//!   not porting cryptanalysis").
//! - [`PracticalCryptoVigenere`] emulates the live JS calculator on
//!   practicalcryptography.com's "Vigenere, Gronsfeld and Autokey Ciphers"
//!   page (fetched directly — the vendored `docs/toolsites/
//!   practicalcrypto_cryptocorner.json` catalogs this page by URL only,
//!   `implementation_coverage` there confirms its JS was never extracted).
//!   That page title covers three named ciphers, but **only Vigenère has a
//!   live tool**: the `Encrypt`/`Decrypt` `<script>` block. Gronsfeld and
//!   Autokey are discussed in prose and demonstrated only via `pycipher`
//!   Python snippets in a `<pre>` — not an interactive site tool — so neither
//!   gets a node from this site.
//!
//! # Cross-site divergences (the reason these are three nodes, not one)
//!
//! | convention | CTO | geocachingtoolbox | practicalcryptography |
//! |---|---|---|---|
//! | non-key-alphabet chars in the key | dropped (`skip_non_letter_keys`, default on) or kept as a no-op key slot | dropped unconditionally, no toggle | dropped unconditionally (stripped before any processing) |
//! | non-alphabet chars in the text | passed through unchanged by default (`delete_non_letters` off) | always passed through, no toggle | **stripped entirely**, no toggle |
//! | keystream advance | only on alphabetic text chars, both sites | only on alphabetic text chars | only on alphabetic text chars (trivially true: non-letters were already stripped) |
//! | output case | preserves each character's own input case by default; `convert_to_upcase` can force upper | preserves each character's own input case, no toggle | **always lowercase**, no toggle |
//! | alphabet | configurable (default `A-Z`/`a-z`, offset 0) | fixed lowercase `a-z`, not configurable | fixed lowercase `a-z`, not configurable |
//! | grouping / whitespace deletion | both configurable (`group_by_5s`, `delete_whitespace`) | neither | neither |
//! | minimum key length | none enforced | none enforced (empty key just means no-op) | **key must be >= 2 letters after stripping**, or the site's UI refuses to run |
//!
//! practicalcryptography's "strip everything, force lowercase" convention is
//! the standout divergence — verified directly against the page's own worked
//! example (`ISWXVIBJEXIGGBOCEWKBJEVIGGQS`, case-insensitively equal to our
//! ground truth) and against its `pycipher` demonstration.

use crate::classical::toolfmt::{self, CaseFold, InputNorm, OutputFmt};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

/// A plain 26-letter alphabet, used only by the [`CaseFoldedAlphabet`] tests
/// below (the case-folding trick it models is no longer how `cto_vigenere`
/// itself works -- see that section's module docs -- but it's still how
/// [`GeocachingVigenere`] and [`PracticalCryptoVigenere`] operate).
#[cfg(test)]
const DEFAULT_ALPHABET: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

/// Case-insensitive alphabet lookup, matching CTO's dual-block (`A-Z`
/// offset-0 and `a-z` offset-0) trick: a letter's numeric value never depends
/// on its case, so a single canonical-uppercase alphabet plus a per-character
/// case flag reproduces it exactly for any alphabet whose members are all
/// ASCII letters (the only kind of alphabet CTO's default configuration, or
/// any config this node accepts, ever contains).
struct CaseFoldedAlphabet {
    upper: Vec<u8>,
}

impl CaseFoldedAlphabet {
    fn build(node: &str, raw: &str) -> Result<Self> {
        if raw.is_empty() || !raw.bytes().all(|b| b.is_ascii_alphabetic()) {
            return Err(Error::bad_param(
                node,
                "alphabet",
                "must be non-empty and contain only ASCII letters",
            ));
        }
        let upper: Vec<u8> = raw.bytes().map(|b| b.to_ascii_uppercase()).collect();
        Ok(Self { upper })
    }

    fn len(&self) -> usize {
        self.upper.len()
    }

    /// Position of `b` in the alphabet, case-insensitively; `None` if `b`
    /// isn't a member.
    fn pos(&self, b: u8) -> Option<usize> {
        self.upper.iter().position(|&a| a == b.to_ascii_uppercase())
    }

    /// The alphabet member at `idx`, cased to match `like` (the original
    /// character occupying this position, whose case selects upper/lower).
    fn char_at(&self, idx: usize, like: u8) -> u8 {
        let c = self.upper[idx];
        if like.is_ascii_lowercase() {
            c.to_ascii_lowercase()
        } else {
            c
        }
    }
}

// ---------------------------------------------------------------------------
// CrypTool Online
// ---------------------------------------------------------------------------
//
// # 2016 vs modern: rewritten to match `vigenere.js` (not the modern rewrite)
//
// This node was originally ported from the *current* `cryptool-org/cto`
// repository (a later rewrite), using a case-folding trick (a single
// canonical-uppercase alphabet plus a per-character case flag) borrowed from
// that modern source's own dual-block-but-case-normalised convention. The
// project owner has since supplied the **2016 sources** (Wayback snapshot of
// cryptool-online.org, timestamp `20160909182347`), committed at
// `docs/toolsites/cryptool2016/js/vigenere.js`
// (`CTOVigenereAlgorithm.crypt`) — the era that actually made these puzzles.
// Running that JS directly under Node (task scratchpad
// `jstest/run_vigenere.js`) revealed the 2016 tool works completely
// differently, and the previous port is wrong on three points:
//
// 1. **The alphabet is a flat, case-*sensitive* concatenation, not a
//    case-folded 26-symbol alphabet with case tracked separately.** The
//    default alphabet (both upper/lower toggles checked, `Vigenere.htm`'s
//    page-load state) is the 52-character string `"A"`..`"Z"` followed by
//    `"a"`..`"z"` — `A` and `a` are *different, unrelated positions* 0 and
//    26. `zp`/`kp` (`vigenere.js:37,40`) are plain `indexOf`s into this flat
//    string, and the output char is `alphabet.charAt((zp±kp) % alphaLen)`
//    with `alphaLen = 52` — so a shift can cross the case boundary and
//    change a letter's case as a side effect, which does *not* generally
//    equal case-preserving Vigenère. E.g. key `"SECRETKEY"` over `"The quick
//    brown fox jumps over the lazy dog."` decrypts/encrypts to `"llg HyBmo
//    zJsyE jHH nSEtu FzxB xFw pcQC wyk."` on the real 2016 machine — compare
//    the previous (modern-derived, wrong for 2016) claimed ground truth
//    `"Llg hybmo zjsye jhh nsetu fzxb xfw pcqc wyk."`, which preserves each
//    letter's own case and is *not* what `vigenere.js` produces.
// 2. **An empty (post-cleaning) key makes the tool emit nothing at all, not
//    identity.** `vigenere.js:33`'s `if (key != "") { ... }` wraps the
//    *entire* per-character loop; when it's false, `chiffre` never leaves
//    `""`, regardless of `text`'s length or contents. This is unconditional
//    on the decrypt arm too (the branches share one `crypt` function).
// 3. **The key is always stripped to the alphabet, with no toggle to keep a
//    non-alphabet key character as a no-op slot.** `checkKey()` always runs
//    `ctolib.cleanInputString(key, alphabet, false)` before `crypt` is ever
//    called; 2016 has no "skip non-letter keys" checkbox at all (that concept
//    doesn't correspond to anything in `Vigenere.htm`).
//
// What *does* still hold from the earlier port: the `signs` checkbox
// (`Vigenere.htm`, id `signs`, label "Keep non-alphabet characters",
// **checked by default**) gates whether text characters outside the
// alphabet survive at all (`vigenere.js:46`) — but even when unchecked,
// carriage return/space/newline still always pass through
// (`text.charCodeAt(i) == 13 || 32 || 10`), so it is not a blanket "delete
// non-letters" — only whitespace is exempt from the drop. This node's
// `keep_non_alphabet` param models that single toggle directly (default
// `true`, matching the site default), rather than the previous two
// independent `delete_whitespace`/`delete_non_letters` params, which implied
// a level of independent control this site never actually offered.
//
// `casesensitiv` (site default: checked, i.e. no forced case) is not a
// separate param here — forcing input to upper/lower before this node's own
// alphabet lookup, which is exactly what happens when `casesensitiv` is
// unchecked, is already what the generic `input_case` artifact param does.

/// The site's default alphabet with only the upper/lower toggles enabled (its
/// initial `Vigenere.htm` page-load state): 52 characters, `A`-`Z` then
/// `a`-`z` as two *distinct* blocks of positions, not a case-folded 26-letter
/// alphabet — see the module docs above for why this distinction matters.
pub const CTO_DEFAULT_ALPHABET: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

const CTO_VIGENERE_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(
    ParamSpec::req(
        "key",
        ParamType::Str,
        "Vigenère key; characters outside the alphabet are always stripped before use \
         (ctolib.js's cleanInputString, unconditional -- 2016 has no toggle to keep them)",
    ),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "flat, case-sensitive alphabet string for text and key positions (default: 52 \
         chars, A-Z then a-z as distinct blocks, matching the site's upper+lower toggles)",
    ),
    ParamSpec::opt(
        "keep_non_alphabet",
        ParamType::Bool,
        "keep text characters outside the alphabet in the output verbatim (default: true, \
         matching the site's default-checked 'Keep non-alphabet characters'); when false, \
         only carriage return/space/newline still pass through -- everything else outside \
         the alphabet is dropped, matching vigenere.js's 'remove' handling exactly",
    ),
);

/// Clean `raw` to the characters literally (case-sensitively) present in
/// `alphabet`, matching `ctolib.js`'s `cleanInputString(key, alphabet,
/// false)` — which `checkKey()` in `vigenere.js` always applies to the key
/// before `crypt` runs, unconditionally, with no site toggle.
pub(crate) fn cto2016_clean_key(alphabet: &[char], raw: &str) -> Vec<char> {
    raw.chars().filter(|c| alphabet.contains(c)).collect()
}

/// `crypt(key, text, type, handle)`, transliterated from `vigenere.js:26-51`.
/// `encrypt=false` runs the `decrypt` arm. `alphabet` positions are matched
/// case-sensitively (see the module docs' point 1); `key` must already be
/// cleaned to the alphabet (point 3), and an empty `key` yields `""`
/// unconditionally (point 2), matching `vigenere.js:33`'s `if (key != "")`
/// gate around the entire loop.
pub(crate) fn cto2016_crypt(alphabet: &[char], key: &[char], text: &str, keep_non_alphabet: bool, encrypt: bool) -> String {
    if key.is_empty() {
        return String::new();
    }
    let n = alphabet.len() as i64;
    let mut out = String::new();
    let mut j = 0usize;
    for c in text.chars() {
        if let Some(zp) = alphabet.iter().position(|&a| a == c) {
            // `key` is pre-cleaned to `alphabet` members, so this is always
            // found under normal use; `unwrap_or(0)` only guards a caller
            // that bypassed cleaning (matching JS's own indexOf==-1 -> -1
            // arithmetic would be a deeper rabbit hole not worth chasing).
            let kp = alphabet
                .iter()
                .position(|&a| a == key[j % key.len()])
                .unwrap_or(0) as i64;
            let zp = zp as i64;
            let idx = if encrypt { (zp + kp) % n } else { (n + zp - kp) % n };
            out.push(alphabet[idx as usize]);
            j += 1;
        } else if keep_non_alphabet || matches!(c, '\r' | ' ' | '\n') {
            out.push(c);
        }
        // else: dropped entirely, matching `handle == "remove"` on a
        // non-whitespace, non-alphabet character.
    }
    out
}

/// CrypTool Online's Vigenère app, matching the 2016 machine
/// (`docs/toolsites/cryptool2016/js/vigenere.js`) — see the module docs for
/// the divergence from this node's earlier, modern-derived version.
///
/// Ground truth: `vigenere.js` run directly under Node with a minimal
/// DOM/global shim (task scratchpad `jstest/run_vigenere.js`); see the tests
/// below.
pub struct CtoVigenere;

impl Node for CtoVigenere {
    fn name(&self) -> &'static str {
        "cto_vigenere"
    }
    fn version(&self) -> &'static str {
        "2.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CTO_VIGENERE_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let input_norm = toolfmt::read_input_norm("cto_vigenere", params, InputNorm::default())?;
        let output_fmt = toolfmt::read_output_fmt("cto_vigenere", params, OutputFmt::default())?;

        let key_raw = params.req_str("cto_vigenere", "key")?;
        let alphabet_raw = params.opt_str("alphabet").unwrap_or(CTO_DEFAULT_ALPHABET);
        if alphabet_raw.is_empty() {
            return Err(Error::bad_param("cto_vigenere", "alphabet", "must not be empty"));
        }
        let alphabet: Vec<char> = alphabet_raw.chars().collect();
        let keep_non_alphabet = params.opt_bool("keep_non_alphabet", true);

        let key = cto2016_clean_key(&alphabet, key_raw);
        let data = input_norm.apply(&input.data);
        let text = String::from_utf8(data)
            .map_err(|_| Error::node_failed("cto_vigenere", "input is not valid UTF-8"))?;
        let out = cto2016_crypt(&alphabet, &key, &text, keep_non_alphabet, false);
        let out = output_fmt.apply(out.as_bytes());

        Ok(Repr::new(out, input.display))
    }
}

register_node!(CTO_VIGENERE => || Box::new(CtoVigenere));

// ---------------------------------------------------------------------------
// geocachingtoolbox.com
// ---------------------------------------------------------------------------

const GEOCACHING_VIGENERE_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(ParamSpec::req(
    "key",
    ParamType::Str,
    "Vigenère key; non-letter characters are dropped unconditionally (no site toggle)",
),);

const GEOCACHING_ALPHABET: &str = "abcdefghijklmnopqrstuvwxyz";

/// geocachingtoolbox.com's `vigenereCipher()` (`page=vigenereCipher`).
///
/// Fixed lowercase `a`-`z` alphabet, no configuration. Key characters outside
/// `a`-`z` (case-insensitively) are dropped unconditionally — there is no
/// `skip_non_letter_keys`-style toggle on this site. Ciphertext characters
/// outside the alphabet always pass through unchanged. Output case matches
/// each input character's own case (`sub.toUpperCase()` iff the input
/// character wasn't already lowercase) — there is no "force case" toggle
/// either.
///
/// Ground truth: this node's own [`cto_decrypt`]-equivalent logic, hand
/// verified against the vendored JS in `docs/toolsites/geocachingtoolbox.json`
/// (tool "Vigenère cipher") in the module-level test below via an
/// encrypt/decrypt round trip plus a literal transliteration check.
///
/// `output_method` is `innerHTML` per `geocachingtoolbox.json`, and
/// `copy_artifact_risk` is `HIGH` there, so — matching the precedent in
/// `toolfmt`'s own doc comment (an `innerHTML`-backed result carries a
/// Chromium select-all-copy CRLF that a `.value =` tool never does) — this
/// node's default `trailing` is [`toolfmt::Trailing::CrLf`], not `None`.
pub struct GeocachingVigenere;

fn geocaching_style_decrypt(alphabet: &CaseFoldedAlphabet, key_vals: &[usize], data: &[u8]) -> Vec<u8> {
    let m = alphabet.len();
    let mut out = Vec::with_capacity(data.len());
    if key_vals.is_empty() {
        return data.to_vec();
    }
    let mut key_pos = 0usize;
    for &c in data {
        match alphabet.pos(c) {
            Some(v) => {
                let kv = key_vals[key_pos];
                key_pos = (key_pos + 1) % key_vals.len();
                out.push(alphabet.char_at((v + m - kv % m) % m, c));
            }
            None => out.push(c),
        }
    }
    out
}

impl Node for GeocachingVigenere {
    fn name(&self) -> &'static str {
        "geocaching_vigenere"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        GEOCACHING_VIGENERE_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let defaults = OutputFmt {
            case: CaseFold::Preserve,
            grouping: None,
            trailing: toolfmt::Trailing::CrLf,
        };
        let input_norm =
            toolfmt::read_input_norm("geocaching_vigenere", params, InputNorm::default())?;
        let output_fmt = toolfmt::read_output_fmt("geocaching_vigenere", params, defaults)?;

        let key_raw = params.req_str("geocaching_vigenere", "key")?;
        let alphabet = CaseFoldedAlphabet::build("geocaching_vigenere", GEOCACHING_ALPHABET)?;
        let key_vals: Vec<usize> = key_raw.bytes().filter_map(|b| alphabet.pos(b)).collect();

        let data = input_norm.apply(&input.data);
        let out = geocaching_style_decrypt(&alphabet, &key_vals, &data);
        let out = output_fmt.apply(&out);

        Ok(Repr::new(out, input.display))
    }
}

register_node!(GEOCACHING_VIGENERE => || Box::new(GeocachingVigenere));

// ---------------------------------------------------------------------------
// practicalcryptography.com
// ---------------------------------------------------------------------------

const PRACTICALCRYPTO_VIGENERE_SCHEMA: &[ParamSpec] =
    &crate::artifact_param_specs!(ParamSpec::req(
        "key",
        ParamType::Str,
        "Vigenère key; lowercased and stripped to a-z before use, like the site's own key field",
    ),);

/// practicalcryptography.com's live JS calculator on "Vigenere, Gronsfeld and
/// Autokey Ciphers" (`<script>` block defining `Encrypt`/`Decrypt`, fetched
/// directly from `http://practicalcryptography.com/ciphers/classical-era/
/// vigenere-gronsfeld-and-autokey/` — `docs/toolsites/
/// practicalcrypto_cryptocorner.json` only catalogs this page by URL, its
/// `implementation_coverage.tools_with_full_algorithm_extraction` does not
/// include it).
///
/// This is the strictest of the three: both plaintext/ciphertext and key are
/// unconditionally lowercased and stripped to `a`-`z`
/// (`.toLowerCase().replace(/[^a-z]/g, "")`) before any shift is applied,
/// with no toggle to preserve case or punctuation. Output is always
/// lowercase, written via `.value =` (a plain textarea assignment, not
/// `innerHTML`), so unlike the geocachingtoolbox nodes there is no CRLF
/// copy-artifact risk by default.
///
/// # Stripping is the page's input normalisation, not the cipher
///
/// Vigenère genuinely needs an alphabet — unlike a transposition, the shift
/// itself is defined in terms of a character's position within it — but
/// *deleting* characters outside that alphabet is not part of the
/// mathematics: [`CtoVigenere`] above proves as much, since its own site
/// instead passes such characters through unshifted by default
/// (`keep_non_alphabet`). This site's `.replace(/[^a-z]/g, "")` is this
/// specific page's own input normalisation, so — matching the rest of this
/// module — it is reproduced by default (site fidelity) via
/// [`crate::classical::toolfmt`]'s `strip_non_alphabet` param, defaulted to
/// the site's own `a`-`z` alphabet, rather than hardcoded. [`decrypt`]'s
/// substitution loop already only touches `a`-`z` bytes and passes everything
/// else through unshifted and un-consumed from the keystream (matching
/// [`CtoVigenere`]'s `keep_non_alphabet=true`/[`GeocachingVigenere`]'s
/// unconditional pass-through), so setting `strip_non_alphabet=false` runs
/// the same cipher over any medium instead of deleting its non-letters —
/// verified in
/// `practicalcrypto_vigenere_preserves_non_alphabet_bytes_when_stripping_disabled`
/// below.
///
/// The site's own UI additionally refuses to run
/// (`alert("keyword should be at least 2 characters long")`) when the
/// stripped key is shorter than two letters; this node reproduces that as a
/// hard error rather than silently no-op'ing, since the site never produces
/// output in that case either.
///
/// Ground truth: the page's own worked example, key `"fortification"` over
/// plaintext `"defend the east wall of the castle"`, encrypts (site's
/// hand-worked tableau demonstration) to `"ISWXVIBJEXIGGBOCEWKBJEVIGGQS"` —
/// case-insensitively equal to what this node's decrypt path recovers back
/// to plaintext from, confirmed in the test below. Independently
/// cross-checked against the page's own `pycipher` Python demonstration
/// (`Vigenere('HELLO').decipher('KIQPBKXSPSHWEHOSPZQHOINLGAPP') ==
/// 'DEFENDTHEEASTWALLOFTHECASTLE'`), which is the *same* classical Vigenère
/// arithmetic, just over a different sample.
pub struct PracticalCryptoVigenere;

fn strip_to_lower_alpha(s: &[u8]) -> Vec<u8> {
    s.iter()
        .filter(|b| b.is_ascii_alphabetic())
        .map(|b| b.to_ascii_lowercase())
        .collect()
}

/// The site's `Decrypt`, transliterated. Only `a`-`z` bytes are shifted and
/// consume a keystream position; everything else passes through unshifted —
/// see the module docs' "Stripping is the page's input normalisation"
/// section. Under the site's own default normalisation (lower-case, strip to
/// `a`-`z`) every byte reaching here is already an alphabet member, so this
/// is behaviourally identical to the site's own `.charCodeAt` arithmetic in
/// that case; the pass-through only matters when `strip_non_alphabet=false`.
fn practicalcrypto_decrypt(key: &[u8], data: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(data.len());
    let mut key_pos = 0usize;
    for &c in data {
        if c.is_ascii_lowercase() {
            let cv = (c - b'a') as i32;
            let kv = (key[key_pos % key.len()] - b'a') as i32;
            let pv = (cv - kv).rem_euclid(26) as u8;
            out.push(b'a' + pv);
            key_pos += 1;
        } else {
            out.push(c);
        }
    }
    out
}

impl Node for PracticalCryptoVigenere {
    fn name(&self) -> &'static str {
        "practicalcrypto_vigenere"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        PRACTICALCRYPTO_VIGENERE_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let input_defaults = InputNorm {
            trim: false,
            case: CaseFold::Lower,
            strip_whitespace: false,
            strip_outside_alphabet: Some(GEOCACHING_ALPHABET.to_string()),
        };
        let input_norm =
            toolfmt::read_input_norm("practicalcrypto_vigenere", params, input_defaults)?;
        let output_fmt =
            toolfmt::read_output_fmt("practicalcrypto_vigenere", params, OutputFmt::default())?;

        let key_raw = params.req_str("practicalcrypto_vigenere", "key")?;
        let key = strip_to_lower_alpha(key_raw.as_bytes());
        if key.len() < 2 {
            return Err(Error::bad_param(
                "practicalcrypto_vigenere",
                "key",
                "must contain at least two letters after stripping non-letters, matching the \
                 site's own 'keyword should be at least 2 characters long' check",
            ));
        }

        let data = input_norm.apply(&input.data);
        if data.is_empty() {
            return Err(Error::node_failed(
                "practicalcrypto_vigenere",
                "input is empty after normalisation (with default strip_non_alphabet=true, \
                 this means no letters survived stripping to a-z)",
            ));
        }

        let out = practicalcrypto_decrypt(&key, &data);
        let out = output_fmt.apply(&out);

        Ok(Repr::new(out, input.display))
    }
}

register_node!(PRACTICALCRYPTO_VIGENERE => || Box::new(PracticalCryptoVigenere));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    // -- CaseFoldedAlphabet -----------------------------------------------

    #[test]
    fn case_folded_alphabet_rejects_non_letters() {
        assert!(CaseFoldedAlphabet::build("t", "ABC123").is_err());
        assert!(CaseFoldedAlphabet::build("t", "").is_err());
    }

    #[test]
    fn case_folded_alphabet_preserves_case_on_char_at() {
        let a = CaseFoldedAlphabet::build("t", DEFAULT_ALPHABET).unwrap();
        assert_eq!(a.char_at(0, b'x'), b'a'); // lowercase input -> lowercase out
        assert_eq!(a.char_at(0, b'X'), b'A'); // uppercase input -> uppercase out
        assert_eq!(a.pos(b'c'), Some(2));
        assert_eq!(a.pos(b'C'), Some(2));
        assert_eq!(a.pos(b'9'), None);
    }

    // -- cto_vigenere: ground truth from vigenere.js (2016), run under Node --
    //
    // See the module docs' "2016 vs modern" section: the previous version of
    // this test suite pinned modern-derived, case-preserving vectors that the
    // real 2016 machine does not produce. All vectors below were captured by
    // running `docs/toolsites/cryptool2016/js/vigenere.js` directly under
    // Node with a minimal DOM/global shim (task scratchpad
    // `jstest/run_vigenere.js`).

    #[test]
    fn cto_vigenere_matches_2016_site_vectors() {
        let n = registry().get("cto_vigenere").unwrap();
        let p = params! {"key" => "SECRETKEY"};
        let ct = "llg HyBmo zJsyE jHH nSEtu FzxB xFw pcQC wyk.";
        let out = n.apply(&Repr::bytes(ct.as_bytes().to_vec()), &p).unwrap();
        assert_eq!(
            String::from_utf8(out.data).unwrap(),
            "The quick brown fox jumps over the lazy dog."
        );
    }

    /// The flat 52-char alphabet (point 1 in the module docs) means a shift
    /// can cross the case boundary: decrypting does *not* generally recover
    /// each output character's case from the ciphertext's own case the way a
    /// case-preserving Vigenère would.
    #[test]
    fn cto_vigenere_alphabet_is_case_sensitive_not_case_preserving() {
        let n = registry().get("cto_vigenere").unwrap();
        let p = params! {"key" => "key"};
        let ct = "dLcaYgMOZbSuXJmh"; // vigenere.js encrypt("key","thequickbrownfox")
        let out = n.apply(&Repr::bytes(ct.as_bytes().to_vec()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "thequickbrownfox");
    }

    /// Point 3: the key is always stripped to the alphabet; a space in the
    /// key is dropped unconditionally, with no toggle to keep it.
    #[test]
    fn cto_vigenere_key_is_always_stripped_to_alphabet() {
        let n = registry().get("cto_vigenere").unwrap();
        let p_with_space = params! {"key" => "SECRET KEY"};
        let p_without = params! {"key" => "SECRETKEY"};
        let ct = "llg HyBmo zJsyE jHH nSEtu FzxB xFw pcQC wyk.";
        let a = n
            .apply(&Repr::bytes(ct.as_bytes().to_vec()), &p_with_space)
            .unwrap();
        let b = n
            .apply(&Repr::bytes(ct.as_bytes().to_vec()), &p_without)
            .unwrap();
        assert_eq!(a.data, b.data);
    }

    /// Point 2: an empty (post-cleaning) key makes the tool emit nothing at
    /// all, not identity -- `vigenere.js:33`'s `if (key != "")` wraps the
    /// entire per-character loop.
    #[test]
    fn cto_vigenere_empty_effective_key_yields_empty_output() {
        let n = registry().get("cto_vigenere").unwrap();
        let p = params! {"key" => "123"}; // no alphabet members survive cleaning
        let out = n.apply(&Repr::bytes(b"Hello, World!".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"".to_vec());
    }

    /// ARCHITECTURE.md pin (rev1 Beaufort's requirement, verified here for
    /// Vigenere too since `cto2016_crypt` backs both): `vigenere.js:35-48`'s
    /// `j = (j+1) % key.length` sits INSIDE `if (zp >= 0)` -- the key phase
    /// only advances on alphabet-member text characters, never on a
    /// passed-through non-alphabet one. Confirmed directly: interleaving
    /// punctuation into the ciphertext must not change which key character
    /// subsequent letters decrypt against.
    #[test]
    fn cto_vigenere_key_phase_skips_non_alphabet_characters() {
        let n = registry().get("cto_vigenere").unwrap();
        let p = params! {"key" => "key"};
        let plain = n.apply(&Repr::bytes(b"aaaaa".to_vec()), &p).unwrap();
        let with_junk = n.apply(&Repr::bytes(b"a, a, a, a, a".to_vec()), &p).unwrap();
        let letters_only: Vec<u8> = with_junk.data.iter().filter(|b| b.is_ascii_alphabetic()).copied().collect();
        assert_eq!(letters_only, plain.data, "punctuation must not advance the key phase");
    }

    /// `keep_non_alphabet=false` matches `handle == "remove"`: only
    /// whitespace (CR/space/LF) survives, everything else outside the
    /// alphabet is dropped -- not merely letters-outside-alphabet.
    #[test]
    fn cto_vigenere_keep_non_alphabet_false_drops_everything_but_whitespace() {
        let n = registry().get("cto_vigenere").unwrap();
        let p = params! {"key" => "key", "keep_non_alphabet" => false};
        // vigenere.js decrypt("key", "rIjVS, UYVjN! 123", "remove") -- the
        // digits are dropped too, not just punctuation; only whitespace
        // (space/CR/LF) survives.
        let ct = "rIjVS, UYVjN! 123";
        let out = n.apply(&Repr::bytes(ct.as_bytes().to_vec()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "Hello World ");
    }

    #[test]
    fn cto_vigenere_convert_output_upper_via_output_case() {
        let n = registry().get("cto_vigenere").unwrap();
        let ct = "dLcaYgMOZbSuXJmh";
        let p = params! {"key" => "key", "output_case" => "upper"};
        let out = n.apply(&Repr::bytes(ct.as_bytes().to_vec()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "THEQUICKBROWNFOX");
    }

    #[test]
    fn cto_vigenere_group_by_5s_matches_site_grouping() {
        let n = registry().get("cto_vigenere").unwrap();
        let ct = "dLcaYgMOZbSuXJmh";
        let p = params! {"key" => "key", "group_size" => 5i64};
        let out = n.apply(&Repr::bytes(ct.as_bytes().to_vec()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), "thequ ickbr ownfo x");
    }

    #[test]
    fn cto_vigenere_preserves_display() {
        let n = registry().get("cto_vigenere").unwrap();
        let p = params! {"key" => "key"};
        let out = n
            .apply(&Repr::new(b"Hello".to_vec(), Display::Hex), &p)
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn cto_vigenere_is_xf_family_and_not_layer_forming() {
        let n = registry().get("cto_vigenere").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    // -- geocaching_vigenere -------------------------------------------------

    #[test]
    fn geocaching_vigenere_round_trips_via_test_encrypt() {
        let alphabet = CaseFoldedAlphabet::build("t", GEOCACHING_ALPHABET).unwrap();
        let key_vals: Vec<usize> = "Secret".bytes().filter_map(|b| alphabet.pos(b)).collect();
        let plain = "The Quick, Brown Fox! 123";
        let enc = geocaching_style_encrypt_for_test(&alphabet, &key_vals, plain.as_bytes());

        let n = registry().get("geocaching_vigenere").unwrap();
        let p = params! {"key" => "Secret", "trailing" => "none"};
        let out = n.apply(&Repr::bytes(enc.into_bytes()), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), plain);
    }

    /// Ground truth: a direct transliteration of geocachingtoolbox.json's
    /// `vigenereCipher()` JS (`inChars`/`splitCleanKey`/`keyPos` loop),
    /// verified by hand before porting.
    #[test]
    fn geocaching_vigenere_matches_transliterated_js_vector() {
        let n = registry().get("geocaching_vigenere").unwrap();
        let p = params! {"key" => "Secret", "trailing" => "none"};
        // enc computed by the transliteration in the round-trip test above,
        // pinned literally here so a future refactor can't silently change it.
        let ct = "Llg Hybuo, Dispf Jqo! 123";
        let out = n.apply(&Repr::bytes(ct.as_bytes().to_vec()), &p).unwrap();
        assert_eq!(
            String::from_utf8(out.data).unwrap(),
            "The Quick, Brown Fox! 123"
        );
    }

    #[test]
    fn geocaching_vigenere_default_trailing_is_crlf_for_innerhtml_output() {
        let n = registry().get("geocaching_vigenere").unwrap();
        let p = params! {"key" => "Secret"};
        let out = n.apply(&Repr::bytes(b"Llg".to_vec()), &p).unwrap();
        assert!(out.data.ends_with(b"\r\n"));
    }

    #[test]
    fn geocaching_vigenere_empty_key_is_passthrough() {
        let n = registry().get("geocaching_vigenere").unwrap();
        let p = params! {"key" => "123", "trailing" => "none"};
        let out = n.apply(&Repr::bytes(b"Hello".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"Hello");
    }

    fn geocaching_style_encrypt_for_test(
        alphabet: &CaseFoldedAlphabet,
        key_vals: &[usize],
        data: &[u8],
    ) -> String {
        let m = alphabet.len();
        let mut out = Vec::with_capacity(data.len());
        if key_vals.is_empty() {
            return String::from_utf8(data.to_vec()).unwrap();
        }
        let mut key_pos = 0usize;
        for &c in data {
            match alphabet.pos(c) {
                Some(v) => {
                    let kv = key_vals[key_pos];
                    key_pos = (key_pos + 1) % key_vals.len();
                    out.push(alphabet.char_at((v + kv) % m, c));
                }
                None => out.push(c),
            }
        }
        String::from_utf8(out).unwrap()
    }

    // -- practicalcrypto_vigenere ---------------------------------------------

    /// Ground truth: the site's own worked example on
    /// http://practicalcryptography.com/ciphers/classical-era/vigenere-gronsfeld-and-autokey/ --
    /// plaintext "defend the east wall of the castle", key "fortification",
    /// tableau-computed ciphertext "ISWXVIBJEXIGGBOCEWKBJEVIGGQS" (their
    /// case). The page's live JS lowercases everything, so decrypting the
    /// lowercase form must recover the (also lowercased/stripped) plaintext.
    #[test]
    fn practicalcrypto_vigenere_matches_site_worked_example() {
        let n = registry().get("practicalcrypto_vigenere").unwrap();
        let p = params! {"key" => "fortification"};
        let ct = "ISWXVIBJEXIGGBOCEWKBJEVIGGQS";
        let out = n.apply(&Repr::bytes(ct.as_bytes().to_vec()), &p).unwrap();
        assert_eq!(
            String::from_utf8(out.data).unwrap(),
            "defendtheeastwallofthecastle"
        );
    }

    /// Independent cross-check against the same page's `pycipher`
    /// demonstration, a different sample using the same classical algorithm.
    #[test]
    fn practicalcrypto_vigenere_matches_pycipher_demo_from_same_page() {
        let n = registry().get("practicalcrypto_vigenere").unwrap();
        let p = params! {"key" => "HELLO"};
        let ct = "KIQPBKXSPSHWEHOSPZQHOINLGAPP";
        let out = n.apply(&Repr::bytes(ct.as_bytes().to_vec()), &p).unwrap();
        assert_eq!(
            String::from_utf8(out.data).unwrap(),
            "defendtheeastwallofthecastle"
        );
    }

    /// Divergence pin: unlike CTO/geocachingtoolbox, this site strips ALL
    /// non-letters and forces lowercase, unconditionally.
    #[test]
    fn practicalcrypto_vigenere_strips_punctuation_and_forces_lowercase() {
        let n = registry().get("practicalcrypto_vigenere").unwrap();
        let p = params! {"key" => "ab"};
        // ciphertext "AB, CD!" -> stripped/lowercased to "abcd" before decrypt.
        let out = n.apply(&Repr::bytes(b"AB, CD!".to_vec()), &p).unwrap();
        assert!(out.data.iter().all(|b| b.is_ascii_lowercase()));
        assert_eq!(out.data.len(), 4);
    }

    /// Divergence pin: the site refuses keys shorter than two letters after
    /// stripping; CTO and geocachingtoolbox both accept any non-empty key.
    #[test]
    fn practicalcrypto_vigenere_rejects_short_key() {
        let n = registry().get("practicalcrypto_vigenere").unwrap();
        let p = params! {"key" => "a"};
        let err = n.apply(&Repr::bytes(b"abcd".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn practicalcrypto_vigenere_key_with_only_punctuation_also_rejected() {
        let n = registry().get("practicalcrypto_vigenere").unwrap();
        let p = params! {"key" => "1 2!"};
        let err = n.apply(&Repr::bytes(b"abcd".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn practicalcrypto_vigenere_preserves_display() {
        let n = registry().get("practicalcrypto_vigenere").unwrap();
        let p = params! {"key" => "ab"};
        let out = n
            .apply(&Repr::new(b"abcd".to_vec(), Display::Hex), &p)
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn practicalcrypto_vigenere_is_xf_family_and_not_layer_forming() {
        let n = registry().get("practicalcrypto_vigenere").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }

    /// Inverse of `practicalcrypto_decrypt`, for building a ciphertext this
    /// node's decrypt path should recover -- mirrors the same pass-through
    /// convention for bytes outside `a`-`z`.
    fn practicalcrypto_encrypt_for_test(key: &[u8], data: &[u8]) -> Vec<u8> {
        let mut out = Vec::with_capacity(data.len());
        let mut key_pos = 0usize;
        for &c in data {
            if c.is_ascii_lowercase() {
                let pv = (c - b'a') as i32;
                let kv = (key[key_pos % key.len()] - b'a') as i32;
                let cv = (pv + kv).rem_euclid(26) as u8;
                out.push(b'a' + cv);
                key_pos += 1;
            } else {
                out.push(c);
            }
        }
        out
    }

    /// The payoff: with `strip_non_alphabet` explicitly disabled, this
    /// Vigenère cipher operates on any medium instead of deleting everything
    /// outside a-z -- proven here against a 1092-character lowercase-hex
    /// string, the length of rev7's ciphertext. `0`-`9` bytes are outside the
    /// alphabet and pass through unshifted/un-consumed; `a`-`f` bytes are
    /// genuine alphabet members and are substituted (and consume a keystream
    /// position) exactly as `a`-`z` plaintext would be.
    #[test]
    fn practicalcrypto_vigenere_preserves_non_alphabet_bytes_when_stripping_disabled() {
        let hex: String = (0..1092).map(|i| "0123456789abcdef".as_bytes()[i % 16] as char).collect();
        let key = b"zombies";
        let ct = practicalcrypto_encrypt_for_test(key, hex.as_bytes());
        assert_eq!(ct.len(), 1092);

        let n = registry().get("practicalcrypto_vigenere").unwrap();
        let p = params! {"key" => "zombies", "strip_non_alphabet" => false};
        let out = n.apply(&Repr::bytes(ct), &p).unwrap();
        assert_eq!(String::from_utf8(out.data).unwrap(), hex);
    }
}
