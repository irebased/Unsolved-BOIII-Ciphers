//! Classical affine cipher.
//!
//! Encryption maps alphabet position `x` to `y = a*x + b mod m`; this node
//! implements the inverse, `x = a^-1 * (y - b) mod m`, i.e. it decrypts.
//!
//! Confirmed against rev13: `reverse | affine:a=15,b=19` recovers the recorded
//! plaintext exactly, using the default 26-letter alphabet below.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

// Default alphabet: the 26 uppercase letters. Matched case-insensitively (both
// `A`..`Z` and `a`..`z` resolve to the same position), with the input's case
// preserved on output — the same convention `rot` and `substitute` use. Handled
// directly by arithmetic below rather than as an indexable array, so there is no
// named constant for it.

const AFFINE_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req(
        "a",
        ParamType::Int,
        "multiplicative key; must be coprime with the alphabet size, or no \
         modular inverse exists",
    ),
    ParamSpec::req("b", ParamType::Int, "additive key"),
    ParamSpec::opt(
        "alphabet",
        ParamType::Str,
        "alphabet to index into (default: the 26 uppercase letters, matched \
         case-insensitively with the input's case preserved). A custom alphabet \
         is matched by exact byte value instead, the same convention `beaufort` \
         uses",
    ),
];

/// Modular inverse of `a` mod `m` via the extended Euclidean algorithm.
///
/// Returns `None` when `gcd(a, m) != 1`, i.e. when `a` and `m` are not coprime
/// and no inverse exists — the caller must reject rather than silently produce
/// garbage, since an affine map with a non-invertible `a` is not a bijection and
/// cannot be decrypted.
fn mod_inverse(a: i64, m: i64) -> Option<i64> {
    if m <= 1 {
        return None;
    }
    let mut old_r = a.rem_euclid(m);
    let mut r = m;
    let mut old_s = 1i64;
    let mut s = 0i64;
    while r != 0 {
        let q = old_r / r;
        let new_r = old_r - q * r;
        old_r = r;
        r = new_r;
        let new_s = old_s - q * s;
        old_s = s;
        s = new_s;
    }
    if old_r != 1 {
        None
    } else {
        Some(old_s.rem_euclid(m))
    }
}

/// Classical affine cipher, decrypting: `x = a^-1 * (y - b) mod m`.
pub struct Affine;

impl Node for Affine {
    fn name(&self) -> &'static str {
        "affine"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        AFFINE_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let a = params.req_i64("affine", "a")?;
        let b = params.req_i64("affine", "b")?;

        let out: Vec<u8> = match params.opt_str("alphabet") {
            None => {
                let m: i64 = 26;
                let a_inv = mod_inverse(a, m).ok_or_else(|| {
                    Error::bad_param(
                        "affine",
                        "a",
                        format!("{a} is not coprime with 26; no modular inverse exists"),
                    )
                })?;
                input
                    .data
                    .iter()
                    .map(|&c| match c {
                        b'A'..=b'Z' => {
                            let y = (c - b'A') as i64;
                            let x = (a_inv * (y - b)).rem_euclid(m);
                            x as u8 + b'A'
                        }
                        b'a'..=b'z' => {
                            let y = (c - b'a') as i64;
                            let x = (a_inv * (y - b)).rem_euclid(m);
                            x as u8 + b'a'
                        }
                        other => other,
                    })
                    .collect()
            }
            Some(alpha_str) => {
                let alphabet: Vec<u8> = alpha_str.bytes().collect();
                let m = alphabet.len() as i64;
                if m == 0 {
                    return Err(Error::bad_param("affine", "alphabet", "must not be empty"));
                }
                let a_inv = mod_inverse(a, m).ok_or_else(|| {
                    Error::bad_param(
                        "affine",
                        "a",
                        format!("{a} is not coprime with the alphabet size {m}; no modular inverse exists"),
                    )
                })?;
                input
                    .data
                    .iter()
                    .map(|&c| match alphabet.iter().position(|&x| x == c) {
                        Some(y) => {
                            let x = (a_inv * (y as i64 - b)).rem_euclid(m);
                            alphabet[x as usize]
                        }
                        None => c,
                    })
                    .collect()
            }
        };

        Ok(Repr::new(out, input.display))
    }
}

register_node!(AFFINE => || Box::new(Affine));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    /// Hand-computed over the 3-letter alphabet "ABC" (m=3): a=2, b=1 encrypts
    /// as y = (2x+1) mod 3, so plaintext "ABC" (x = 0,1,2) encrypts to
    /// y = 1,0,2 -> "BAC". Decrypting "BAC" with a=2 (inverse 2, since 2*2=4=1
    /// mod 3), b=1 must recover "ABC".
    #[test]
    fn affine_hand_computed_small_alphabet() {
        let n = registry().get("affine").unwrap();
        let p = params! {"a" => 2i64, "b" => 1i64, "alphabet" => "ABC"};
        let out = n.apply(&Repr::bytes(b"BAC".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"ABC");
    }

    /// The rev13 case: default alphabet, a=15, b=19, case-preserving.
    #[test]
    fn affine_default_alphabet_case_preserving() {
        let n = registry().get("affine").unwrap();
        let p = params! {"a" => 15i64, "b" => 19i64};
        // Encrypt "Hi" by hand: H=7 -> y=(15*7+19)%26=(105+19)%26=124%26=20='U';
        // i=8 -> y=(15*8+19)%26=(120+19)%26=139%26=9='j'. So "Hi" -> "Uj".
        let out = n.apply(&Repr::bytes(b"Uj".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"Hi");
    }

    #[test]
    fn affine_rejects_non_coprime_a() {
        let n = registry().get("affine").unwrap();
        // gcd(13, 26) = 13, not invertible.
        let p = params! {"a" => 13i64, "b" => 0i64};
        let err = n.apply(&Repr::bytes(b"HELLO".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn affine_rejects_non_coprime_a_custom_alphabet() {
        let n = registry().get("affine").unwrap();
        // alphabet size 4, a=2 shares a factor with 4.
        let p = params! {"a" => 2i64, "b" => 0i64, "alphabet" => "WXYZ"};
        assert!(n.apply(&Repr::bytes(b"WXYZ".to_vec()), &p).is_err());
    }

    #[test]
    fn affine_passthrough_non_alphabet_characters() {
        let n = registry().get("affine").unwrap();
        let p = params! {"a" => 15i64, "b" => 19i64};
        let out = n
            .apply(&Repr::bytes(b"U, j! 123".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"H, i! 123");
    }

    #[test]
    fn affine_round_trip_via_encryption_formula() {
        let n = registry().get("affine").unwrap();
        let a = 15i64;
        let b = 19i64;
        let plain = b"ATTACKATDAWNTHEQUICKBROWNFOXzzz";
        // Encrypt by hand using y = a*x + b mod 26, then decrypt via the node
        // and confirm we recover the original.
        let encrypted: Vec<u8> = plain
            .iter()
            .map(|&c| match c {
                b'A'..=b'Z' => {
                    let x = (c - b'A') as i64;
                    let y = (a * x + b).rem_euclid(26);
                    y as u8 + b'A'
                }
                b'a'..=b'z' => {
                    let x = (c - b'a') as i64;
                    let y = (a * x + b).rem_euclid(26);
                    y as u8 + b'a'
                }
                other => other,
            })
            .collect();
        let p = params! {"a" => a, "b" => b};
        let decrypted = n.apply(&Repr::bytes(encrypted), &p).unwrap();
        assert_eq!(decrypted.data, plain);
    }

    #[test]
    fn affine_preserves_display() {
        let n = registry().get("affine").unwrap();
        let p = params! {"a" => 15i64, "b" => 19i64};
        let out = n
            .apply(&Repr::new(b"Uj".to_vec(), Display::Hex), &p)
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn affine_is_xf_family_and_not_layer_forming() {
        let n = registry().get("affine").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
