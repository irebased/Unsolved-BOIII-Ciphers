//! rumkin.com's transposition family: Columnar Transposition, Double Columnar, Übchi.
//!
//! # Ported from the recovered `coltrans.js` / `ubchi.js`
//!
//! # `MakeColumnKey` decides everything, and it has a tie-break quirk
//!
//! A keyword is turned into a column order by ranking: each character becomes its
//! character code (`meth = "alpha"`, the default) or the text is parsed as explicit
//! numbers (`meth = "num"`). Ranks are then assigned 1..N by ascending value.
//!
//! Ties break **left to right** — except when `meth == "ahpla"` (that is `alpha`
//! spelled backwards), where the source's condition
//! `if (a > b || (a == b && meth == 'ahpla'))` moves the winner to the *later*
//! index, so ties break **right to left**. Nothing else about `ahpla` differs, which
//! is easy to misread as "reverse alphabetical"; it is not. See
//! `ahpla_only_changes_tie_breaking`.
//!
//! # Übchi's padding count is the number of WORDS in the keyword
//!
//! `Ubchi()` computes `words = keywords.length - Tr(keywords," ").length + 1`, i.e.
//! one more than the number of spaces, then appends that many `'Z'` between the two
//! columnar passes. Decoding strips exactly that many characters between passes. A
//! two-word keyword therefore pads 2, not 1 — see `ubchi_pads_by_word_count`.
//!
//! Übchi is recorded in the Black Ops 4 corpus as a method this puzzle author used,
//! and was previously unimplemented.
//!
//! # Coverage semantics
//!
//! [`Family::Xf`]: transforms at stated parameters.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::{Display, Repr};

use super::rumkin_common::{insert_crlf, strip_crlf};

/// `coltrans.js`'s `MakeColumnKey(meth, text)` — a keyword (or number list) to a
/// 1..N column order.
pub fn make_column_key(meth: &str, text: &str) -> Vec<usize> {
    let values: Vec<i64> = if meth == "num" {
        let t = text.trim();
        if t.is_empty() {
            return vec![1];
        }
        t.split(|c: char| !c.is_ascii_digit())
            .filter(|s| !s.is_empty())
            .filter_map(|s| s.parse::<i64>().ok())
            .collect()
    } else {
        let t: Vec<u8> = text
            .bytes()
            .filter(|b| !matches!(b, b' ' | b'\r' | b'\n' | b'\t'))
            .collect();
        if t.is_empty() {
            return vec![1];
        }
        t.iter().map(|&b| b as i64).collect()
    };
    if values.is_empty() {
        return vec![1];
    }
    let n = values.len();
    let mut ranks = vec![0usize; n];
    for loop_i in 0..n {
        let mut lowest: Option<usize> = None;
        for i in 0..n {
            if ranks[i] != 0 {
                continue;
            }
            match lowest {
                None => lowest = Some(i),
                Some(l) => {
                    let (a, b) = (values[l], values[i]);
                    // the site's literal condition, including the ahpla tie-break
                    if a > b || (a == b && meth == "ahpla") {
                        lowest = Some(i);
                    }
                }
            }
        }
        if let Some(l) = lowest {
            ranks[l] = loop_i + 1;
        }
    }
    ranks
}

fn col_encode(t: &[u8], key: &[usize]) -> Vec<u8> {
    let n = key.len();
    let mut cols: Vec<Vec<u8>> = vec![Vec::new(); n];
    let mut back = vec![0usize; n];
    for (i, &k) in key.iter().enumerate() {
        back[k - 1] = i;
    }
    for (i, &b) in t.iter().enumerate() {
        cols[i % n].push(b);
    }
    let mut out = Vec::with_capacity(t.len());
    for i in 0..n {
        out.extend_from_slice(&cols[back[i]]);
    }
    out
}

fn col_decode(t: &[u8], key: &[usize]) -> Vec<u8> {
    let n = key.len();
    let min_num = t.len() / n;
    let mut num = vec![min_num; n];
    let mut back = vec![0usize; n];
    for (i, &k) in key.iter().enumerate() {
        back[k - 1] = i;
    }
    // extras are handed out in KEY order, not column order
    let mut j = min_num * n;
    let mut i = 0usize;
    while j < t.len() {
        num[key[i] - 1] += 1;
        i += 1;
        j += 1;
    }
    let mut s: Vec<Vec<u8>> = vec![Vec::new(); n];
    let mut rest = t;
    for i in 0..n {
        let take = num[i].min(rest.len());
        s[back[i]] = rest[..take].to_vec();
        rest = &rest[take..];
    }
    let mut out = Vec::with_capacity(t.len());
    for i in 0..min_num + 1 {
        for col in s.iter() {
            if col.len() > i {
                out.push(col[i]);
            }
        }
    }
    out
}

fn key_of(node: &'static str, params: &Params) -> Result<Vec<usize>> {
    let meth = params.opt_str("key_type").unwrap_or("alpha");
    if !matches!(meth, "alpha" | "ahpla" | "num") {
        return Err(Error::bad_param(
            node,
            "key_type",
            format!("expected \"alpha\", \"ahpla\" or \"num\", got {meth:?}"),
        ));
    }
    let k = make_column_key(meth, params.req_str(node, "key")?);
    if k.is_empty() {
        return Err(Error::bad_param(node, "key", "produced an empty column order"));
    }
    Ok(k)
}

fn dir(node: &'static str, params: &Params) -> Result<bool> {
    match params.opt_str("direction").unwrap_or("decrypt") {
        "encrypt" => Ok(true),
        "decrypt" => Ok(false),
        o => Err(Error::bad_param(node, "direction", format!("got {o:?}"))),
    }
}

const COLTRANS: &str = "rumkin_coltrans";
const SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "keyword, or explicit numbers with key_type=num"),
    ParamSpec::opt(
        "key_type",
        ParamType::Str,
        "\"alpha\" (default; rank by character code, ties left-to-right), \"ahpla\" \
         (same but ties right-to-left) or \"num\" (parse explicit numbers)",
    ),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// `coltrans.js`'s `ColTrans(encdec, text, key)`.
///
/// A key producing fewer than two columns returns the text unchanged, exactly as the
/// site does (`if (NumberList.length < 2) return text;`).
pub struct RumkinColTrans;

impl Node for RumkinColTrans {
    fn name(&self) -> &'static str { COLTRANS }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_trans(coltrans.js)" }
    fn params_schema(&self) -> &'static [ParamSpec] { SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = key_of(COLTRANS, params)?;
        if key.len() < 2 {
            return Ok(Repr::new(input.data.clone(), input.display));
        }
        let (stripped, crlf) = strip_crlf(&input.data);
        let done = if dir(COLTRANS, params)? {
            col_encode(&stripped, &key)
        } else {
            col_decode(&stripped, &key)
        };
        Ok(Repr::new(insert_crlf(&done, &crlf), Display::Bytes))
    }
}

const DOUBLE: &str = "rumkin_coltrans_double";
const DOUBLE_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key1", ParamType::Str, "first columnar key"),
    ParamSpec::req("key2", ParamType::Str, "second columnar key"),
    ParamSpec::opt("key1_type", ParamType::Str, "\"alpha\" (default), \"ahpla\" or \"num\""),
    ParamSpec::opt("key2_type", ParamType::Str, "\"alpha\" (default), \"ahpla\" or \"num\""),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// The site's **Double Transposition**: two columnar passes with independent keys.
///
/// Encoding applies key1 then key2; decoding undoes key2 first. Getting that order
/// backwards still round-trips against itself, so the order is pinned by
/// `double_applies_keys_in_the_stated_order`.
pub struct RumkinColTransDouble;

impl Node for RumkinColTransDouble {
    fn name(&self) -> &'static str { DOUBLE }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_trans(coltrans-double)" }
    fn params_schema(&self) -> &'static [ParamSpec] { DOUBLE_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let k1 = make_column_key(
            params.opt_str("key1_type").unwrap_or("alpha"),
            params.req_str(DOUBLE, "key1")?,
        );
        let k2 = make_column_key(
            params.opt_str("key2_type").unwrap_or("alpha"),
            params.req_str(DOUBLE, "key2")?,
        );
        let (stripped, crlf) = strip_crlf(&input.data);
        let enc = dir(DOUBLE, params)?;
        let mut cur = stripped;
        if enc {
            if k1.len() >= 2 { cur = col_encode(&cur, &k1); }
            if k2.len() >= 2 { cur = col_encode(&cur, &k2); }
        } else {
            if k2.len() >= 2 { cur = col_decode(&cur, &k2); }
            if k1.len() >= 2 { cur = col_decode(&cur, &k1); }
        }
        Ok(Repr::new(insert_crlf(&cur, &crlf), Display::Bytes))
    }
}

const UBCHI: &str = "rumkin_ubchi";
const UBCHI_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("key", ParamType::Str, "keyword phrase; its WORD COUNT sets the padding"),
    ParamSpec::opt("key_type", ParamType::Str, "\"alpha\" (default), \"ahpla\" or \"num\""),
    ParamSpec::opt("direction", ParamType::Str, "\"decrypt\" (default) or \"encrypt\""),
];

/// `ubchi.js`'s `Ubchi(EncDec, text, keywords, meth)` — the German double columnar.
///
/// Both passes use the *same* key; what makes it Übchi rather than a plain double
/// transposition is the `'Z'` padding inserted between them, whose length is the
/// number of words in the keyword phrase.
pub struct RumkinUbchi;

impl Node for RumkinUbchi {
    fn name(&self) -> &'static str { UBCHI }
    fn version(&self) -> &'static str { "1.0.0" }
    fn family(&self) -> Family { Family::Xf }
    fn source_digest(&self) -> &'static str { "ra-core/classical/rumkin_trans(ubchi.js)" }
    fn params_schema(&self) -> &'static [ParamSpec] { UBCHI_SCHEMA }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let keywords = params.req_str(UBCHI, "key")?;
        let key = key_of(UBCHI, params)?;
        // words = keywords.length - Tr(keywords," ").length + 1  == (#spaces) + 1
        let words = keywords.bytes().filter(|&b| b == b' ').count() + 1;
        let (stripped, _crlf) = strip_crlf(&input.data);
        let out = if dir(UBCHI, params)? {
            let mut o = if key.len() >= 2 { col_encode(&stripped, &key) } else { stripped };
            o.extend(std::iter::repeat(b'Z').take(words));
            if key.len() >= 2 { col_encode(&o, &key) } else { o }
        } else {
            let o = if key.len() >= 2 { col_decode(&stripped, &key) } else { stripped };
            let cut = o.len().saturating_sub(words);
            let o = o[..cut].to_vec();
            if key.len() >= 2 { col_decode(&o, &key) } else { o }
        };
        Ok(Repr::new(out, Display::Bytes))
    }
}

register_node!(RUMKIN_COLTRANS => || Box::new(RumkinColTrans));
register_node!(RUMKIN_COLTRANS_DOUBLE => || Box::new(RumkinColTransDouble));
register_node!(RUMKIN_UBCHI => || Box::new(RumkinUbchi));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn n(name: &str) -> &'static dyn Node { registry().get(name).unwrap() }

    #[test]
    fn all_are_xf() {
        for x in [COLTRANS, DOUBLE, UBCHI] { assert_eq!(n(x).family(), Family::Xf); }
    }

    /// Ranking is by character code, ascending, ties left to right.
    #[test]
    fn column_key_ranks_by_charcode() {
        assert_eq!(make_column_key("alpha", "ZEBRA"), vec![5, 3, 2, 4, 1]);
        assert_eq!(make_column_key("num", "3 1 2"), vec![3, 1, 2]);
        assert_eq!(make_column_key("alpha", ""), vec![1]);
    }

    /// `ahpla` is NOT reverse alphabetical — it only flips the tie-break direction.
    #[test]
    fn ahpla_only_changes_tie_breaking() {
        // no ties: identical result
        assert_eq!(make_column_key("alpha", "ZEBRA"), make_column_key("ahpla", "ZEBRA"));
        // with a repeated letter the two disagree
        let a = make_column_key("alpha", "AA");
        let b = make_column_key("ahpla", "AA");
        assert_eq!(a, vec![1, 2]);
        assert_eq!(b, vec![2, 1]);
    }

    #[test]
    fn coltrans_round_trips_including_ragged_columns() {
        let p = params! {"key" => "ZEBRA"};
        for msg in ["WEAREDISCOVEREDFLEEATONCE", "SHORT", "EXACTLYTWENTYFIVECHARSXX"] {
            let enc = n(COLTRANS)
                .apply(&Repr::bytes(msg.as_bytes().to_vec()), &p.clone().set("direction", "encrypt"))
                .unwrap();
            let back = n(COLTRANS).apply(&enc, &p).unwrap();
            assert_eq!(back.data, msg.as_bytes(), "{msg}");
        }
    }

    /// Newlines never enter the grid and come back at their original offsets.
    #[test]
    fn newlines_are_excluded_and_restored() {
        let p = params! {"key" => "ZEBRA", "direction" => "encrypt"};
        let out = n(COLTRANS)
            .apply(&Repr::bytes(b"ABCDE\nFGHIJ".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data.iter().filter(|&&b| b == b'\n').count(), 1);
        assert_eq!(out.data[5], b'\n', "newline stays at its original offset");
    }

    /// A single-column key is a no-op, exactly as the site returns the text unchanged.
    #[test]
    fn single_column_key_is_a_noop() {
        let out = n(COLTRANS)
            .apply(&Repr::bytes(b"HELLO".to_vec()), &params! {"key" => "A", "direction" => "encrypt"})
            .unwrap();
        assert_eq!(out.data, b"HELLO");
    }

    #[test]
    fn double_applies_keys_in_the_stated_order() {
        let p = params! {"key1" => "ZEBRA", "key2" => "CAT"};
        let enc = n(DOUBLE)
            .apply(&Repr::bytes(b"WEAREDISCOVEREDFLEE".to_vec()), &p.clone().set("direction","encrypt"))
            .unwrap();
        assert_eq!(n(DOUBLE).apply(&enc, &p).unwrap().data, b"WEAREDISCOVEREDFLEE");
        // key order matters: swapping them gives a different ciphertext
        let swapped = n(DOUBLE)
            .apply(&Repr::bytes(b"WEAREDISCOVEREDFLEE".to_vec()),
                   &params! {"key1" => "CAT", "key2" => "ZEBRA", "direction" => "encrypt"})
            .unwrap();
        assert_ne!(enc.data, swapped.data);
    }

    /// The Übchi signature: padding length equals the keyword's WORD count.
    #[test]
    fn ubchi_pads_by_word_count() {
        let one = n(UBCHI)
            .apply(&Repr::bytes(b"ATTACKATDAWN".to_vec()),
                   &params! {"key" => "ZEBRA", "direction" => "encrypt"})
            .unwrap();
        let two = n(UBCHI)
            .apply(&Repr::bytes(b"ATTACKATDAWN".to_vec()),
                   &params! {"key" => "ZEBRA CAT", "direction" => "encrypt"})
            .unwrap();
        assert_eq!(one.data.len(), 13, "one word -> 1 pad char");
        assert_eq!(two.data.len(), 14, "two words -> 2 pad chars");
    }

    #[test]
    fn ubchi_round_trips() {
        let p = params! {"key" => "ZEBRA CAT"};
        let enc = n(UBCHI)
            .apply(&Repr::bytes(b"WEAREDISCOVEREDFLEEATONCE".to_vec()),
                   &p.clone().set("direction", "encrypt"))
            .unwrap();
        let back = n(UBCHI).apply(&enc, &p).unwrap();
        assert_eq!(back.data, b"WEAREDISCOVEREDFLEEATONCE");
    }

    #[test]
    fn bad_key_type_is_rejected() {
        assert!(n(COLTRANS)
            .apply(&Repr::bytes(b"ABC".to_vec()), &params! {"key" => "AB", "key_type" => "zzz"})
            .is_err());
    }
}
