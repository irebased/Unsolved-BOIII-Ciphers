const S = require("./style.js");
const { docx, PAGE, numbering, title, subtitle, h1, h2, h3, p, mono, li, numItem, table, callout, spacer, makeHeaderFooter } = S;
const { Document, Packer, Paragraph, TextRun, AlignmentType, BorderStyle } = docx;
const fs = require("fs");

const REV7 = "83 B57B2 C3434 697F6 FCA3F 8EAD6 63C42 B7F20 041B5 B6A0D A4AE0 AD24B 93B27 FF54C 6E79A 1136E 36860 C69C7 2D497 CDC98 2D49C D25B3 FCB36 D934C F0D31 512AF A78E6 26FFD 81CAC AAED6 226DA CD449 86768 3A2E0 B9E64 406C6 10C14 04907 51A9D 4A5F2 4475C 91C91 9AE5E 89D79 477DB 2B29C 5444D EA362 54E94 A14A7 58C42 096FE BD177 739B3 A4185 6272A";

const children = [];
const A = (...x) => children.push(...x);

A(title("Target Analysis: Revelations 7"));
A(subtitle("Statistical Twin of the Confirmed Modern Ciphers, With an Anomalous Classical Surface"));
A(p([
  { t: "Document 3 of 3 (Target Paper). ", bold: true },
  "This paper analyzes the unsolved cipher Revelations 7 (REV7), the last open cipher on the Revelations map. It relies on Document 1 for the shared modern-encryption invariants and evidence taxonomy. Unlike The Giant 4, REV7 sits inside the Revelations corpus and may legitimately inherit techniques established by its solved neighbors, so forensic inference from the rest of Revelations is admissible here in a way it is not for The Giant 4.",
]));

// 1. Cipher of record
A(h1("1. The Cipher of Record"));
A(p("REV7 is presented as uppercase hexadecimal, grouped into five-character blocks, with a leading two-character remainder. The ciphertext of record begins:"));
A(...mono(REV7.split(" ").slice(0, 42).join(" ").match(/.{1,60}/g).join("\n")));
A(p([{ t: "(truncated for display; full ciphertext is 218 five-character groups plus one leading two-character group, 1092 hex characters total, carried in the accompanying evidence base). ", italics: true }], { after: 160 }));

// 2. Hard facts
A(h1("2. Hard Facts (Directly Measured)"));
A(table(
  ["Measurement", "Value", "Interpretation"],
  [
    ["Character set", "0-9, A-F (uppercase only)", "Uppercase hexadecimal"],
    ["Total hex characters", "1092", "Even; 546 bytes if parsed as-is"],
    ["Group structure", "218 groups of 5 + 1 group of 2", "Five-gram formatting with a remainder"],
    ["Remainder position", "Front (index 0), value 83", "Anomalous; see Section 3"],
    ["Shannon entropy (hex symbols)", "3.991 / 4.000 bits", "Near ceiling for a 16-symbol alphabet"],
    ["Nibble chi-square (16 bins)", "13.1", "Near-uniform; matches confirmed modern ciphers"],
    ["Index of coincidence (hex)", "0.0624", "Flat; no classical periodicity at surface"],
    ["Byte entropy (as-parsed)", "7.63 / 8.00 bits", "Modern-cipher range"],
  ],
  [3350, 2450, 3440]
));

// 3. The reversal / grouping anomaly
A(h1("3. The Grouping Anomaly Points to Reversal"));
A(p([
  "The single most diagnostic surface feature of REV7 is the position of the remainder group. Every n-gram splitter observed in the corpus places a short remainder at the end of the output, because grouping proceeds left to right and the leftover characters fall at the tail. REV7's two-character remainder sits at the front. The most parsimonious explanation is that the text was grouped into fives in the normal way, producing a trailing remainder, and then the entire string was reversed, moving that remainder to the head. This makes reversal the leading candidate for the outermost operation.",
]));
A(callout("Hard fact and its leading reading.", [
  "The remainder-of-two sits at the front of the ciphertext. Standard five-gram splitters place remainders at the end. The observation is a hard fact; the inference that the outer operation is a reversal (or a route transform that relocates the remainder) is a strong working hypothesis and is the recommended first step of any pipeline.",
]));
A(p([
  "A second surface feature is the uppercase constraint. Some hex-producing tools emit lowercase; REV7 is strictly uppercase. Whatever tool produced the surface form either emitted uppercase natively or applied an uppercasing step. Document 1 records a suspected lost CrypTool feature that produced all-uppercase output with five-character grouping. If recovered, that single tool behavior would explain both the casing and the grouping simultaneously.",
]));

// 4. The entropy classification, corrected
A(h1("4. Classification: REV7 Is a Statistical Twin of the Modern Ciphers"));
A(p([
  "REV7 has been described informally as occupying an in-between entropy band, higher than a classical cipher should reach but lower than a clean modern cipher. Direct measurement does not support the in-between reading once alphabet size is normalized. The correct comparison is against the solved Revelations ciphers that are also presented as raw hex.",
]));
A(table(
  ["Cipher", "Class (confirmed)", "Charset", "Entropy/sym", "Nibble chi-sq", "IoC"],
  [
    ["REV10", "Modern (5 layers)", "16", "3.994", "31.8", "0.0628"],
    ["REV12", "Modern (4 layers)", "16", "3.979", "12.7", "0.0622"],
    ["REV7", "Unsolved", "16", "3.991", "13.1", "0.0624"],
    ["REV3", "Classical only", "10", "2.956", "n/a", "0.1497"],
    ["REV4", "Classical only", "5", "1.893", "n/a", "0.3189"],
  ],
  [1500, 2450, 1150, 1500, 1548, 1100]
));
A(callout("Correction to a prior belief.", [
  "Normalized for alphabet size, REV7's statistics (entropy 3.991 of 4.000, nibble chi-square 13.1, IoC 0.0624) are a near-exact match to REV12, a confirmed four-layer modern cipher, and close to REV10. The in-between-entropy characterization does not survive measurement. REV7 should be classified as carrying a modern-encryption payload with high confidence. This supersedes any earlier note treating REV7's class as genuinely ambiguous on entropy grounds.",
], S.ACCENT));

// 5. The two-family tension, resolved as layered
A(h1("5. Resolving the Classical-versus-Modern Tension"));
A(p([
  "The apparent tension is that REV7 shows a classical surface signature (five-gram grouping, uppercasing, a reversal tell) while its byte-level statistics are modern. The Revelations corpus already contains the resolution: several confirmed ciphers are classical on the outside and modern underneath. Revelations 1 is classical-over-modern; Revelations 5, 6, 8, 9, 10, and 12 interleave classical transforms and base conversions around modern cores. REV7 is best modeled not as either classical or modern but as a layered cipher with a thin classical or transform wrapper over a modern payload.",
]));
A(callout("Working hypothesis (well supported).", [
  "REV7 is a multi-layer cipher: an outer transform layer (reversal, and possibly a route or grouping-driven transposition, plus base handling) over one or more modern block-cipher layers keyed with Zombies under the ASCII-zero IV in CFB-8. The surface hex is an encoding of the outer layer, not the payload itself.",
]));

// 6. The verification problem
A(h1("6. The Verification Problem for Layered Search"));
A(p([
  "Layered ciphers with a modern core impose a specific methodological hazard. When a classical or transform layer sits outside a modern layer, applying a wrong outer transform to what is ultimately modern ciphertext produces pseudorandom bytes. There is no analytic signal, no index-of-coincidence bump, no crib match, to confirm that the outer layer was correct until the entire remaining stack has also been peeled correctly. The search cannot greedily validate one layer at a time.",
]));
A(p([
  "The practical consequence is that the outer transform and the modern layer must be treated as a single composite operation and swept jointly. Fix an outer-transform candidate, sweep the full modern menu beneath it under the fixed invariants, and score only on the emergence of printable text or a valid next-layer encoding at the bottom of the stack. This is expensive but bounded, because Document 1 fixes the key, IV, and mode, and constrains the primitive to a finite menu.",
]));
A(callout("Instruction to downstream agents.", [
  "Do not attempt to validate the outer layer in isolation. Treat (outer transform x modern primitive x optional second modern layer) as one composite unit and score only on final-layer plaintext or a clean intermediate encoding. Log every composite tried so that a later correction to any single assumption (for example a transcription fix or a different outer transform) can re-run only the affected composites rather than the whole space.",
], S.ACCENT));

// 7. Tooling forensics specific to REV7
A(h1("7. Tooling Forensics Specific to Revelations 7"));
A(p([
  "The published forensic spreadsheet records REV7's tool as unknown, so any tool attribution here is net-new signal and is offered as a lead, not a finding. Two threads are worth pursuing.",
]));
A(h2("7.1 The uppercase five-gram producer"));
A(p([
  "The surface form (uppercase hex, five-character groups) is the fingerprint to chase. The suspected lost CrypTool feature that produced all-uppercase five-grouped output is the strongest single candidate because it would explain the surface in one step. Because that CrypTool version processed on a back-end server, it is not reproducible from the Wayback client capture and must be reconstructed from documentation or a surviving mirror. Geocaching Toolbox is a secondary candidate for the hex handling and for any classical layer, consistent with its suspected role in several other Revelations classical layers.",
]));
A(h2("7.2 Contributor tool hypotheses for the Revelations set"));
A(p([
  "The following per-cipher tool hypotheses were supplied for this dossier and are reconciled here against the confirmed solution chains from Document 1. They are forensic inferences at best and, for the unsolved target, working hypotheses. They are recorded so the search has a starting prior and so later confirmation can upgrade or discard each cleanly.",
]));
A(table(
  ["Cipher", "Contributor tool hypothesis", "Reconciliation with confirmed chain"],
  [
    ["Rev1", "tools4noobs + CrypTool (Beaufort alphabet)", "Consistent: chain is Beaufort then RC2/Rijndael modern layers"],
    ["Rev2", "tools4noobs + geo toolbox (hex) + Bacon", "Consistent: chain includes hex decode, DES, Bacon"],
    ["Rev3", "geo toolbox (reverse/ASCII) + straddling tool", "Consistent: base10 then straddling checkerboard then substitution"],
    ["Rev4", "CrypTool + geo toolbox (ADFGX to numbers)", "Consistent: ADFGX with Polybius, transpose key to ZOMBIES"],
    ["Rev5", "tools4noobs", "Consistent: RC2, Blowfish, Loki97 modern layers"],
    ["Rev6", "tools4noobs + zero-pad encoder (also substitution)", "Consistent: decimal, Serpent, substitution; supports zero-pad lead"],
    ["Rev7 (target)", "CrypTool + geo toolbox (hypothesis)", "Unverified; target is unsolved"],
    ["Rev8", "tools4noobs + encoding tool (geo toolbox?)", "Consistent: hex, Blowfish-compat, base64"],
    ["Rev9", "tools4noobs + zero-pad encoder", "Consistent: DES, decimal, Twofish; supports zero-pad lead"],
    ["Rev10", "tools4noobs + zero-pad encoder", "Consistent: RC4, octal, Saferplus"],
    ["Rev11", "geo toolbox (hypothesis)", "Chain is classical (reverse, ROT, Playfair, Trifid); tool unconfirmed"],
    ["Rev12", "tools4noobs + web tool with ROT-6", "Consistent: XTEA, reverse, ROT-6"],
    ["Rev13", "site with affine", "Consistent: reverse then affine (a=15, b=19)"],
    ["Rev14", "possibly the CrypTool transposition", "Consistent: columnar transposition on a 6x27 grid"],
  ],
  [1350, 3550, 4348]
));
A(callout("Open forensic lead (shared with Document 1).", [
  "The zero-padding base encoder appears across Rev6, Rev9, and Rev10 and is not yet sourced. Confirming it against those known-good chains is a prerequisite before relying on it for REV7. Likewise the CrypTool uppercase five-gram behavior should be validated against Rev14 before being assumed for REV7.",
]));

// 8. Search plan
A(h1("8. A Constrained Search Plan"));
A(h2("8.1 Fixed constraints (hard facts)"));
A(li("Surface is uppercase hex, 1092 characters, five-gram grouped with a front remainder."));
A(li("Outer operation is almost certainly a reversal or a remainder-relocating route transform; apply it first."));
A(li("Payload statistics are modern; key, IV, and mode are fixed by the Document 1 invariants."));
A(h2("8.2 Recommended pipeline order (working hypotheses)"));
A(numItem([{ t: "Reverse ", bold: true }, "the full string (restores natural grouping, remainder to tail)."], "steps3"));
A(numItem([{ t: "Parse hex ", bold: true }, "to bytes, or re-encode hex to Base64 as the Revelations modern layers commonly require."], "steps3"));
A(numItem([{ t: "Sweep the modern menu ", bold: true }, "(DES, Blowfish, Blowfish-compat, RC2, Twofish, Serpent, Loki97, Saferplus, XTEA, Rijndael) under key Zombies, IV 30303030..., CFB-8, as a joint composite with step 1."], "steps3"));
A(numItem([{ t: "On any clean intermediate, ", bold: true }, "recurse: re-detect encoding (hex, octal, decimal, Base64), apply reverse/ROT if present, and sweep the modern menu again for a second or third layer."], "steps3"));
A(numItem([{ t: "If no modern hit, ", bold: true }, "test a thin classical outer layer (substitution, ROT, affine) as the composite outer transform over the modern sweep, scoring only on final printable text."], "steps3"));
A(h2("8.3 Parallel forensic tasks"));
A(li("Recover or reconstruct the CrypTool uppercase five-gram behavior; validate it against Rev14 before applying to REV7."));
A(li("Source the zero-padding base encoder; validate against Rev6, Rev9, Rev10."));
A(li("Fingerprint any trailing line-ending artifact (CRLF versus LF) in REV7 against the corpus tools, since line-ending handling is a discriminating tool tell in this corpus."));

// 9. Evidence summary
A(h1("9. Evidence Summary"));
A(table(
  ["Claim", "Tier"],
  [
    ["1092 uppercase hex chars, five-gram grouped, front remainder", "Hard fact"],
    ["Byte statistics match confirmed modern ciphers (REV12 twin)", "Hard fact"],
    ["Outer operation is a reversal / remainder-relocating transform", "Working hypothesis (leading)"],
    ["REV7 carries a modern-encryption payload", "Working hypothesis (well supported)"],
    ["Payload key/IV/mode follow the Document 1 invariants", "Forensic inference"],
    ["Surface produced by a CrypTool uppercase five-gram feature", "Forensic inference (unverified)"],
    ["Zero-pad encoder involved (via corpus neighbors)", "Working hypothesis"],
  ],
  [6600, 2648]
));

A(spacer(60));
A(new Paragraph({
  border: { top: { style: BorderStyle.SINGLE, size: 4, color: "9A9A9A", space: 6 } },
  spacing: { before: 120 },
  children: [new TextRun({ text: "End of Document 3. See Document 1 for shared invariants and Document 2 for The Giant 4.", italics: true, size: 18, color: "6A6A6A", font: S.FONT })],
}));

const doc = new Document({
  numbering,
  styles: { default: { document: { run: { font: S.FONT, size: 21, color: S.INK } } } },
  sections: [{
    properties: { page: PAGE },
    ...makeHeaderFooter("Target Analysis  -  Revelations 7"),
    children,
  }],
});
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/claude/BO3_Cipher_Dossier/papers/03_Target_Revelations_7.docx", buf);
  console.log("wrote 03_Target_Revelations_7.docx", buf.length, "bytes");
});
