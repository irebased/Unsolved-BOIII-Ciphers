//! Character-level repair nodes: `remove_character`, `replace_character`,
//! `insert_characters`.
//!
//! # Why a chain needs these
//!
//! Some transforms in the corpus are *lossy*, so a chain that inverts them cannot
//! be a pure composition of inverses — a human has to put back what the forward
//! transform threw away. rev11 is the case in point. Its Playfair step
//! ([`crate::classical::playfair`]) discarded every non-alphabetic character,
//! folded `J` onto `I`, and split doubled letters with an `X`; the recorded
//! solution's steps 4, 5 and 6 are the hand repair of exactly those three losses:
//!
//! | rev11 step | recorded description | node |
//! |---|---|---|
//! | 4 | "Remove all but one 'probable padding' X between doubles" | `remove_character` |
//! | 5 | "Replace some I with J" | `replace_character` |
//! | 6 | "Insert periods in that were removed during playfair encryption" | `insert_characters` |
//!
//! # These are transforms, not solvers
//!
//! The recorded descriptions hedge — "probable", "some" — because the human doing
//! the repair was guessing, and checking the guess against whether the next step
//! produced English. A node that *made those guesses itself* would be a solver
//! wearing an `Xf` badge: its coverage would be heuristic, and heuristic coverage
//! must never subtract from the exhaustive residual.
//!
//! So every edit here takes its **positions as an explicit parameter**. The node
//! is then a deterministic function of its arguments and is exhaustive at them,
//! and the guesswork lives where it belongs — in the recorded parameter values,
//! visible in the chain spec and auditable against the corpus.
//!
//! A condition-based mode is provided too (`between_doubles`, or omitting
//! `positions` to hit every occurrence), because "remove every X that sits between
//! two identical letters" is also a deterministic, auditable rule. What is not
//! provided is any mode that decides *which* candidates to keep.
//!
//! # Position lists
//!
//! Positions are given as a **semicolon-separated** list of non-negative,
//! strictly increasing integers: `positions=31;133;179`. Semicolons rather than
//! commas because the chain-spec syntax already uses `,` to separate parameters.
//!
//! `remove_character` and `replace_character` index the **input**;
//! `insert_characters` indexes the **output**, which is the frame the corpus's own
//! recorded step-6 output is naturally read in.
//!
//! # Why not the existing `insert` node?
//!
//! [`crate::nodes::Insert`] does not fit step 6, and the difference is not
//! cosmetic. `insert` splices **one** literal string at **one** position (rev8's
//! single missing hex bigram): its `pos` is a scalar `Int`, and its `hexpair` unit
//! counts hex bigrams rather than characters. rev11 step 6 inserts eleven
//! characters at eleven positions in one step. Expressing that with `insert` would
//! take eleven chained steps whose positions each had to be pre-shifted by the
//! number of earlier insertions — arithmetic the reader would have to redo to audit
//! the chain, against a corpus record that states the eleven output positions
//! directly. So `insert_characters` is a distinct node rather than a widening of
//! `insert`, and `insert` keeps its single-splice contract and its rev8 tests.

use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

/// Parse a semicolon-separated list of strictly increasing, non-negative indices.
fn positions(node: &'static str, raw: &str) -> Result<Vec<usize>> {
    let mut out: Vec<usize> = Vec::new();
    for tok in raw.split(';') {
        let tok = tok.trim();
        if tok.is_empty() {
            continue;
        }
        let v: usize = tok.parse().map_err(|_| {
            Error::bad_param(
                node,
                "positions",
                format!("{tok:?} is not a non-negative integer"),
            )
        })?;
        if let Some(&last) = out.last() {
            if v <= last {
                return Err(Error::bad_param(
                    node,
                    "positions",
                    format!(
                        "must be strictly increasing so the edit is unambiguous; {v} \
                         follows {last}"
                    ),
                ));
            }
        }
        out.push(v);
    }
    if out.is_empty() {
        return Err(Error::bad_param(
            node,
            "positions",
            "list is empty; omit the parameter to act on every occurrence instead",
        ));
    }
    Ok(out)
}

/// Read a parameter that must be exactly one byte.
fn one_byte(node: &'static str, params: &Params, key: &str) -> Result<u8> {
    let s = params.req_str(node, key)?;
    let b = s.as_bytes();
    if b.len() != 1 {
        return Err(Error::bad_param(
            node,
            key,
            format!("expected a single byte, got {s:?} ({} bytes)", b.len()),
        ));
    }
    Ok(b[0])
}

fn out_of_range(node: &'static str, pos: usize, len: usize) -> Error {
    Error::bad_param(
        node,
        "positions",
        format!("position {pos} is out of range for a {len}-byte input"),
    )
}

// ---------------------------------------------------------------------------
// remove_character
// ---------------------------------------------------------------------------

const REMOVE: &str = "remove_character";

const REMOVE_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("char", ParamType::Str, "the single byte to remove"),
    ParamSpec::opt(
        "positions",
        ParamType::Str,
        "semicolon-separated, strictly increasing 0-based indices into the input; \
         each must hold `char`. Omit to remove every occurrence.",
    ),
    ParamSpec::opt(
        "between_doubles",
        ParamType::Bool,
        "only act where the character sits between two identical characters (default \
         false). With `positions`, this is an additional requirement each listed \
         position must satisfy.",
    ),
];

pub struct RemoveCharacter;

impl Node for RemoveCharacter {
    fn name(&self) -> &'static str {
        REMOVE
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/edits(remove_character)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        REMOVE_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let ch = one_byte(REMOVE, params, "char")?;
        let guard = params.opt_bool("between_doubles", false);
        let data = &input.data;

        let is_between_doubles = |i: usize| -> bool {
            i > 0 && i + 1 < data.len() && data[i - 1] == data[i + 1]
        };

        let doomed: Vec<usize> = match params.opt_str("positions") {
            Some(raw) => {
                let list = positions(REMOVE, raw)?;
                for &i in &list {
                    if i >= data.len() {
                        return Err(out_of_range(REMOVE, i, data.len()));
                    }
                    if data[i] != ch {
                        return Err(Error::bad_param(
                            REMOVE,
                            "positions",
                            format!(
                                "position {i} holds {:?}, not the requested {:?}",
                                data[i] as char, ch as char
                            ),
                        ));
                    }
                    if guard && !is_between_doubles(i) {
                        return Err(Error::bad_param(
                            REMOVE,
                            "positions",
                            format!(
                                "position {i} is not between two identical characters, \
                                 but between_doubles was requested"
                            ),
                        ));
                    }
                }
                list
            }
            None => (0..data.len())
                .filter(|&i| data[i] == ch && (!guard || is_between_doubles(i)))
                .collect(),
        };

        let doomed_set: std::collections::BTreeSet<usize> = doomed.into_iter().collect();
        let out: Vec<u8> = data
            .iter()
            .enumerate()
            .filter(|(i, _)| !doomed_set.contains(i))
            .map(|(_, &b)| b)
            .collect();
        Ok(Repr::new(out, input.display))
    }
}

register_node!(REMOVE_CHARACTER => || Box::new(RemoveCharacter));

// ---------------------------------------------------------------------------
// replace_character
// ---------------------------------------------------------------------------

const REPLACE: &str = "replace_character";

const REPLACE_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("from", ParamType::Str, "the single byte to replace"),
    ParamSpec::req("to", ParamType::Str, "the single byte to put in its place"),
    ParamSpec::opt(
        "positions",
        ParamType::Str,
        "semicolon-separated, strictly increasing 0-based indices into the input; \
         each must hold `from`. Omit to replace every occurrence.",
    ),
];

pub struct ReplaceCharacter;

impl Node for ReplaceCharacter {
    fn name(&self) -> &'static str {
        REPLACE
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/edits(replace_character)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        REPLACE_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let from = one_byte(REPLACE, params, "from")?;
        let to = one_byte(REPLACE, params, "to")?;
        let mut out = input.data.clone();

        match params.opt_str("positions") {
            Some(raw) => {
                for i in positions(REPLACE, raw)? {
                    if i >= out.len() {
                        return Err(out_of_range(REPLACE, i, out.len()));
                    }
                    if out[i] != from {
                        return Err(Error::bad_param(
                            REPLACE,
                            "positions",
                            format!(
                                "position {i} holds {:?}, not the requested {:?}",
                                out[i] as char, from as char
                            ),
                        ));
                    }
                    out[i] = to;
                }
            }
            None => {
                for b in out.iter_mut() {
                    if *b == from {
                        *b = to;
                    }
                }
            }
        }
        Ok(Repr::new(out, input.display))
    }
}

register_node!(REPLACE_CHARACTER => || Box::new(ReplaceCharacter));

// ---------------------------------------------------------------------------
// insert_characters
// ---------------------------------------------------------------------------

const INSERT_CHARS: &str = "insert_characters";

const INSERT_SCHEMA: &[ParamSpec] = &[
    ParamSpec::req("char", ParamType::Str, "the single byte to insert"),
    ParamSpec::req(
        "positions",
        ParamType::Str,
        "semicolon-separated, strictly increasing 0-based indices in the **output**: \
         after the edit, each listed index holds `char`",
    ),
];

pub struct InsertCharacters;

impl Node for InsertCharacters {
    fn name(&self) -> &'static str {
        INSERT_CHARS
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn source_digest(&self) -> &'static str {
        "ra-core/classical/edits(insert_characters)"
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        INSERT_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let ch = one_byte(INSERT_CHARS, params, "char")?;
        let list = positions(INSERT_CHARS, params.req_str(INSERT_CHARS, "positions")?)?;
        let out_len = input.data.len() + list.len();
        if let Some(&last) = list.last() {
            if last >= out_len {
                return Err(Error::bad_param(
                    INSERT_CHARS,
                    "positions",
                    format!(
                        "output position {last} is out of range: inserting {} \
                         characters into {} bytes yields {out_len}",
                        list.len(),
                        input.data.len()
                    ),
                ));
            }
        }

        let mut out = Vec::with_capacity(out_len);
        let mut next = 0usize; // index into `list`
        let mut src = 0usize; // index into the input
        let mut i = 0usize; // index into the output
        while i < out_len {
            if next < list.len() && list[next] == i {
                out.push(ch);
                next += 1;
            } else {
                out.push(input.data[src]);
                src += 1;
            }
            i += 1;
        }
        Ok(Repr::new(out, input.display))
    }
}

register_node!(INSERT_CHARACTERS => || Box::new(InsertCharacters));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;

    fn n(name: &str) -> &'static dyn Node {
        registry().get(name).unwrap()
    }

    #[test]
    fn all_three_are_xf_family_and_not_layer_forming() {
        for name in [REMOVE, REPLACE, INSERT_CHARS] {
            let node = n(name);
            assert_eq!(node.family(), Family::Xf, "{name}");
            assert!(!node.layer_forming(), "{name}");
            assert!(!node.terminal(), "{name}");
        }
    }

    // -- remove_character ---------------------------------------------------

    /// Hand-computed. In `"aXa b XcX"` the `X` at index 1 sits between two `a`s and
    /// the one at index 6 does not (its neighbours are a space and `c`), so
    /// `between_doubles` removes only the first, while the unconditional form
    /// removes all three.
    #[test]
    fn remove_hand_computed_between_doubles_and_unconditional() {
        let node = n(REMOVE);
        let input = Repr::bytes(b"aXa b XcX".to_vec());

        let guarded = node
            .apply(&input, &params! {"char" => "X", "between_doubles" => true})
            .unwrap();
        assert_eq!(guarded.data, b"aa b XcX");

        let all = node.apply(&input, &params! {"char" => "X"}).unwrap();
        assert_eq!(all.data, b"aa b c");
    }

    /// Explicit positions are what make "all but one" expressible without the node
    /// having to decide which one.
    #[test]
    fn remove_explicit_positions_keep_the_unlisted_occurrences() {
        let node = n(REMOVE);
        // "gxg" three times; keep the middle one
        let input = Repr::bytes(b"gxg-gxg-gxg".to_vec());
        let out = node
            .apply(
                &input,
                &params! {"char" => "x", "positions" => "1;9", "between_doubles" => true},
            )
            .unwrap();
        assert_eq!(out.data, b"gg-gxg-gg");
    }

    #[test]
    fn remove_rejects_positions_that_do_not_hold_the_character() {
        let node = n(REMOVE);
        let input = Repr::bytes(b"abcdef".to_vec());
        let e = node
            .apply(&input, &params! {"char" => "x", "positions" => "2"})
            .unwrap_err();
        assert!(format!("{e}").contains("not the requested"), "{e}");
    }

    #[test]
    fn remove_rejects_a_position_failing_the_between_doubles_guard() {
        let node = n(REMOVE);
        let input = Repr::bytes(b"abxcd".to_vec());
        // index 2 holds 'x' but its neighbours are 'b' and 'c'
        assert!(node
            .apply(
                &input,
                &params! {"char" => "x", "positions" => "2", "between_doubles" => true}
            )
            .is_err());
        // ... and succeeds with the guard off
        let ok = node
            .apply(&input, &params! {"char" => "x", "positions" => "2"})
            .unwrap();
        assert_eq!(ok.data, b"abcd");
    }

    /// A trailing occurrence has no right-hand neighbour, so it can never be
    /// "between doubles". rev11 needs exactly this: its ninth removal is the
    /// odd-length tail pad Playfair appended, not a doubling pad.
    #[test]
    fn remove_a_trailing_character_is_not_between_doubles() {
        let node = n(REMOVE);
        let input = Repr::bytes(b"abcx".to_vec());
        assert!(node
            .apply(
                &input,
                &params! {"char" => "x", "positions" => "3", "between_doubles" => true}
            )
            .is_err());
        let ok = node
            .apply(&input, &params! {"char" => "x", "positions" => "3"})
            .unwrap();
        assert_eq!(ok.data, b"abc");
    }

    // -- replace_character --------------------------------------------------

    #[test]
    fn replace_hand_computed_at_positions_and_everywhere() {
        let node = n(REPLACE);
        let input = Repr::bytes(b"iiii".to_vec());

        let some = node
            .apply(&input, &params! {"from" => "i", "to" => "j", "positions" => "0;3"})
            .unwrap();
        assert_eq!(some.data, b"jiij");

        let all = node
            .apply(&input, &params! {"from" => "i", "to" => "j"})
            .unwrap();
        assert_eq!(all.data, b"jjjj");
    }

    #[test]
    fn replace_rejects_a_position_not_holding_the_source_character() {
        let node = n(REPLACE);
        let e = n(REPLACE)
            .apply(
                &Repr::bytes(b"abc".to_vec()),
                &params! {"from" => "i", "to" => "j", "positions" => "0"},
            )
            .unwrap_err();
        assert!(format!("{e}").contains("not the requested"), "{e}");
        assert!(node
            .apply(
                &Repr::bytes(b"abc".to_vec()),
                &params! {"from" => "i", "to" => "j", "positions" => "9"}
            )
            .is_err());
    }

    // -- insert_characters --------------------------------------------------

    /// Hand-computed, and the reason output-frame indices are the right choice:
    /// inserting `.` at output positions 0, 3 and 7 into `"abcde"` gives
    /// `".ab.cde."`, in which those three indices hold `.` — read straight off the
    /// result, with no arithmetic.
    #[test]
    fn insert_hand_computed_in_the_output_frame() {
        let node = n(INSERT_CHARS);
        let out = node
            .apply(
                &Repr::bytes(b"abcde".to_vec()),
                &params! {"char" => ".", "positions" => "0;3;7"},
            )
            .unwrap();
        assert_eq!(out.data, b".ab.cde.");
        for i in [0usize, 3, 7] {
            assert_eq!(out.data[i], b'.', "output index {i}");
        }
    }

    #[test]
    fn insert_at_the_final_output_index_appends() {
        let node = n(INSERT_CHARS);
        let out = node
            .apply(
                &Repr::bytes(b"abc".to_vec()),
                &params! {"char" => "!", "positions" => "3"},
            )
            .unwrap();
        assert_eq!(out.data, b"abc!");
    }

    #[test]
    fn insert_beyond_the_output_length_errors_rather_than_panics() {
        let node = n(INSERT_CHARS);
        let e = node
            .apply(
                &Repr::bytes(b"abc".to_vec()),
                &params! {"char" => "!", "positions" => "4"},
            )
            .unwrap_err();
        assert!(format!("{e}").contains("out of range"), "{e}");
    }

    // -- shared parameter handling -----------------------------------------

    #[test]
    fn position_lists_must_be_strictly_increasing_and_numeric() {
        assert!(positions(REMOVE, "3;3").is_err());
        assert!(positions(REMOVE, "5;2").is_err());
        assert!(positions(REMOVE, "-1").is_err());
        assert!(positions(REMOVE, "two").is_err());
        assert!(positions(REMOVE, "").is_err());
        assert_eq!(positions(REMOVE, "0; 4 ;9").unwrap(), vec![0, 4, 9]);
    }

    #[test]
    fn multi_byte_character_parameters_are_rejected() {
        let d = Repr::bytes(b"abc".to_vec());
        assert!(n(REMOVE).apply(&d, &params! {"char" => "xy"}).is_err());
        assert!(n(REPLACE)
            .apply(&d, &params! {"from" => "ab", "to" => "c"})
            .is_err());
        assert!(n(INSERT_CHARS)
            .apply(&d, &params! {"char" => "..", "positions" => "0"})
            .is_err());
    }

    #[test]
    fn required_parameters_are_required() {
        let d = Repr::bytes(b"abc".to_vec());
        assert!(n(REMOVE).apply(&d, &Params::new()).is_err());
        assert!(n(REPLACE).apply(&d, &params! {"from" => "a"}).is_err());
        assert!(n(INSERT_CHARS).apply(&d, &params! {"char" => "."}).is_err());
    }

    /// The display is carried through: these are edits to a representation, not a
    /// change of how it is displayed.
    #[test]
    fn display_is_preserved() {
        let input = Repr::new(b"aXa".to_vec(), crate::repr::Display::Hex);
        let out = n(REMOVE).apply(&input, &params! {"char" => "X"}).unwrap();
        assert_eq!(out.display, crate::repr::Display::Hex);
    }

    // -- rev11 --------------------------------------------------------------

    /// rev11 steps 4, 5 and 6, on the real recorded intermediates.
    ///
    /// Every position below is **recovered** by diffing the corpus's own recorded
    /// step outputs against each other, not transcribed from the record — the
    /// record gives prose ("all but one", "some I") and the outputs, never the
    /// positions.
    ///
    /// Two findings about the recorded prose, both material:
    ///
    /// - Step 4's note says "all but one" padding X between doubles. The Playfair
    ///   output has **ten** X's flanked by identical letters, of which the record
    ///   removes **eight**, keeping *two* (at offsets 61 and 172) — not one. Its
    ///   ninth removal is the X at offset 459, the very last character, which is
    ///   Playfair's odd-length tail pad and is not between doubles at all. So the
    ///   note is right in spirit and wrong in both counts, which is exactly why the
    ///   node takes positions rather than a rule.
    /// - Step 5's "some I with J" is eighteen replacements.
    /// - Step 6 inserts eleven periods.
    #[test]
    fn reproduces_rev11_steps_four_five_and_six() {
        // rev11's Playfair output: 460 letters, reproduced from the corpus
        // ciphertext by `reverse | rot:n=20 | playfair:key=ZOMBIES`.
        const STEP3: &str = "cubeuvridxiledluvebmdixcdtedmxgxgarcvtwmgbdgbpsntdzedrsogshtbxbsikaiesgtagbgbsaehcumkuhmreyfhxbfktudmcyarbipgobestsechhabmacvpmiexgzgxgahgwcbmdvldeacbigyiteotgiptkgtahueqpixitqnrixiuycmqvdfzfzitgmnskptpxrpgqxaskurhkxkpzvonmoegsbueeimizxzshvwrubbhbquadrtqkitxhtbtiklenpwqtudspzdtxcpolaxomcntxhfdogfeomkiptgowzfpsndtihaleqrlxwsapncaqxgckzsefhetizixincaxenftprnmiekingqcknwmqfadfhttifmqxqofawugbeiiuehghnvcanwqcvqfatnpzacavqpqtwtfxfsicmyedqbupwisepzfzfloudpoctdpx";
        // The corpus's recorded step-4, step-5 and step-6 outputs, verbatim. Note
        // the single upper-case `X` at offset 60 of STEP4: the record capitalised
        // the X it meant to keep, which is where "all but one" comes from — and it
        // then kept a second one, at offset 170, without marking it. Comparison is
        // therefore case-insensitive on step 4.
        const STEP4: &str = "cubeuvridxiledluvebmdixcdtedmxggarcvtwmgbdgbpsntdzedrsogshtbXbsikaiesgtagbgbsaehcumkuhmreyfhxbfktudmcyarbipgobestsechhabmacvpmiexgzggahgwcbmdvldeacbigyiteotgiptkgtahueqpixitqnriiuycmqvdfzfzitgmnskptpxrpgqxaskurhkkpzvonmoegsbueeimizzshvwrubbhbquadrtqkitxhtbtiklenpwqtudspzdtxcpolaxomcntxhfdogfeomkiptgowzfpsndtihaleqrlxwsapncaqxgckzsefhetiziincaxenftprnmiekingqcknwmqfadfhttifmqqofawugbeiiuehghnvcanwqcvqfatnpzacavqpqtwtffsicmyedqbupwisepzfzfloudpoctdp";
        const STEP5: &str = "cubeuvridxJledluvebmdJxcdtedmxggarcvtwmgbdgbpsntdzedrsogshtbxbsJkaJesgtagbgbsaehcumkuhmreyfhxbfktudmcyarbipgobestsechhabmacvpmiexgzggahgwcbmdvldeacbigyiteotgiptkgtahueqpJxitqnriJuycmqvdfzfzJtgmnskptpxrpgqxaskurhkkpzvonmoegsbueeJmizzshvwrubbhbquadrtqkJtxhtbtiklenpwqtudspzdtxcpolaxomcntxhfdogfeomkJptgowzfpsndtihaleqrlxwsapncaqxgckzsefhetJziJncaxenftprnmJekingqcknwmqfadfhttJfmqqofawugbeJJuehghnvcanwqcvqfatnpzacavqpqtwtffsJcmyedqbupwJsepzfzfloudpoctdp";
        const STEP6: &str = "cubeuvridxjledluvebmdjxcdtedmxggarcvtwmgbdgbps.ntdzedrsogshtbxbsjkajesgtagbgbsaehcu.mkuhmreyfhxbfktudmcyarbipgobestsechhabmacvpmiexgzggahgwcbmdvldeacbigyiteotgiptkgt.ahueqpjxitqnr.ijuycmqvdfzfzjtgmnskp.tpxrpgqxaskurhkkpzvo.nmoegsbuee.jmizzsh.vwrubbhbquadrtqkjtxhtb.tikle.npwqtudspzdtxcpolaxomcntxhfdogfeomkjptgowzfpsndtihaleqrlxwsapncaqxgckzsefhetjzijn.caxenftprnmjekingqcknwmqfadfhttjfmqqofawugbejjuehghnvcanwqcvqfatnpzacavqpqtwtffsjcmyedqbupwjsepzfzfloudpoctdp";

        assert_eq!(STEP3.len(), 460);
        assert_eq!(STEP4.len(), 451);
        assert_eq!(STEP5.len(), 451);
        assert_eq!(STEP6.len(), 462);

        // step 4: nine X removals. Eight are doubling pads; the ninth (459) is the
        // odd-length tail pad, so `between_doubles` is *not* asserted here.
        let s4 = n(REMOVE)
            .apply(
                &Repr::bytes(STEP3.as_bytes().to_vec()),
                &params! {
                    "char" => "x",
                    "positions" => "31;133;179;215;235;345;383;427;459",
                },
            )
            .unwrap();
        assert_eq!(String::from_utf8_lossy(&s4.data), STEP4.to_ascii_lowercase());

        // the first eight really are between doubles, and the ninth really is the
        // final character — assert the classification rather than describing it
        let b = STEP3.as_bytes();
        for i in [31usize, 133, 179, 215, 235, 345, 383, 427] {
            assert_eq!(b[i], b'x');
            assert_eq!(b[i - 1], b[i + 1], "offset {i} should be between doubles");
        }
        assert_eq!(b[459], b'x');
        assert_eq!(b.len(), 460, "offset 459 is the last character: a tail pad");

        // and two between-doubles X's are deliberately kept, against a note that
        // says one
        let kept: Vec<usize> = (1..b.len() - 1)
            .filter(|&i| b[i] == b'x' && b[i - 1] == b[i + 1])
            .filter(|i| ![31usize, 133, 179, 215, 235, 345, 383, 427].contains(i))
            .collect();
        assert_eq!(kept, vec![61, 172]);

        // step 5: eighteen i -> j replacements
        let s5 = n(REPLACE)
            .apply(
                &s4,
                &params! {
                    "from" => "i",
                    "to" => "j",
                    "positions" => "10;21;63;66;169;177;189;227;250;296;337;340;353;373;386;387;422;433",
                },
            )
            .unwrap();
        assert_eq!(String::from_utf8_lossy(&s5.data), STEP5.to_ascii_lowercase());

        // step 6: eleven periods, at output positions
        let s6 = n(INSERT_CHARS)
            .apply(
                &s5,
                &params! {
                    "char" => ".",
                    "positions" => "46;83;165;179;201;222;233;241;264;270;352",
                },
            )
            .unwrap();
        assert_eq!(String::from_utf8_lossy(&s6.data), STEP6);
    }
}
