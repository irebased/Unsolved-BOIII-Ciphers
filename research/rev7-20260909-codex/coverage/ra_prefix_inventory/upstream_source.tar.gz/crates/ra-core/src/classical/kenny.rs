//! Kenny code, matching geocachingtoolbox.com's implementation.
//!
//! Each of a-z maps to a fixed 3-character code drawn from `{m, p, f}` (26 of
//! the 27 possible 3-letter combinations over that alphabet; `fff` is unused).
//! The site's default method is `Decrypt`, matching this crate's decrypt-only
//! engine, so [`Kenny`] implements exactly that direction; `encode` below is a
//! test-only transliteration of the site's `Encrypt` branch, used only to
//! produce ground-truth ciphertext for round-trip tests.
//!
//! # Decrypt algorithm (verbatim from the site)
//!
//! Input is split on single space characters into groups. Within each group,
//! walk forward taking 3-character chunks: if a chunk case-insensitively
//! matches one of the 26 codes, emit the corresponding lowercase letter and
//! advance 3; otherwise emit the chunk's *first* character unchanged (original
//! case preserved) and advance 1 — this is how stray non-code text or a
//! short trailing chunk survives a decode. A single space is re-inserted
//! between groups (not after the last one).
//!
//! # Artifacts
//!
//! Output is built as an HTML string and written into `kennyCodeDiv` via
//! `.innerHTML =` (`copy_artifact_risk: HIGH`), so the default [`OutputFmt`]
//! carries a trailing CRLF (the Chromium select-all-copy artifact). The site
//! applies no normalisation to the input text itself.

use crate::classical::toolfmt::{read_input_norm, read_output_fmt, InputNorm, OutputFmt, Trailing};
use crate::error::Result;
use crate::node::{Family, Node, ParamSpec};
use crate::params::Params;
use crate::repr::Repr;
use crate::{artifact_param_specs, register_node};

const KENNY_SCHEMA: &[ParamSpec] = &artifact_param_specs!();

/// The site's `code` array: `CODE[i]` is the 3-letter code for `b'a' + i`.
const CODE: [&[u8; 3]; 26] = [
    b"mmm", b"mmp", b"mmf", b"mpm", b"mpp", b"mpf", b"mfm", b"mfp", b"mff", b"pmm", b"pmp", b"pmf",
    b"ppm", b"ppp", b"ppf", b"pfm", b"pfp", b"pff", b"fmm", b"fmp", b"fmf", b"fpm", b"fpp", b"fpf",
    b"ffm", b"ffp",
];

fn code_index(chunk: &[u8]) -> Option<usize> {
    if chunk.len() != 3 {
        return None;
    }
    let lower = [
        chunk[0].to_ascii_lowercase(),
        chunk[1].to_ascii_lowercase(),
        chunk[2].to_ascii_lowercase(),
    ];
    CODE.iter().position(|c| **c == lower)
}

/// Decode Kenny-coded text back to plaintext, following the site's decrypt
/// algorithm exactly (see module docs).
pub fn decode(text: &[u8]) -> Vec<u8> {
    let groups: Vec<&[u8]> = split_on_space(text);
    let mut out = Vec::new();
    for (gi, group) in groups.iter().enumerate() {
        let mut j = 0;
        while j < group.len() {
            let end = (j + 3).min(group.len());
            let chunk = &group[j..end];
            if let Some(idx) = code_index(chunk) {
                out.push(b'a' + idx as u8);
                j += 3;
            } else {
                out.push(chunk[0]);
                j += 1;
            }
        }
        if gi + 1 < groups.len() {
            out.push(b' ');
        }
    }
    out
}

fn split_on_space(text: &[u8]) -> Vec<&[u8]> {
    if text.is_empty() {
        return vec![&[]];
    }
    text.split(|&b| b == b' ').collect()
}

/// Encode plaintext into Kenny code. Test-only: this crate is decrypt-direction,
/// so nothing but the test suite (proving [`decode`] agrees with the site's
/// algorithm) needs it.
#[cfg(test)]
fn encode(text: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    for &b in text {
        let lower = b.to_ascii_lowercase();
        if lower.is_ascii_lowercase() {
            let idx = (lower - b'a') as usize;
            out.extend_from_slice(CODE[idx]);
        } else {
            out.push(b);
        }
    }
    out
}

fn default_input_norm() -> InputNorm {
    InputNorm::default()
}

fn default_output_fmt() -> OutputFmt {
    OutputFmt {
        trailing: Trailing::CrLf,
        ..Default::default()
    }
}

/// Kenny code, decrypting: a fixed 26-letter-to-3-character substitution.
pub struct Kenny;

impl Node for Kenny {
    fn name(&self) -> &'static str {
        "kenny"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        KENNY_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let in_norm = read_input_norm("kenny", params, default_input_norm())?;
        let out_fmt = read_output_fmt("kenny", params, default_output_fmt())?;

        let normalised = in_norm.apply(&input.data);
        let transformed = decode(&normalised);
        let formatted = out_fmt.apply(&transformed);

        Ok(Repr::new(formatted, input.display))
    }
}

register_node!(KENNY => || Box::new(Kenny));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    #[test]
    fn code_table_has_26_distinct_entries() {
        let mut seen: Vec<&[u8; 3]> = CODE.to_vec();
        seen.sort();
        seen.dedup();
        assert_eq!(seen.len(), 26);
    }

    #[test]
    fn encode_hello() {
        // h=7 -> mfp, e=4 -> mpp, l=11 -> pmf, l=11 -> pmf, o=14 -> ppf
        assert_eq!(encode(b"hello"), b"mfpmpppmfpmfppf");
    }

    #[test]
    fn decode_hello_round_trips() {
        let encoded = encode(b"hello");
        assert_eq!(decode(&encoded), b"hello");
    }

    /// `encode` always lowercases a matched letter before looking up its code
    /// (the site does `splitChars[i].toLowerCase()` with no case bit stored
    /// anywhere), and `decode` always emits the lowercase letter back — so the
    /// round trip only recovers the *lowercased* original, exactly like the
    /// site itself; case is genuinely lost, not a bug in this port.
    #[test]
    fn decode_matches_encode_for_a_range_of_inputs() {
        let samples: &[&[u8]] = &[
            b"hello world",
            b"The Quick Brown Fox 123!",
            b"zzz aaa",
            b"a",
            b"",
        ];
        for sample in samples {
            let encoded = encode(sample);
            let decoded = decode(&encoded);
            let want = sample.to_ascii_lowercase();
            assert_eq!(decoded, want, "sample={sample:?} encoded={encoded:?}");
        }
    }

    #[test]
    fn decode_preserves_case_of_unmatched_leading_byte() {
        // 'X' is not a code letter's first char in any valid triple combined
        // with the rest, so this exercises the "not found" branch directly.
        assert_eq!(decode(b"XYZ"), b"XYZ");
    }

    #[test]
    fn decode_single_space_separates_groups() {
        let encoded_hi = encode(b"hi");
        let mut input = encoded_hi.clone();
        input.push(b' ');
        input.extend_from_slice(&encode(b"there"));
        let decoded = decode(&input);
        assert_eq!(decoded, b"hi there");
    }

    #[test]
    fn decode_is_case_insensitive_on_the_code_itself() {
        assert_eq!(decode(b"MMM"), b"a");
        assert_eq!(decode(b"MmM"), b"a");
    }

    #[test]
    fn kenny_node_decodes_default_no_params() {
        let n = registry().get("kenny").unwrap();
        let p = params! {};
        let out = n
            .apply(&Repr::bytes(b"mfpmpppmfpmfppf".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"hello\r\n");
    }

    #[test]
    fn kenny_default_output_has_trailing_crlf() {
        // .innerHTML write (HIGH copy_artifact_risk), so the default must
        // append the Chromium select-all-copy CRLF artifact.
        let n = registry().get("kenny").unwrap();
        let p = params! {};
        let out = n.apply(&Repr::bytes(b"mmm".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"a\r\n");
    }

    #[test]
    fn kenny_trailing_can_be_disabled_via_param() {
        let n = registry().get("kenny").unwrap();
        let p = params! {"trailing" => "none"};
        let out = n.apply(&Repr::bytes(b"mmm".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"a");
    }

    #[test]
    fn kenny_preserves_display() {
        let n = registry().get("kenny").unwrap();
        let p = params! {};
        let out = n
            .apply(&Repr::new(b"mmm".to_vec(), Display::Hex), &p)
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn kenny_is_xf_family_and_not_layer_forming() {
        let n = registry().get("kenny").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
