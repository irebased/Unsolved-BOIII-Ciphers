//! Rumkin's "Rotate" cipher (`rumkin.com/tools/cipher/rotate.php`).
//!
//! Source: `docs/toolsites/rumkin.json`, `page_id: "rotate"`, 2015-era
//! Wayback snapshot (`20150207115326`). The tool lays the (CR/LF-stripped)
//! text into a `cols`-wide grid, filling one column at a time down its
//! height (`grid[i % cols] += t2.charAt(i)`), then rotates 90 degrees:
//! "Rotate Left" (`encdec=1`, the site's own *encode* direction) reads the
//! grid's columns back out **in reverse column order, top-to-bottom**;
//! "Rotate Right" (`encdec=-1`, the site's own *decode* direction) reads them
//! **in original column order, each reversed bottom-to-top**. This node is
//! decrypt-direction, so it always runs the site's own decode branch
//! (`encdec=-1`) directly — this is *not* a derived inverse of the encode
//! formula, it is the exact branch the site itself labels "Rotate Right 90°
//! (decode)".
//!
//! # This is not a self-inverting rotation for a fixed `cols`
//!
//! Rotating a `C`-column grid left turns it into (conceptually) an `R`-row by
//! `C`-column shape read out as `C` rows of length `R` — but the site's tool
//! always treats its `cols` input as "how many columns to lay the *current*
//! text into", never remembering the previous grid's shape. So decoding with
//! the *same* `cols` the encoder used does **not** recover the original text
//! (confirmed empirically: `Rotate(-1, Rotate(1, "HELLOWORLD", 3), 3)` !=
//! `"HELLOWORLD"`). Recovering the original requires decoding with `cols` set
//! to the *row count* of the encoder's grid (`ceil(original_length / encode_cols)`)
//! instead — e.g. `Rotate(-1, Rotate(1, "HELLOWORLD", 3), 4)` does recover
//! `"HELLOWORLDXX"` (the padded plaintext; see below). A puzzle-maker who used
//! this tool to encrypt therefore hands a solver a `cols` value that is the
//! *rotated* grid's width, not the plaintext grid's — this node's `cols`
//! parameter is exactly that value, matching the site.
//!
//! # Padding is always uppercase `X`, and is irreversible
//!
//! If the CR/LF-stripped text length isn't a multiple of `cols`, the site
//! pads with literal uppercase `X` characters — appended to *both* the
//! padded-for-rotation copy and the original (CRLF-bearing) copy used to
//! reinsert CR/LF afterwards — until it is. There is no way to tell, from the
//! ciphertext alone, how many (if any) of a decoded result's trailing `X`s
//! are padding versus genuine plaintext; this node reproduces the padding
//! rule exactly (so its output matches the site's) and leaves stripping any
//! resulting trailing `X`s to the operator/sweep, the same way this crate
//! generally leaves genuinely ambiguous artifacts for a human or sweep to
//! resolve rather than guessing.
//!
//! # CR/LF handling
//!
//! Newlines are excluded from the grid/rotation entirely and reinserted at
//! their original character offsets afterwards, via the same `Tr`/
//! `InsertCRLF` convention as [`crate::classical::skip`] — see
//! [`crate::classical::rumkin_common`] for the shared reconstruction (the
//! functions themselves aren't in the extracted JSON) and how it's verified.
//! Per the page's own description ("Spaces are rotated with the letters,
//! enters (newlines) are not"), spaces *do* participate in the grid/rotation
//! like any other character.
//!
//! # Output artifact
//!
//! Writes into `<span id=output>` via `.innerHTML` (`copy_artifact_risk:
//! MEDIUM`), no case transformation — same defaults as `skip` (see that
//! module's docs for the `.innerHTML` -> `Trailing::CrLf` default rationale).

use crate::classical::rumkin_common::{insert_crlf, strip_crlf};
use crate::classical::toolfmt::{read_input_norm, read_output_fmt, CaseFold, InputNorm, OutputFmt, Trailing};
use crate::error::Result;
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

const ROTATE_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(ParamSpec::opt(
    "cols",
    ParamType::Int,
    "grid width for this rotation (site default: 1, which fully REVERSES the \
     text -- a single column read back reversed, not a no-op); must be >= 1 \
     -- values below 1 are clamped up to 1, matching the site"
),);

const DEFAULT_COLS: i64 = 1;
const PAD_BYTE: u8 = b'X';

/// Build the `cols`-wide grid (`grid[c]` = every byte of `stripped` at
/// offsets `c, c+cols, c+2*cols, ...`, i.e. one bucket per column, filled in
/// row-major order) and read it back out via the site's "Rotate Right"
/// (decode) rule: each column in its original order, reversed. Padding
/// with [`PAD_BYTE`] to a multiple of `cols` is the caller's job (see
/// [`Rotate::apply`]).
fn rotate_right(stripped: &[u8], cols: usize) -> Vec<u8> {
    debug_assert!(cols >= 1 && stripped.len() % cols == 0);
    let mut grid: Vec<Vec<u8>> = vec![Vec::new(); cols];
    for (i, &b) in stripped.iter().enumerate() {
        grid[i % cols].push(b);
    }
    let mut out = Vec::with_capacity(stripped.len());
    for column in &grid {
        out.extend(column.iter().rev());
    }
    out
}

/// The site's "Rotate Left" (encode) rule: same grid, columns read back in
/// **reverse** order, top-to-bottom (not reversed within a column).
/// Test-only: this crate is decrypt-direction, so nothing but the test suite
/// (proving [`rotate_right`] matches the site's own decode branch, including
/// generating ground-truth vectors) needs it.
#[cfg(test)]
fn rotate_left(stripped: &[u8], cols: usize) -> Vec<u8> {
    debug_assert!(cols >= 1 && stripped.len() % cols == 0);
    let mut grid: Vec<Vec<u8>> = vec![Vec::new(); cols];
    for (i, &b) in stripped.iter().enumerate() {
        grid[i % cols].push(b);
    }
    let mut out = Vec::with_capacity(stripped.len());
    for c in (0..cols).rev() {
        out.extend_from_slice(&grid[c]);
    }
    out
}

/// Rumkin's Rotate cipher, decrypting: always runs the site's "Rotate Right"
/// branch directly.
pub struct Rotate;

impl Node for Rotate {
    fn name(&self) -> &'static str {
        "rotate"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        ROTATE_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let cols_raw = params.opt_i64("cols", DEFAULT_COLS);
        let cols: usize = if cols_raw < 1 { 1 } else { cols_raw as usize };

        let in_norm = read_input_norm("rotate", params, InputNorm::default())?;
        let normalized = in_norm.apply(&input.data);

        let (mut stripped, crlf) = strip_crlf(&normalized);
        while stripped.len() % cols != 0 {
            stripped.push(PAD_BYTE);
        }

        let decoded = if stripped.is_empty() {
            Vec::new()
        } else {
            rotate_right(&stripped, cols)
        };
        let with_crlf = insert_crlf(&decoded, &crlf);

        let out_fmt = read_output_fmt(
            "rotate",
            params,
            OutputFmt {
                case: CaseFold::Preserve,
                grouping: None,
                trailing: Trailing::CrLf, // .innerHTML select-all copy risk (MEDIUM)
            },
        )?;
        let out = out_fmt.apply(&with_crlf);
        Ok(Repr::new(out, input.display))
    }
}

register_node!(ROTATE => || Box::new(Rotate));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    // Ground truth generated by running the JSON's own Rotate() (encdec=1
    // for encode/"left", encdec=-1 for decode/"right") under Node, with
    // Tr/InsertCRLF/Reverse_String reconstructed from the tool's prose
    // description. Script: `rotate.js` in the task scratchpad; e.g.
    // `Rotate(1, "HELLOWORLD", 3)` -> `"LWLXEORXHLOD"`.

    #[test]
    fn rotate_left_matches_site_ground_truth() {
        assert_eq!(rotate_left(b"HELLOWORLDXX", 3), b"LWLXEORXHLOD");
        assert_eq!(rotate_left(b"THEQUICKBROWNFOX", 4), b"QKWXECOOHIRFTUBN");
    }

    #[test]
    fn rotate_right_matches_site_ground_truth_directly() {
        // Rotate(-1, "HROELWLDOL", 3) -> "LLEHXDLRXOWO" (site ground truth).
        // The site pads on decode too: length 10 isn't a multiple of 3, so
        // it appends 2 X's (to "HROELWLDOLXX") before permuting -- matching
        // this node's own padding step in `apply`.
        assert_eq!(rotate_right(b"HROELWLDOLXX", 3), b"LLEHXDLRXOWO");
    }

    /// The load-bearing finding from the module docs: decoding with the SAME
    /// `cols` the encoder used does not recover the original text.
    #[test]
    fn rotate_right_with_same_cols_does_not_invert_rotate_left() {
        let encoded = rotate_left(b"HELLOWORLDXX", 3); // pad 10->12 chars, cols 3
        let decoded_same_cols = rotate_right(&encoded, 3);
        assert_ne!(decoded_same_cols, b"HELLOWORLDXX");
        assert_eq!(decoded_same_cols, b"LRXLOXEWDHOL"); // site ground truth for dec1
    }

    /// Decoding with `cols` = the ORIGINAL grid's row count does recover the
    /// (padded) original -- confirmed against the site's own JS.
    #[test]
    fn rotate_right_with_row_count_cols_inverts_rotate_left() {
        let padded = b"HELLOWORLDXX"; // 10 chars padded to 12 for cols=3 -> 4 rows
        let encoded = rotate_left(padded, 3);
        let decoded = rotate_right(&encoded, 4);
        assert_eq!(decoded, padded);

        let padded2 = b"THEQUICKBROWNFOX"; // already a multiple of 4, no padding
        let encoded2 = rotate_left(padded2, 4);
        let decoded2 = rotate_right(&encoded2, 4);
        assert_eq!(decoded2, padded2);
    }

    #[test]
    fn crlf_round_trips_at_original_positions() {
        // Site ground truth: Rotate(1, "HEL\r\nLOWORLD", 3) -> "LWL\r\nXEORXHLOD".
        let ct = b"LWL\r\nXEORXHLOD";
        let (stripped, crlf) = strip_crlf(ct);
        assert_eq!(stripped, b"LWLXEORXHLOD");
        let decoded = rotate_right(&stripped, 4); // row-count inversion of cols=3, 12 chars
        let rebuilt = insert_crlf(&decoded, &crlf);
        // CRLF lands at its offset in the CIPHERTEXT (index 3), not the
        // plaintext's own CRLF offset -- confirmed against the site's own JS.
        assert_eq!(rebuilt, b"HEL\r\nLOWORLDXX");
    }

    #[test]
    fn rotate_node_decodes_via_registry() {
        let n = registry().get("rotate").unwrap();
        let p = params! {"cols" => 3i64, "trailing" => "none"};
        let out = n.apply(&Repr::bytes(b"HROELWLDOL".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"LLEHXDLRXOWO");
    }

    #[test]
    fn rotate_node_pads_with_uppercase_x() {
        let n = registry().get("rotate").unwrap();
        // Length 10, cols=3 -> pads with 2 X's to reach 12 before permuting.
        let p = params! {"cols" => 3i64, "trailing" => "none"};
        let out = n.apply(&Repr::bytes(b"HELLOWORLD".to_vec()), &p).unwrap();
        assert_eq!(out.data.len(), 12);
        assert_eq!(out.data, rotate_right(b"HELLOWORLDXX", 3));
    }

    #[test]
    fn rotate_node_clamps_cols_below_one_to_one() {
        let n = registry().get("rotate").unwrap();
        let p = params! {"cols" => 0i64, "trailing" => "none"};
        let out = n.apply(&Repr::bytes(b"HELLO".to_vec()), &p).unwrap();
        // cols=1: the whole text is one column, and decode reverses each
        // column -- confirmed against the site's own JS (`Rotate(-1,
        // "HELLO", 1)` -> `"OLLEH"`), so this is a full reversal, not a
        // no-op (that flagged finding is about "Rotate Left"/encode, whose
        // encode loop is `grid[cols-(i+1)]`; decode instead reverses each
        // column in place regardless of `cols`).
        assert_eq!(out.data, b"OLLEH");
    }

    #[test]
    fn rotate_node_default_cols_is_one_reverses_text() {
        let n = registry().get("rotate").unwrap();
        let p = params! {"trailing" => "none"};
        let out = n.apply(&Repr::bytes(b"HELLOWORLD".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"DLROWOLLEH");
    }

    #[test]
    fn rotate_node_handles_crlf_via_registry() {
        let n = registry().get("rotate").unwrap();
        let p = params! {"cols" => 4i64, "trailing" => "none"};
        let out = n
            .apply(&Repr::bytes(b"LWL\r\nXEORXHLOD".to_vec()), &p)
            .unwrap();
        assert_eq!(out.data, b"HEL\r\nLOWORLDXX");
    }

    #[test]
    fn rotate_node_empty_input_is_empty() {
        let n = registry().get("rotate").unwrap();
        let p = params! {"cols" => 3i64, "trailing" => "none"};
        let out = n.apply(&Repr::bytes(Vec::new()), &p).unwrap();
        assert_eq!(out.data, b"");
    }

    #[test]
    fn rotate_node_output_case_preserve_by_default() {
        let n = registry().get("rotate").unwrap();
        let p = params! {"cols" => 3i64, "trailing" => "none"};
        let ct = rotate_left(b"HeLLoWoRLdXX", 3);
        let out = n.apply(&Repr::bytes(ct.clone()), &p).unwrap();
        assert_eq!(out.data, rotate_right(&ct, 3));
    }

    #[test]
    fn rotate_preserves_display() {
        let n = registry().get("rotate").unwrap();
        let p = params! {"cols" => 3i64};
        let out = n
            .apply(&Repr::new(b"HROELWLDOL".to_vec(), Display::Hex), &p)
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn rotate_is_xf_family_and_not_layer_forming() {
        let n = registry().get("rotate").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
