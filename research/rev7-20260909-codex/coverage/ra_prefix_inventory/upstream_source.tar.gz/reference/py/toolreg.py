"""
toolreg.py  -  Per-tool versioning and selective invalidation.

The payoff of versioning each tool independently rather than versioning the
platform: when a single implementation is found defective you can compute EXACTLY
which coverage is voided, and re-run only that. Platform-level versioning forces
you to discard everything built on that platform version.

A chain is a composition of independently versioned tools. Chain identity is the
hash of the ordered tool identities plus bound parameters, so two workers running
different implementations of the same logical tool produce DIFFERENT chain ids and
can be cross-validated against each other.
"""
from __future__ import annotations
import hashlib, json
from typing import Dict, List, Optional


def h(*parts) -> str:
    m = hashlib.sha256()
    for p in parts:
        m.update(str(p).encode())
        m.update(b"\x1f")
    return m.hexdigest()


class Tool:
    """One versioned implementation of one logical operation."""
    def __init__(self, family, name, version, impl_hash,
                 conformance_status="UNTESTED", conformance_vectors=None,
                 supersedes=None):
        self.family = family                  # dec | cls | xf | dcd
        self.name = name                      # Twofish, reverse, hex, ...
        self.version = version
        self.impl_hash = impl_hash            # hash of the built artifact
        self.conformance_status = conformance_status
        self.conformance_vectors = conformance_vectors or []
        self.supersedes = supersedes

    @property
    def tool_id(self) -> str:
        return f"{self.family}:{self.name}@{self.version}#{self.impl_hash[:12]}"

    def is_admissible(self, required_vectors: Dict[str, List[str]]) -> (bool, str):
        if self.conformance_status != "PASS":
            return False, f"conformance={self.conformance_status}"
        if self.family == "dec":
            expected = {c for c, _ in required_vectors.get(self.name, [])}
            if expected and not (set(self.conformance_vectors) & expected):
                return False, (f"cited vectors {sorted(self.conformance_vectors)} do not "
                               f"exercise {self.name}; expected one of {sorted(expected)}")
        return True, "ok"

    def to_json(self):
        return {"tool_id": self.tool_id, "family": self.family, "name": self.name,
                "version": self.version, "impl_hash": self.impl_hash,
                "conformance": {"status": self.conformance_status,
                                "vectors": self.conformance_vectors},
                "supersedes": self.supersedes}


class ToolRegistry:
    def __init__(self, conformance_vectors: Dict[str, List]):
        self.tools: Dict[str, Tool] = {}
        self.revoked: Dict[str, str] = {}          # tool_id -> reason
        self.conformance_vectors = conformance_vectors

    def register(self, t: Tool) -> Tool:
        self.tools[t.tool_id] = t
        return t

    def revoke(self, tool_id: str, reason: str):
        self.revoked[tool_id] = reason

    def status(self, tool_id: str) -> str:
        if tool_id in self.revoked:
            return "REVOKED"
        t = self.tools.get(tool_id)
        if not t:
            return "UNKNOWN"
        ok, _ = t.is_admissible(self.conformance_vectors)
        return "ADMISSIBLE" if ok else "INADMISSIBLE"

    def implementations_of(self, name: str) -> List[Tool]:
        return [t for t in self.tools.values() if t.name == name]


class ChainRef:
    """A concrete pipeline: ordered tool_ids plus the parameter binding."""
    def __init__(self, tool_ids: List[str], params: Dict):
        self.tool_ids = list(tool_ids)
        self.params = params

    @property
    def chain_id(self) -> str:
        canon = json.dumps({"t": self.tool_ids, "p": self.params},
                           sort_keys=True, separators=(",", ":"))
        return "chain:" + hashlib.sha256(canon.encode()).hexdigest()[:24]

    def uses(self, tool_id) -> bool:
        return tool_id in self.tool_ids


class Ledger:
    """Records coverage claims as (chain set) and supports selective invalidation."""
    def __init__(self, registry: ToolRegistry):
        self.reg = registry
        self.claims: List[Dict] = []

    def submit(self, claim_id, worker, chains: List[ChainRef], candidates: int):
        self.claims.append({"claim_id": claim_id, "worker": worker,
                            "chains": chains, "candidates": candidates,
                            "status": "ACTIVE"})

    def invalidate_tool(self, tool_id: str, reason: str):
        """Revoke one tool version; report exactly which coverage is voided."""
        self.reg.revoke(tool_id, reason)
        voided, kept = [], []
        for c in self.claims:
            if any(ch.uses(tool_id) for ch in c["chains"]):
                c["status"] = "VOID"
                voided.append(c)
            else:
                kept.append(c)
        return voided, kept

    def totals(self):
        active = sum(c["candidates"] for c in self.claims if c["status"] == "ACTIVE")
        void = sum(c["candidates"] for c in self.claims if c["status"] == "VOID")
        return active, void


# --------------------------------------------------------------------------
if __name__ == "__main__":
    CV = json.load(open("../data/conformance_suite.json"))["vectors"]
    CV = {k: [(d["cipher"], d["mode"]) for d in v] for k, v in CV.items()}
    reg = ToolRegistry(CV)

    # two independent implementations of the same logical primitive
    tw_a = reg.register(Tool("dec", "Twofish", "1.2.0", h("twofishA"), "PASS", ["rev9"]))
    tw_b = reg.register(Tool("dec", "Twofish", "0.9.1", h("twofishB"), "PASS", ["rev9"]))
    des  = reg.register(Tool("dec", "DES", "3.23.0", h("pycdes"), "PASS", ["rev2", "rev9"]))
    xtea = reg.register(Tool("dec", "XTEA", "0.2.0", h("xtea02"), "PASS", ["rev2"]))  # wrong vector
    rev  = reg.register(Tool("xf", "reverse", "1.0.0", h("rev1"), "PASS", []))
    b64  = reg.register(Tool("dcd", "base64", "1.0.0", h("b64"), "PASS", []))

    print("=" * 78); print("TOOL REGISTRY"); print("=" * 78)
    for t in reg.tools.values():
        ok, why = t.is_admissible(CV)
        print(f"  {t.tool_id:<46} {reg.status(t.tool_id):<13} {'' if ok else why}")

    print("\n  NOTE: two Twofish implementations coexist with distinct tool_ids.")
    print("  Chains built on each are distinguishable, enabling N-version cross-check.")

    # build claims
    led = Ledger(reg)
    c1 = ChainRef([b64.tool_id, tw_a.tool_id], {"key": "Zombies", "mode": "cfb8"})
    c2 = ChainRef([b64.tool_id, tw_b.tool_id], {"key": "Zombies", "mode": "cfb8"})
    c3 = ChainRef([b64.tool_id, des.tool_id], {"key": "Zombies", "mode": "cfb8"})
    c4 = ChainRef([b64.tool_id, rev.tool_id, tw_a.tool_id], {"key": "TheGiant", "mode": "ecb"})

    led.submit("claim-001", "worker-alpha", [c1, c3], 120_000_000)
    led.submit("claim-002", "worker-beta",  [c2, c3], 118_000_000)
    led.submit("claim-003", "worker-gamma", [c4],      95_000_000)
    led.submit("claim-004", "worker-delta", [c3],      40_000_000)

    print("\n" + "=" * 78); print("CHAIN IDENTITY"); print("=" * 78)
    print(f"  Twofish impl A chain: {c1.chain_id}")
    print(f"  Twofish impl B chain: {c2.chain_id}")
    print("  -> different chain ids for the same logical pipeline, so agreement")
    print("     between them is meaningful evidence rather than a tautology.")

    a, v = led.totals()
    print("\n" + "=" * 78); print("SELECTIVE INVALIDATION"); print("=" * 78)
    print(f"  before: ACTIVE={a:,}  VOID={v:,}")
    voided, kept = led.invalidate_tool(tw_a.tool_id, "off-by-one in key schedule, fails rev9 on re-test")
    a2, v2 = led.totals()
    print(f"\n  revoked {tw_a.tool_id}")
    print(f"  voided claims : {[c['claim_id'] for c in voided]}")
    print(f"  retained      : {[c['claim_id'] for c in kept]}")
    print(f"  after : ACTIVE={a2:,}  VOID={v2:,}")
    print(f"\n  Platform-level versioning would have voided all "
          f"{a:,} candidates.")
    print(f"  Per-tool versioning voids {v2:,} and retains {a2:,} "
          f"({100*a2/a:.0f}% preserved).")
