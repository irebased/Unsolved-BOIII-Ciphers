//! Crypto Corner's Columnar Transposition Cipher tool.
//!
//! Source: the page's own JavaScript, fetched directly (task scratchpad
//! `pages/cc_columnar_js.txt`). `columnEncrypt`/`columnDecrypt`/`keyNumbers`
//! are transliterated verbatim below.
//!
//! # Column ordering: `keyNumbers`
//!
//! ```js
//! for (i = 0; i < alphabet.length; i++)
//!   for (j = 0; j < key.length; j++)
//!     if (key[j] == alphabet[i]) { k[j] = a; a = a + 1; }
//! ```
//!
//! For each letter of the alphabet in order, every column whose key letter
//! matches gets the *next* rank, scanning columns left to right. This gives
//! ordinary alphabetical-order columns, and for repeated key letters, ties
//! are broken by original left-to-right column position (the inner `j` loop
//! order) — the same stable-tie convention as CrypTool's tool
//! (`cryptool_columnar.rs`), just fixed to the 26-letter Latin alphabet
//! instead of a user-definable one.
//!
//! # Grid fill and read-out
//!
//! `columnEncrypt` fills an `m x key.length` grid row-major (`m =
//! ceil(len/key.length)`, so the last row may be short and its missing cells
//! are simply never read), then for each column in ascending rank order,
//! appends that column's cells top-to-bottom. `columnDecrypt` is the direct
//! inverse: mark the last row's short-column cells `"blank"` up front (using
//! the *un-permuted* column index, mirroring the site's own
//! `key.length - j` indexing), then walk ranks in order handing out
//! ciphertext characters to the matching column's non-blank cells.
//!
//! # Nulls
//!
//! The site's "nulls" option pads the plaintext with a repeated filler letter
//! before encrypting so every row is full (an encrypt-only convenience — it
//! has no decrypt counterpart, since decrypt has no way to tell a genuine
//! trailing null from real ciphertext). Not modelled here for the same
//! reason: it does not change decrypt's behaviour at all.
//!
//! # Case
//!
//! The site always upper-cases before encrypting and lower-cases the
//! decrypted result; default `output_case` is `Lower`, matching that.
//!
//! # Stripping is the page's input normalisation, not the cipher
//!
//! A columnar transposition permutes *positions* within a grid — it does not
//! need an alphabet at all, only a length and a key's column ordering (which
//! stays letters, since it is a typed-in keyword, not the medium being
//! transposed). The site's A-Z filtering of the *message* is a property of
//! this specific web page (it only ever expected letters), not of the
//! transposition itself, so it is reproduced by default (for site fidelity)
//! via [`crate::classical::toolfmt`]'s `strip_non_alphabet` param rather than
//! hardcoded — set `strip_non_alphabet=false` to run the same permutation
//! over any medium (e.g. hex ciphertext from an earlier layer), verified in
//! `cc_columnar_preserves_hex_medium_when_stripping_disabled` below.
//!
//! # Engine direction
//!
//! Decrypt-direction: [`CcColumnar::apply`] runs [`decrypt`]. [`encrypt`] is
//! reproduced test-only.

use crate::classical::toolfmt::{read_output_fmt, CaseFold, InputNorm, OutputFmt, Trailing};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::register_node;
use crate::repr::Repr;

const CC_COLUMNAR_SCHEMA: &[ParamSpec] = &crate::artifact_param_specs!(ParamSpec::req(
    "key",
    ParamType::Str,
    "transposition keyword (letters A-Z only; non-letter characters are dropped)"
),);

const ALPHABET: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZ";

/// `keyNumbers`, transliterated. Returns, for each column (0-indexed,
/// original key order), its 1-based rank in ascending alphabetical order,
/// stable on ties.
fn key_numbers(key: &[u8]) -> Vec<usize> {
    let mut ranks = vec![0usize; key.len()];
    let mut a = 1usize;
    for &alpha_c in ALPHABET {
        for (j, &kc) in key.iter().enumerate() {
            if kc == alpha_c {
                ranks[j] = a;
                a += 1;
            }
        }
    }
    ranks
}

/// `columnDecrypt`, transliterated from `pages/cc_columnar_js.txt`. `ctext`
/// and `key` are expected already upper-cased (case handling lives in the
/// node's `apply`).
pub fn decrypt(ctext: &[u8], key: &[u8]) -> Result<Vec<u8>> {
    if key.is_empty() {
        return Err(Error::bad_param("cc_columnar", "key", "must not be empty"));
    }
    let klen = key.len();
    let m = ctext.len().div_ceil(klen);
    let mut count = ctext.len();
    while count % klen != 0 {
        count += 1;
    }
    let count = count - ctext.len() + 1;

    // Cell state: None = unfilled, Some(Blank) = short-row placeholder,
    // Some(Char(c)) = filled.
    #[derive(Clone, Copy, PartialEq)]
    enum Cell {
        Empty,
        Blank,
        Char(u8),
    }
    let mut grid = vec![vec![Cell::Empty; klen]; m];

    for j in 0..count {
        // Site: mainArray[m-1][key.length - j] = "blank"; key.length - j can
        // be == key.length (out of bounds in JS, silently a no-op on a plain
        // array) or negative-going only if j > key.length, which never
        // happens here since count <= key.length.
        if j < klen {
            let idx = klen - j;
            if idx < klen {
                grid[m - 1][idx] = Cell::Blank;
            }
        }
    }

    let keyn = key_numbers(key);
    let mut kc = 1usize;
    let mut q = 0usize;
    while kc < keyn.len() + 1 {
        for (i, &rank) in keyn.iter().enumerate() {
            if rank == kc {
                for row in grid.iter_mut().take(m) {
                    if row[i] == Cell::Empty {
                        if q == ctext.len() {
                            break;
                        }
                        row[i] = Cell::Char(ctext[q]);
                        q += 1;
                    }
                }
                kc += 1;
            }
        }
    }

    for cell in grid[m - 1].iter_mut().take(klen) {
        if *cell == Cell::Blank {
            *cell = Cell::Empty;
        }
    }

    let mut out = Vec::with_capacity(ctext.len());
    for row in &grid {
        for cell in row.iter().take(klen) {
            if let Cell::Char(c) = cell {
                out.push(*c);
            }
        }
    }
    Ok(out)
}

/// `columnEncrypt`, transliterated the same way. Test-only.
#[cfg(test)]
fn encrypt(ptext: &[u8], key: &[u8]) -> Vec<u8> {
    let klen = key.len();
    let m = ptext.len().div_ceil(klen);
    let mut grid = vec![vec![None::<u8>; klen]; m];
    let mut q = 0usize;
    for row in grid.iter_mut().take(m) {
        for cell in row.iter_mut().take(klen) {
            if q < ptext.len() {
                *cell = Some(ptext[q]);
            }
            q += 1;
        }
    }
    let keyn = key_numbers(key);
    let mut out = Vec::with_capacity(ptext.len());
    let mut kc = 1usize;
    while kc < keyn.len() + 1 {
        for (i, &rank) in keyn.iter().enumerate() {
            if rank == kc {
                for row in grid.iter().take(m) {
                    if let Some(c) = row[i] {
                        out.push(c);
                    }
                }
                kc += 1;
            }
        }
    }
    out
}

/// Crypto Corner's Columnar Transposition Cipher tool, decrypting.
pub struct CcColumnar;

impl Node for CcColumnar {
    fn name(&self) -> &'static str {
        "cc_columnar"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        CC_COLUMNAR_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = params.req_str("cc_columnar", "key")?;
        let key: Vec<u8> = key
            .to_uppercase()
            .bytes()
            .filter(|b| ALPHABET.contains(b))
            .collect();
        if key.is_empty() {
            return Err(Error::bad_param(
                "cc_columnar",
                "key",
                "no letters remain in the key after filtering to A-Z",
            ));
        }

        let in_norm = crate::classical::toolfmt::read_input_norm(
            "cc_columnar",
            params,
            InputNorm {
                case: CaseFold::Upper,
                strip_outside_alphabet: Some("ABCDEFGHIJKLMNOPQRSTUVWXYZ".to_string()),
                ..InputNorm::default()
            },
        )?;
        let text = in_norm.apply(&input.data);

        let plain = decrypt(&text, &key)?;

        let out_fmt: OutputFmt = read_output_fmt(
            "cc_columnar",
            params,
            OutputFmt {
                case: CaseFold::Lower,
                grouping: None,
                trailing: Trailing::None,
            },
        )?;
        let out = out_fmt.apply(&plain);
        Ok(Repr::new(out, input.display))
    }
}

register_node!(CC_COLUMNAR => || Box::new(CcColumnar));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    /// Ground truth: direct Python transliteration of the fetched JS (task
    /// scratchpad `cc_oracle.py`), run and cross-checked here.
    #[test]
    fn cc_columnar_oracle_vector() {
        let pt = b"DEFENDTHEEASTWALLOFTHECASTLE";
        let key = b"GERMAN";
        let ct = encrypt(pt, key);
        assert_eq!(ct, b"NALCEHWTTDTTFSEELEEDSOAFEAHL");
        let back = decrypt(&ct, key).unwrap();
        assert_eq!(back, pt);
    }

    #[test]
    fn cc_columnar_round_trips_varied_keys_and_lengths() {
        let samples: &[&[u8]] = &[
            b"A",
            b"AB",
            b"ATTACKATDAWN",
            b"THEQUICKBROWNFOXJUMPSOVERTHELAZYDOGTWICE",
        ];
        let keys: &[&[u8]] = &[b"ZEBRA", b"KEY", b"A", b"ABCDEFGHIJ", b"BAB"];
        for pt in samples {
            for key in keys {
                let ct = encrypt(pt, key);
                let back = decrypt(&ct, key).unwrap();
                assert_eq!(&back, pt, "pt={pt:?} key={key:?}");
            }
        }
    }

    #[test]
    fn cc_columnar_node_decrypts_lowercasing_output() {
        let pt = b"DEFENDTHEEASTWALLOFTHECASTLE";
        let ct = encrypt(pt, b"GERMAN");
        let n = registry().get("cc_columnar").unwrap();
        let p = params! {"key" => "GERMAN"};
        let out = n.apply(&Repr::bytes(ct), &p).unwrap();
        assert_eq!(
            String::from_utf8(out.data).unwrap(),
            String::from_utf8(pt.to_ascii_lowercase()).unwrap()
        );
    }

    #[test]
    fn cc_columnar_rejects_key_with_no_letters() {
        let n = registry().get("cc_columnar").unwrap();
        let p = params! {"key" => "123"};
        assert!(n.apply(&Repr::bytes(b"XYZ".to_vec()), &p).is_err());
    }

    #[test]
    fn cc_columnar_preserves_display() {
        let ct = encrypt(b"DEFENDTHEEASTWALLOFTHECASTLE", b"GERMAN");
        let n = registry().get("cc_columnar").unwrap();
        let p = params! {"key" => "GERMAN"};
        let out = n.apply(&Repr::new(ct, Display::Hex), &p).unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    /// The payoff: with `strip_non_alphabet` explicitly disabled, this
    /// transposition operates on any medium, not just A-Z text -- proven here
    /// against a 1092-character hex string, the length of rev7's ciphertext.
    #[test]
    fn cc_columnar_preserves_hex_medium_when_stripping_disabled() {
        let hex: String = (0..1092).map(|i| "0123456789ABCDEF".as_bytes()[i % 16] as char).collect();
        let n = registry().get("cc_columnar").unwrap();
        let p = params! {
            "key" => "ZOMBIES",
            "strip_non_alphabet" => false,
            "output_case" => "preserve",
        };
        let out = n.apply(&Repr::bytes(hex.clone().into_bytes()), &p).unwrap();
        assert_eq!(out.data.len(), 1092);
        let mut want: Vec<u8> = hex.into_bytes();
        want.sort();
        let mut got = out.data.clone();
        got.sort();
        assert_eq!(got, want, "must be a pure permutation: same multiset of bytes");
    }

    #[test]
    fn cc_columnar_is_xf_family_and_not_layer_forming() {
        let n = registry().get("cc_columnar").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
