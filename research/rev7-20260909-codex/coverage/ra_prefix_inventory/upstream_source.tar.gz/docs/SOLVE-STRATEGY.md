# Solve strategy: ix3, ix7, ix9, tg4, rev7

Written before the runs, so the plan can be judged against what it predicted rather
than rewritten afterwards. Numbers are measured, not assumed.

## 1. The five targets are two different problems

| target | ciphertext | distinct | H (bits/sym) | IC | structure |
|---|---|---|---|---|---|
| ix9 | 30 letters | 19 | — | 0.0322 | one classical layer |
| ix7 | 38 letters | 16 | — | 0.0626 | one classical layer |
| ix3 | 41 letters | 21 | — | 0.0427 | one classical layer |
| tg4 | 192 base64 chars → 144 bytes | 62 | 5.805 | 0.0145 | classical? → **modern** |
| rev7 | 1310 chars, 218 ws → 1092 hex → 546 bytes | 18 | 4.037 | 0.0674 | strip → reverse → classical? → **modern** |

**This distinction drives everything below.**

- **ix3/ix7/ix9** — the classical layer's output *is* the English plaintext, so it is
  directly scorable. The binding wall is **decidability**: keyspace vs the 81–111 bits
  of constraint the ciphertext carries.
- **tg4/rev7** — the classical layer feeds a modern cipher. Its output is a modern
  *ciphertext*, random by construction, so English scoring cannot validate it in
  isolation. Only the **full chain** is checkable. The wall is **search cost**
  (classical_keys × modern_keys), *not* decidability: 144–546 bytes of English carry
  389–1474 bits, far above any key in play.

Conflating these two walls is what wasted effort previously. They need different tactics.

## 2. What the new nodes actually add

39 new nodes (87 → 126). Two categories matter here:

**(a) Families that were simply absent** — Hill (incl. singular keys), Porta, Bellaso,
bifid, two/tri-square, digrafid, seriated Playfair, Slidefair, Portax, Quagmire I–IV,
Gromark, Nicodemus, interrupted/progressive key, Ragbaby, Condi, Phillips, Albam,
Atbah, key phrase, headlines, Jefferson/M-94, Bazeries, Chaocipher, running key, AMSCO,
Cadenus, Redefence, Swagman, CM bifid, numbered key, Grandpré, syllabary.

**(b) Non-26 alphabets.** `hill`, `bifid`, `playfair`, `slidefair` take an `alphabet`
parameter, so they work over the **hex** (16-symbol) and **base64** (64-symbol)
alphabets that tg4 and rev7 actually live in:

| construction | keyspace |
|---|---|
| hill 2×2 mod 16 (hex) | **16.0 bits** |
| hill 3×3 mod 16 | 36.0 bits |
| hill 2×2 mod 64 (base64) | 24.0 bits |
| substitution mod 16 | 44.3 bits |
| substitution mod 64 | 296.0 bits — excluded, see §5 |

Hill mod 16 at 16 bits is *tiny*. That is the single most promising new capability for
rev7, because it can be enumerated exhaustively and still leaves budget for the modern
sweep.

## 3. Order of work (by expected value, not by interest)

**Tier 1 — ix7, ix9, ix3.** Cheapest and directly checkable. Run every new node across
its key space, judged by the validated word-segmentation scorer. Decidable for
substitution (U=27.6), Playfair (U=26.2), and every new node with H(K) < 96 bits.

**Tier 2 — rev7.** Confirmed prefix is `strip whitespace → reverse`. Insert each new
*alphabet-agnostic* classical layer over the 1092-char hex text, then `hexdecode`, then
the existing mcrypt sweep. Only low-DOF classical layers are affordable (see §4).

**Tier 3 — tg4.** Same shape over base64, but 144 bytes and a 62-symbol alphabet;
run only the constructions that survive the cost gate.

## 4. Cost gate for the layered targets

For tg4/rev7 the total cost is `classical_options × modern_keys`. The mcrypt sweep is
~10⁸ per skeleton, so the classical multiplier must stay small — order 10²–10⁴, not 10⁶.

Admissible classical layers for rev7 (hex text):
- `hill` mod 16, 2×2 — enumerate invertible keys only (det odd)
- transpositions with structured keys (columnar/AMSCO/redefence/cadenus/swagman)
- `bifid` 4×4 over hex, small periods
- `substitution` mod 16 **only** with structured (keyed) alphabets, never free 16!

Inadmissible: free substitution mod 64 (296 bits), Chaocipher (177 bits), any
multi-square cipher. These exceed the budget *and*, for tg4, exceed the constraint.

## 5. Scoring: the modern layer does NOT have to yield English

This is the correction that matters most for tiers 2 and 3. **A correct modern
decryption frequently produces another *encoding*, not plaintext.** The corpus proves
it — counting encoding steps across solved chains:

| encoding | solved chains using it | example |
|---|---|---|
| hex | 14 | rev2 |
| base64 | 13 | rev5 |
| decimal | 7 | rev6 |
| octal | 4 | rev10 |
| ascii | 3 | printable-1.00 |
| bacon / base10 | 2 each | rev2 / rev3 |
| numbers_to_letters, binary, tap | 1 each | zns5, zns9, gk7 |

rev6's Serpent layer decrypts to **3-digit decimal ASCII**, and rev2's DES layer
decrypts to **bacon**. A prose-tuned oracle rejects both — the right key looks like a
miss. So a single English test at the end of the chain is the wrong instrument, and
using one would repeat the threshold error that invalidated earlier sweeps.

**The scoring cascade for tiers 2/3**, in order, accepting a candidate if *any* fires:

1. `encoding-valid` — clean hex / octal / base64 / decimal intermediate. Catches
   "decrypted correctly, output is the next encoding".
2. `ioc-english` — substituted or transposed English (rev6, rev2 shapes). Recognises
   letter-soup that preserves coincidence structure while destroying prose fitness.
   Needs ≥90 letters; both tier-2/3 targets clear that (546 and 144 bytes).
3. `printable-and-english` — actual plaintext. The recommended hit-caller.
4. Structural fallback: entropy drop vs the 7.6–8.0 of a wrong key, plus charset
   purity in {hex, base64, decimal, octal, A–Z, a–z, letters+space}.

A candidate passing (1) or (2) is **decoded one level and re-scored**, up to 3 levels —
because the corpus chains stack encodings (rev3: base10 inside base64).

**Tier 1** keeps the word-segmentation scorer: threshold −1.20, measured
false-negative rate **0.000%** across 230 classical-register windows (worst true
plaintext −0.892), noise ceiling **−1.50 at 10⁷ draws** by Gumbel extrapolation, so it
is safe to ~10¹³ candidates.

## 5b. Falsification protocol

Non-negotiable, because three separate "findings" died to these checks earlier:

1. **Every harness is validated on a planted case before its negative is believed** —
   including the cascade above: plant English → encode as decimal/octal/base64 →
   encrypt with a known key, and confirm the cascade fires on the right key and not on
   wrong ones.
2. **Every claimed hit gets a control run** through the identical pipeline on shuffled
   or random input. A hit that controls match is noise, whatever it scores.
3. **No search whose keyspace exceeds the target's constraint.** Those cannot produce a
   falsifiable answer and will manufacture a convincing one.

## 6. What would falsify this plan

- Tier 1 returning nothing would mean ix3/ix7/ix9 use something outside the 62 ACA
  types plus the 39 new nodes — or that a premise (transcription, English plaintext) is
  wrong.
- Tier 2/3 returning nothing bounds the classical layer to constructions outside the
  admissible set, which would be evidence the layer is not classical at all.

## 7. Prior from the author

For ix*: Playfair is the most-used method across BO4 (6 of ~28), and the author keys it
with **explicit random 25-letter squares**, not keywords — so keyword sweeps of Playfair
are known-futile and are excluded. Recorded keys seen in the corpus: `Nine`,
`Classified`, and six explicit squares.
