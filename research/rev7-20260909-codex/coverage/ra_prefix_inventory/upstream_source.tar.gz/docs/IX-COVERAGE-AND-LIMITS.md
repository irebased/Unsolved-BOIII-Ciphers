---
name: ix-coverage-and-limits
description: What has been eliminated for the three unsolved IX ciphers, and the decidability math showing what remains is unreachable at these lengths
metadata:
  type: project
---

As of 2026-07-31. All negatives below come from harnesses validated on planted
cases and judged by the word-segmentation scorer (see [[ix-cipher-goal-and-method]]).

**42 of the 62 ACA cipher types are covered or excluded. 20 untested.**

Excluded WITHOUT search, by chi-squared on unigrams (transposition cannot change
letter frequencies): AMSCO, CADENUS, COMPLETE/INCOMPLETE COLUMNAR, GRILLE,
NIHILIST TRANSPOSITION, RAILFENCE, REDEFENCE, ROUTE, SEQUENCE, SWAGMAN,
MYSZKOWSKI. CT1 p=0.0084, CT3 p=0.0036. (CT2 p=0.056 survives, barely.)

Excluded by length/format: BACONIAN (5:1 expansion), FRACTIONATED MORSE,
MONOME-DINOME, MORBIT, POLLUX, TRIDIGITAL, CHECKERBOARD, NIHILIST SUBSTITUTION
(all numeric output).

Searched and negative: substitution (general 26! via 480 harvested optima, AND
keyed-alphabet 7.3M), Hill 2x2 (full 456,976 incl. singular), Hill 3x3 (353
crib-determined matrices), Playfair/four-square/two-square (+ alternate line
readings), bifid/trifid (1.68M), autokey (exhaustive primers<=4), porta/vigenere/
beaufort/variant (periods 1-16 with controls), Quagmire I-IV + Progressive Key,
Gromark (100k primers), Ragbaby/Condi/Phillips, Nicodemus, Null, running key
(31 author-derived sources), transposition x polyalphabetic (both orders),
custom-alphabet polyalphabetic, two-layer repertoire (119,716 pairs).

**DECIDABILITY - why the rest is unreachable.** Constraint = n*(4.7-2.0) bits:
n=30 -> 81 bits, n=38 -> 103, n=41 -> 111. Keyspaces:
  Nicodemus 50 bits (decidable - TESTED, negative)
  Playfair/Seriated Playfair 83.7 | Substitution o Transposition 100.5
  Portax 121 | Homophonic 200 | Tri-Square 251 | Digrafid 265
Anything at or above the constraint cannot be confirmed even if guessed correctly.
Polyalphabetic decidability needs period p < 0.57n; empirically controls beat the
real text from p>=13.

**What would actually break it:** more ciphertext, a confirmed crib, or the
in-game lore naming a key. Not more search.
