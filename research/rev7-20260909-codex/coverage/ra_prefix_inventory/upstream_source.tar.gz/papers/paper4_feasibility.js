const S = require("./style.js");
const { docx, PAGE, numbering, title, subtitle, h1, h2, h3, p, mono, li, numItem, table, callout, spacer, makeHeaderFooter } = S;
const { Document, Packer, Paragraph, TextRun, BorderStyle } = docx;
const fs = require("fs");

const children = [];
const A = (...x) => children.push(...x);

A(title("Search Space and Feasibility Analysis"));
A(subtitle("Combinatorial Bounds, Throughput Measurement, and Where Compute Stops Helping"));
A(p([
  { t: "Document 4 of 4 (Analysis). ", bold: true },
  "This paper quantifies the size of the search space for The Giant 4 and Revelations 7 under the constraints established in Documents 1 to 3, measures achievable throughput, and identifies which regions of the space are reachable with current resources. Its central conclusion is that the tractable portion of the space is small enough to have been exhausted already, which relocates the problem from compute to hypothesis precision.",
]));

// 1 Method
A(h1("1. Method"));
A(p([
  "The space is modeled as a product of independent dimensions and partitioned into tiers of increasing structural complexity. Throughput was measured directly rather than assumed, using CFB-8 decryption over payloads matching each target's actual length. All figures below are reproducible from the accompanying scripts.",
]));
A(table(
  ["Dimension", "TG4", "REV7", "Basis"],
  [
    ["Transcription variants", "16", "1", "Oswald glyph ambiguity; hex is unambiguous"],
    ["Key candidates", "6", "3", "TheGiant readings vs corpus invariant"],
    ["Key derivation", "2", "2", "Null-pad vs repeat-pad (tools4noobs behavior)"],
    ["Primitives (observed)", "11", "11", "Confirmed in solved corpus"],
    ["Primitives (full mcrypt)", "19", "19", "Complete mcrypt menu"],
    ["Modes", "2 obs / 7 all", "2 obs / 7 all", "mcrypt cfb=CFB-8, ncfb=full-block"],
    ["IV variants", "3", "3", "ASCII-zero, true null, other"],
  ],
  [2100, 1250, 1250, 4648]
));
A(p([
  "One modern-layer parameterisation therefore costs 66 candidates against the observed menu, or 399 against the full mcrypt menu. This unit is the building block for all tiers below.",
]));

// 2 Throughput
A(h1("2. Measured Throughput"));
A(p([
  "CFB-8 is the dominant cost because it performs one block operation per byte, making it roughly block-size times slower than full-block modes. Measured single-core Python rates, including per-operation cipher construction:",
]));
A(table(
  ["Operation", "Payload", "Rate (decrypt/sec)"],
  [
    ["DES CFB-8", "144 B (TG4)", "34,062"],
    ["DES CFB-8", "546 B (REV7)", "13,493"],
    ["Blowfish CFB-8", "144 B", "20,125"],
    ["AES CFB-8", "144 B", "76,097"],
    ["RC4 (stream)", "144 B", "159,263"],
  ],
  [3400, 2900, 2948]
));
A(p([
  "A working figure of 25,000 candidates per second per core in Python is used below. A native implementation with cipher-object reuse across eight cores is taken as 2,000,000 per second, a conservative eighty-fold improvement. A GPU or small cluster is taken as 100,000,000 per second.",
]));

// 3 Tiered space
A(h1("3. Tiered Search Space"));
A(h2("3.1 The Giant 4"));
A(table(
  ["Tier", "Candidates", "1 core Python", "8 core native"],
  [
    ["T1  single modern layer (observed menu)", "12,672", "0.5 sec", "instant"],
    ["T1' single modern layer (full mcrypt)", "76,608", "3.1 sec", "instant"],
    ["T2  transform + modern", "7.7 million", "5.1 min", "3.8 sec"],
    ["T3  two modern layers", "305.7 million", "3.4 hr", "2.5 min"],
    ["T4  bounded classical over modern", "766.1 million", "8.5 hr", "6.4 min"],
    ["T5  three modern layers", "1.2 trillion", "1.5 years", "6.9 days"],
    ["T7  free columnar (key len 10) over modern", "278 billion", "128.7 days", "1.6 days"],
    ["T6  free substitution over modern", "3.1e30", "beyond reach", "beyond reach"],
  ],
  [3600, 1900, 1874, 1874]
));
A(h2("3.2 Revelations 7"));
A(table(
  ["Tier", "Candidates", "1 core Python", "8 core native"],
  [
    ["T1  single modern layer (observed menu)", "396", "instant", "instant"],
    ["T1' single modern layer (full mcrypt)", "2,394", "0.2 sec", "instant"],
    ["T2  transform + modern", "239,400", "18.4 sec", "0.1 sec"],
    ["T3  two modern layers", "9.6 million", "12.2 min", "4.8 sec"],
    ["T4  bounded classical over modern", "23.9 million", "30.7 min", "12 sec"],
    ["T5  three modern layers", "38.1 billion", "33.9 days", "5.3 hr"],
    ["T7  free columnar (key len 10) over modern", "8.7 billion", "7.7 days", "1.2 hr"],
    ["T6  free substitution over modern", "9.7e29", "beyond reach", "beyond reach"],
  ],
  [3600, 1900, 1874, 1874]
));
A(callout("Principal finding.", [
  "The complete bounded programme, tiers T1 through T4, costs 1.15 billion candidates for TG4 (12 hours single-core Python, 9 minutes optimised) and 33.7 million for REV7 (43 minutes single-core, 17 seconds optimised). These are not large numbers. The bounded space is small enough that it has very probably been exhausted already by prior community effort, which is consistent with the reported negative results.",
], S.ACCENT));

// 4 Verification
A(h1("4. Verification Is Not the Bottleneck"));
A(p([
  "A common concern in large sweeps is drowning in false positives. That concern does not apply here. Treating a hit as output that is at least seventy-five percent printable ASCII, which is deliberately loose to tolerate CFB-8 first-block corruption:",
]));
A(table(
  ["Target", "P(hit by chance, 100% printable)", "P(hit by chance, 75%)", "Expected false positives over T1-T4"],
  [
    ["TG4 (144 B)", "1.0e-62", "2.5e-20", "3.8e-11"],
    ["REV7 (546 B)", "8.7e-236", "7.8e-73", "1.2e-63"],
  ],
  [1700, 2600, 1900, 3048]
));
A(callout("Consequence.", [
  "Expected false positives across the entire bounded programme are effectively zero. The scoring function is reliable, and a correct hit anywhere in T1 through T4 would have been recognised unambiguously. The absence of a solve is therefore strong evidence that the answer lies outside the modeled space, not that it was missed inside it.",
]));

// 5 The real bottleneck
A(h1("5. The Real Bottleneck Is Implementation, Not Compute"));
A(p([
  "Of the eleven modern primitives confirmed in the solved corpus, only four are available in stock modern cryptographic libraries. The remaining seven require custom or legacy implementations before any sweep can run at all.",
]));
A(table(
  ["Primitive", "Availability today"],
  [
    ["RC2, RC4, DES, Blowfish", "Available (pycryptodome)"],
    ["Blowfish-compat", "Not available; byte-order variant, needs custom build"],
    ["Twofish, Serpent, Loki97, Saferplus, XTEA", "Not in pycryptodome or cryptography"],
    ["Rijndael-256", "Not available; AES standardised the 128-bit block only"],
  ],
  [3200, 6048]
));
A(callout("Implementation note.", [
  "Rijndael-256 refers to a 256-bit block, not a 256-bit key. No standard AES implementation can produce it, because AES adopted only the 128-bit block from the Rijndael family. Any harness intending to reproduce the Revelations 1 chain, or to test Rijndael-256 against either remaining target, must source a genuine Rijndael implementation with variable block size. This is a prerequisite engineering cost, and it is currently the binding constraint on coverage.",
], S.ACCENT));

// 6 Headroom
A(h1("6. Headroom for Unknown Dimensions"));
A(p([
  "The productive question is not how large the known space is, but how large an unknown dimension can be absorbed on top of it. An unknown dimension might be an unidentified pre-transform family, an undiscovered tool quirk with N settings, or an unmodeled key-derivation rule. Headroom depends strongly on what it is combined with.",
]));
A(table(
  ["Base", "Base cost", "Headroom (1 month at 2M/sec)"],
  [
    ["REV7 + single modern layer", "2,394", "x2.17 billion"],
    ["REV7 + two modern layers", "9.6 million", "x540,000"],
    ["TG4 + single modern layer", "76,608", "x67.7 million"],
    ["TG4 + two modern layers", "305.7 million", "x16,958"],
  ],
  [3300, 2300, 3648]
));
A(p("Against those budgets, concrete unknown dimensions resolve as follows:"));
A(table(
  ["Unknown dimension", "Size", "TG4 + 1 layer", "TG4 + 2 layers", "REV7 + 1 layer"],
  [
    ["ROT shifts on an outer layer", "26", "reachable", "reachable", "reachable"],
    ["Affine (a,b) pairs", "312", "reachable", "reachable", "reachable"],
    ["4-row route/read permutations", "24", "reachable", "reachable", "reachable"],
    ["Columnar keys up to length 7", "5,913", "reachable", "reachable", "reachable"],
    ["10k keyword dictionary", "10,000", "reachable", "reachable", "reachable"],
    ["Columnar keys up to length 9", "409,113", "reachable", "out of reach", "reachable"],
    ["100k keyword dictionary", "100,000", "reachable", "out of reach", "reachable"],
    ["Columnar keys up to length 10", "4.0 million", "reachable", "out of reach", "reachable"],
    ["Free 26-letter substitution", "4.0e26", "out of reach", "out of reach", "out of reach"],
  ],
  [2900, 1300, 1700, 1700, 1648]
));
A(callout("Interpretation.", [
  "Only one dimension is categorically out of reach in every configuration: a free 26-letter substitution alphabet. Everything else, including sizable keyword dictionaries and columnar key spaces, is affordable provided it is combined with a shallow rather than deep modern stack. The strategy that follows is to go wide on structured outer-layer hypotheses over a single modern layer, rather than deep on stacked modern layers.",
]));

// 7 Asymmetry
A(h1("7. The Asymmetry Between the Two Targets"));
A(p([
  "TG4's base cost is thirty-two times REV7's, and the entire difference comes from unresolved ambiguity rather than from the cipher itself. Sixteen transcription variants and six key candidates multiply out to a ninety-six-fold penalty, against REV7's six.",
]));
A(callout("Highest-leverage action.", [
  "Resolving the TG4 transcription to a single confirmed variant cuts its search space sixteenfold. Resolving the TheGiant key question cuts it a further two to sixfold. Together these are worth between thirty-two and ninety-six times more effective compute, obtainable for zero compute spend. No plausible hardware upgrade delivers a comparable return on this target.",
], S.ACCENT));

// 8 Recommendations
A(h1("8. Recommendations"));
A(numItem([{ t: "Treat the bounded space as spent. ", bold: true }, "Do not re-run T1 through T4 as originally specified without adding a new dimension. Given near-zero false positives, a hit there would already have been seen."], "steps3"));
A(numItem([{ t: "Close the implementation gap first. ", bold: true }, "Source or build Twofish, Serpent, Loki97, Saferplus, XTEA, Blowfish-compat, and a variable-block Rijndael. Until these exist in the harness, coverage of the confirmed primitive menu is only four of eleven, and any claim of exhaustive sweep is unsupported."], "steps3"));
A(numItem([{ t: "Prioritise forensics on TG4. ", bold: true }, "Transcription and key resolution are worth up to ninety-six times more than any compute increase. This is the single best return available on either target."], "steps3"));
A(numItem([{ t: "Go wide, not deep. ", bold: true }, "Spend the headroom on large structured outer-layer families over a single modern layer, rather than on three-layer modern stacks. The former is affordable at dictionary scale; the latter exhausts the budget quickly for far less hypothesis coverage."], "steps3"));
A(numItem([{ t: "Prefer REV7 for compute-led attack. ", bold: true }, "Its unambiguous transcription and tighter key space give it two to three orders of magnitude more headroom. TG4 is the better forensics target; REV7 is the better brute-force target."], "steps3"));
A(numItem([{ t: "Log assumption scope per sweep. ", bold: true }, "Record which assumptions each composite inherited so that a later correction re-runs only affected composites. At bounded-programme sizes a full re-run is cheap, but this discipline becomes essential once dictionary-scale dimensions are in play."], "steps3"));

A(spacer(60));
A(new Paragraph({
  border: { top: { style: BorderStyle.SINGLE, size: 4, color: "9A9A9A", space: 6 } },
  spacing: { before: 120 },
  children: [new TextRun({ text: "End of Document 4. Figures reproducible from the accompanying analysis scripts in tools/.", italics: true, size: 18, color: "6A6A6A", font: S.FONT })],
}));

const doc = new Document({
  numbering,
  styles: { default: { document: { run: { font: S.FONT, size: 21, color: S.INK } } } },
  sections: [{ properties: { page: PAGE }, ...makeHeaderFooter("Search Space and Feasibility Analysis"), children }],
});
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/claude/BO3_Cipher_Dossier/papers/04_Search_Space_Feasibility.docx", buf);
  console.log("wrote 04_Search_Space_Feasibility.docx", buf.length, "bytes");
});
