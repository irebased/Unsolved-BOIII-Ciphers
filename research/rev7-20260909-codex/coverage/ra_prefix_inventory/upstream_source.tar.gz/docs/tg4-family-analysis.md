# TG4: key-variant list, and whether mcrypt is the right family

Author: cryptanalysis pass, 2026-07-30. Every number below was measured in this
session unless it cites a file. Claims are labelled **EVIDENCED** (measured or
recorded), **INFERRED** (argued from evidence), or **SPECULATION**.

Ciphertexts used:

| label | string | note |
|---|---|---|
| `v00` | `data/the_giant.json` -> `ciphertext` | legacy recorded reading |
| `v10` | `data/the_giant.json` -> `ciphertext_canonical` | official transcription |

They differ at exactly one base64 character (offset 39, `I` -> `l`), which is one
decoded byte (index 29, `0x88` -> `0xa5`). Measured this session.

---

## Part 0. Two record defects found on the way

### 0.1 The canonical transcription is labelled `v46`; it is actually `v10`

`data/the_giant.json` -> `ciphertext_canonical_provenance` says the official
reading "corresponds to variant label v46". It does not. Measured:

- ambiguous offsets ascending: `3, 15, 31, 36, 39, 90, 160`
- glyphs in `v00`: `l I I I I l I`
- glyphs in the canonical: `l I I I l l I`
- they differ at offset 39 only, which is index 4, so mask `1<<4` = `0x10`

The label is **`v10`**. `v46` looks like the quoted mask string `lIIIllI` read
MSB-first with `l`=1, which is neither the bit order nor the polarity the label
convention uses (`crates/ra-cli/src/variants.rs`: bit *i* set means the *partner*
of the recorded glyph at the *i*-th ascending offset).

This matters because it looks like a coverage hole and is not one. **EVIDENCED**:
`claims/tg4-official-v10.json` swept `v10` across all three skeletons,
163,936,080 candidates. The official transcription *has* had the full deep sweep.
The literal string labelled `v46` was covered at T1/T2 only
(`claims/tg4-t1t2-all-variants.json`, all 128 variants, 1,419,264 candidates).

### 0.2 The T3 "hits" figure is entirely short-region artefact

`claims/tg4-t3.json` reports `hits: 1820718` against
`expected_false_positives: 2363006` and `longest_scored_region_among_passes: 32`
versus `longest_scored_region: 144`. So no passing candidate scored a region
longer than 32 bytes: every one of the 1.82M "hits" is a codec that consumed a
short prefix and left a tiny string for the oracle. The count is a false-positive
budget, not a lead. Worth stating in the claim schema so it is not read as signal.

---

## Part 1. Casing and spacing variants worth adding

### What the corpus can and cannot tell us

**EVIDENCED.** Across all six maps, every recorded key with a space or a
non-uppercase form sits in a *classical* cipher: `Aurora Borealis` (zns7, keyed
Caesar), `testsubject` (de3, Playfair), `Maxis` (de4, Bifid), `shinonuma`
(zns12, Quagmire III), `ONLYTHECURSEDSURVIVE` (soe1, Porta), `TRYTHIS` (gk12,
autokey). Classical tools strip non-letters and fold case before use, so **the
recorded spelling of a classical key is evidence about the write-up, not about
what the author typed.** The corpus therefore places *no* constraint on spacing
or casing for a byte-exact modern key. Both `TheGiant` and `The Giant` have to
be swept; the corpus cannot discriminate between them.

**EVIDENCED.** The only case evidence that *is* byte-exact comes from
Revelations' 13 modern steps:

| key as recorded | modern steps |
|---|---|
| `Zombies` | 12 |
| `ZOMBIES` | 1 (rev2, DES/CFB) |

The single `ZOMBIES` is also the only modern step with no `iv` field recorded, so
that record is the least carefully filled in of the thirteen. **INFERRED**: title
case `Zombies` is the author's modern-cipher form; the uppercase form is the
classical form, and rev2 may be a write-up slip. Sweep both anyway - it is two
keys.

### The list

Already swept (per `claims/tg4-*.json`): `TheGiant`, `TheGiant_b64`, `ZOMBIES`,
`Zombies`, `thegiant`, `zombies`.

**Tier 1 - add these six.** Each has a named precedent in the corpus.

| # | exact string | reasoning | confidence |
|---|---|---|---|
| 1 | `THEGIANT` | joined + uppercase is the corpus's dominant phrase form: `ONLYTHECURSEDSURVIVE`, `TRYTHIS`, `ZOMBIESAREEVERYWHERE`. The only joined-phrase form not yet tried. | high |
| 2 | `The Giant` | space retained, title case. Exact form of `Aurora Borealis`, the corpus's one spaced key. The paper's label is joined, but a spaced key typed into a form is the same author habit. | high |
| 3 | `Zombie` | owner states `ZOMBIE`/`zombie` are in the fallback set; the title-case singular completes the pattern that gives `Zombies` 12 of 13 modern steps. | high |
| 4 | `ZOMBIE` | owner-stated fallback, uppercase singular. | high |
| 5 | `zombie` | owner-stated fallback, lowercase singular. | high |
| 6 | `The Giant` / `TheGiant` with one trailing space or `\n` | mundane copy-paste artefact from a web form. Invisible in a screenshot, byte-decisive for a modern key, and it costs 4 keys to rule out. No corpus precedent - it is a failure mode, not a convention. | medium |

**Tier 2 - only if tier 1 is clean.**

| exact string | reasoning | confidence |
|---|---|---|
| `THE GIANT` | space + uppercase. No corpus key combines the two. | low |
| `the giant` | space + lowercase. No precedent. | low |
| `Thegiant` | sentence case. The paper shows *two* capitals, so this contradicts the only direct evidence. | low |
| `theGiant` | camel case. No precedent. | low |

I swept all of tier 1 and tier 2 this session against a non-mcrypt primitive set
(see Part 3); they are still untested against the eleven mcrypt primitives with
mcrypt key derivation, which is where they belong.

**Not recommended.** Generating Der Riese lore phrases (`Group935`, `Samantha`,
`Richtofen`, `Element115`, ...). The label on the paper is direct physical
evidence in the author's conventional key position; a lore list is speculation
competing against it, and each entry multiplies every sweep. I did include
`DerRiese`/`Der Riese` in my own sweep because it was free; nothing.

---

## Part 2. Is the mcrypt family the right target? The measurements

### 2.1 What the artefact is, measured

| measurement | TG4 | reference |
|---|---|---|
| base64 chars | 192, no padding | decodes to exactly 144 bytes |
| distinct base64 symbols | 62 of 64 (`+` and `S` absent) | E[distinct] = 60.9 under uniform |
| symbol entropy | 5.8045 bits/sym | max 6.0 |
| symbol IC | 0.01445 | uniform-64 = 0.01562 |
| repeated 3-grams / 4-grams | 0 / 0 in 190 positions | - |
| byte entropy | 6.7514 bits/byte | uniform-144: mean 6.6678, 95% band [6.536, 6.793] |
| distinct byte values | 116, max repeat 4 | - |
| 1-bits | 560 of 1152 | expect 576 +/- 17, z = -0.94 |
| zlib -9 | 155 bytes | larger than the input: incompressible |
| repeated 8/16-byte blocks | none | no ECB tell |
| bytes >= 128 | 66 of 144 | expect 72 +/- 6 |
| printable after decode | 42.4% | - |
| file signatures (fwd/rev/inverted) | none | gzip, zlib, bzip2, xz, zip, PNG, JPEG, GIF, PDF, `Salted__` |
| raw-DEFLATE at every byte offset x 3 orientations x 3 window settings | 0 streams | - |

Everything is at the uniform-random expectation for a 144-byte sample. **The
payload is high-entropy binary. EVIDENCED.**

### 2.2 A new elimination: no base64 relabelling makes TG4 text

TG3's alphabet looked like base64 and was ITA2 in Bletchley notation. That
precedent is *on this map*, so "the 62 symbols are not really base64" had to be
tested, not assumed. It can be tested without guessing the alphabet.

In base64, byte 0 of each quantum takes its high bit from bit 5 of char 0, byte 1
from bit 3 of char 1, byte 2 from bit 1 of char 2. For *any* assignment of the 64
six-bit values to symbols, each of those bits is 0 on exactly 32 symbols. So if
the payload were 7-bit text, the characters at positions 0, 1 and 2 mod 4 would
each be confined to a 32-symbol subset.

Measured distinct symbols per residue class, 48 characters each:

| class | TG4 | base64 of English (control) | rev5 (modern, confirmed) | rev9 (modern, confirmed) |
|---|---|---|---|---|
| 0 mod 4 | 30 | 9 | 37 | 36 |
| 1 mod 4 | **33** | 11 | 34 | 34 |
| 2 mod 4 | **37** | 16 | 38 | 32 |

E[distinct] is 25.0 under the 32-symbol hypothesis and 33.9 under 64 symbols.
Classes 1 and 2 exceed 32 outright.

Maximising over all 64! alphabet permutations (greedy on the 32 most frequent
symbols per class, which is exact because the three high-bit planes are
independent): **at most 138 of the 144 bytes can be < 128, under any base64
alphabet whatsoever.** Uniform random b64 gives a median of 138 with a 5-95 band
of [131, 142]; base64 of English gives 111.

**PROVED IMPOSSIBLE**: TG4 is not base64, under any 64-symbol relabelling, of
7-bit text. And its per-class profile is indistinguishable from rev5 and rev9,
the confirmed modern ciphertexts, and nowhere near base64-of-text.

I also tested nine named non-standard base64 alphabets (base64url, crypt(3),
bcrypt, xxencode, GEDCOM, digits-first, lowercase-first, reversed radix-64):
printable ratio 0.319-0.424 throughout, none above chance.

### 2.3 A new elimination: reading order

The sheet is "taped to the back wall, upside down" (paper 2), so reading order is
a live variable that no sweep has treated as one. I tested 17 readings: as
recorded, full 180-degree reverse, row-order reversed and in-row reversed at row
widths 48/64/32/24/16, and column-wise at each width. Printable ratio 0.319-0.465,
byte entropy 6.66-6.80 throughout. **No reading order is plaintext, and none has
a materially different profile.** SEARCHED AND EMPTY over that 17-point space.

### 2.4 The argument *against* mcrypt, stated at full strength

1. **EVIDENCED.** 13 of 13 modern cipher steps in the corpus are Revelations
   steps. 0 of 35 non-Revelations cipher steps are modern (paper 8, s.13). By the
   rule of three the 95% upper bound on the modern rate outside Revelations is
   3/35 = 8.6%.
2. **EVIDENCED.** The Giant shipped ~10 months before Revelations. The
   `Zombies`/IV-`30303030...`/CFB-8/libmcrypt invariant is derived entirely from
   Revelations and is a *later* practice.
3. **EVIDENCED.** The Giant's attributed tools are CIMT/MEP (tg3, 100%, and
   reproduced in-repo), Practical Cryptography (tg5, 100%), Cryptool Online (tg1,
   40%) and hand encoding (tg2, 25%). tools4noobs is attributed to Revelations
   and to nothing else. `data/zombies_sources.csv`.
4. **EVIDENCED.** tg4's row in the community sheet is `Unknown / Unknown / N/A`,
   the only Giant cipher with no attribution, against three at 100%.
5. **EVIDENCED.** Every other Giant puzzle is a *physical* presentation trick -
   a scannable barcode, atomic numbers, teleprinter glyphs, an A-Z Enigma strip,
   a scarab arrangement. A base64 blob is thematically inert by comparison.
6. **New this session, and it closes a door the base-rate argument wanted open.**
   Paper 8 s.12 shows The Giant draws on the MEP "Codes and Ciphers" curriculum,
   whose unit list contains four units that *could* explain a high-entropy
   artefact: 12 One-Time Pads, 16 Modern Encryption, 17 Huffman Codes, 18
   Arithmetic Coding. I fetched cimt.org.uk: **units 12, 16, 17 and 18 ship
   pupil text, teacher resources, slides, lesson plans and web links, and no
   interactive toolkit.** Only unit 19 has one (the Lorenz toolkit that produced
   tg3). So the curriculum cannot be the source of a 144-byte high-entropy
   artefact. The map's own tradition offers no candidate.
7. Two further "not a cipher" hypotheses are now dead by measurement: no
   compression container (no signature, no raw-DEFLATE stream at any of 432
   offset/orientation/window combinations, and zlib *expands* the payload), and
   no OTP/running-key over ASCII (that forces every byte < 128; 66 of 144 are
   not, and at least 6 must be under any alphabet).

### 2.5 The argument *for* modern, and why it wins

The base rate is an argument about the author's habits over five maps of
classical ciphers. It cannot reach the one artefact on those maps that is
*measurably not classical*.

**PROVED IMPOSSIBLE.** Monoalphabetic substitution and pure transposition
preserve the frequency multiset, hence the IC. TG4's surface IC is 0.01445
against a uniform-64 floor of 0.01562; the payload beneath is 6.7514 bits/byte,
inside the uniform band, and incompressible. No classical cipher over a redundant
alphabet raises entropy, so no composition of them produces this. Section 2.2
additionally rules out the "it isn't really base64" escape that worked for tg3.

So the payload is the output of something that behaves like a modern cipher, a
CSPRNG, or a compressor - and 2.4(7) killed the compressor. **INFERRED, and I
think firmly: TG4 is a modern keyed cipher.**

### 2.6 The real problem is not the family. It is how little of the family was swept.

This is the finding I would act on. "163.94e6 candidates, no solve" sounds like
the modern hypothesis is dying. Decomposed, it is barely tested.

**EVIDENCED, from `crates/ra-prim/src/prim.rs` and `keyderiv.rs`:**

- **Primitives.** The engine implements 11 of libmcrypt's 19. Absent:
  `cast-128`, `cast-256`, `enigma`, `gost`, `rijndael-128`, `rijndael-192`,
  `tripledes`, `wake`. **`rijndael-128` is AES.** The sweep contains
  Rijndael-*256* (a 256-bit *block*, which is not AES and which almost no web
  tool exposes) and does not contain AES, the default algorithm on essentially
  every encryption web form - including tools4noobs' own successor site, whose
  recorded form default is `aes-128` (`docs/toolsites/tools4noobs.json`).
- **Key derivation.** 4 policies, all raw-byte: `natural`, `null-pad-max`,
  `null-pad-next-supported`, `repeat-pad-max`. There is no hash-derived key.
  A large fraction of browser and PHP crypto front ends do `key = md5(pass)`,
  `sha256(pass)`, or OpenSSL's `EVP_BytesToKey`, and several pass the *hex
  string* of the digest as the key.
- **Modes** 7, **IVs** 2, **keys** 6.

So the swept region is roughly (11/19 of the mcrypt menu, and the wrong 11 for a
casual user) x (one of at least five plausible key-derivation families). The
honest reading of the 163.94e6 negative is **"tools4noobs-style mcrypt with
raw-byte keys is empty"**, not "modern is empty".

---

## Part 3. What I actually ran this session

Both are SEARCHED AND EMPTY, not proofs.

**Sweep A - the missing primitive family, printable oracle.** 48,948 candidates.
AES-128/192/256, DES, 3DES-2key/3key, Blowfish, CAST-128, RC2, RC4 x
{ECB, CBC, CFB-8, CFB-full, OFB, CTR} x IV {zero, ASCII-'0'} x 18 keys x ~50 key
derivations (raw, null-pad, repeat-pad, MD5/SHA1/SHA256 digest and hex-digest in
both cases, EVP_BytesToKey) x both transcriptions. Oracle: printable ratio,
block-aware (whole output and the tail past one block). **0 hits at >= 0.90.**

**Sweep B - the same space, with structural intermediate oracles.** 274,400
candidates, adding a `reverse` transform and an all-`0xFF` IV. This is the
important one. Under the tools4noobs model the decrypt box base64-decodes its
input, so **a layer-1 output that feeds a further layer must be pure text in one
of base64, hex, decimal or octal**. Scoring layer-1 output for charset purity
therefore tests every deeper chain at once. Chance purities are 0.258 / 0.090 /
0.043 / 0.035. Measured best over the whole sweep:

| oracle | best purity observed | chance |
|---|---|---|
| base64 | 0.4191 | 0.258 |
| hex | 0.2222 | 0.090 |
| decimal | 0.1544 | 0.043 |
| octal | 0.1471 | 0.035 |
| printable | 0.5694 | 0.371 |

**0 candidates reached 0.95 in any charset.** Nothing is even close to a
structural signal.

**Sweep validation (canaries).** A clean negative from a broken sweep is worth
nothing, so I planted three solutions and re-ran the harness against them:

| plant | recovered? |
|---|---|
| single layer, AES/CFB-8, key = `md5("THEGIANT")`, IV ASCII-'0' | yes, printable 1.000 |
| **two layers**, inner 48-char riddle -> 3-digit decimal -> Blowfish/CFB-8, key `The Giant` null-padded to 16 | yes, decimal purity 1.000 - **caught at layer 1 by the structural oracle**, exactly as the method claims |
| single layer, RC4, key = `sha256("Zombie")` hex string | yes, printable 1.000 |

The two-layer canary is the important one: it confirms that scoring layer-1
output for charset purity does detect a chain whose real plaintext is two layers
down, without ever enumerating layer 2.

Caveat: pycryptodome's RC2 uses the RFC 2268 effective-key-bits reduction;
libmcrypt strips it and always behaves as 1024 bits (`crates/ra-prim/src/rc2.rs`).
My RC2 results do **not** transfer to mcrypt RC2. The engine's do.

A hypothesis of mine that the measurement killed: I expected 144 mod 32 = 16 to
eliminate Rijndael-256 in ECB/CBC by block alignment. It does not.
`crates/ra-prim/src/mode.rs` documents that `mdecrypt_generic` leaves a trailing
partial block untouched, and rev1's own confirmed Rijndael-256/ECB layer runs on
48 bytes, which is also 16 short of a multiple of 32. The alignment argument does
not apply to libmcrypt. Retracted.

---

## Part 4. Position, and where to spend the next large sweep

**Stay in the modern family. Leave the mcrypt *implementation*.** The
measurements on the artefact are decisive about the payload class and the base
rate cannot overturn them; but the sweep that exhausted 163.94e6 candidates
covered the wrong 11 primitives and one key-derivation family out of at least
five.

Ranked, with sizes.

**1. Stop enlarging T3. Almost all of it was already implied by T1.**
This is a correction to my own first recommendation, forced by a measurement.
T3 per variant factorises as 3696 (layer 1) x 2 (xf) x 6 (codec) x 3696 (layer 2)
= 163,924,992. Under the tools4noobs model an intermediate must be *text* in one
of base64 / hex / decimal / octal - and every one of those is **100% printable**.
The engine's oracle is `printable-0.75`. So any layer-1 output that could feed a
codec branch would already have registered as a T1 hit.

`claims/tg4-t1t2-all-variants.json`: 1,419,264 candidates over all 128
transcription variants, **0 hits**. Therefore:

- T3's five non-identity codec branches, **136,604,160 candidates**, were already
  eliminated by 11,088 layer-1 tests per variant. Redundancy factor **12,320x**.
- T3's genuine marginal contribution is only the `identity`-codec branch,
  27,320,832 per variant - and `identity` means layer 1's raw bytes are fed
  straight into layer 2 with no re-encoding, which is precisely what the
  tools4noobs decrypt box does *not* do (it base64-decodes its input at every
  hop; `crates/ra-cli/src/sweep.rs`, `README.md`).

So the 163.94e6 headline is ~83% arithmetic restatement of a 1.42e6 result, and
the remaining 17% models a composition the tool fingerprint argues against. This
does not make the sweep wrong; it makes it a much weaker negative than its size
suggests. **The next large sweep must widen the primitive and key-derivation
axes, not the layer count.**

**2. The structural oracle is the right instrument, just aim it at new
primitives.** Length arithmetic on a 144-byte layer-1 output read as codec text:

| codec | layer-2 byte count |
|---|---|
| base64 | 108 |
| hex | 72 |
| **decimal or octal, 3-digit fixed width** | **48** |

The Giant's four solved plaintexts are 49, 51, 58 and 57 characters. **48 is the
only predicted length in that band**, and fixed-width zero-padded 3-digit decimal
is a *confirmed* rendering in this corpus - rev6's ciphertext is 256 three-digit
tokens, 198 with a leading zero (paper 8, item 2), and rev6/rev9/rev10 pass
through it. For the six swept keys and eleven swept primitives this is already
dead (item 1). Its value is as the **acceptance test for every new primitive and
key derivation**: run layer 1 only, score charset purity, and one pass eliminates
all depths. Cost per new primitive, all 128 variants, 18 keys:
7 modes x 2 IVs x 4 key derivations x 18 x 128 = **129,024** - and it eliminates
that primitive at every chain depth, not just depth 1.

**3. The five mcrypt primitives nobody has swept.**
`cast-256`, `gost`, `enigma`, `wake`, `rijndael-192`. At layer 1 with 18 keys:
5 x 7 x 2 x 4 x 18 = **5,040 per variant**. Note **`enigma`** specifically:
libmcrypt's `enigma` is the Unix `crypt(1)` one-rotor stream cipher. The author
had just built an Enigma puzzle for tg5 on this same map. An algorithm dropdown
containing an entry literally labelled `enigma` is exactly the kind of thing that
gets clicked, it is length-preserving so it fits 144 bytes at any depth, and it
is weak enough to attack without the key. **SPECULATION**, but cheap and specific.

**4. AES and 3DES *inside the engine*, with mcrypt key derivation.**
I swept these with library key handling and found nothing, but `rijndael-128` and
`tripledes` under libmcrypt's own zero-padding are different byte-for-byte and
are the two most likely picks in the whole menu. Implementing them is item 4 of
paper 8 s.15 already; this raises its priority above everything except item 1.

**5. Hash-derived keys as a fifth key-derivation family.**
`md5(k)`, `sha1(k)`, `sha256(k)` as raw digest and as lowercase/uppercase hex
string, plus `EVP_BytesToKey`. Multiplies the key-derivation axis from 4 to ~9.
Tested for 6 primitives this session; untested for the engine's 11.

**6. Ask the owner one question, at zero compute cost.**
*Is there anything else on the TG4 sheet besides the `TheGiant` label and the four
rows - a number, a date, a stamp, a second word?* The author demonstrably uses
numeric keys (de7 `198346572`; gk11 `654371979` and `10271978`, which read as
dates). A number on that sheet would have exactly the same evidential standing as
the label does, and it is the only remaining route to a *new* key that is evidence
rather than guesswork.

**What I would not do.** Do not spend the next large sweep widening the key list.
The key axis is the best-evidenced axis in the problem and the cheapest to
extend; the primitive and key-derivation axes are where the coverage actually is
not.
