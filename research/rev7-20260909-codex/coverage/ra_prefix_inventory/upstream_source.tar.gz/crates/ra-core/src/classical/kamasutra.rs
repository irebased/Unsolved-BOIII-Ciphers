//! Kamasutra (Vatsyayana) cipher, matching geocachingtoolbox.com's implementation.
//!
//! The site's key is entered as 26 single-character `<input>` fields with ids
//! `"0"`..`"25"`, each holding one letter of a permutation of a-z. The first 13
//! (`upperRow`, ids 0-12) and last 13 (`lowerRow`, ids 13-25) pair up
//! positionally: `upperRow[i]` substitutes for `lowerRow[i]` and vice versa. We
//! model that as a single 26-character `key` parameter — the concatenation of
//! `id0`..`id25` in order — rather than 26 separate parameters, since it is
//! exactly the same information and much easier for a chain to carry.
//!
//! Substitution is per character: an alphabetic byte found in one half is
//! replaced by the letter at the same position in the other half, with the
//! *output's* case following the *input's* case (lowercase in, lowercase out;
//! uppercase in, uppercase out) — the site does this by comparing the raw
//! character against its own lowercased form. Non-alphabetic bytes, and (were
//! the key incomplete) any letter missing from the key, pass through unchanged.
//!
//! # Self-inverse
//!
//! Because the substitution is a fixed-point-free involution on the alphabet
//! (each pair maps both ways), encrypting and decrypting are the *same*
//! operation — there is no separate "encode" to test against; the site's
//! `kamasutraCipher()` function is used unmodified for the decrypt direction,
//! and the test suite instead proves the involution property (`f(f(x)) == x`)
//! plus fixed hand-checked vectors.
//!
//! # `key` is authoritative for non-letter symbols
//!
//! `parse_key` and `substitute` used to hardcode `is_ascii_alphabetic`, even
//! though the pairing scheme itself (`upperRow[i]` swaps with `lowerRow[i]`)
//! has no actual dependency on the 26 symbols being letters — the site's own
//! 26 single-character fields just happen to be typically filled with a
//! permutation of a-z. Both now test `is_ascii_graphic` (any printable,
//! non-whitespace ASCII byte) instead, which is a strict superset of
//! `is_ascii_alphabetic`, so the letters-only default is unaffected. The
//! duplicate-letter check, which previously indexed a 26-slot array by
//! `letter - b'a'` (only well-defined for a-z), is now a `HashSet` so it works
//! for any byte. See `alphanumeric_key_round_trips` below: ten digits paired
//! with sixteen punctuation symbols is a working, self-inverse key.
//!
//! # Artifacts
//!
//! The result is written into `kamasutraCipherText` via `.value =`
//! (`copy_artifact_risk: LOW`), so the default [`OutputFmt`] has no trailing
//! terminator. The site applies no case-forcing or whitespace-stripping to the
//! input text itself (only to the 26 key characters, which we validate
//! separately), so [`InputNorm`] defaults to identity.

use crate::classical::toolfmt::{read_input_norm, read_output_fmt, InputNorm, OutputFmt};
use crate::error::{Error, Result};
use crate::node::{Family, Node, ParamSpec, ParamType};
use crate::params::Params;
use crate::repr::Repr;
use crate::{artifact_param_specs, register_node};

const KAMASUTRA_SCHEMA: &[ParamSpec] = &artifact_param_specs!(ParamSpec::req(
    "key",
    ParamType::Str,
    "26 distinct printable, non-whitespace ASCII symbols: id0..id25 concatenated \
     in order, where key[i] (i<13) pairs with key[13+i] for substitution \
     (typically a permutation of a-z, matching the site's own 26 single-letter \
     fields, but the pairing scheme itself has no dependency on the symbols \
     being letters)",
));

/// Parse and validate the 26-character key into (upperRow, lowerRow), each an
/// array of 13 lowercase-folded bytes. Errors unless `key` is exactly 26
/// distinct printable, non-whitespace ASCII bytes — the site itself refuses to
/// run ("Character pairs are incomplete") unless all 26 fields are filled with
/// distinct letters; `is_ascii_graphic` generalises "distinct letters" to
/// "distinct symbols" without changing the letters-only default case, since
/// every ASCII letter is also `is_ascii_graphic`.
fn parse_key(node: &str, key: &str) -> Result<([u8; 13], [u8; 13])> {
    let bytes = key.as_bytes();
    if bytes.len() != 26 || !bytes.is_ascii() {
        return Err(Error::bad_param(
            node,
            "key",
            format!("must be exactly 26 ASCII symbols, got {key:?}"),
        ));
    }
    let mut lower = [0u8; 26];
    for (i, &b) in bytes.iter().enumerate() {
        if !b.is_ascii_graphic() {
            return Err(Error::bad_param(
                node,
                "key",
                format!("byte {i} ({}) is not a printable, non-whitespace symbol", b as char),
            ));
        }
        // A no-op for anything but a letter, so a non-letter alphabet's
        // symbols pass through unchanged; only two letters that differ solely
        // by case collide here, same as the site's own letters-only key.
        lower[i] = b.to_ascii_lowercase();
    }
    let mut seen = std::collections::HashSet::with_capacity(26);
    for &b in &lower {
        if !seen.insert(b) {
            return Err(Error::bad_param(
                node,
                "key",
                format!("key must be a permutation of 26 distinct symbols; '{}' repeats", b as char),
            ));
        }
    }
    let mut upper_row = [0u8; 13];
    let mut lower_row = [0u8; 13];
    upper_row.copy_from_slice(&lower[0..13]);
    lower_row.copy_from_slice(&lower[13..26]);
    Ok((upper_row, lower_row))
}

/// Apply the substitution to `data`, given the parsed key halves. Self-inverse:
/// calling this twice with the same key returns the original bytes.
fn substitute(data: &[u8], upper_row: &[u8; 13], lower_row: &[u8; 13]) -> Vec<u8> {
    data.iter()
        .map(|&b| {
            if !b.is_ascii_graphic() {
                return b;
            }
            let lower_b = b.to_ascii_lowercase();
            let is_lower = lower_b == b;
            if let Some(i) = upper_row.iter().position(|&c| c == lower_b) {
                let sub = lower_row[i];
                if is_lower {
                    sub
                } else {
                    sub.to_ascii_uppercase()
                }
            } else if let Some(i) = lower_row.iter().position(|&c| c == lower_b) {
                let sub = upper_row[i];
                if is_lower {
                    sub
                } else {
                    sub.to_ascii_uppercase()
                }
            } else {
                b
            }
        })
        .collect()
}

fn default_input_norm() -> InputNorm {
    InputNorm::default()
}

fn default_output_fmt() -> OutputFmt {
    OutputFmt::default()
}

/// Kamasutra (Vatsyayana) substitution cipher. Self-inverse, so this same node
/// serves both directions.
pub struct Kamasutra;

impl Node for Kamasutra {
    fn name(&self) -> &'static str {
        "kamasutra"
    }
    fn version(&self) -> &'static str {
        "1.0.0"
    }
    fn family(&self) -> Family {
        Family::Xf
    }
    fn params_schema(&self) -> &'static [ParamSpec] {
        KAMASUTRA_SCHEMA
    }

    fn apply(&self, input: &Repr, params: &Params) -> Result<Repr> {
        let key = params.req_str("kamasutra", "key")?;
        let (upper_row, lower_row) = parse_key("kamasutra", key)?;

        let in_norm = read_input_norm("kamasutra", params, default_input_norm())?;
        let out_fmt = read_output_fmt("kamasutra", params, default_output_fmt())?;

        let normalised = in_norm.apply(&input.data);
        let transformed = substitute(&normalised, &upper_row, &lower_row);
        let formatted = out_fmt.apply(&transformed);

        Ok(Repr::new(formatted, input.display))
    }
}

register_node!(KAMASUTRA => || Box::new(Kamasutra));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params;
    use crate::registry::registry;
    use crate::repr::Display;

    /// A fixed, hand-checked key: upperRow = "abcdefghijklm", lowerRow =
    /// "nopqrstuvwxyz" (identity split, i.e. a<->n, b<->o, ..., m<->z) — this is
    /// the simplest possible valid permutation and lets substitutions be
    /// checked by hand (a<->n, b<->o, e<->r, etc., the classic ROT13-like
    /// halves-swap, since it happens to coincide with ROT13 when the split is
    /// exactly this one).
    const SIMPLE_KEY: &str = "abcdefghijklmnopqrstuvwxyz";

    #[test]
    fn parse_key_accepts_valid_permutation() {
        let (u, l) = parse_key("kamasutra", SIMPLE_KEY).unwrap();
        assert_eq!(&u, b"abcdefghijklm");
        assert_eq!(&l, b"nopqrstuvwxyz");
    }

    #[test]
    fn parse_key_rejects_wrong_length() {
        let err = parse_key("kamasutra", "abc").unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn parse_key_rejects_repeated_letter() {
        // 'b' replaced with 'a': still 26 letters, but 'a' now appears twice
        // and 'b' is missing.
        let key = "aacdefghijklmnopqrstuvwxyz";
        assert_eq!(key.len(), 26);
        let err = parse_key("kamasutra", key).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    /// A digit is a printable symbol now (see `alphanumeric_key_round_trips`
    /// below), so it no longer makes a key invalid on its own -- what still
    /// makes a key invalid is a genuinely non-printable byte, like a space,
    /// which `is_ascii_graphic` still excludes.
    #[test]
    fn parse_key_rejects_non_printable_symbol() {
        let key = "abcdefghijklmnopqrstuvwxy ";
        let err = parse_key("kamasutra", key).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    /// The declared `key` is authoritative for a non-letter alphabet: ten
    /// digits paired with sixteen punctuation symbols is a coherent
    /// 26-symbol permutation, and substitution over it round trips exactly
    /// like the letters-only default -- proving the pairing scheme was never
    /// actually about letters.
    #[test]
    fn alphanumeric_key_round_trips() {
        let key = "0123456789!@#$%^&*()-_=+[]";
        assert_eq!(key.len(), 26);
        let (u, l) = parse_key("kamasutra", key).unwrap();
        let coded = substitute(b"0!5^", &u, &l);
        // every substituted byte should be a *different* symbol than its
        // input, not the input silently passed through unrecognised
        assert_ne!(coded, b"0!5^".to_vec());
        assert_eq!(substitute(&coded, &u, &l), b"0!5^");
    }

    #[test]
    fn parse_key_is_case_insensitive() {
        let (u, l) = parse_key("kamasutra", "ABCDEFGHIJKLMnopqrstuvwxyz").unwrap();
        assert_eq!(&u, b"abcdefghijklm");
        assert_eq!(&l, b"nopqrstuvwxyz");
    }

    #[test]
    fn substitute_simple_key_matches_rot13_on_letters() {
        let (u, l) = parse_key("kamasutra", SIMPLE_KEY).unwrap();
        // With this exact split, the substitution coincides with ROT13.
        assert_eq!(substitute(b"hello", &u, &l), b"uryyb");
        assert_eq!(substitute(b"Hello World", &u, &l), b"Uryyb Jbeyq");
    }

    #[test]
    fn substitute_preserves_case_per_character() {
        let (u, l) = parse_key("kamasutra", SIMPLE_KEY).unwrap();
        assert_eq!(substitute(b"aA", &u, &l), b"nN");
        assert_eq!(substitute(b"nN", &u, &l), b"aA");
    }

    #[test]
    fn substitute_passes_non_alphabetic_bytes_through() {
        let (u, l) = parse_key("kamasutra", SIMPLE_KEY).unwrap();
        assert_eq!(substitute(b"a, b! 123", &u, &l), b"n, o! 123");
    }

    #[test]
    fn substitute_is_self_inverse_for_any_valid_key() {
        let keys = [
            SIMPLE_KEY.to_string(),
            "zyxwvutsrqponmlkjihgfedcba".to_string(),
            "qwertyuiopasdfghjklzxcvbnm".to_string(),
        ];
        let samples: &[&[u8]] = &[b"", b"hello world", b"The Quick Brown FOX 123!", b"zzz AAA"];
        for key in &keys {
            let (u, l) = parse_key("kamasutra", key).unwrap();
            for sample in samples {
                let once = substitute(sample, &u, &l);
                let twice = substitute(&once, &u, &l);
                assert_eq!(&twice, sample, "key={key:?} sample={sample:?}");
            }
        }
    }

    #[test]
    fn kamasutra_node_decodes_with_simple_key() {
        let n = registry().get("kamasutra").unwrap();
        let p = params! {"key" => SIMPLE_KEY};
        let out = n.apply(&Repr::bytes(b"uryyb".to_vec()), &p).unwrap();
        assert_eq!(out.data, b"hello");
    }

    #[test]
    fn kamasutra_node_missing_key_errors() {
        let n = registry().get("kamasutra").unwrap();
        let p = params! {};
        let err = n.apply(&Repr::bytes(b"uryyb".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::MissingParam { .. }), "{err}");
    }

    #[test]
    fn kamasutra_node_invalid_key_errors() {
        let n = registry().get("kamasutra").unwrap();
        let p = params! {"key" => "tooshort"};
        let err = n.apply(&Repr::bytes(b"uryyb".to_vec()), &p).unwrap_err();
        assert!(matches!(err, Error::BadParam { .. }), "{err}");
    }

    #[test]
    fn kamasutra_default_output_has_no_trailing_terminator() {
        // .value = write (LOW copy_artifact_risk), so the default must not
        // append a trailing CRLF the way an innerHTML-backed tool would.
        let n = registry().get("kamasutra").unwrap();
        let p = params! {"key" => SIMPLE_KEY};
        let out = n.apply(&Repr::bytes(b"hello".to_vec()), &p).unwrap();
        assert!(!out.data.ends_with(b"\n") && !out.data.ends_with(b"\r\n"));
    }

    #[test]
    fn kamasutra_preserves_display() {
        let n = registry().get("kamasutra").unwrap();
        let p = params! {"key" => SIMPLE_KEY};
        let out = n
            .apply(&Repr::new(b"uryyb".to_vec(), Display::Hex), &p)
            .unwrap();
        assert_eq!(out.display, Display::Hex);
    }

    #[test]
    fn kamasutra_is_xf_family_and_not_layer_forming() {
        let n = registry().get("kamasutra").unwrap();
        assert_eq!(n.family(), Family::Xf);
        assert!(!n.layer_forming());
        assert!(!n.terminal());
    }
}
