//! End-to-end tests against a real `ra serve` process: the actual binary, bound
//! to a real loopback socket, driven over real HTTP. No mocking of the server or
//! the engine — this is what an actual browser client would see.

use std::io::{Read, Write};
use std::net::TcpStream;
use std::path::PathBuf;
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};

struct Server {
    child: Child,
    port: u16,
}

impl Drop for Server {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}

fn data_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../data")
}

fn free_port() -> u16 {
    // Ask the OS for an ephemeral port, then release it immediately. There is a
    // small race window before `ra serve` binds it, acceptable for a test.
    let l = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
    l.local_addr().unwrap().port()
}

fn start_server() -> Server {
    let port = free_port();
    let mut child = Command::new(env!("CARGO_BIN_EXE_ra"))
        .args([
            "--data",
            data_dir().to_str().unwrap(),
            "serve",
            "--port",
            &port.to_string(),
        ])
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("failed to start `ra serve`");

    // Wait for the listen line rather than a fixed sleep.
    let mut out = child.stdout.take().unwrap();
    let deadline = Instant::now() + Duration::from_secs(10);
    let mut buf = Vec::new();
    let mut byte = [0u8; 1];
    loop {
        if Instant::now() > deadline {
            panic!("server did not start listening in time");
        }
        match out.read(&mut byte) {
            Ok(0) => panic!("server exited before listening"),
            Ok(_) => {
                buf.push(byte[0]);
                if byte[0] == b'\n' {
                    let line = String::from_utf8_lossy(&buf);
                    if line.contains("listening") {
                        break;
                    }
                    buf.clear();
                }
            }
            Err(e) => panic!("reading server stdout: {e}"),
        }
    }
    // Give the OS a moment to make the listener acceptable even after the print.
    for _ in 0..50 {
        if TcpStream::connect(("127.0.0.1", port)).is_ok() {
            break;
        }
        std::thread::sleep(Duration::from_millis(20));
    }
    Server { child, port }
}

/// Send a raw HTTP/1.1 request and return `(status, body)`. Always sends
/// `Connection: close` so reading to EOF is a valid way to collect the whole body.
fn request(port: u16, method: &str, path: &str, body: Option<&str>) -> (u16, String) {
    let mut stream = TcpStream::connect(("127.0.0.1", port)).expect("connect");
    stream
        .set_read_timeout(Some(Duration::from_secs(10)))
        .unwrap();
    let payload = body.unwrap_or("");
    let req = format!(
        "{method} {path} HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\nContent-Type: application/json\r\nContent-Length: {}\r\n\r\n{payload}",
        payload.len()
    );
    stream.write_all(req.as_bytes()).unwrap();
    let mut raw = Vec::new();
    stream.read_to_end(&mut raw).unwrap();
    let raw = String::from_utf8_lossy(&raw).to_string();
    let mut parts = raw.splitn(2, "\r\n\r\n");
    let head = parts.next().unwrap_or("");
    let body = parts.next().unwrap_or("").to_string();
    let status: u16 = head
        .lines()
        .next()
        .and_then(|l| l.split_whitespace().nth(1))
        .and_then(|s| s.parse().ok())
        .unwrap_or(0);
    (status, body)
}

fn poll_run_until_terminal(port: u16, run_id: &str) -> serde_json::Value {
    let deadline = Instant::now() + Duration::from_secs(30);
    loop {
        let (status, body) = request(port, "GET", &format!("/api/runs/{run_id}"), None);
        assert_eq!(status, 200, "GET /api/runs/{run_id}: {body}");
        let v: serde_json::Value = serde_json::from_str(&body).unwrap();
        if v["state"] != "running" {
            return v;
        }
        if Instant::now() > deadline {
            panic!("run {run_id} did not terminate in time: {v}");
        }
        std::thread::sleep(Duration::from_millis(20));
    }
}

#[test]
fn binds_loopback_only_not_all_interfaces() {
    let server = start_server();
    // The documented, load-bearing property: reachable on loopback...
    assert!(TcpStream::connect(("127.0.0.1", server.port)).is_ok());
    // ...and NOT reachable via a socket bound to every interface, which is what
    // `ra serve` binding 0.0.0.0 would additionally satisfy. There is no direct
    // negative check for "not listening on 0.0.0.0" other than binding to the
    // same port ourselves and observing it is free elsewhere, but the strongest
    // black-box check available here is that a *second* listener can still bind
    // 0.0.0.0 on a different port without an "address in use" collision against
    // ra serve's listener, which would only happen if ra serve had grabbed the
    // wildcard address. This is best-effort; see the source-level assertion
    // (`web::run` hardcodes `127.0.0.1:{port}`) as the primary evidence.
    let probe_port = free_port();
    assert!(
        std::net::TcpListener::bind(("0.0.0.0", probe_port)).is_ok(),
        "0.0.0.0 bind space is unaffected by ra serve, as expected"
    );
}

#[test]
fn nodes_targets_and_plan_endpoints() {
    let server = start_server();
    let port = server.port;

    let (status, body) = request(port, "GET", "/api/nodes", None);
    assert_eq!(status, 200);
    let v: serde_json::Value = serde_json::from_str(&body).unwrap();
    let names: Vec<&str> = v["nodes"]
        .as_array()
        .unwrap()
        .iter()
        .map(|n| n["name"].as_str().unwrap())
        .collect();
    assert!(names.contains(&"beaufort"), "{names:?}");
    assert!(names.contains(&"b64decode"), "{names:?}");
    assert!(names.contains(&"des"), "{names:?}");

    let (status, body) = request(port, "GET", "/api/targets", None);
    assert_eq!(status, 200);
    let v: serde_json::Value = serde_json::from_str(&body).unwrap();
    let tg4 = v["targets"]
        .as_array()
        .unwrap()
        .iter()
        .find(|t| t["id"] == "tg4")
        .expect("tg4 present");
    assert_eq!(tg4["ciphertext_len"], 192);
    assert_eq!(tg4["map"], "The Giant");
    assert_eq!(tg4["solved"], false);

    // unknown node -> 400 with a useful message
    let (status, body) = request(
        port,
        "POST",
        "/api/plan",
        Some(r#"{"target":"tg4","steps":[{"node":"no_such_node","params":{}}]}"#),
    );
    assert_eq!(status, 400, "{body}");
    let v: serde_json::Value = serde_json::from_str(&body).unwrap();
    assert_eq!(v["ok"], false);
    assert!(v["error"].as_str().unwrap().contains("unknown node"));

    // unknown param -> 400
    let (status, body) = request(
        port,
        "POST",
        "/api/plan",
        Some(r#"{"target":"tg4","steps":[{"node":"b64decode","params":{"bogus":[1]}}]}"#),
    );
    assert_eq!(status, 400, "{body}");
    let v: serde_json::Value = serde_json::from_str(&body).unwrap();
    assert!(v["error"].as_str().unwrap().contains("unknown param"));

    // bad value type -> 400
    let (status, body) = request(
        port,
        "POST",
        "/api/plan",
        Some(r#"{"target":"tg4","steps":[{"node":"rot","params":{"n":["not-an-int"]}}]}"#),
    );
    assert_eq!(status, 400, "{body}");
}

/// The single most important test: `/api/plan`'s `total_ops` must equal the
/// number of candidates a real run actually evaluates, because that same
/// `engine::Plan` is what both the counter and the executor walk.
#[test]
fn plan_total_ops_matches_a_real_runs_evaluated_candidates() {
    let server = start_server();
    let port = server.port;

    let body = r#"{"target":"tg4","steps":[
        {"node":"beaufort","params":{"key":["TheGiant"],"alphabet":["ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"]}},
        {"node":"b64decode","params":{}},
        {"node":"des","params":{"key":["Zombies"],"mode":["cfb","ecb"]}}
    ]}"#;

    let (status, plan_body) = request(port, "POST", "/api/plan", Some(body));
    assert_eq!(status, 200, "{plan_body}");
    let plan: serde_json::Value = serde_json::from_str(&plan_body).unwrap();
    assert_eq!(plan["ok"], true);
    let planned_total = plan["total_ops"].as_u64().unwrap();
    assert_eq!(planned_total, 4, "2 alphabets x 1 b64decode x 2 modes");

    let axes = plan["axes"].as_array().unwrap();
    assert!(axes.iter().any(|a| a["param"] == "alphabet" && a["values"] == 2));
    assert!(axes.iter().any(|a| a["param"] == "mode" && a["values"] == 2));

    let (status, run_body) = request(port, "POST", "/api/runs", Some(body));
    assert_eq!(status, 200, "{run_body}");
    let run: serde_json::Value = serde_json::from_str(&run_body).unwrap();
    let run_id = run["run_id"].as_str().unwrap().to_string();

    let final_state = poll_run_until_terminal(port, &run_id);
    assert_eq!(final_state["state"], "done", "{final_state}");
    assert_eq!(final_state["total_ops"], planned_total);
    assert_eq!(
        final_state["done_ops"], planned_total,
        "a done run must have evaluated exactly its planned total: {final_state}"
    );

    // And /api/runs lists it consistently too.
    let (status, list_body) = request(port, "GET", "/api/runs", None);
    assert_eq!(status, 200);
    let list: serde_json::Value = serde_json::from_str(&list_body).unwrap();
    let entry = list["runs"]
        .as_array()
        .unwrap()
        .iter()
        .find(|r| r["run_id"] == run_id)
        .expect("run listed");
    assert_eq!(entry["total_ops"], planned_total);
    assert_eq!(entry["done_ops"], planned_total);
    assert_eq!(entry["state"], "done");
}

/// `GET /api/groups`: presets derived from the live registry rather than a
/// hardcoded list — every node reported must actually be in `/api/nodes`, every
/// `dec` node must land in `modern`, every `xf` node in `classical`, every
/// `codec` node in `codecs`, and nothing is duplicated across groups.
#[test]
fn groups_endpoint_reflects_the_registry_not_a_hardcoded_list() {
    let server = start_server();
    let port = server.port;

    let (status, nodes_body) = request(port, "GET", "/api/nodes", None);
    assert_eq!(status, 200);
    let nodes_v: serde_json::Value = serde_json::from_str(&nodes_body).unwrap();
    let by_name: std::collections::BTreeMap<String, String> = nodes_v["nodes"]
        .as_array()
        .unwrap()
        .iter()
        .map(|n| {
            (
                n["name"].as_str().unwrap().to_string(),
                n["family"].as_str().unwrap().to_string(),
            )
        })
        .collect();

    let (status, body) = request(port, "GET", "/api/groups", None);
    assert_eq!(status, 200, "{body}");
    let v: serde_json::Value = serde_json::from_str(&body).unwrap();
    let groups = v["groups"].as_array().unwrap();
    let expect_family = |id: &str| match id {
        "modern" => "dec",
        "classical" => "xf",
        "codecs" => "codec",
        other => panic!("unexpected group id {other}"),
    };
    let mut seen = std::collections::BTreeSet::new();
    for g in groups {
        let id = g["id"].as_str().unwrap();
        let want_family = expect_family(id);
        let names = g["nodes"].as_array().unwrap();
        assert!(!names.is_empty(), "group {id} unexpectedly empty");
        for n in names {
            let name = n.as_str().unwrap();
            assert_eq!(
                by_name.get(name).map(String::as_str),
                Some(want_family),
                "node {name} in group {id} should have family {want_family}"
            );
            assert!(seen.insert(name.to_string()), "node {name} duplicated across groups");
        }
    }
    // beaufort (xf) and des (dec) are always registered; sanity-check they land
    // in the group their family predicts, rather than a hand-maintained list.
    let classical = groups.iter().find(|g| g["id"] == "classical").unwrap();
    assert!(classical["nodes"]
        .as_array()
        .unwrap()
        .iter()
        .any(|n| n == "beaufort"));
    let modern = groups.iter().find(|g| g["id"] == "modern").unwrap();
    assert!(modern["nodes"].as_array().unwrap().iter().any(|n| n == "des"));
}

/// The multi-alternative, optional-slot form of the load-bearing property: a
/// slot's `total_ops` (summing alternatives, adding one skip branch for the
/// optional layer) must equal the number of candidates a real run actually
/// evaluates, via the exact contract-shaped request from the spec.
#[test]
fn plan_total_ops_matches_a_real_run_with_alternatives_and_an_optional_step() {
    let server = start_server();
    let port = server.port;

    let body = r#"{"target":"tg4","steps":[
        {"optional":false,"alternatives":[
            {"node":"beaufort","params":{"key":["TheGiant"],"alphabet":["ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"]}},
            {"node":"rot","params":{"n":[1,2,3]}}]},
        {"optional":true,"alternatives":[{"node":"reverse","params":{}}]},
        {"optional":false,"alternatives":[
            {"node":"des","params":{"key":["Zombies"],"mode":["cfb","ecb"]}},
            {"node":"blowfish","params":{"key":["Zombies"],"mode":["cfb"]}}]}
    ]}"#;

    // step 0: beaufort (2 alphabets) + rot (3 n) = cardinality 5
    // step 1: optional, reverse (1 combination) -> cardinality 1, radix 2
    // step 2: des (2 modes) + blowfish (1 mode) = cardinality 3
    // total_ops = 5 * 2 * 3 = 30
    let (status, plan_body) = request(port, "POST", "/api/plan", Some(body));
    assert_eq!(status, 200, "{plan_body}");
    let plan: serde_json::Value = serde_json::from_str(&plan_body).unwrap();
    assert_eq!(plan["ok"], true);
    let planned_total = plan["total_ops"].as_u64().unwrap();
    assert_eq!(planned_total, 30, "{plan_body}");

    let per_step = plan["per_step"].as_array().unwrap();
    assert_eq!(per_step.len(), 3);
    assert_eq!(per_step[0]["cardinality"], 5);
    assert_eq!(per_step[0]["optional"], false);
    let alts0: Vec<(String, u64)> = per_step[0]["alternatives"]
        .as_array()
        .unwrap()
        .iter()
        .map(|a| {
            (
                a["node"].as_str().unwrap().to_string(),
                a["combinations"].as_u64().unwrap(),
            )
        })
        .collect();
    assert!(alts0.contains(&("beaufort".to_string(), 2)));
    assert!(alts0.contains(&("rot".to_string(), 3)));

    assert_eq!(per_step[1]["optional"], true);
    assert_eq!(per_step[1]["cardinality"], 1);

    assert_eq!(per_step[2]["cardinality"], 3);

    let (status, run_body) = request(port, "POST", "/api/runs", Some(body));
    assert_eq!(status, 200, "{run_body}");
    let run: serde_json::Value = serde_json::from_str(&run_body).unwrap();
    let run_id = run["run_id"].as_str().unwrap().to_string();

    let final_state = poll_run_until_terminal(port, &run_id);
    assert_eq!(final_state["state"], "done", "{final_state}");
    assert_eq!(final_state["total_ops"], planned_total);
    assert_eq!(
        final_state["done_ops"], planned_total,
        "a done run over a multi-alternative, optional-slot plan must have \
         evaluated exactly its planned total: {final_state}"
    );
}

/// A `total_ops` above the warn threshold gets a `warn` field describing the
/// size in a rough-time-estimate sentence, without refusing to plan or run it.
#[test]
fn huge_plan_gets_a_warn_field_but_is_not_refused() {
    let server = start_server();
    let port = server.port;

    // 4000 * 4000 = 16,000,000 > 10,000,000.
    let ns: Vec<i64> = (0..4000).collect();
    let body = serde_json::json!({
        "target": "tg4",
        "steps": [
            {"node": "rot", "params": {"n": ns}},
            {"node": "rot", "params": {"n": ns}},
        ]
    })
    .to_string();

    let (status, plan_body) = request(port, "POST", "/api/plan", Some(&body));
    assert_eq!(status, 200, "{plan_body}");
    let plan: serde_json::Value = serde_json::from_str(&plan_body).unwrap();
    assert_eq!(plan["total_ops"], 16_000_000u64);
    let warn = plan["warn"].as_str().expect("warn field present");
    assert!(warn.contains("16.0e6"), "{warn}");
}

#[test]
fn stop_actually_halts_a_run_before_completion() {
    let server = start_server();
    let port = server.port;

    // A chain large enough that stopping shortly after launch reliably catches it
    // mid-flight: two independent 1000-value integer axes multiply to 1e6
    // candidates, each a trivial byte rotation, so the debug-build run takes long
    // enough to observe a partial `done_ops` before it would finish on its own.
    let ns: Vec<i64> = (0..1000).collect();
    let body = serde_json::json!({
        "target": "tg4",
        "steps": [
            {"node": "rot", "params": {"n": ns}},
            {"node": "reverse", "params": {}},
            {"node": "rot", "params": {"n": ns}},
        ]
    })
    .to_string();

    let (status, run_body) = request(port, "POST", "/api/runs", Some(&body));
    assert_eq!(status, 200, "{run_body}");
    let run: serde_json::Value = serde_json::from_str(&run_body).unwrap();
    let run_id = run["run_id"].as_str().unwrap().to_string();

    std::thread::sleep(Duration::from_millis(30));
    let (status, stop_body) = request(port, "POST", &format!("/api/runs/{run_id}/stop"), None);
    assert_eq!(status, 200, "{stop_body}");
    let stop: serde_json::Value = serde_json::from_str(&stop_body).unwrap();
    assert_eq!(stop["ok"], true);

    let final_state = poll_run_until_terminal(port, &run_id);
    assert_eq!(final_state["state"], "stopped", "{final_state}");
    let total = final_state["total_ops"].as_u64().unwrap();
    let done = final_state["done_ops"].as_u64().unwrap();
    assert!(
        done < total,
        "a stopped run must halt before evaluating every candidate: done={done} total={total}"
    );
}

#[test]
fn events_stream_reports_progress_and_terminates() {
    let server = start_server();
    let port = server.port;

    let ns: Vec<i64> = (0..2000).collect();
    let body = serde_json::json!({
        "target": "tg4",
        "steps": [{"node": "rot", "params": {"n": ns}}]
    })
    .to_string();
    let (status, run_body) = request(port, "POST", "/api/runs", Some(&body));
    assert_eq!(status, 200, "{run_body}");
    let run: serde_json::Value = serde_json::from_str(&run_body).unwrap();
    let run_id = run["run_id"].as_str().unwrap().to_string();

    let mut stream = TcpStream::connect(("127.0.0.1", port)).unwrap();
    stream
        .set_read_timeout(Some(Duration::from_secs(10)))
        .unwrap();
    let req = format!(
        "GET /api/runs/{run_id}/events HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n"
    );
    stream.write_all(req.as_bytes()).unwrap();

    let mut raw = Vec::new();
    let mut buf = [0u8; 4096];
    let deadline = Instant::now() + Duration::from_secs(20);
    loop {
        match stream.read(&mut buf) {
            Ok(0) => break, // server closed the connection: stream terminated
            Ok(n) => raw.extend_from_slice(&buf[..n]),
            Err(e)
                if e.kind() == std::io::ErrorKind::WouldBlock
                    || e.kind() == std::io::ErrorKind::TimedOut =>
            {
                break
            }
            Err(e) => panic!("reading SSE stream: {e}"),
        }
        if Instant::now() > deadline {
            break;
        }
    }
    let text = String::from_utf8_lossy(&raw);
    assert!(text.starts_with("HTTP/1.1 200"), "{text}");
    assert!(text.contains("text/event-stream"), "{text}");
    assert!(text.contains("data: {"), "{text}");
    assert!(text.contains("\"total_ops\":2000"), "{text}");

    // The run should reach a terminal state on its own; confirm via the JSON API
    // too (the byte-stream assertions above already showed at least one sample).
    let final_state = poll_run_until_terminal(port, &run_id);
    assert_ne!(final_state["state"], "running");
}
