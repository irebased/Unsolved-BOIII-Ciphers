use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};

use crate::error::{Error, Result};

/// A scalar parameter value.
///
/// Byte-valued parameters (an IV, for instance) are carried as lowercase hex in
/// [`Value::Str`] and read back with [`Params::req_hex`]. Keeping the value type
/// to three scalars means canonical JSON is unambiguous, which matters because
/// chain identity is a hash of it.
#[derive(Clone, PartialEq, Eq, PartialOrd, Ord, Debug, Serialize, Deserialize)]
#[serde(untagged)]
pub enum Value {
    Bool(bool),
    Int(i64),
    Str(String),
}

impl From<bool> for Value {
    fn from(v: bool) -> Self {
        Value::Bool(v)
    }
}
impl From<i64> for Value {
    fn from(v: i64) -> Self {
        Value::Int(v)
    }
}
impl From<usize> for Value {
    fn from(v: usize) -> Self {
        Value::Int(v as i64)
    }
}
impl From<&str> for Value {
    fn from(v: &str) -> Self {
        Value::Str(v.to_string())
    }
}
impl From<String> for Value {
    fn from(v: String) -> Self {
        Value::Str(v)
    }
}

/// An ordered parameter binding. `BTreeMap` so serialisation is canonical.
#[derive(Clone, Default, PartialEq, Eq, PartialOrd, Ord, Debug, Serialize, Deserialize)]
#[serde(transparent)]
pub struct Params(pub BTreeMap<String, Value>);

impl Params {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn set(mut self, key: &str, v: impl Into<Value>) -> Self {
        self.0.insert(key.to_string(), v.into());
        self
    }

    pub fn get(&self, key: &str) -> Option<&Value> {
        self.0.get(key)
    }

    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }

    /// Deterministic serialisation, used as an input to chain identity.
    pub fn canonical_json(&self) -> String {
        serde_json::to_string(self).unwrap_or_else(|_| "{}".into())
    }

    pub fn req_str(&self, node: &str, key: &str) -> Result<&str> {
        match self.0.get(key) {
            Some(Value::Str(s)) => Ok(s),
            Some(other) => Err(Error::bad_param(
                node,
                key,
                format!("expected a string, got {other:?}"),
            )),
            None => Err(Error::MissingParam {
                node: node.to_string(),
                param: key.to_string(),
            }),
        }
    }

    pub fn opt_str(&self, key: &str) -> Option<&str> {
        match self.0.get(key) {
            Some(Value::Str(s)) => Some(s),
            _ => None,
        }
    }

    pub fn req_i64(&self, node: &str, key: &str) -> Result<i64> {
        match self.0.get(key) {
            Some(Value::Int(i)) => Ok(*i),
            Some(other) => Err(Error::bad_param(
                node,
                key,
                format!("expected an integer, got {other:?}"),
            )),
            None => Err(Error::MissingParam {
                node: node.to_string(),
                param: key.to_string(),
            }),
        }
    }

    pub fn opt_i64(&self, key: &str, default: i64) -> i64 {
        match self.0.get(key) {
            Some(Value::Int(i)) => *i,
            _ => default,
        }
    }

    pub fn opt_bool(&self, key: &str, default: bool) -> bool {
        match self.0.get(key) {
            Some(Value::Bool(b)) => *b,
            _ => default,
        }
    }

    /// Read a hex-encoded byte parameter.
    pub fn req_hex(&self, node: &str, key: &str) -> Result<Vec<u8>> {
        let s = self.req_str(node, key)?;
        hex::decode(s).map_err(|e| Error::bad_param(node, key, format!("invalid hex: {e}")))
    }

    pub fn opt_hex(&self, node: &str, key: &str) -> Result<Option<Vec<u8>>> {
        match self.0.get(key) {
            None => Ok(None),
            Some(_) => self.req_hex(node, key).map(Some),
        }
    }
}

impl<K: Into<String>, V: Into<Value>> FromIterator<(K, V)> for Params {
    fn from_iter<I: IntoIterator<Item = (K, V)>>(iter: I) -> Self {
        Params(
            iter.into_iter()
                .map(|(k, v)| (k.into(), v.into()))
                .collect(),
        )
    }
}

/// Convenience constructor: `params!{"key" => "Zombies", "n" => 6i64}`.
#[macro_export]
macro_rules! params {
    () => { $crate::params::Params::new() };
    ($($k:expr => $v:expr),+ $(,)?) => {{
        let mut p = $crate::params::Params::new();
        $( p = p.set($k, $v); )+
        p
    }};
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn canonical_json_is_key_ordered() {
        let a = Params::new().set("zeta", 1i64).set("alpha", "x");
        let b = Params::new().set("alpha", "x").set("zeta", 1i64);
        assert_eq!(a.canonical_json(), b.canonical_json());
        assert_eq!(a.canonical_json(), r#"{"alpha":"x","zeta":1}"#);
    }

    #[test]
    fn hex_round_trip() {
        let p = Params::new().set("iv", "30303030");
        assert_eq!(p.req_hex("n", "iv").unwrap(), b"0000");
    }

    #[test]
    fn missing_and_mistyped_params_are_distinguished() {
        let p = Params::new().set("n", 6i64);
        assert!(matches!(
            p.req_str("rot", "n"),
            Err(Error::BadParam { .. })
        ));
        assert!(matches!(
            p.req_str("rot", "absent"),
            Err(Error::MissingParam { .. })
        ));
    }
}
