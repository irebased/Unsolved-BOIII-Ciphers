#!/usr/bin/env python3
"""TG3 reproduced end to end from the CIMT/MEP Simplified Lorenz Toolkit model.

The toolkit (https://www.cimt.org.uk/resources/codes/lorenz/index.htm, produced
by the Centre for Innovation in Mathematics Teaching with Bletchley Park
National Codes Centre, MEP "Codes and Ciphers" Unit 19) specifies:

  * a K wheel with 14 positions, numbered 1..14
  * an S wheel with  4 positions, numbered 1..4
  * "56 combinations (14 x 4)" of start positions
  * an alphabet of A-Z plus the teleprinter glyphs 3 4 8 9 + /
  * enciphering = teleprinter-add (XOR of the ITA2 five-bit codes) the K-wheel
    letter, then the S-wheel letter; both wheels step once per character

and gives the worked example:

    "If the K-wheel start-position is 7 i.e. letter 'G',
     K = GHIJKLMNABCDEFGHIJKLMNABCDEF..."

which pins the K wheel's cam pattern to the literal 14 letters A..N, read
cyclically from the 1-indexed start position.

TG3's record says "K-wheel = 9 and S-wheel = 4".  This script derives the S
wheel from the known plaintext under exactly that model and checks that it is
a consistent 4-letter pattern, i.e. that the record's two numbers reproduce
the published ciphertext.

Stdlib only.  Run: python3 papers/analysis/tg3_cimt.py
"""

# ITA2 five-bit codes in numeric order 0..31, in the Bletchley Park notation
# the toolkit uses.  Index 31 is LETTER SHIFT, which the toolkit writes '8'
# (the General Report on Tunny also writes it '-'); index 27 is FIGURE SHIFT,
# written '+' by both.
ITA2 = "/T3O9HNM4LRGIPCVEZDBSYFXAWJ+UQK8"
CODE = {c: i for i, c in enumerate(ITA2)}

CT = "NMFU3DNILVAXTPPH9AYHRXUM3PDBVMHN/CANVGPYS+3HGQKH"
PT = "".join(
    c for c in "When finished we will return to the house and the infinite".upper()
    if c.isalpha()
)

K_WHEEL = "ABCDEFGHIJKLMN"      # 14 cams, from the toolkit's worked example
K_START = 9                     # recorded "K-wheel = 9"  (1-indexed)
S_START = 4                     # recorded "S-wheel = 4"  (1-indexed)


def main():
    print("== model ==")
    print(f"  K wheel : {K_WHEEL}  ({len(K_WHEEL)} positions)")
    print(f"  recorded start positions : K={K_START}, S={S_START}")
    print(f"  key period = lcm(14, 4) = 28")
    print()

    ks = [CODE[c] ^ CODE[p] for c, p in zip(CT, PT)]
    kseq = [CODE[K_WHEEL[(K_START - 1 + i) % 14]] for i in range(len(ks))]
    resid = [a ^ b for a, b in zip(ks, kseq)]

    print("== residual after removing the K wheel ==")
    print("  keystream        :", "".join(ITA2[x] for x in ks))
    print("  K-wheel sequence :", "".join(ITA2[x] for x in kseq))
    print("  residual (= S)   :", "".join(ITA2[x] for x in resid))
    per4 = all(resid[i] == resid[i + 4] for i in range(len(resid) - 4))
    print(f"\n  residual is exactly 4-periodic : {per4}")
    if not per4:
        print("  -> the K wheel pattern or start position is wrong")
        return

    s_by_slot = {}
    for i, v in enumerate(resid):
        s_by_slot.setdefault((S_START - 1 + i) % 4, v)
    s_wheel = [s_by_slot[j] for j in range(4)]
    print(f"  recovered S wheel, positions 1..4 : "
          f"{''.join(ITA2[x] for x in s_wheel)}   {s_wheel}")
    print()

    print("== end-to-end reproduction ==")
    out = []
    for i, c in enumerate(CT):
        k = CODE[K_WHEEL[(K_START - 1 + i) % 14]]
        s = s_wheel[(S_START - 1 + i) % 4]
        out.append(ITA2[CODE[c] ^ k ^ s])
    got = "".join(out)
    print(f"  decrypted : {got}")
    print(f"  recorded  : {PT}")
    print(f"  match     : {got == PT}   ({sum(a == b for a, b in zip(got, PT))}"
          f"/{len(PT)} symbols)")
    print()
    print("  Note the cipher is an involution: the same two wheel settings")
    print("  encipher and decipher, which is what the toolkit states.")


if __name__ == "__main__":
    main()
