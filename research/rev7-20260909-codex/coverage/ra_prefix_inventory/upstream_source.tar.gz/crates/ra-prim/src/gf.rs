//! GF(2^8) arithmetic and the Rijndael S-box, derived from first principles.
//!
//! The tables are *computed* rather than transcribed. A mistyped byte in a 256-entry
//! literal table produces a cipher that is subtly wrong everywhere, which is the
//! exact failure mode Document 5 warns about: the sweep looks fine and covers a
//! space that is not the real one. Deriving them removes that class of defect.

use std::sync::OnceLock;

/// Multiply in GF(2^8) modulo the AES polynomial x^8 + x^4 + x^3 + x + 1 (0x11b).
pub fn gmul(mut a: u8, mut b: u8) -> u8 {
    let mut p = 0u8;
    for _ in 0..8 {
        if b & 1 != 0 {
            p ^= a;
        }
        let hi = a & 0x80;
        a <<= 1;
        if hi != 0 {
            a ^= 0x1b;
        }
        b >>= 1;
    }
    p
}

/// Multiplicative inverse in GF(2^8), with `inv(0) = 0` by convention.
fn ginv(a: u8) -> u8 {
    if a == 0 {
        return 0;
    }
    (1u16..256)
        .map(|c| c as u8)
        .find(|&c| gmul(a, c) == 1)
        .unwrap_or(0)
}

pub struct Boxes {
    pub sbox: [u8; 256],
    pub inv_sbox: [u8; 256],
}

fn build() -> Boxes {
    let mut sbox = [0u8; 256];
    for (i, slot) in sbox.iter_mut().enumerate() {
        let s = ginv(i as u8);
        // affine transform: b ^ rotl(b,1) ^ rotl(b,2) ^ rotl(b,3) ^ rotl(b,4) ^ 0x63
        let mut x = s;
        x ^= s.rotate_left(1);
        x ^= s.rotate_left(2);
        x ^= s.rotate_left(3);
        x ^= s.rotate_left(4);
        *slot = x ^ 0x63;
    }
    let mut inv_sbox = [0u8; 256];
    for i in 0..256usize {
        inv_sbox[sbox[i] as usize] = i as u8;
    }
    Boxes { sbox, inv_sbox }
}

pub fn boxes() -> &'static Boxes {
    static B: OnceLock<Boxes> = OnceLock::new();
    B.get_or_init(build)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Spot-check the derived S-box against the published FIPS-197 values.
    #[test]
    fn sbox_matches_fips197_spot_values() {
        let b = boxes();
        assert_eq!(b.sbox[0x00], 0x63);
        assert_eq!(b.sbox[0x01], 0x7c);
        assert_eq!(b.sbox[0x53], 0xed);
        assert_eq!(b.sbox[0x10], 0xca);
        assert_eq!(b.sbox[0xff], 0x16);
    }

    #[test]
    fn sbox_is_a_permutation_and_inverse_is_correct() {
        let b = boxes();
        let mut seen = [false; 256];
        for i in 0..256usize {
            assert!(!seen[b.sbox[i] as usize], "s-box is not injective");
            seen[b.sbox[i] as usize] = true;
            assert_eq!(b.inv_sbox[b.sbox[i] as usize], i as u8);
        }
    }

    #[test]
    fn gmul_known_values() {
        assert_eq!(gmul(0x57, 0x83), 0xc1); // FIPS-197 section 4.2 worked example
        assert_eq!(gmul(0x02, 0x80), 0x1b);
        assert_eq!(gmul(1, 0xab), 0xab);
        assert_eq!(gmul(0, 0xab), 0);
    }

    #[test]
    fn inverses_are_mutual() {
        for a in 1..=255u8 {
            assert_eq!(gmul(a, ginv(a)), 1, "inverse failed for {a:#04x}");
        }
    }
}
